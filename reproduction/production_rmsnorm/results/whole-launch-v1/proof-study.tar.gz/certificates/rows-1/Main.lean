import LarkReal.NativeRmsNorm
namespace LarkCertificate
open LarkNonlinear
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
def shape : LarkNativeRmsNorm.Shape := ⟨1, by decide, by decide⟩
def layout : Layout := ⟨[⟨.output, 16384⟩, ⟨.input, 16384⟩, ⟨.input, 16384⟩],
  [16, 1], []⟩
def geometry : Geometry := ⟨1, 1024, 64⟩
def fuel : Fuel := ⟨256, 8, 3, 1⟩
def program : List LarkCollective.Instr := [(.scalar (.index 0 .bid)), (.scalar (.index 1 .tid)), (.scalar (.index 2 (.mod (.ivar (1)) (.const (64))))), (.scalar (.index 3 (.div (.ivar (1)) (.const (64))))), (.scalar (.index 4 (.sub (.const (1024)) (.mul (.ivar (3)) (.const (64)))))), (.scalar (.assign 0 (.lit (0) 1))), (.scalar (.assign 1 (.lit (0) 1))), (.scalar (.index 5 (.ivar (1)))), (.scalar (.branch (.lt (.ivar (5)) (.const (2048))) 18)), (.scalar (.index 6 (.const (0)))), (.scalar (.branch (.lt (.ivar (6)) (.const (8))) 16)), (.scalar (.assign 2 (.un .fromHalf (.load .global 1 (.add (.add (.mul (.ivar (0)) (.const (16384))) (.mul (.ivar (5)) (.const (8)))) (.ivar (6))))))), (.scalar (.assign 3 (.bin .mul (.reg (2)) (.reg (2))))), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (3))))), (.scalar (.index 6 (.add (.ivar (6)) (.const (1))))), (.scalar (.jump 10)), (.scalar (.index 5 (.add (.ivar (5)) (.const (1024))))), (.scalar (.jump 8)), (.shuffle .down 1 0 (.const (1)) 64), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (1))) (.ivar (4))) 21)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (2)) 64), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (2))) (.ivar (4))) 24)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (4)) 64), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (4))) (.ivar (4))) 27)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (8)) 64), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (8))) (.ivar (4))) 30)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (16)) 64), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (16))) (.ivar (4))) 33)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (32)) 64), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (32))) (.ivar (4))) 36)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (2)) (.const (0))) 38)), (.scalar (.store .shared 0 (.ivar (3)) (.reg (0)))), (.scalar (.barrier .block)), (.scalar (.branch (.lt (.ivar (1)) (.const (16))) 55)), (.scalar (.assign 0 (.load .shared 0 (.ivar (2))))), (.shuffle .down 1 0 (.const (1)) 16), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (1))) (.const (16))) 44)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (2)) 16), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (2))) (.const (16))) 47)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (4)) 16), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (4))) (.const (16))) 50)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .down 1 0 (.const (8)) 16), (.scalar (.branch (.lt (.add (.ivar (2)) (.const (8))) (.const (16))) 53)), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (1)) (.const (0))) 55)), (.scalar (.store .shared 1 (.const (0)) (.un .rsqrt (.bin .add (.bin .div (.reg (0)) (.lit (16384) 1)) (.lit (1) 100000))))), (.scalar (.barrier .block)), (.scalar (.assign 4 (.load .shared 1 (.const (0))))), (.scalar (.index 7 (.ivar (1)))), (.scalar (.branch (.lt (.ivar (7)) (.const (2048))) 70)), (.scalar (.index 8 (.const (0)))), (.scalar (.branch (.lt (.ivar (8)) (.const (8))) 68)), (.scalar (.assign 5 (.un .fromHalf (.load .global 1 (.add (.add (.mul (.ivar (0)) (.const (16384))) (.mul (.ivar (7)) (.const (8)))) (.ivar (8))))))), (.scalar (.assign 6 (.un .fromHalf (.load .global 2 (.add (.mul (.ivar (7)) (.const (8))) (.ivar (8))))))), (.scalar (.assign 7 (.bin .mul (.reg (5)) (.reg (4))))), (.scalar (.assign 8 (.bin .mul (.reg (7)) (.reg (6))))), (.scalar (.store .global 0 (.add (.add (.mul (.ivar (0)) (.const (16384))) (.mul (.ivar (7)) (.const (8)))) (.ivar (8))) (.un .toHalf (.reg (8))))), (.scalar (.index 8 (.add (.ivar (8)) (.const (1))))), (.scalar (.jump 60)), (.scalar (.index 7 (.add (.ivar (7)) (.const (1024))))), (.scalar (.jump 58)), (.scalar .halt)]
-- The closed reference AST is checked before this fixed mathematical interpretation
-- is emitted. Half/float conversions are identities in the exact-real model.
noncomputable def reference (input : Nat → Nat → ℝ) (row col : Nat) : ℝ :=
  input 1 (row * 16384 + col) *
    (1 / Real.sqrt ((((List.range 16384).map fun j =>
      input 1 (row * 16384 + j) * input 1 (row * 16384 + j)).sum) / 16384 + 1 / 100000)) * input 2 col
noncomputable def spec (input : Nat → Nat → ℝ) : List ℝ :=
  (List.range (1 * 16384)).map fun i => reference input (i / 16384) (i % 16384)
theorem reference_data (input : Nat → Nat → ℝ) :
    spec input = LarkReal.NativeRmsNorm.canonical_spec shape input := by rfl
theorem layout_data : layout = LarkNativeRmsNorm.layout shape := by rfl
theorem geometry_data : geometry = LarkNativeRmsNorm.geometry shape := by rfl
theorem fuel_data : fuel = LarkNativeRmsNorm.fuel := by rfl
theorem program_data : program = LarkNativeRmsNorm.program := by decide
theorem segmentation_data : program = LarkNativeRmsNorm.program := program_data
theorem segmentation (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program (initial layout input outside) =
      some (LarkNativeRmsNorm.finalState shape LarkReal.ops input outside) := by
  rewrite [segmentation_data, layout_data, geometry_data, fuel_data]
  exact (LarkNativeRmsNorm.final_exec shape LarkReal.ops input outside).1
theorem race_free (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    raceFree geometry (LarkNativeRmsNorm.finalState shape LarkReal.ops input outside).trace = true := by
  rewrite [geometry_data]
  exact (LarkNativeRmsNorm.final_exec shape LarkReal.ops input outside).2
theorem segment_equivalence (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    extract layout (LarkNativeRmsNorm.finalState shape LarkReal.ops input outside) = some (spec input) := by
  have hs : LarkNativeRmsNorm.spec shape LarkReal.ops input = spec input :=
    (LarkReal.NativeRmsNorm.spec_eq shape input).trans (reference_data input).symm
  rewrite [layout_data]
  exact (LarkNativeRmsNorm.final_extract shape LarkReal.ops input outside).trans (congrArg some hs)
theorem kernel_eq_spec :
    LarkPartitionCollective.Correct LarkReal.ops layout geometry fuel program spec := by
  intro input outside
  exact ⟨LarkNativeRmsNorm.finalState shape LarkReal.ops input outside,
    segmentation input outside, race_free input outside, segment_equivalence input outside⟩
theorem kernel_eq_spec_pre (input : Nat → Nat → ℝ) (s : State ℝ) (pre : StdPre layout input s) :
    ∃ final, LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec input) := by
  obtain ⟨outside, rfl⟩ := pre
  exact kernel_eq_spec input outside
#print axioms reference_data
#print axioms program_data
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
