import Std

/-!
Pinned, dependency-free machine model for the bounded scalar profile.
Scalar arithmetic is universally quantified: the certificate holds for EVERY
interpretation of scalar operations and explicit half conversions.
This extends Model.lean; operation-to-hardware correspondence remains trusted.
Addresses and control depend only on exact integer index expressions.
-/
namespace LarkNonlinear

structure Ops (α : Type) where
  literal : Int → Nat → α
  add : α → α → α
  sub : α → α → α
  mul : α → α → α
  max : α → α → α
  div : α → α → α
  exp : α → α
  tanh : α → α
  rsqrt : α → α
  fromHalf : α → α
  toHalf : α → α

inductive Space where
  | global | shared | local
  deriving DecidableEq, Repr, BEq

structure Location where
  space : Space
  owner : Nat
  buffer : Nat
  offset : Nat
  deriving DecidableEq, Repr, BEq

inductive Role where
  | input | output | scratch
  deriving DecidableEq, Repr, BEq

structure Buffer where
  role : Role
  size : Nat
  deriving DecidableEq, Repr

structure Layout where
  global : List Buffer
  shared : List Nat := []
  locals : List Nat := []
  deriving DecidableEq, Repr

structure Geometry where
  grid : Nat
  block : Nat
  warp : Nat
  deriving DecidableEq, Repr

structure Fuel where
  lane : Nat
  warp : Nat
  block : Nat
  grid : Nat
  deriving DecidableEq, Repr

inductive Index where
  | const : Int → Index
  | tid | bid | bdim
  | ivar : Nat → Index
  | add : Index → Index → Index
  | sub : Index → Index → Index
  | mul : Index → Index → Index
  | div : Index → Index → Index
  | mod : Index → Index → Index
  deriving DecidableEq, Repr

inductive Predicate where
  | lt : Index → Index → Predicate
  | le : Index → Index → Predicate
  | eq : Index → Index → Predicate
  | ne : Index → Index → Predicate
  deriving DecidableEq, Repr

inductive Binary where
  | add | sub | mul | max | div
  deriving DecidableEq, Repr

inductive Unary where
  | exp | tanh | rsqrt | fromHalf | toHalf
  deriving DecidableEq, Repr

inductive Expr where
  | lit : Int → Nat → Expr
  | reg : Nat → Expr
  | load : Space → Nat → Index → Expr
  | bin : Binary → Expr → Expr → Expr
  | un : Unary → Expr → Expr
  deriving DecidableEq, Repr

inductive Cut where
  | warp | block | grid | halt
  deriving DecidableEq, Repr, BEq

inductive Instr where
  | index : Nat → Index → Instr
  | assign : Nat → Expr → Instr
  | store : Space → Nat → Index → Expr → Instr
  | branch : Predicate → Nat → Instr -- false target; true falls through
  | jump : Nat → Instr
  | barrier : Cut → Instr
  | halt
  deriving DecidableEq, Repr

structure Epoch where
  grid : Nat := 0
  block : Nat := 0
  warp : Nat := 0
  deriving DecidableEq, Repr

structure Access where
  thread : Nat
  location : Location
  write : Bool
  epoch : Epoch
  deriving DecidableEq, Repr

structure State (α : Type) where
  pc : Nat → Nat
  indices : Nat → Nat → Option Int
  regs : Nat → Nat → Option α
  memory : Location → Option α
  epochs : Nat → Epoch
  trace : List Access

def initial (layout : Layout) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α where
  pc := fun _ => 0
  indices := fun _ _ => none
  regs := fun _ _ => none
  epochs := fun _ => {}
  trace := []
  memory := fun l =>
    if l.space = .global ∧ l.owner = 0 then
      match layout.global[l.buffer]? with
      | some b => if b.role = .input ∧ l.offset < b.size
                  then some (input l.buffer l.offset) else outside l
      | none => outside l
    else outside l

/-- The fixed interface is satisfiable for every input, without a kernel premise. -/
theorem initial_exists (layout : Layout) (input : Nat → Nat → α) :
    ∃ s : State α, s = initial layout input (fun _ => none) := ⟨_, rfl⟩

def StdPre (layout : Layout) (input : Nat → Nat → α) (s : State α) : Prop :=
  ∃ outside, s = initial layout input outside

theorem pre_satisfiable (layout : Layout) (input : Nat → Nat → α) :
    ∃ s, StdPre layout input s := ⟨_, (fun _ => none), rfl⟩

theorem initial_places (layout : Layout) (input : Nat → Nat → α)
    (outside : Location → Option α) (b i : Nat) (buf : Buffer)
    (hb : layout.global[b]? = some buf) (hr : buf.role = .input) (hi : i < buf.size) :
    (initial layout input outside).memory ⟨.global, 0, b, i⟩ = some (input b i) := by
  simp [initial, hb, hr, hi]

def int32 (n : Int) : Option Int :=
  if 0 ≤ n ∧ n < 2147483648 then some n else none

def evalIndex (g : Geometry) (t : Nat) (s : State α) : Index → Option Int
  | .const n => int32 n
  | .tid => int32 (Int.ofNat (t % g.block))
  | .bid => int32 (Int.ofNat (t / g.block))
  | .bdim => int32 (Int.ofNat g.block)
  | .ivar r => s.indices t r
  | .add a b => do int32 ((← evalIndex g t s a) + (← evalIndex g t s b))
  | .sub a b => do int32 ((← evalIndex g t s a) - (← evalIndex g t s b))
  | .mul a b => do int32 ((← evalIndex g t s a) * (← evalIndex g t s b))
  | .div a b => do
      let x ← evalIndex g t s a
      let y ← evalIndex g t s b
      if y = 0 ∨ x < 0 ∨ y < 0 then none else some (x / y)
  | .mod a b => do
      let x ← evalIndex g t s a
      let y ← evalIndex g t s b
      if y = 0 ∨ x < 0 ∨ y < 0 then none else some (x % y)

def evalPredicate (g : Geometry) (t : Nat) (s : State α) : Predicate → Option Bool
  | .lt a b => return (← evalIndex g t s a) < (← evalIndex g t s b)
  | .le a b => return (← evalIndex g t s a) ≤ (← evalIndex g t s b)
  | .eq a b => return (← evalIndex g t s a) = (← evalIndex g t s b)
  | .ne a b => return (← evalIndex g t s a) ≠ (← evalIndex g t s b)

def location (layout : Layout) (g : Geometry) (t : Nat) (space : Space)
    (buffer : Nat) (index : Int) (write : Bool) : Option Location := do
  if index < 0 then none else do
    let bounds : Option (Nat × Nat) := match space with
      | .global => do
          let b ← layout.global[buffer]?
          if write && b.role == .input then none else some (0, b.size)
      | .shared => do pure (t / g.block, ← layout.shared[buffer]?)
      | .local => do pure (t, ← layout.locals[buffer]?)
    let (owner, size) ← bounds
    if index.toNat < size then some ⟨space, owner, buffer, index.toNat⟩ else none

def record (s : State α) (t : Nat) (l : Location) (write : Bool) : State α :=
  { s with trace := ⟨t, l, write, s.epochs t⟩ :: s.trace }

def applyBinary (ops : Ops α) : Binary → α → α → α
  | .add => ops.add
  | .sub => ops.sub
  | .mul => ops.mul
  | .max => ops.max
  | .div => ops.div

def applyUnary (ops : Ops α) : Unary → α → α
  | .exp => ops.exp
  | .tanh => ops.tanh
  | .rsqrt => ops.rsqrt
  | .fromHalf => ops.fromHalf
  | .toHalf => ops.toHalf

def evalExpr (ops : Ops α) (layout : Layout) (g : Geometry) (t : Nat) :
    Expr → State α → Option (α × State α)
  | .lit n d, s => if d = 0 then none else some (ops.literal n d, s)
  | .reg r, s => return (← s.regs t r, s)
  | .load space b ix, s => do
      let i ← evalIndex g t s ix
      let l ← location layout g t space b i false
      let v ← s.memory l
      return (v, record s t l false)
  | .bin op a b, s => do
      let (x, s) ← evalExpr ops layout g t a s
      let (y, s) ← evalExpr ops layout g t b s
      return (applyBinary ops op x y, s)
  | .un op a, s => do
      let (x, s) ← evalExpr ops layout g t a s
      return (applyUnary ops op x, s)

def advance (s : State α) (t : Nat) (pc : Nat) : State α :=
  { s with pc := fun u => if u = t then pc else s.pc u }

def execute (ops : Ops α) (layout : Layout) (g : Geometry) (t : Nat)
    (i : Instr) (s : State α) : Option (State α) := do
  let next := s.pc t + 1
  match i with
  | .index r ix =>
      let v ← evalIndex g t s ix
      return advance { s with indices := fun u q =>
        if u = t ∧ q = r then some v else s.indices u q } t next
  | .assign r e =>
      let (v, s) ← evalExpr ops layout g t e s
      return advance { s with regs := fun u q =>
        if u = t ∧ q = r then some v else s.regs u q } t next
  | .store space b ix e =>
      let index ← evalIndex g t s ix
      let loc ← location layout g t space b index true
      let (v, s) ← evalExpr ops layout g t e s
      let s := record s t loc true
      let updated : State α := { s with memory := fun cell =>
        (if cell = loc then some v else s.memory cell) }
      return advance updated t next
  | .branch p target =>
      let yes ← evalPredicate g t s p
      return advance s t (if yes then next else target)
  | .jump target => return advance s t target
  | .barrier _ | .halt => none

def parked (p : List Instr) (s : State α) (t : Nat) : Option Cut :=
  match p[s.pc t]? with
  | some (.barrier c) => some c
  | some .halt => some .halt
  | _ => none

def runLane (ops : Ops α) (layout : Layout) (g : Geometry) (p : List Instr)
    (t : Nat) : Nat → State α → Option (State α)
  | 0, _ => none
  | n + 1, s =>
      match parked p s t with
      | some _ => some s
      | none => do
          let i ← p[s.pc t]?
          let s ← execute ops layout g t i s
          runLane ops layout g p t n s

def converged (p : List Instr) (ts : List Nat) (s : State α) : Option Cut := do
  let t ← ts.head?
  if ts.all (fun u => s.pc u == s.pc t) then parked p s t else none

def bumpEpoch (e : Epoch) : Cut → Epoch
  | .warp => { e with warp := e.warp + 1 }
  | .block => { e with block := e.block + 1 }
  | .grid => { e with grid := e.grid + 1 }
  | .halt => e

def resume (ts : List Nat) (c : Cut) (s : State α) : State α :=
  { s with
    pc := fun t => if ts.contains t then s.pc t + 1 else s.pc t
    epochs := fun t => if ts.contains t then bumpEpoch (s.epochs t) c else s.epochs t }

def warpThreads (g : Geometry) (b w : Nat) : List Nat :=
  ((List.range g.block).filter (fun t => t / g.warp == w)).map (b * g.block + ·)

def blockThreads (g : Geometry) (b : Nat) : List Nat :=
  (List.range g.block).map (b * g.block + ·)

def runWarp (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) (ts : List Nat) : Nat → State α → Option (State α)
  | 0, _ => none
  | n + 1, s => do
      let s ← ts.foldlM (fun s t => runLane ops layout g p t f.lane s) s
      let c ← converged p ts s
      if c = .warp then runWarp ops layout g f p ts n (resume ts c s) else some s

def runBlock (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) (b : Nat) : Nat → State α → Option (State α)
  | 0, _ => none
  | n + 1, s => do
      let ws := List.range ((g.block + g.warp - 1) / g.warp)
      let s ← ws.foldlM (fun s w =>
        runWarp ops layout g f p (warpThreads g b w) f.warp s) s
      let ts := blockThreads g b
      let c ← converged p ts s
      if c = .block then runBlock ops layout g f p b n (resume ts c s) else
        if c = .grid ∨ c = .halt then some s else none

def runGrid (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) : Nat → State α → Option (State α)
  | 0, _ => none
  | n + 1, s => do
      let s ← (List.range g.grid).foldlM (fun s b =>
        runBlock ops layout g f p b f.block s) s
      let ts := List.range (g.grid * g.block)
      let c ← converged p ts s
      if c = .grid then runGrid ops layout g f p n (resume ts c s) else
        if c = .halt then some s else none

def runLaunch (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) (s : State α) : Option (State α) :=
  if g.grid = 0 ∨ g.block = 0 ∨ g.warp = 0 then none
  else runGrid ops layout g f p f.grid s

/-- Only a synchronization scope shared by BOTH threads orders two accesses. -/
def ordered (g : Geometry) (a b : Access) : Bool :=
  a.epoch.grid != b.epoch.grid ||
  (a.thread / g.block == b.thread / g.block &&
    (a.epoch.block != b.epoch.block ||
      ((a.thread % g.block) / g.warp == (b.thread % g.block) / g.warp &&
        a.epoch.warp != b.epoch.warp)))

def sameLocation (a b : Location) : Bool :=
  decide (a.space = b.space) && a.owner == b.owner &&
    a.buffer == b.buffer && a.offset == b.offset

def conflict (g : Geometry) (a b : Access) : Bool :=
  a.thread != b.thread && sameLocation a.location b.location &&
    (a.write || b.write) && !(ordered g a b)

def raceFree (g : Geometry) (trace : List Access) : Bool :=
  trace.all (fun a => trace.all (fun b => !(conflict g a b)))

def extract (layout : Layout) (s : State α) : Option (List α) := do
  let cells := (layout.global.zipIdx).flatMap fun (b, id) =>
    if b.role = .output then (List.range b.size).map (id, ·) else []
  cells.mapM fun (b, i) => s.memory ⟨.global, 0, b, i⟩

inductive Segment where
  | op : Instr → Segment
  | seq : List Segment → Segment
  | repeat : Nat → List Instr → Segment
  deriving Repr

def flattenSegment : Segment → List Instr
  | .op i => [i]
  | .seq ss => ss.flatMap flattenSegment
  | .repeat n body => (List.replicate n body).flatten

def flatten (ss : List Segment) : List Instr := ss.flatMap flattenSegment

/-- The final statement fixes its program and specification before any proof proposal. -/
def Correct (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) (spec : (Nat → Nat → α) → List α) : Prop :=
  ∀ input outside, ∃ final,
    runLaunch ops layout g f p (initial layout input outside) = some final ∧
    raceFree g final.trace = true ∧ extract layout final = some (spec input)

theorem correct_from_pre (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) (spec : (Nat → Nat → α) → List α)
    (h : Correct ops layout g f p spec) (input : Nat → Nat → α) (s : State α)
    (pre : StdPre layout input s) :
    ∃ final, runLaunch ops layout g f p s = some final ∧
      raceFree g final.trace = true ∧ extract layout final = some (spec input) := by
  obtain ⟨outside, rfl⟩ := pre
  exact h input outside

theorem assemble (ops : Ops α) (layout : Layout) (g : Geometry) (f : Fuel)
    (p : List Instr) (segments : List Segment)
    (spec : (Nat → Nat → α) → List α)
    (seg : flatten segments = p)
    (eqv : Correct ops layout g f (flatten segments) spec) :
    Correct ops layout g f p spec := by
  rw [← seg]
  exact eqv

end LarkNonlinear


namespace LarkCertificate
open LarkNonlinear
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

def layout : Layout := ⟨[⟨.input, 128⟩, ⟨.input, 64⟩, ⟨.output, 2⟩], [], []⟩
def geometry : Geometry := ⟨2, 1, 64⟩
def fuel : Fuel := ⟨262, 1, 1, 1⟩
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (64))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.ivar (0)) (.const (64))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.ivar (1))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]
def traceData : List Access := [⟨1, ⟨.global, 0, 2, 1⟩, true, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 63⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 127⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 62⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 126⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 61⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 125⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 60⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 124⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 59⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 123⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 58⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 122⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 57⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 121⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 56⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 120⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 55⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 119⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 54⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 118⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 53⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 117⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 52⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 116⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 51⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 115⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 50⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 114⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 49⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 113⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 48⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 112⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 47⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 111⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 46⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 110⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 45⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 109⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 44⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 108⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 43⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 107⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 42⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 106⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 41⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 105⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 40⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 104⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 39⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 103⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 38⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 102⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 37⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 101⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 36⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 100⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 35⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 99⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 34⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 98⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 33⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 97⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 32⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 96⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 31⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 95⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 30⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 94⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 29⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 93⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 28⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 92⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 27⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 91⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 26⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 90⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 25⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 89⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 24⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 88⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 23⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 87⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 22⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 86⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 21⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 85⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 20⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 84⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 19⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 83⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 18⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 82⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 17⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 81⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 16⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 80⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 15⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 79⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 14⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 78⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 13⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 77⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 12⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 76⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 11⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 75⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 10⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 74⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 9⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 73⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 8⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 72⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 7⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 71⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 6⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 70⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 5⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 69⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 4⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 68⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 3⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 67⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 2⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 66⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 1⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 65⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 1, 0⟩, false, ⟨0, 0, 0⟩⟩, ⟨1, ⟨.global, 0, 0, 64⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 2, 0⟩, true, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 63⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 63⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 62⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 62⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 61⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 61⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 60⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 60⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 59⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 59⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 58⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 58⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 57⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 57⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 56⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 56⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 55⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 55⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 54⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 54⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 53⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 53⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 52⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 52⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 51⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 51⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 50⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 50⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 49⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 49⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 48⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 48⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 47⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 47⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 46⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 46⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 45⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 45⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 44⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 44⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 43⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 43⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 42⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 42⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 41⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 41⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 40⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 40⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 39⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 39⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 38⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 38⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 37⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 37⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 36⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 36⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 35⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 35⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 34⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 34⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 33⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 33⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 32⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 32⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 31⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 31⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 30⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 30⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 29⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 29⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 28⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 28⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 27⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 27⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 26⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 26⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 25⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 25⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 24⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 24⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 23⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 23⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 22⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 22⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 21⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 21⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 20⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 20⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 19⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 19⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 18⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 18⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 17⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 17⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 16⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 16⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 15⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 15⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 14⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 14⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 13⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 13⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 12⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 12⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 11⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 11⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 10⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 10⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 9⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 9⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 8⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 8⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 7⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 7⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 6⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 6⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 5⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 5⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 4⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 4⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 3⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 3⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 2⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 2⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 1⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 1⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 1, 0⟩, false, ⟨0, 0, 0⟩⟩, ⟨0, ⟨.global, 0, 0, 0⟩, false, ⟨0, 0, 0⟩⟩]
def segments : List Segment := [(.seq [(.op (.index 0 .bid)), (.op (.assign 0 (.lit (0) 1))), (.op (.index 1 (.const (0)))), (.op (.branch (.lt (.ivar (1)) (.const (64))) 7)), (.op (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.ivar (0)) (.const (64))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.ivar (1)))))))), (.op (.index 1 (.add (.ivar (1)) (.const (1))))), (.op (.jump 3)), (.op (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0))))), (.op .halt)])]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  [(ops.toHalf (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.literal (0) 1) (ops.mul (ops.fromHalf (input 0 0)) (ops.fromHalf (input 1 0)))) (ops.mul (ops.fromHalf (input 0 1)) (ops.fromHalf (input 1 1)))) (ops.mul (ops.fromHalf (input 0 2)) (ops.fromHalf (input 1 2)))) (ops.mul (ops.fromHalf (input 0 3)) (ops.fromHalf (input 1 3)))) (ops.mul (ops.fromHalf (input 0 4)) (ops.fromHalf (input 1 4)))) (ops.mul (ops.fromHalf (input 0 5)) (ops.fromHalf (input 1 5)))) (ops.mul (ops.fromHalf (input 0 6)) (ops.fromHalf (input 1 6)))) (ops.mul (ops.fromHalf (input 0 7)) (ops.fromHalf (input 1 7)))) (ops.mul (ops.fromHalf (input 0 8)) (ops.fromHalf (input 1 8)))) (ops.mul (ops.fromHalf (input 0 9)) (ops.fromHalf (input 1 9)))) (ops.mul (ops.fromHalf (input 0 10)) (ops.fromHalf (input 1 10)))) (ops.mul (ops.fromHalf (input 0 11)) (ops.fromHalf (input 1 11)))) (ops.mul (ops.fromHalf (input 0 12)) (ops.fromHalf (input 1 12)))) (ops.mul (ops.fromHalf (input 0 13)) (ops.fromHalf (input 1 13)))) (ops.mul (ops.fromHalf (input 0 14)) (ops.fromHalf (input 1 14)))) (ops.mul (ops.fromHalf (input 0 15)) (ops.fromHalf (input 1 15)))) (ops.mul (ops.fromHalf (input 0 16)) (ops.fromHalf (input 1 16)))) (ops.mul (ops.fromHalf (input 0 17)) (ops.fromHalf (input 1 17)))) (ops.mul (ops.fromHalf (input 0 18)) (ops.fromHalf (input 1 18)))) (ops.mul (ops.fromHalf (input 0 19)) (ops.fromHalf (input 1 19)))) (ops.mul (ops.fromHalf (input 0 20)) (ops.fromHalf (input 1 20)))) (ops.mul (ops.fromHalf (input 0 21)) (ops.fromHalf (input 1 21)))) (ops.mul (ops.fromHalf (input 0 22)) (ops.fromHalf (input 1 22)))) (ops.mul (ops.fromHalf (input 0 23)) (ops.fromHalf (input 1 23)))) (ops.mul (ops.fromHalf (input 0 24)) (ops.fromHalf (input 1 24)))) (ops.mul (ops.fromHalf (input 0 25)) (ops.fromHalf (input 1 25)))) (ops.mul (ops.fromHalf (input 0 26)) (ops.fromHalf (input 1 26)))) (ops.mul (ops.fromHalf (input 0 27)) (ops.fromHalf (input 1 27)))) (ops.mul (ops.fromHalf (input 0 28)) (ops.fromHalf (input 1 28)))) (ops.mul (ops.fromHalf (input 0 29)) (ops.fromHalf (input 1 29)))) (ops.mul (ops.fromHalf (input 0 30)) (ops.fromHalf (input 1 30)))) (ops.mul (ops.fromHalf (input 0 31)) (ops.fromHalf (input 1 31)))) (ops.mul (ops.fromHalf (input 0 32)) (ops.fromHalf (input 1 32)))) (ops.mul (ops.fromHalf (input 0 33)) (ops.fromHalf (input 1 33)))) (ops.mul (ops.fromHalf (input 0 34)) (ops.fromHalf (input 1 34)))) (ops.mul (ops.fromHalf (input 0 35)) (ops.fromHalf (input 1 35)))) (ops.mul (ops.fromHalf (input 0 36)) (ops.fromHalf (input 1 36)))) (ops.mul (ops.fromHalf (input 0 37)) (ops.fromHalf (input 1 37)))) (ops.mul (ops.fromHalf (input 0 38)) (ops.fromHalf (input 1 38)))) (ops.mul (ops.fromHalf (input 0 39)) (ops.fromHalf (input 1 39)))) (ops.mul (ops.fromHalf (input 0 40)) (ops.fromHalf (input 1 40)))) (ops.mul (ops.fromHalf (input 0 41)) (ops.fromHalf (input 1 41)))) (ops.mul (ops.fromHalf (input 0 42)) (ops.fromHalf (input 1 42)))) (ops.mul (ops.fromHalf (input 0 43)) (ops.fromHalf (input 1 43)))) (ops.mul (ops.fromHalf (input 0 44)) (ops.fromHalf (input 1 44)))) (ops.mul (ops.fromHalf (input 0 45)) (ops.fromHalf (input 1 45)))) (ops.mul (ops.fromHalf (input 0 46)) (ops.fromHalf (input 1 46)))) (ops.mul (ops.fromHalf (input 0 47)) (ops.fromHalf (input 1 47)))) (ops.mul (ops.fromHalf (input 0 48)) (ops.fromHalf (input 1 48)))) (ops.mul (ops.fromHalf (input 0 49)) (ops.fromHalf (input 1 49)))) (ops.mul (ops.fromHalf (input 0 50)) (ops.fromHalf (input 1 50)))) (ops.mul (ops.fromHalf (input 0 51)) (ops.fromHalf (input 1 51)))) (ops.mul (ops.fromHalf (input 0 52)) (ops.fromHalf (input 1 52)))) (ops.mul (ops.fromHalf (input 0 53)) (ops.fromHalf (input 1 53)))) (ops.mul (ops.fromHalf (input 0 54)) (ops.fromHalf (input 1 54)))) (ops.mul (ops.fromHalf (input 0 55)) (ops.fromHalf (input 1 55)))) (ops.mul (ops.fromHalf (input 0 56)) (ops.fromHalf (input 1 56)))) (ops.mul (ops.fromHalf (input 0 57)) (ops.fromHalf (input 1 57)))) (ops.mul (ops.fromHalf (input 0 58)) (ops.fromHalf (input 1 58)))) (ops.mul (ops.fromHalf (input 0 59)) (ops.fromHalf (input 1 59)))) (ops.mul (ops.fromHalf (input 0 60)) (ops.fromHalf (input 1 60)))) (ops.mul (ops.fromHalf (input 0 61)) (ops.fromHalf (input 1 61)))) (ops.mul (ops.fromHalf (input 0 62)) (ops.fromHalf (input 1 62)))) (ops.mul (ops.fromHalf (input 0 63)) (ops.fromHalf (input 1 63))))), (ops.toHalf (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.add (ops.literal (0) 1) (ops.mul (ops.fromHalf (input 0 64)) (ops.fromHalf (input 1 0)))) (ops.mul (ops.fromHalf (input 0 65)) (ops.fromHalf (input 1 1)))) (ops.mul (ops.fromHalf (input 0 66)) (ops.fromHalf (input 1 2)))) (ops.mul (ops.fromHalf (input 0 67)) (ops.fromHalf (input 1 3)))) (ops.mul (ops.fromHalf (input 0 68)) (ops.fromHalf (input 1 4)))) (ops.mul (ops.fromHalf (input 0 69)) (ops.fromHalf (input 1 5)))) (ops.mul (ops.fromHalf (input 0 70)) (ops.fromHalf (input 1 6)))) (ops.mul (ops.fromHalf (input 0 71)) (ops.fromHalf (input 1 7)))) (ops.mul (ops.fromHalf (input 0 72)) (ops.fromHalf (input 1 8)))) (ops.mul (ops.fromHalf (input 0 73)) (ops.fromHalf (input 1 9)))) (ops.mul (ops.fromHalf (input 0 74)) (ops.fromHalf (input 1 10)))) (ops.mul (ops.fromHalf (input 0 75)) (ops.fromHalf (input 1 11)))) (ops.mul (ops.fromHalf (input 0 76)) (ops.fromHalf (input 1 12)))) (ops.mul (ops.fromHalf (input 0 77)) (ops.fromHalf (input 1 13)))) (ops.mul (ops.fromHalf (input 0 78)) (ops.fromHalf (input 1 14)))) (ops.mul (ops.fromHalf (input 0 79)) (ops.fromHalf (input 1 15)))) (ops.mul (ops.fromHalf (input 0 80)) (ops.fromHalf (input 1 16)))) (ops.mul (ops.fromHalf (input 0 81)) (ops.fromHalf (input 1 17)))) (ops.mul (ops.fromHalf (input 0 82)) (ops.fromHalf (input 1 18)))) (ops.mul (ops.fromHalf (input 0 83)) (ops.fromHalf (input 1 19)))) (ops.mul (ops.fromHalf (input 0 84)) (ops.fromHalf (input 1 20)))) (ops.mul (ops.fromHalf (input 0 85)) (ops.fromHalf (input 1 21)))) (ops.mul (ops.fromHalf (input 0 86)) (ops.fromHalf (input 1 22)))) (ops.mul (ops.fromHalf (input 0 87)) (ops.fromHalf (input 1 23)))) (ops.mul (ops.fromHalf (input 0 88)) (ops.fromHalf (input 1 24)))) (ops.mul (ops.fromHalf (input 0 89)) (ops.fromHalf (input 1 25)))) (ops.mul (ops.fromHalf (input 0 90)) (ops.fromHalf (input 1 26)))) (ops.mul (ops.fromHalf (input 0 91)) (ops.fromHalf (input 1 27)))) (ops.mul (ops.fromHalf (input 0 92)) (ops.fromHalf (input 1 28)))) (ops.mul (ops.fromHalf (input 0 93)) (ops.fromHalf (input 1 29)))) (ops.mul (ops.fromHalf (input 0 94)) (ops.fromHalf (input 1 30)))) (ops.mul (ops.fromHalf (input 0 95)) (ops.fromHalf (input 1 31)))) (ops.mul (ops.fromHalf (input 0 96)) (ops.fromHalf (input 1 32)))) (ops.mul (ops.fromHalf (input 0 97)) (ops.fromHalf (input 1 33)))) (ops.mul (ops.fromHalf (input 0 98)) (ops.fromHalf (input 1 34)))) (ops.mul (ops.fromHalf (input 0 99)) (ops.fromHalf (input 1 35)))) (ops.mul (ops.fromHalf (input 0 100)) (ops.fromHalf (input 1 36)))) (ops.mul (ops.fromHalf (input 0 101)) (ops.fromHalf (input 1 37)))) (ops.mul (ops.fromHalf (input 0 102)) (ops.fromHalf (input 1 38)))) (ops.mul (ops.fromHalf (input 0 103)) (ops.fromHalf (input 1 39)))) (ops.mul (ops.fromHalf (input 0 104)) (ops.fromHalf (input 1 40)))) (ops.mul (ops.fromHalf (input 0 105)) (ops.fromHalf (input 1 41)))) (ops.mul (ops.fromHalf (input 0 106)) (ops.fromHalf (input 1 42)))) (ops.mul (ops.fromHalf (input 0 107)) (ops.fromHalf (input 1 43)))) (ops.mul (ops.fromHalf (input 0 108)) (ops.fromHalf (input 1 44)))) (ops.mul (ops.fromHalf (input 0 109)) (ops.fromHalf (input 1 45)))) (ops.mul (ops.fromHalf (input 0 110)) (ops.fromHalf (input 1 46)))) (ops.mul (ops.fromHalf (input 0 111)) (ops.fromHalf (input 1 47)))) (ops.mul (ops.fromHalf (input 0 112)) (ops.fromHalf (input 1 48)))) (ops.mul (ops.fromHalf (input 0 113)) (ops.fromHalf (input 1 49)))) (ops.mul (ops.fromHalf (input 0 114)) (ops.fromHalf (input 1 50)))) (ops.mul (ops.fromHalf (input 0 115)) (ops.fromHalf (input 1 51)))) (ops.mul (ops.fromHalf (input 0 116)) (ops.fromHalf (input 1 52)))) (ops.mul (ops.fromHalf (input 0 117)) (ops.fromHalf (input 1 53)))) (ops.mul (ops.fromHalf (input 0 118)) (ops.fromHalf (input 1 54)))) (ops.mul (ops.fromHalf (input 0 119)) (ops.fromHalf (input 1 55)))) (ops.mul (ops.fromHalf (input 0 120)) (ops.fromHalf (input 1 56)))) (ops.mul (ops.fromHalf (input 0 121)) (ops.fromHalf (input 1 57)))) (ops.mul (ops.fromHalf (input 0 122)) (ops.fromHalf (input 1 58)))) (ops.mul (ops.fromHalf (input 0 123)) (ops.fromHalf (input 1 59)))) (ops.mul (ops.fromHalf (input 0 124)) (ops.fromHalf (input 1 60)))) (ops.mul (ops.fromHalf (input 0 125)) (ops.fromHalf (input 1 61)))) (ops.mul (ops.fromHalf (input 0 126)) (ops.fromHalf (input 1 62)))) (ops.mul (ops.fromHalf (input 0 127)) (ops.fromHalf (input 1 63)))))]

def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  (runLaunch ops layout geometry fuel program (initial layout input outside)).getD
    (initial layout input outside)

theorem segmentation_data : flatten segments = program :=
  by simp [flatten, flattenSegment, segments, program]

theorem segmentation (ops : Ops α) (s : State α) :
    runLaunch ops layout geometry fuel program s =
    runLaunch ops layout geometry fuel (flatten segments) s := by
  rw [segmentation_data]

def unitOps : Ops Unit := ⟨fun _ _ => (), fun _ _ => (), fun _ _ => (),
  fun _ _ => (), fun _ _ => (), fun _ _ => (), fun _ => (), fun _ => (), fun _ => (), fun _ => (), fun _ => ()⟩

theorem race_free : ∃ final,
    runLaunch unitOps layout geometry fuel program
      (initial layout (fun _ _ => ()) (fun _ => some ())) = some final ∧
    raceFree geometry final.trace = true :=
  by
  refine ⟨finalState unitOps (fun _ _ => ()) (fun _ => some ()), rfl, ?_⟩
  have htrace : (finalState unitOps (fun _ _ => ()) (fun _ => some ())).trace = traceData := by rfl
  rw [htrace]
  decide

theorem segment_equivalence (ops : Ops α) :
    Correct ops layout geometry fuel (flatten segments) (spec ops) :=
  by
  intro input outside
  rw [segmentation_data]
  refine ⟨finalState ops input outside, rfl, ?_, rfl⟩
  have htrace : (finalState ops input outside).trace = traceData := by rfl
  rw [htrace]
  decide

theorem kernel_eq_spec (ops : Ops α) :
    Correct ops layout geometry fuel program (spec ops) := by
  exact assemble ops layout geometry fuel program segments (spec ops)
    segmentation_data (segment_equivalence ops)

theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (s : State α)
    (pre : StdPre layout input s) :
    ∃ final, runLaunch ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec ops input) := by
  exact correct_from_pre ops layout geometry fuel program (spec ops)
    (kernel_eq_spec ops) input s pre

#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
