import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def profile : LarkDot.Profile := LarkConvolution.depthProfile 32 16 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
def layout : Layout := LarkDot.layout profile
def geometry : Geometry := LarkDot.geometry profile 64
def fuel : Fuel := LarkDot.fuel profile
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (25))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.add (.mul (.add (.add (.mul (.div (.ivar (0)) (.const (144))) (.const (16))) (.mod (.div (.ivar (0)) (.const (12))) (.const (12)))) (.mod (.div (.ivar (1)) (.const (5))) (.const (5)))) (.const (16))) (.mod (.ivar (0)) (.const (12)))) (.mod (.ivar (1)) (.const (5)))))) (.un .fromHalf (.load .global 1 (.add (.mul (.div (.ivar (0)) (.const (144))) (.const (25))) (.ivar (1)))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkDot.matrixSpec ops profile input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkDot.partialState ops input outside profile profile.n
benchmark_audit_float @spec from "Input.json" at [0,1,127,2304,4607]
end LarkCertificate
