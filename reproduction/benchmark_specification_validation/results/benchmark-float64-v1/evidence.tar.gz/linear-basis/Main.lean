import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def profile : LarkBias.Profile := LarkBias.linearProfile 64 512 256 (by decide) (by decide) (by decide) (by decide) (by decide)
def layout : Layout := LarkBias.layout profile
def geometry : Geometry := LarkBias.geometry profile 64
def fuel : Fuel := LarkBias.fuel profile
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (512))) (.const (256))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (512))) (.mod (.ivar (0)) (.const (512))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 3 (.ivar (0)) (.un .toHalf (.bin .add (.reg (0)) (.un .fromHalf (.load .global 2 (.mod (.ivar (0)) (.const (512)))))))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkBias.matrixSpec ops profile input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkBias.partialState ops input outside profile profile.n
benchmark_audit_float @spec from "Input.json" at [0,1,127,16384,32767]
end LarkCertificate
