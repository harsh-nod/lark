import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def profile : LarkUnaryMap.Profile := LarkNormalization.profile .rms 16384
def layout : Layout := LarkUnaryMap.layout 16384
def geometry : Geometry := LarkUnaryMap.geometry 16384 64
def fuel : Fuel := LarkUnaryMap.fuel profile
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.assign 1 (.lit (0) 1)), (.assign 2 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (16384))) 10), (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (1))))), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.reg (2)) (.reg (2))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 5), (.assign 1 (.bin .div (.reg (0)) (.lit (16384) 1))), (.assign 0 (.lit (0) 1)), (.index 1 (.const (16384))), (.branch (.lt (.ivar (1)) (.const (16384))) 18), (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (1))))), (.assign 0 (.bin .add (.reg (0)) (.reg (2)))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 13), (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (0))))), (.store .global 1 (.ivar (0)) (.un .toHalf (.bin .mul (.reg (2)) (.un .rsqrt (.bin .add (.reg (1)) (.lit (1) 100000)))))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkUnaryMap.spec profile ops input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α := LarkUnaryMap.partialState profile ops input outside 16384
benchmark_audit_float @spec from "Input.json" at [0,1,127,8192,16383]
end LarkCertificate
