import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
open Lean Meta Elab
elab "#probe_cache" : command => do
  match LarkBenchmarkFloatAudit.scoreAt #[Float.ofBits (UInt64.ofNat 9218868437227405312)] 0 with
  | .error reason => throwError reason
  | .ok value => logInfo m!"LARK_CACHE_CONTROL {value.toBits.toNat}"
#probe_cache
