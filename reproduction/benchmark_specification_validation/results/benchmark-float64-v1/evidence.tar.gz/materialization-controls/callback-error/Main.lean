import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
open Lean Meta Elab
elab "#probe_callback" : command => do
  match LarkBenchmarkFloatAudit.materialize 3 (fun i =>
      if i=1 then .error "reference-audit injected score failure" else .ok 0.25) with
  | .error reason => throwError reason
  | .ok _ => throwError "unexpected callback success"
#probe_callback
