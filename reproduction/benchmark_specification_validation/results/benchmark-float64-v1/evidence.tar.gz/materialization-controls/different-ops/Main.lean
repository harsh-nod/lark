import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
open Lean Meta Elab
namespace LarkCertificate
open LarkNonlinear
def shape : LarkAttention.Shape := ⟨1,1,128,256,16,
  by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide⟩
def programs : LarkAttention.Programs := ⟨[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (16384))) (.const (32768))) (.add (.mul (.mod (.div (.ivar (0)) (.const (128))) (.const (128))) (.const (256))) (.ivar (1)))))) (.un .fromHalf (.load .global 1 (.add (.mul (.div (.div (.ivar (0)) (.const (16384))) (.const (1))) (.const (32768))) (.add (.mul (.mod (.ivar (0)) (.const (128))) (.const (256))) (.ivar (1))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.bin .div (.reg (0)) (.lit (16) 1))), .halt],[(.index 0 .bid), (.index 1 (.const (0))), (.assign 0 (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (128))) (.const (128))) (.ivar (1))))), (.assign 1 (.lit (0) 1)), (.assign 2 (.lit (0) 1)), (.index 1 (.const (1))), (.branch (.lt (.ivar (1)) (.const (128))) 11), (.assign 2 (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (128))) (.const (128))) (.ivar (1))))), (.assign 0 (.bin .max (.reg (0)) (.reg (2)))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 6), (.assign 1 (.reg (0))), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (128))) 19), (.assign 2 (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (128))) (.const (128))) (.ivar (1))))), (.assign 0 (.bin .add (.reg (0)) (.un .exp (.bin .sub (.reg (2)) (.reg (1)))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 14), (.assign 2 (.load .global 0 (.ivar (0)))), (.store .global 1 (.ivar (0)) (.bin .div (.un .exp (.bin .sub (.reg (2)) (.reg (1)))) (.reg (0)))), .halt],[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (128))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (32768))) (.const (16384))) (.add (.mul (.mod (.div (.ivar (0)) (.const (256))) (.const (128))) (.const (128))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.div (.div (.ivar (0)) (.const (32768))) (.const (1))) (.const (32768))) (.add (.mul (.ivar (1)) (.const (256))) (.mod (.ivar (0)) (.const (256)))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]⟩
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkAttention.spec shape ops input
open Lean Meta Elab
elab "#probe_source" : command => Command.liftTermElabM do
  withLocalDeclD `buffers (mkConst ``LarkBenchmarkFloatAudit.Inputs) fun inputVariable => do
    let scoreType ← Term.elabType (← `(Array Float))
    withLocalDeclD `scores scoreType fun scoreVariable => do
      let shape := mkConst `LarkCertificate.shape
      let inputFunction := mkApp (mkConst ``LarkBenchmarkFloatAudit.checkedInput) inputVariable
      let operationArgument ← Term.elabTerm
        (← `({ LarkBenchmarkFloatAudit.ops with add := LarkBenchmarkFloatAudit.ops.sub })) none
      Term.synthesizeSyntheticMVarsNoPostponing
      let operationArgument ← instantiateMVars operationArgument
      let shapeArgument := shape
      let inputArgument := inputFunction
      let expression := mkAppN (mkConst ``LarkAttention.spec)
        #[mkConst ``LarkBenchmarkFloatAudit.Checked,shapeArgument,operationArgument,inputArgument]
      let (selected,_) ← (LarkBenchmarkRealAudit.listAt expression 0).run #[] |>.run {}
      let _ ← LarkBenchmarkFloatAudit.replaceScores selected shape inputFunction scoreVariable
      throwError "unexpected source replacement success"
#probe_source
end LarkCertificate
