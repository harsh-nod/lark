import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def layout : Layout := LarkReduction.layout 512 1024
def geometry : Geometry := LarkReduction.geometry 512 64
def fuel : Fuel := LarkReduction.fuel 1024
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (1024))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.ivar (0)) (.const (1024))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.ivar (1))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkReduction.matrixSpec ops 512 1024 input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkReduction.partialState ops input outside 512 1024 512
benchmark_audit_float @spec from "Input.json" at [0,1,127,256,511]
end LarkCertificate
