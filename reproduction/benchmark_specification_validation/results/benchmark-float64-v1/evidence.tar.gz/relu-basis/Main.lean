import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
open LarkPointwise (Scalar)
def body : Scalar := (.bin .max .input (.lit (0) 1))
def referenceBody : Scalar := (.bin .max .input (.lit (0) 1))
def layout : Layout := LarkPointwise.layout 16384
def geometry : Geometry := LarkPointwise.geometry 16384 64
def fuel : Fuel := LarkPointwise.fuel
def program : List Instr := [(.index 0 .bid), (.assign 0 (.un .fromHalf (.load .global 0 (.ivar (0))))), (.store .global 1 (.ivar (0)) (.un .toHalf (.bin .max (.reg (0)) (.lit (0) 1)))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkPointwise.spec ops referenceBody 16384 input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkPointwise.partialState ops body 16384 input outside 16384

benchmark_audit_float @spec from "Input.json" at [0,1,127,8192,16383]
end LarkCertificate
