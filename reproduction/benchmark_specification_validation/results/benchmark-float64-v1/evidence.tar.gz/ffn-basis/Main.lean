import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def shape : LarkFeedForward.Shape :=
  ⟨64,256,1024,256,by decide,by decide,by decide,by decide,
    by decide,by decide,by decide,by decide,by decide⟩
def chain : LarkPipeline.Chain := LarkFeedForward.chain shape
def upProgram : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (1024))) (.const (256))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (1024))) (.mod (.ivar (0)) (.const (1024))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.bin .max (.reg (0)) (.lit (0) 1)))), .halt]
def downProgram : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (1024))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (256))) (.const (1024))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (256))) (.mod (.ivar (0)) (.const (256))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkPipeline.spec chain ops input
def firstFinal (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  LarkPipeline.firstFinal chain ops input outside
def secondFinal (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  LarkPipeline.secondFinal chain ops input outside
benchmark_audit_float @spec from "Input.json" at [0,1,127,8192,16383]
end LarkCertificate
