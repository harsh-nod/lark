import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
def spec {α : Type} (ops : LarkNonlinear.Ops α) (input : Nat → Nat → α) : List α := [ops.rsqrt (ops.literal (-1) 1)]
end LarkCertificate
benchmark_audit_float @LarkCertificate.spec from "Input.json" at [0]
