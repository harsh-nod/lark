import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
def spec {α : Type} (ops : LarkNonlinear.Ops α) (input : Nat → Nat → α) : List α := [ops.literal (Int.ofNat ((Float.exp (0 : Float)).toUInt64.toNat)) 1]
end LarkCertificate
benchmark_audit_float @LarkCertificate.spec from "Input.json" at [0]
