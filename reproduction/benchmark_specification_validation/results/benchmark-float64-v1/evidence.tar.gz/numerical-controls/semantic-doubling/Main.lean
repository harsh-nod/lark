import BenchmarkFloatAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
def spec {α : Type} (ops : LarkNonlinear.Ops α) (input : Nat → Nat → α) : List α := [ops.mul (ops.literal 2 1) (ops.add (input 1 0) (ops.literal 1 1))]
end LarkCertificate
benchmark_audit_float @LarkCertificate.spec from "Input.json" at [0]
