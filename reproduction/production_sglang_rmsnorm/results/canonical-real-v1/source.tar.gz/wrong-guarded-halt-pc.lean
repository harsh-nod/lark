import LarkReal.NativeSglangRmsNorm
open LarkNativeSglangRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
example : (program true)[108]? = some (.scalar .halt) := by decide
