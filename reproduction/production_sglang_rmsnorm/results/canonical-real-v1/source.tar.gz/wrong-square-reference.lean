import LarkReal.NativeSglangRmsNorm
open LarkReal.NativeSglangRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
example : rowSquare (fun _ _ => (2 : ℝ)) 0 0 = 2 := by norm_num [rowSquare]
