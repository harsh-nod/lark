import LarkReal.NativeSglangRmsNorm
namespace LarkCertificate
open LarkNonlinear
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeSglangRmsNorm.Shape := ⟨1, by decide, by decide⟩
def layout : Layout := ⟨[⟨.output, 16384⟩, ⟨.input, 16384⟩, ⟨.input, 16384⟩],
  [32], [16, 16, 16]⟩
def geometry : Geometry := ⟨1, 1024, 64⟩
def fuel : Fuel := ⟨512, 8, 3, 1⟩
def program : List LarkCollective.Instr := [(.scalar (.index 0 .bid)), (.scalar (.index 1 .tid)), (.scalar (.index 2 (.mod (.ivar (1)) (.const (32))))), (.scalar (.index 3 (.div (.ivar (1)) (.const (32))))), (.scalar (.index 4 (.const (0)))), (.scalar (.branch (.lt (.ivar (4)) (.const (2))) 16)), (.scalar (.index 5 (.const (0)))), (.scalar (.branch (.lt (.ivar (5)) (.const (8))) 14)), (.scalar (.index 6 (.add (.mul (.add (.mul (.ivar (4)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (5))))), (.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (6))))), (.scalar (.index 8 (.add (.mul (.ivar (4)) (.const (8))) (.ivar (5))))), (.scalar (.store .local 0 (.ivar (8)) (.load .global 1 (.ivar (7))))), (.scalar (.index 5 (.add (.ivar (5)) (.const (1))))), (.scalar (.jump 7)), (.scalar (.index 4 (.add (.ivar (4)) (.const (1))))), (.scalar (.jump 5)), (.scalar (.index 9 (.const (0)))), (.scalar (.branch (.lt (.ivar (9)) (.const (2))) 27)), (.scalar (.index 10 (.const (0)))), (.scalar (.branch (.lt (.ivar (10)) (.const (8))) 25)), (.scalar (.index 11 (.add (.mul (.add (.mul (.ivar (9)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (10))))), (.scalar (.index 12 (.add (.mul (.ivar (9)) (.const (8))) (.ivar (10))))), (.scalar (.store .local 1 (.ivar (12)) (.load .global 2 (.ivar (11))))), (.scalar (.index 10 (.add (.ivar (10)) (.const (1))))), (.scalar (.jump 19)), (.scalar (.index 9 (.add (.ivar (9)) (.const (1))))), (.scalar (.jump 17)), (.scalar (.assign 0 (.lit (0) 1))), (.scalar (.assign 1 (.lit (0) 1))), (.scalar (.index 13 (.const (0)))), (.scalar (.branch (.lt (.ivar (13)) (.const (2))) 44)), (.scalar (.index 14 (.const (0)))), (.scalar (.branch (.lt (.ivar (14)) (.const (4))) 42)), (.scalar (.index 15 (.add (.mul (.ivar (13)) (.const (8))) (.mul (.ivar (14)) (.const (2)))))), (.scalar (.assign 2 (.un .fromHalf (.load .local 0 (.ivar (15)))))), (.scalar (.assign 3 (.un .fromHalf (.load .local 0 (.add (.ivar (15)) (.const (1))))))), (.scalar (.assign 4 (.bin .mul (.reg (2)) (.reg (2))))), (.scalar (.assign 5 (.bin .mul (.reg (3)) (.reg (3))))), (.scalar (.assign 6 (.bin .add (.reg (4)) (.reg (5))))), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (6))))), (.scalar (.index 14 (.add (.ivar (14)) (.const (1))))), (.scalar (.jump 32)), (.scalar (.index 13 (.add (.ivar (13)) (.const (1))))), (.scalar (.jump 30)), (.shuffle .xor 1 0 (.const (16)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (8)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (4)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (2)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (1)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (2)) (.const (0))) 56)), (.scalar (.store .shared 0 (.ivar (3)) (.reg (0)))), (.scalar (.barrier .block)), (.scalar (.branch (.eq (.ivar (3)) (.const (0))) 76)), (.scalar (.assign 7 (.lit (0) 1))), (.scalar (.branch (.lt (.ivar (1)) (.const (32))) 61)), (.scalar (.assign 7 (.load .shared 0 (.ivar (1))))), (.scalar (.assign 8 (.lit (0) 1))), (.shuffle .xor 8 7 (.const (16)) 32), (.scalar (.assign 7 (.bin .add (.reg (7)) (.reg (8))))), (.shuffle .xor 8 7 (.const (8)) 32), (.scalar (.assign 7 (.bin .add (.reg (7)) (.reg (8))))), (.shuffle .xor 8 7 (.const (4)) 32), (.scalar (.assign 7 (.bin .add (.reg (7)) (.reg (8))))), (.shuffle .xor 8 7 (.const (2)) 32), (.scalar (.assign 7 (.bin .add (.reg (7)) (.reg (8))))), (.shuffle .xor 8 7 (.const (1)) 32), (.scalar (.assign 7 (.bin .add (.reg (7)) (.reg (8))))), (.scalar (.assign 9 (.bin .div (.reg (7)) (.lit (16384) 1)))), (.scalar (.assign 10 (.bin .add (.reg (9)) (.lit (1) 100000)))), (.scalar (.assign 11 (.un .rsqrt (.reg (10))))), (.scalar (.store .shared 0 (.ivar (1)) (.reg (11)))), (.scalar (.barrier .block)), (.scalar (.assign 12 (.load .shared 0 (.ivar (3))))), (.scalar (.index 16 (.const (0)))), (.scalar (.branch (.lt (.ivar (16)) (.const (2))) 97)), (.scalar (.index 17 (.const (0)))), (.scalar (.branch (.lt (.ivar (17)) (.const (4))) 95)), (.scalar (.index 18 (.add (.mul (.ivar (16)) (.const (8))) (.mul (.ivar (17)) (.const (2)))))), (.scalar (.assign 13 (.un .fromHalf (.load .local 0 (.ivar (18)))))), (.scalar (.assign 14 (.un .fromHalf (.load .local 0 (.add (.ivar (18)) (.const (1))))))), (.scalar (.assign 15 (.un .fromHalf (.load .local 1 (.ivar (18)))))), (.scalar (.assign 16 (.un .fromHalf (.load .local 1 (.add (.ivar (18)) (.const (1))))))), (.scalar (.assign 17 (.bin .mul (.reg (13)) (.reg (12))))), (.scalar (.assign 18 (.bin .mul (.reg (17)) (.reg (15))))), (.scalar (.assign 19 (.bin .mul (.reg (14)) (.reg (12))))), (.scalar (.assign 20 (.bin .mul (.reg (19)) (.reg (16))))), (.scalar (.store .local 2 (.ivar (18)) (.un .toHalf (.reg (18))))), (.scalar (.store .local 2 (.ivar (18)) (.un .toHalf (.reg (20))))), (.scalar (.index 17 (.add (.ivar (17)) (.const (1))))), (.scalar (.jump 81)), (.scalar (.index 16 (.add (.ivar (16)) (.const (1))))), (.scalar (.jump 79)), (.scalar (.index 19 (.const (0)))), (.scalar (.branch (.lt (.ivar (19)) (.const (2))) 109)), (.scalar (.index 20 (.const (0)))), (.scalar (.branch (.lt (.ivar (20)) (.const (8))) 107)), (.scalar (.index 21 (.add (.mul (.add (.mul (.ivar (19)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (20))))), (.scalar (.index 22 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (21))))), (.scalar (.index 23 (.add (.mul (.ivar (19)) (.const (8))) (.ivar (20))))), (.scalar (.store .global 0 (.ivar (22)) (.load .local 2 (.ivar (23))))), (.scalar (.index 20 (.add (.ivar (20)) (.const (1))))), (.scalar (.jump 100)), (.scalar (.index 19 (.add (.ivar (19)) (.const (1))))), (.scalar (.jump 98)), (.scalar .halt)]
-- The closed reference AST is checked before this fixed mathematical interpretation
-- is emitted. Half/float conversions are identities in the exact-real model.
noncomputable def reference (input : Nat → Nat → ℝ) (row col : Nat) : ℝ :=
  input 1 (row * 16384 + col) *
    (1 / Real.sqrt ((((List.range 16384).map fun j =>
      input 1 (row * 16384 + j) * input 1 (row * 16384 + j)).sum) / 16384 + 1 / 100000)) * input 2 col
noncomputable def spec (input : Nat → Nat → ℝ) : List ℝ :=
  (List.range (1 * 16384)).map fun i => reference input (i / 16384) (i % 16384)
theorem reference_data (input : Nat → Nat → ℝ) :
    spec input = LarkReal.NativeSglangRmsNorm.canonical_spec shape input := by
  have value_eq : reference input = LarkReal.NativeSglangRmsNorm.canonical input := by
    funext row col
    have squares_eq : LarkReal.NativeSglangRmsNorm.rowSquare input row =
        (fun j => input 1 (row * 16384 + j) * input 1 (row * 16384 + j)) := by rfl
    simp only [reference, LarkReal.NativeSglangRmsNorm.canonical, squares_eq, zero_add]
  exact congrArg (fun value : Nat → Nat → ℝ =>
    (List.range (1 * 16384)).map (fun i => value (i / 16384) (i % 16384))) value_eq
theorem layout_data : layout = LarkNativeSglangRmsNorm.layout shape := by rfl
theorem geometry_data : geometry = LarkNativeSglangRmsNorm.geometry shape := by rfl
theorem fuel_data : fuel = LarkNativeSglangRmsNorm.fuel := by rfl
theorem program_data : program = (LarkNativeSglangRmsNorm.program true) := by decide
theorem segmentation_data : program = (LarkNativeSglangRmsNorm.program true) := program_data
theorem segmentation (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program (initial layout input outside) =
      some (LarkNativeSglangRmsNorm.finalState shape LarkReal.ops input outside) := by
  rewrite [segmentation_data, layout_data, geometry_data, fuel_data]
  exact (LarkNativeSglangRmsNorm.final_exec shape LarkReal.ops input outside).1
theorem race_free (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    raceFree geometry (LarkNativeSglangRmsNorm.finalState shape LarkReal.ops input outside).trace = true := by
  rewrite [geometry_data]
  exact (LarkNativeSglangRmsNorm.final_exec shape LarkReal.ops input outside).2
theorem segment_equivalence (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    extract layout (LarkNativeSglangRmsNorm.finalState shape LarkReal.ops input outside) = some (spec input) := by
  have hs : LarkNativeSglangRmsNorm.spec shape LarkReal.ops input = spec input :=
    (LarkReal.NativeSglangRmsNorm.spec_eq shape input).trans (reference_data input).symm
  rewrite [layout_data]
  exact (LarkNativeSglangRmsNorm.final_extract shape LarkReal.ops input outside).trans (congrArg some hs)
theorem kernel_eq_spec :
    LarkPartitionCollective.Correct LarkReal.ops layout geometry fuel program spec := by
  intro input outside
  exact ⟨LarkNativeSglangRmsNorm.finalState shape LarkReal.ops input outside,
    segmentation input outside, race_free input outside, segment_equivalence input outside⟩
theorem kernel_eq_spec_pre (input : Nat → Nat → ℝ) (s : State ℝ) (pre : StdPre layout input s) :
    ∃ final, LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec input) := by
  obtain ⟨outside, rfl⟩ := pre
  exact kernel_eq_spec input outside
#print axioms reference_data
#print axioms program_data
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
