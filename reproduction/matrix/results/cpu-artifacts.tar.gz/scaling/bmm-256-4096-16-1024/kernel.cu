extern "C" __global__ void induction_bmm_hip_256_4096_16_1024(const __half* a, const __half* b, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 16) {
    acc = acc + __half2float(a[(i / 4194304) * 65536 + (((i / 1024) % 4096) * 16 + j)]) * __half2float(b[(i / 4194304) * 16384 + (j * 1024 + i % 1024)]);
    j++;
  }
  out[i] = __float2half(acc);
}
