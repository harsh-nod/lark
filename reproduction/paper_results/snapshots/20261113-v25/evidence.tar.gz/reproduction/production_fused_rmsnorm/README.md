# Native in-place fused add RMSNorm

This independently implements the paper's `sglang_fused_add_rmsnorm` family.
The complete native seeded-inout launch, actual-trace race freedom and both
canonical-real reference buffers are proved for the closed shape family.
The [real certificate](REAL.md) extends the source-ordered proof and exports
`native-fused-rmsnorm-real-v18`. Numerical validation has also run on both AMD
hosts. IEEE/error bounds and reproduction of the original production result
remain open; the authors' adapted source is unavailable at the inspected endpoints.

The [provenance record](provenance.json) pins SGLang commit
`fc32cbff6983c7573f4b60eab8b44815668130a0`, independently selected before the
preprint date. Its
[wrapper](https://github.com/sgl-project/sglang/blob/fc32cbff6983c7573f4b60eab8b44815668130a0/python/sglang/kernels/aot/csrc/elementwise/fused_add_rms_norm_kernel.cu)
calls FlashInfer. The pinned
[build file](https://github.com/sgl-project/sglang/blob/fc32cbff6983c7573f4b60eab8b44815668130a0/python/sglang/kernels/aot/CMakeLists.txt)
selects FlashInfer commit `bc29697ba20b7e6bdb728ded98f04788e16ee021`; its
[actual kernel and host launch](https://github.com/flashinfer-ai/flashinfer/blob/bc29697ba20b7e6bdb728ded98f04788e16ee021/include/flashinfer/norm.cuh)
are retained locally with their licenses. This does not identify the authors'
original adapted source or experiment revision.

The fixed profile uses FP16 `[rows,16384]` input/residual buffers, FP16 weights,
`1 <= rows <= 255`, 1,024 threads and physical wave64. Each physical wave contains
two complete logical32 XOR-reduction groups. The source retains two block
barriers, eight-element ownership and both vector rounds. Identical shared
stores are guarded by their unique writer; vector accesses are scalarized.
The host supplies three mutually disjoint, contiguous, aligned buffers.

Both `input` and `residual` start initialized and are updated in place. The
kernel computes their sum in FP32, stores its FP16-rounded form in `residual`,
and retains the **unrounded FP32 sum** in shared memory for normalization into
`input`. Reading back the rounded residual for that last step changes the
floating-point algorithm. Weight remains read-only.

## Proof components and limits

The scoped development reader maps the two in-out buffers to writable cells of
the existing machine and initializes them using `LarkInOut.initial`. The pinned
scalar/collective machine definitions and ordinary reader acceptance rules are
unchanged. The ordinary task parser still refuses this in-out task. The separate
`verify-native-fused-rmsnorm` command uses its closed in-out contract and the
complete canonical-real proof. The historical packets below retain the claims
and open obligations at each checkpoint; the latest reference proof is described
in [REAL.md](REAL.md).

The [frozen component packet](results/components-v1/results.json) freshly builds
11 local Lean modules, replays the frozen Python reader, checks exact IR/layout/
geometry/fuel/interface binding and audits 40 results. Nine false claims are
rejected, including omitted mutable initialization, read-only weight writes,
foreign-owner initialization, missing barriers and changed source operations.
An [independent archive replay](results/components-validation-v1/results.json)
rebuilds from an empty directory with Git unavailable and no seeded own Lean
objects, repeating the reader check and all nine refusals.

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42953296625) passed
at experiment-source commit `d35cd2042d839fa07d29ee1f76bfa75f26c4893d`, including
the new component checker and 165 ordinary tests (nine optional tests skipped).
The [saved responses/logs](results/ci-v1/results.json) distinguish these component
checks from a complete fused-kernel proof. The real-semantics job rechecks the
earlier existing real-certified profiles; this new family has no real source
certificate yet. Later evidence/replay metadata is validated separately.

The sufficient footprint theorem proves race freedom **if** every actual access
satisfies its classification. Deriving that classification and successful
execution from the full source was open at the component checkpoint and is
established by the later whole-launch proof. A separate finite value-erased run
for one row halts at PC71/epoch2 and checks 115,777 accesses; it is not a universal
trace theorem, numerical evaluation or source certificate.

The later [scalar-prefix proof](../../lean/Lark/NativeFusedRmsNormPrefix.lean)
connects the actual seeded initializer to PC23, immediately before the first
logical32 shuffle. For every valid lane, every row count 1..255, arbitrary
abstract arithmetic operations, inputs and outside memory, it proves the actual
210-instruction execution with the existing 512-instruction lane fuel. Both
rounds complete all 16 owned values: residual receives `toHalf(x)`, shared memory
receives the separate unrounded `x`, its owned input cells remain unchanged,
and register zero contains the source-ordered sum of squares. The actual prefix contains 64
accesses; classification and race freedom follow without assuming either.

The [standalone prefix packet](results/scalar-prefix-v1/results.json) includes
the source/reader, complete local Lean import closure, axiom audits, positive
nonidentity-cast witnesses, four changed-source refusals and six false-value/
counter/endpoint refusals. The source, interface, launch geometry and fuel stay
pinned to the existing development case. This is a per-lane prefix theorem;
native scheduling across lanes, logical32 reductions, barriers, normalized
outputs, final halt, whole-launch classification and canonical-real equivalence
are still open. The older component/GPU packets retain their original flags.
An [independent archive replay](results/scalar-prefix-validation-v1/results.json)
rebuilds all 18 modules, repeats all 89 audits and ten refusals, and checks the
positive witnesses from the archive with no Git available on PATH and no cached
own Lean objects. The archived reader verifies exact source/IR/interface binding.

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42960404492) passed
at scalar-prefix source commit `b768edfd5263c879192b9d417c85b2627459f7ad`,
including the new fresh-prefix step and 165 ordinary tests (nine optional skips).
The [saved source-CI evidence](results/scalar-prefix-ci-v1/results.json) records
the exact head and scope. This adds no whole-source or real fused certificate.

The later [native-wave theorem](../../lean/Lark/NativeFusedRmsNormFirstWave.lean)
composes the sequential lane fold, all five actual snapshot XOR/add stages and
both distinct partial stores under `LarkPartitionCollective.runWarp`, with the
unchanged fuel. Every lane ends at PC35, the first block barrier. The physical
wave64 contains two complete logical32 groups. Their partial results select
lane0 and lane32 respectively, preserving the source order under arbitrary
arithmetic operations; the proof assumes no commutativity or uniform lane sums.
All 16 rounded residual/unrounded shared values per lane and owned input cells
are retained, epochs do not change, and the actual wave trace is classified and
proved race-free without assuming race freedom.

The [first-wave packet](results/first-wave-v1/results.json) freshly builds 29
standard-library-only Lean modules, audits 204 results, checks exact
source/reader/IR/interface binding and rejects 20 false claims. It adds controls
for crossed logical partitions, an omitted second
partial writer, aliased partial cells, changed XOR order and reversed operand
order under a noncommutative arithmetic witness. The
[independent archive replay](results/first-wave-validation-v1/results.json)
repeats the build, axiom audits, positive witnesses and every rejection with Git
unavailable and no cached own Lean objects. These theorems cover arbitrary inputs,
operations and outside memory, rows1..255, and physical waves0..15.

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42964138741) passed
at first-wave source commit `cd665d0a696f0367767cb2b217f010156f93ee38`.
The fresh first-wave step and 165 ordinary tests (nine optional skips) passed;
the [saved source-CI evidence](results/first-wave-ci-v1/results.json) records the
exact head and scope. The real job checks earlier real-certified profiles;
this fused family still has no canonical-real or whole-launch certificate.

The updated replay tool also
[rechecks the original scalar-prefix packet](results/scalar-prefix-compatibility-v1/results.json),
repeating its 18-module build, 89 audits and ten refusals. Its default lane-stage
generator and proof closure are
[byte-identical to the earlier archive](results/scalar-prefix-compatibility-v1/default-generation-comparison.json).

The later [first-block-phase proof](../../lean/Lark/NativeFusedRmsNormFirstBlock.lean)
composes the exact sequential `runWarp` calls for all 16 physical waves. It
preserves earlier results and unread cells of later waves. Every one of the
16,384 residual cells receives its rounded sum, all 16,384 shared cells retain
the unrounded sums, all 32 partial slots have their source-ordered logical-group
results, and all 1,024 threads converge at the source's first block barrier.

The [barrier theorem](../../lean/Lark/NativeFusedRmsNormBarrier.lean) then
decomposes the actual `runBlock` call with fuel3 into the remaining call with
fuel2. All participating PCs advance from 35 to 36 and their block epochs from
zero to one. Memory, read-only weights and historical trace epochs remain
unchanged. Actual-prefix classification and race freedom are derived for every
input, outside memory and arithmetic interpretation, for every valid block in
the rows1..255 profile. This proves the first block phase and resume, not the
complete block or grid execution.

The [first-block packet](results/first-block-v1/results.json) freshly checks 33
local Lean modules, 251 axiom audits and 31 rejection controls. New controls
cover omitted barrier/source changes, the last physical wave, the next-block
boundary, partial-cell separation, PC/epoch participation and preservation of
historical trace records. The
[independent archive replay](results/first-block-validation-v1/results.json)
repeats all checks with Git unavailable and no cached own Lean objects. The
earlier lane and first-wave generators/proof closures remain byte-identical to
their archived versions, as recorded in the
[source comparison receipt](results/first-block-compatibility-v1/results.json).

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42966727590) passed
at first-block-phase source commit `059ca70808c877d4a2cca8664aff73192250fb9a`,
including its fresh prefix check and 165 ordinary tests (nine optional skips).
The [saved source-CI evidence](results/first-block-ci-v1/results.json) records
the exact head and scope. The real job rechecks earlier certified profiles;
this adds no fused canonical-real or complete source certificate.

The later [second-phase proof](../../lean/Lark/NativeFusedRmsNormScaleBlock.lean)
executes the actual mixed physical wave after the first barrier. Exactly 32
threads load the shared partials, while the upper32 wait at PC50. The unchanged
scheduler selects the active logical32 cohort for all five snapshot XOR/add
stages and still visits every parked physical lane in order. Only tid0 stores
the final source-ordered total. All 15 remaining physical waves execute their
inactive path, so all 1,024 participants converge at the second block barrier.

The [second-resume theorem](../../lean/Lark/NativeFusedRmsNormOutBarrier.lean)
composes both actual block phases and barrier resumes. The original `runBlock`
call with fuel3 equals the remaining output-phase call with fuel1, entering
PC51/block epoch2. The total, every rounded residual and separate unrounded
shared value, read-only weights and historical trace epochs are retained.
Actual-prefix classification and race freedom are derived for all valid blocks,
all rows1..255 and arbitrary arithmetic, inputs and outside memory. The proof
preserves operand order and chooses logical lane0; it assumes no commutativity
or uniform per-lane sums.

The [two-phase packet](results/second-block-v1/results.json) rebuilds all 46
local Lean modules, audits 349 declarations using only the standard Lean axioms,
and rejects 46 false claims. Its
[independent archive replay](results/second-block-validation-v1/results.json)
repeats all checks from the frozen source/reader and full local Lean closure,
including positive witnesses and all earlier and new rejection controls. New controls cover the
active/inactive boundary, exact mixed-cohort selection, changed source guards
and shuffles, unique unrounded total storage, second-resume PCs/epochs and
unchanged historical access epochs. Replay requires no Git, cached own Lean
objects, GPU or model calls. The earlier three stage generators/proof closures
remain byte-identical to their archived versions, as recorded in the
[source comparison receipt](results/second-block-compatibility-v1/results.json).

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42971700790) passed
at second-block-phase source commit `433f04a44b813ce6bcef8a7c12b0ff192eb8bb7e`,
including the fresh 46-module/349-audit/46-control check and 165 ordinary tests
(nine optional skips). The [saved source-CI evidence](results/second-block-ci-v1/results.json)
records the exact head, raw logs and scope. The real job rechecks earlier
certified profiles; it adds no fused canonical-real or complete source certificate.

The later [output-lane proof](../../lean/Lark/NativeFusedRmsNormOutputLane.lean)
executes the actual 192 instructions from PC51 through normalization, both
output rounds, both false loop exits and halt at PC71. It retains the exact
division/epsilon/rsqrt order, unrounded shared loads, explicit `0 + weight`, both
multiplies and the final half cast. Every valid lane stores all sixteen of its
output values and records exactly 49 accesses. The
[frame theorem](../../lean/Lark/NativeFusedRmsNormOutputFrame.lean) proves
all other memory cells retain their exact values, including every residual,
shared, weight and outside cell. Actual-trace classification/race freedom and
unchanged epochs follow for arbitrary operations and inputs from the proved
second-barrier state, without race-freedom assumptions.

The [output-lane packet](results/output-lane-v1/results.json) rebuilds all 53
local Lean modules, audits 407 declarations using only the standard Lean axioms,
and rejects 63 false claims. Its
[independent archive replay](results/output-lane-validation-v1/results.json)
repeats all 66 checks from the full frozen source/reader/proof closure, including
positive concrete witnesses and earlier/new false-claim controls. New controls cover
skipped output rounds, premature rounding, changed divisor/epsilon/literal bias,
swapped multiplies, changed half-store values, wrong output buffers/strides,
missing casts, wrong halt and missing trace accesses. All four earlier stage
generators/proof closures remain byte-identical to their archived versions, as
recorded in the [source comparison receipt](results/output-lane-compatibility-v1/results.json).

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42975198726) passed
at output-lane source commit `b92a9414de5a7f6d188295c2044833fc56a5cf40`, including
the fresh 53-module/407-audit/63-control check and 165 ordinary tests (nine
optional skips). The [saved source-CI evidence](results/output-lane-ci-v1/results.json)
records the exact head, raw logs and scope. The real job rechecks earlier
certified profiles; it adds no fused canonical-real or complete source certificate.

The later [whole-launch proof](../../lean/Lark/NativeFusedRmsNormCorrect.lean)
composes the actual physical output waves, complete blocks and source grid.
Every thread reaches halt at PC71. Every row retains all 16,384 normalized
outputs and 16,384 rounded residuals; later rows preserve completed values and
the original operands of rows still waiting to run. It derives actual full-trace
classification/race freedom without assuming race freedom. The unchanged source,
geometry and fuel are bound to the theorem for all rows1..255 and arbitrary
operations, inputs and outside memory.

The [seeded-inout correctness relation](../../lean/Lark/InOutPartition.lean)
requires a valid mutable-buffer declaration and the actual initialized mutable
precondition. The original extractor returns normalized buffer0 followed by
rounded residual buffer1. The specification preserves the exact source-order
reduction tree, division/epsilon/rsqrt sequence, unrounded shared reads, literal
zero weight add, multiplies and final casts. It is not an independent
canonical-real reference theorem or an IEEE/error-bound result.

The [whole-launch packet](results/whole-launch-v1/results.json) rebuilds all 66
local Lean modules, audits 514 declarations using only the standard Lean axioms,
and rejects 77 false claims. Its
[independent archive replay](results/whole-launch-validation-v1/results.json)
repeats all 80 checks from the frozen source/reader/proof closure, including the
positive examples and all earlier/new rejection controls. New controls cover
unseeded mutable buffers, insufficient block/grid fuel, wrong native geometry,
wrong extraction order or missing/extra buffers, cross-row write footprints,
readonly weights, the last output writer, other-row controls and omitted or
duplicated output waves. The five earlier generators and proof closures remain
byte-identical, as recorded in the
[source comparison receipt](results/whole-launch-compatibility-v1/results.json).
The [wheel audit](results/whole-launch-packaging-v1/results.json) checks that all
66 local proof sources, including the seeded-inout correctness relation, are
packaged byte-for-byte. Two
[rehashed stage-claim controls](results/whole-launch-stage-guards-v2/results.json)
are separately rejected before extraction/build: an earlier packet relabeled as
whole-launch and a whole-launch report missing its extraction theorem audit.
These two preflight checks are separate from the 77 Lean false-claim controls.

[Both CI jobs](https://github.com/harsh-nod/lark/actions/runs/42981079794) passed
at whole-launch source commit `ca0c9e3cab1c1eca0a88d37b1e9bb7fc2ac7af02`.
The [saved CI packet](results/whole-launch-ci-v1/results.json) includes raw job
responses and logs, the fresh whole-launch rebuild, both stage guards and165
ordinary tests with9 optional skips. This checks the source-ordered checkpoint;
the later [real profile](REAL.md) adds the independent reference bridge.

The whole-launch packet proves source-ordered machine correctness; its independent
reference bridge is supplied by the later [canonical-real packet](REAL.md).
IEEE/error bounds and original paper results remain open. All older frozen
packets retain their original flags and certificate counts. A later
[bounded public-release recheck](results/whole-launch-artifact-recheck-v1/results.json)
found no original release at the inspected endpoints: KernelCraft remained
empty, the related benchmark head was unchanged, and the title search returned
only this independent repository. This does not exclude other authors, branches,
unindexed/private files or future releases. No authors were contacted.

```bash
# Lean 4.19.0, standard library only; fresh output outside the checkout:
python3 reproduction/production_fused_rmsnorm/check_program.py --output /tmp/fused-components
python3 reproduction/production_fused_rmsnorm/check_prefix.py --output /tmp/fused-scalar-prefix
python3 reproduction/production_fused_rmsnorm/check_prefix.py --stage first-wave --output /tmp/fused-first-wave
python3 reproduction/production_fused_rmsnorm/check_prefix.py --stage first-block --output /tmp/fused-first-block
python3 reproduction/production_fused_rmsnorm/check_prefix.py --stage second-block --output /tmp/fused-second-block
python3 reproduction/production_fused_rmsnorm/check_prefix.py --stage output-lane --output /tmp/fused-output-lane
python3 reproduction/production_fused_rmsnorm/check_prefix.py --stage whole-launch --output /tmp/fused-whole-launch
python3 reproduction/production_fused_rmsnorm/check_replay_stages.py --output /tmp/fused-stage-guards --lean-bin /path/to/lean-4.19.0/bin
python3 -m unittest discover -s tests -p test_native_fused_rmsnorm.py -v
```

```bash
python3 reproduction/production_fused_rmsnorm/replay_prefix.py \
  --packet reproduction/production_fused_rmsnorm/results/scalar-prefix-v1 \
  --output /tmp/fused-prefix-archive-replay --lean-bin /path/to/lean-4.19.0/bin
# Other archived stages: results/first-wave-v1, results/first-block-v1,
# results/second-block-v1, results/output-lane-v1, or results/whole-launch-v1.
```

## Finite AMD results

Each host ran 24 paired trials: rows 1, 3, 64 and 255, with six finite input
families including signed zeros, halfway rounding, cancellation and mixed
magnitudes. One method is the scalarized HIP adaptation. The comparison retains
the selected upstream template body verbatim while explicitly replacing CUDA
shuffle/rsqrt and vector helpers with HIP helpers. It is not unchanged NVIDIA
kernel execution or a proof of helper/compiler equivalence.

| Host | Normalized CPU-double comparisons | Exact residual-bit comparisons | Failures |
| --- | ---: | ---: | ---: |
| mi350 | 63,504,384 | 63,504,384 | 0 |
| mi350-2 | 63,504,384 | 63,504,384 | 0 |

The independent audit recomputes every reference from the original FP16 input,
residual and weight bytes. Normalized values use `0.002 + 0.002 * abs(reference)`;
maximum absolute error is `0.0037352077129462202`. Residual storage matches the
FP32-add/FP16-store oracle exactly for both methods. All allocation guards and
read-only weights pass. Compiler-reported inputs are captured: 318 files on
`mi350`, 313 on `mi350-2`.

Per host, normalized method streams differ at 3,084,098 signed-zero values and
475 other values, each of the latter by one FP16 ULP. The residual streams are
bit-identical. All four streams match between hosts. These finite observations
are not an IEEE equivalence or numerical-error theorem.

Three fully rehashed audit controls reject an invented source certificate,
original-paper completion and a nonfinite output. No paid endpoints or model
calls are used. The original production adaptation, historical agent results,
NVIDIA measurements and full upstream API remain unreproduced.

The [numerical/source packet](results/native-v1/report.json) binds experiment-code
commit `d35cd2042d839fa07d29ee1f76bfa75f26c4893d`. Individual compressed streams
preserve the prepared operands, references and all four outputs on each host;
compiler-reported dependencies and the exact comparison driver are included.
The [numerical replay validation](results/numerical-validation-v1/results.json)
restores the packet outside the checkout and regenerates its audit report byte
for byte. A fully rehashed archive-traversal control is rejected before writing
the parent-directory target. The replay uses Python and NumPy, with no GPU,
Lean, Git or model calls:

```bash
python3 reproduction/production_fused_rmsnorm/replay_packet.py \
  --packet reproduction/production_fused_rmsnorm/results/native-v1 --output /tmp/fused-replay
```

```bash
python3 reproduction/production_fused_rmsnorm/prepare_gpu.py --output /tmp/fused-input
# On each available AMD host after copying that frozen directory:
HIP_VISIBLE_DEVICES=0 python3 /tmp/fused-input/run_gpu.py --input /tmp/fused-input --output /tmp/fused-device
# Retrieve both host directories, then recompute all references on a CPU:
python3 reproduction/production_fused_rmsnorm/audit_gpu.py --input /tmp/fused-input \
  --host /tmp/fused-mi350 --host /tmp/fused-mi350-2 --output /tmp/fused-audit.json
python3 reproduction/production_fused_rmsnorm/check_audit_controls.py --input /tmp/fused-input \
  --host /tmp/fused-mi350 --output /tmp/fused-controls
```
