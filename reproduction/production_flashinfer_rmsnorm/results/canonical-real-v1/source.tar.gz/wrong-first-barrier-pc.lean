import LarkReal.NativeFlashInferRmsNorm
open LarkNativeFlashInferRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
example : program[32]? = some (.scalar (.barrier .block)) := by decide
