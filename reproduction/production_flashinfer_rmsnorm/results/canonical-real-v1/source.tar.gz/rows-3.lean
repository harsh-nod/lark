import LarkReal.NativeFlashInferRmsNorm
namespace LarkCertificate
open LarkNonlinear
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeFlashInferRmsNorm.Shape := ⟨3, by decide, by decide⟩
def layout : Layout := ⟨[⟨.output, 49152⟩, ⟨.input, 49152⟩, ⟨.input, 16384⟩],
  [32], []⟩
def geometry : Geometry := ⟨3, 1024, 64⟩
def fuel : Fuel := ⟨512, 8, 3, 1⟩
def program : List LarkCollective.Instr := [(.scalar (.index 0 .bid)), (.scalar (.index 1 .tid)), (.scalar (.index 2 (.mod (.ivar (1)) (.const (32))))), (.scalar (.index 3 (.div (.ivar (1)) (.const (32))))), (.scalar (.assign 0 (.lit (0) 1))), (.scalar (.assign 1 (.lit (0) 1))), (.scalar (.index 4 (.const (0)))), (.scalar (.branch (.lt (.ivar (4)) (.const (2))) 19)), (.scalar (.index 5 (.const (0)))), (.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)), (.scalar (.index 6 (.add (.mul (.add (.mul (.ivar (4)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (5))))), (.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (6))))), (.scalar (.assign 2 (.un .fromHalf (.load .global 1 (.ivar (7)))))), (.scalar (.assign 3 (.bin .mul (.reg (2)) (.reg (2))))), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (3))))), (.scalar (.index 5 (.add (.ivar (5)) (.const (1))))), (.scalar (.jump 9)), (.scalar (.index 4 (.add (.ivar (4)) (.const (1))))), (.scalar (.jump 7)), (.shuffle .xor 1 0 (.const (16)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (8)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (4)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (2)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (1)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (2)) (.const (0))) 31)), (.scalar (.store .shared 0 (.ivar (3)) (.reg (0)))), (.scalar (.barrier .block)), (.scalar (.branch (.lt (.ivar (1)) (.const (32))) 46)), (.scalar (.assign 0 (.load .shared 0 (.ivar (1))))), (.shuffle .xor 1 0 (.const (16)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (8)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (4)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (2)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (1)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (1)) (.const (0))) 46)), (.scalar (.store .shared 0 (.const (0)) (.reg (0)))), (.scalar (.barrier .block)), (.scalar (.assign 4 (.load .shared 0 (.const (0))))), (.scalar (.assign 5 (.bin .div (.reg (4)) (.lit (16384) 1)))), (.scalar (.assign 6 (.bin .add (.reg (5)) (.lit (1) 100000)))), (.scalar (.assign 7 (.un .rsqrt (.reg (6))))), (.scalar (.index 8 (.const (0)))), (.scalar (.branch (.lt (.ivar (8)) (.const (2))) 67)), (.scalar (.index 9 (.const (0)))), (.scalar (.branch (.lt (.ivar (9)) (.const (8))) 65)), (.scalar (.index 10 (.add (.mul (.add (.mul (.ivar (8)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (9))))), (.scalar (.index 11 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (10))))), (.scalar (.assign 8 (.un .fromHalf (.load .global 1 (.ivar (11)))))), (.scalar (.assign 9 (.un .fromHalf (.load .global 2 (.ivar (10)))))), (.scalar (.assign 10 (.bin .add (.lit (0) 1) (.reg (9))))), (.scalar (.assign 11 (.bin .mul (.reg (8)) (.reg (7))))), (.scalar (.assign 12 (.bin .mul (.reg (11)) (.reg (10))))), (.scalar (.store .global 0 (.ivar (11)) (.un .toHalf (.reg (12))))), (.scalar (.index 9 (.add (.ivar (9)) (.const (1))))), (.scalar (.jump 54)), (.scalar (.index 8 (.add (.ivar (8)) (.const (1))))), (.scalar (.jump 52)), (.scalar .halt)]
-- The closed reference AST is checked before this fixed mathematical interpretation
-- is emitted. Half/float conversions are identities in the exact-real model.
noncomputable def reference (input : Nat → Nat → ℝ) (row col : Nat) : ℝ :=
  input 1 (row * 16384 + col) *
    (1 / Real.sqrt ((((List.range 16384).map fun j =>
      input 1 (row * 16384 + j) * input 1 (row * 16384 + j)).sum) / 16384 + 1 / 100000)) * (0 + input 2 col)
noncomputable def spec (input : Nat → Nat → ℝ) : List ℝ :=
  (List.range (3 * 16384)).map fun i => reference input (i / 16384) (i % 16384)
theorem reference_data (input : Nat → Nat → ℝ) :
    spec input = LarkReal.NativeFlashInferRmsNorm.canonical_spec shape input := by
  have value_eq : reference input = LarkReal.NativeFlashInferRmsNorm.canonical input := by
    funext row col
    have squares_eq : LarkReal.NativeFlashInferRmsNorm.rowSquare input row =
        (fun j => input 1 (row * 16384 + j) * input 1 (row * 16384 + j)) := by rfl
    simp only [reference, LarkReal.NativeFlashInferRmsNorm.canonical, squares_eq, zero_add]
  exact congrArg (fun value : Nat → Nat → ℝ =>
    (List.range (3 * 16384)).map (fun i => value (i / 16384) (i % 16384))) value_eq
theorem layout_data : layout = LarkNativeFlashInferRmsNorm.layout shape := by rfl
theorem geometry_data : geometry = LarkNativeFlashInferRmsNorm.geometry shape := by rfl
theorem fuel_data : fuel = LarkNativeFlashInferRmsNorm.fuel := by rfl
theorem program_data : program = LarkNativeFlashInferRmsNorm.program := by decide
theorem segmentation_data : program = LarkNativeFlashInferRmsNorm.program := program_data
theorem segmentation (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program (initial layout input outside) =
      some (LarkNativeFlashInferRmsNorm.finalState shape LarkReal.ops input outside) := by
  rewrite [segmentation_data, layout_data, geometry_data, fuel_data]
  exact (LarkNativeFlashInferRmsNorm.final_exec shape LarkReal.ops input outside).1
theorem race_free (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    raceFree geometry (LarkNativeFlashInferRmsNorm.finalState shape LarkReal.ops input outside).trace = true := by
  rewrite [geometry_data]
  exact (LarkNativeFlashInferRmsNorm.final_exec shape LarkReal.ops input outside).2
theorem segment_equivalence (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    extract layout (LarkNativeFlashInferRmsNorm.finalState shape LarkReal.ops input outside) = some (spec input) := by
  have hs : LarkNativeFlashInferRmsNorm.spec shape LarkReal.ops input = spec input :=
    (LarkReal.NativeFlashInferRmsNorm.spec_eq shape input).trans (reference_data input).symm
  rewrite [layout_data]
  exact (LarkNativeFlashInferRmsNorm.final_extract shape LarkReal.ops input outside).trans (congrArg some hs)
theorem kernel_eq_spec :
    LarkPartitionCollective.Correct LarkReal.ops layout geometry fuel program spec := by
  intro input outside
  exact ⟨LarkNativeFlashInferRmsNorm.finalState shape LarkReal.ops input outside,
    segmentation input outside, race_free input outside, segment_equivalence input outside⟩
theorem kernel_eq_spec_pre (input : Nat → Nat → ℝ) (s : State ℝ) (pre : StdPre layout input s) :
    ∃ final, LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec input) := by
  obtain ⟨outside, rfl⟩ := pre
  exact kernel_eq_spec input outside
#print axioms reference_data
#print axioms program_data
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
