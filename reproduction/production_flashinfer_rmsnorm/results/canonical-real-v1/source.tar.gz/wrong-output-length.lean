import LarkReal.NativeFlashInferRmsNorm
open LarkReal.NativeFlashInferRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
example (input : Nat → Nat → ℝ) :
    (canonical_spec ⟨1, by decide, by decide⟩ input).length = 16383 := by
  simp [canonical_spec]
