Fresh checks: python3 validate_source.py; lake build. All other root Lean files intentionally fail.
Both full source variants execute their scalar maximum prefix to PC20 with the original fuel.
The actual56-access prefix reads input only, preserves memory and is race-free, for arbitrary inputs/operations.
Logical reductions, later passes, the complete launch and reference bridge remain open. Source certificates0.
