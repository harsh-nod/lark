import Lark.NativeSoftmaxWitness
open LarkNonlinear LarkNativeSoftmax
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def sourceOriginal : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.div (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (-1) 4294967296))),
(.scalar (.index 4 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (50257))) 19)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)),
(.scalar (.index 6 (.add (.ivar (4)) (.mul (.ivar (5)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (6))) 12)),
(.scalar (.index 6 (.const (50256)))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (6))))),
(.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (1))))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 8)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (8192))))),
(.scalar (.jump 6)),
(.scalar (.assign 2 (.lit (0) 1))),
(.shuffle .down 2 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 32)),
(.scalar (.store .shared 0 (.ivar (2)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 42)),
(.scalar (.assign 3 (.load .shared 0 (.const (0))))),
(.scalar (.index 8 (.const (1)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (32))) 41)),
(.scalar (.assign 4 (.load .shared 0 (.ivar (8))))),
(.scalar (.assign 3 (.bin .max (.reg (3)) (.reg (4))))),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 36)),
(.scalar (.store .shared 0 (.const (0)) (.reg (3)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.lit (0) 1))),
(.scalar (.index 9 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (50257))) 69)),
(.scalar (.index 10 (.const (0)))),
(.scalar (.branch (.lt (.ivar (10)) (.const (8))) 56)),
(.scalar (.index 11 (.add (.ivar (9)) (.mul (.ivar (10)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (11))) 52)),
(.scalar (.index 11 (.const (50256)))),
(.scalar (.index 12 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (11))))),
(.scalar (.store .local 0 (.ivar (10)) (.un .fromHalf (.load .global 1 (.ivar (12)))))),
(.scalar (.index 10 (.add (.ivar (10)) (.const (1))))),
(.scalar (.jump 48)),
(.scalar (.index 13 (.const (0)))),
(.scalar (.branch (.lt (.ivar (13)) (.const (8))) 67)),
(.scalar (.index 14 (.add (.ivar (9)) (.mul (.ivar (13)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (14)) (.const (50257))) 65)),
(.scalar (.assign 7 (.load .local 0 (.ivar (13))))),
(.scalar (.assign 8 (.un .exp (.bin .sub (.reg (7)) (.reg (5)))))),
(.scalar (.index 15 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (14))))),
(.scalar (.store .global 0 (.ivar (15)) (.un .toHalf (.reg (8))))),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (8))))),
(.scalar (.index 13 (.add (.ivar (13)) (.const (1))))),
(.scalar (.jump 57)),
(.scalar (.index 9 (.add (.ivar (9)) (.const (8192))))),
(.scalar (.jump 46)),
(.scalar (.assign 9 (.lit (0) 1))),
(.shuffle .xor 9 6 (.const (16)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (8)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (4)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (2)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (1)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 82)),
(.scalar (.store .shared 1 (.ivar (2)) (.reg (6)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 92)),
(.scalar (.assign 10 (.load .shared 1 (.const (0))))),
(.scalar (.index 16 (.const (1)))),
(.scalar (.branch (.lt (.ivar (16)) (.const (32))) 91)),
(.scalar (.assign 11 (.load .shared 1 (.ivar (16))))),
(.scalar (.assign 10 (.bin .add (.reg (10)) (.reg (11))))),
(.scalar (.index 16 (.add (.ivar (16)) (.const (1))))),
(.scalar (.jump 86)),
(.scalar (.store .shared 1 (.const (0)) (.reg (10)))),
(.scalar (.barrier .block)),
(.scalar (.assign 12 (.load .shared 1 (.const (0))))),
(.scalar (.index 17 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (17)) (.const (50257))) 116)),
(.scalar (.index 18 (.const (0)))),
(.scalar (.branch (.lt (.ivar (18)) (.const (8))) 105)),
(.scalar (.index 19 (.add (.ivar (17)) (.mul (.ivar (18)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (19))) 101)),
(.scalar (.index 19 (.const (50256)))),
(.scalar (.index 20 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (19))))),
(.scalar (.store .local 1 (.ivar (18)) (.un .fromHalf (.load .global 0 (.ivar (20)))))),
(.scalar (.index 18 (.add (.ivar (18)) (.const (1))))),
(.scalar (.jump 97)),
(.scalar (.index 21 (.const (0)))),
(.scalar (.branch (.lt (.ivar (21)) (.const (8))) 114)),
(.scalar (.index 22 (.add (.ivar (17)) (.mul (.ivar (21)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (22)) (.const (50257))) 112)),
(.scalar (.assign 13 (.load .local 1 (.ivar (21))))),
(.scalar (.index 23 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (22))))),
(.scalar (.store .global 0 (.ivar (23)) (.un .toHalf (.reg (13))))),
(.scalar (.index 21 (.add (.ivar (21)) (.const (1))))),
(.scalar (.jump 106)),
(.scalar (.index 17 (.add (.ivar (17)) (.const (8192))))),
(.scalar (.jump 95)),
(.scalar .halt)
]
def sourceFixed : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.div (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (-1) 4294967296))),
(.scalar (.index 4 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (50257))) 19)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)),
(.scalar (.index 6 (.add (.ivar (4)) (.mul (.ivar (5)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (6))) 12)),
(.scalar (.index 6 (.const (50256)))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (6))))),
(.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (1))))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 8)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (8192))))),
(.scalar (.jump 6)),
(.scalar (.assign 2 (.lit (0) 1))),
(.shuffle .down 2 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 32)),
(.scalar (.store .shared 0 (.ivar (2)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 42)),
(.scalar (.assign 3 (.load .shared 0 (.const (0))))),
(.scalar (.index 8 (.const (1)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (32))) 41)),
(.scalar (.assign 4 (.load .shared 0 (.ivar (8))))),
(.scalar (.assign 3 (.bin .max (.reg (3)) (.reg (4))))),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 36)),
(.scalar (.store .shared 0 (.const (0)) (.reg (3)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.lit (0) 1))),
(.scalar (.index 9 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (50257))) 69)),
(.scalar (.index 10 (.const (0)))),
(.scalar (.branch (.lt (.ivar (10)) (.const (8))) 56)),
(.scalar (.index 11 (.add (.ivar (9)) (.mul (.ivar (10)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (11))) 52)),
(.scalar (.index 11 (.const (50256)))),
(.scalar (.index 12 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (11))))),
(.scalar (.store .local 0 (.ivar (10)) (.un .fromHalf (.load .global 1 (.ivar (12)))))),
(.scalar (.index 10 (.add (.ivar (10)) (.const (1))))),
(.scalar (.jump 48)),
(.scalar (.index 13 (.const (0)))),
(.scalar (.branch (.lt (.ivar (13)) (.const (8))) 67)),
(.scalar (.index 14 (.add (.ivar (9)) (.mul (.ivar (13)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (14)) (.const (50257))) 65)),
(.scalar (.assign 7 (.load .local 0 (.ivar (13))))),
(.scalar (.assign 8 (.un .exp (.bin .sub (.reg (7)) (.reg (5)))))),
(.scalar (.index 15 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (14))))),
(.scalar (.store .global 0 (.ivar (15)) (.un .toHalf (.reg (8))))),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (8))))),
(.scalar (.index 13 (.add (.ivar (13)) (.const (1))))),
(.scalar (.jump 57)),
(.scalar (.index 9 (.add (.ivar (9)) (.const (8192))))),
(.scalar (.jump 46)),
(.scalar (.assign 9 (.lit (0) 1))),
(.shuffle .xor 9 6 (.const (16)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (8)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (4)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (2)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (1)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 82)),
(.scalar (.store .shared 1 (.ivar (2)) (.reg (6)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 92)),
(.scalar (.assign 10 (.load .shared 1 (.const (0))))),
(.scalar (.index 16 (.const (1)))),
(.scalar (.branch (.lt (.ivar (16)) (.const (32))) 91)),
(.scalar (.assign 11 (.load .shared 1 (.ivar (16))))),
(.scalar (.assign 10 (.bin .add (.reg (10)) (.reg (11))))),
(.scalar (.index 16 (.add (.ivar (16)) (.const (1))))),
(.scalar (.jump 86)),
(.scalar (.store .shared 1 (.const (0)) (.reg (10)))),
(.scalar (.barrier .block)),
(.scalar (.assign 12 (.load .shared 1 (.const (0))))),
(.scalar (.index 17 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (17)) (.const (50257))) 115)),
(.scalar (.index 18 (.const (0)))),
(.scalar (.branch (.lt (.ivar (18)) (.const (8))) 104)),
(.scalar (.index 19 (.add (.ivar (17)) (.mul (.ivar (18)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (19)) (.const (50257))) 102)),
(.scalar (.index 20 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (19))))),
(.scalar (.store .local 1 (.ivar (18)) (.un .fromHalf (.load .global 0 (.ivar (20)))))),
(.scalar (.index 18 (.add (.ivar (18)) (.const (1))))),
(.scalar (.jump 97)),
(.scalar (.index 21 (.const (0)))),
(.scalar (.branch (.lt (.ivar (21)) (.const (8))) 113)),
(.scalar (.index 22 (.add (.ivar (17)) (.mul (.ivar (21)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (22)) (.const (50257))) 111)),
(.scalar (.assign 13 (.load .local 1 (.ivar (21))))),
(.scalar (.index 23 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (22))))),
(.scalar (.store .global 0 (.ivar (23)) (.un .toHalf (.bin .div (.reg (13)) (.reg (12)))))),
(.scalar (.index 21 (.add (.ivar (21)) (.const (1))))),
(.scalar (.jump 105)),
(.scalar (.index 17 (.add (.ivar (17)) (.const (8192))))),
(.scalar (.jump 95)),
(.scalar .halt)
]
def sourceShared : List Nat := [32, 32]
def sourceLocals : List Nat := [8, 8]
def sourceLayout (p : Shape) : Layout := ⟨[⟨.output,p.rows * 50257⟩, ⟨.input,p.rows * 50257⟩],sourceShared,sourceLocals⟩
def sourceGeometry (p : Shape) : Geometry := ⟨p.rows,1024,64⟩
def sourceFuel : Fuel := ⟨4096,8,5,1⟩
theorem source_program_data : sourceOriginal = racyProgram ∧ sourceFixed = fixedProgram := by decide
theorem source_interface_data (p : Shape) :
    sourceLayout p = layout p ∧ sourceGeometry p = geometry p ∧ sourceFuel = fuel := ⟨rfl,rfl,rfl⟩
def sourceStep (p : Shape) (guarded : Bool) (ops : Ops α) (t : Nat) (s : State α) : Option (State α) := do
  match ← (if guarded then sourceFixed else sourceOriginal)[s.pc t]? with
  | .scalar i => execute ops (sourceLayout p) (sourceGeometry p) t i s
  | .shuffle .. => none
theorem source_step_data (p : Shape) (guarded : Bool) (ops : Ops α) (t : Nat) (s : State α) :
    sourceStep p guarded ops t s = sourceScalarStep p guarded ops t s := by
  simp only [sourceStep,sourceScalarStep,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1]
  cases h : (if guarded then fixedProgram else racyProgram)[s.pc t]? with
  | none => rfl
  | some i => cases i <;> rfl
theorem source_seed_code : sourceOriginal[4]? = some (.scalar (.assign 0 (.lit (-1) 4294967296))) ∧
    sourceFixed[4]? = some (.scalar (.assign 0 (.lit (-1) 4294967296))) := by decide
theorem source_seed_evaluates (p : Shape) (ops : Ops α) (seed : α) (t : Nat) (s : State α) :
    evalExpr (withSeed ops seed) (sourceLayout p) (sourceGeometry p) t (.lit (-1) 4294967296) s =
      some (seed,s) := seed_expr ops seed (sourceLayout p) (sourceGeometry p) t s
theorem source_reader_trace (p : Shape) (ops : Ops α) (x : α) :
    (sourceStep p false ops 0 (readerStart 50256 2 x)).map State.trace =
      some [⟨0,⟨.local,0,1,2⟩,true,⟨0,4,0⟩⟩,reader] := by
  rewrite [source_step_data]
  exact reader_step p ops x
theorem source_writer_trace (p : Shape) (ops : Ops α) (x denominator : α) :
    (sourceStep p false ops 80 (writerStart 50256 x denominator)).map State.trace = some [writerAccess] := by
  rewrite [source_step_data]
  exact writer_step p ops x denominator
theorem source_guard_trace (p : Shape) :
    (sourceStep p true unitOps 0 guardStart).map (fun s => (s.pc 0,s.trace)) = some (102,[]) := by
  rewrite [source_step_data]
  exact guard_step p
theorem source_pair_conflicts (p : Shape) : conflict (sourceGeometry p) reader writerAccess = true := by
  rewrite [(source_interface_data p).2.1]
  exact pair_conflict p
theorem source_sufficient_rf (p : Shape) (trace : List Access) (h : ∀ a ∈ trace, Good a) :
    raceFree (sourceGeometry p) trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact race_free p trace h
#print axioms source_program_data
#print axioms source_interface_data
#print axioms source_step_data
#print axioms source_seed_code
#print axioms source_seed_evaluates
#print axioms source_reader_trace
#print axioms source_writer_trace
#print axioms source_guard_trace
#print axioms source_pair_conflicts
#print axioms source_sufficient_rf
