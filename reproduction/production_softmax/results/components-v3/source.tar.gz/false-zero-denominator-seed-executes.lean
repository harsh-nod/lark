import Main
open LarkNativeSoftmax LarkNonlinear
example (p : Shape) (s : State Unit) :
    (evalExpr unitOps (sourceLayout p) (sourceGeometry p) 0 (.lit (-1) 0) s).isSome = true := by
  change false = true
  decide
