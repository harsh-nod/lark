Fresh checks: python3 validate_source.py; lake build. Other root Lean files intentionally fail.
The maximum pass resumes both block barriers from the actual initializer.
From that proved state each selected lane executes seven scalar exponential/sum rounds and parks at PC70.
All valid exponential outputs and the unrounded source-ordered sum are proved, with the original fuel.
Every native64 wave also executes all five source-ordered logical32 XOR/add stages, writes two partials and parks at PC82.
The third barrier has not resumed; the block sum, normalization and whole launch remain open.
Source certificates0. Canonical/IEEE equivalence and original-paper completion remain open.
