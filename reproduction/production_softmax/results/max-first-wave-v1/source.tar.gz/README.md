Fresh checks: python3 validate_source.py; lake build. All other root Lean files intentionally fail.
Both full source variants execute a physical wave64 from entry to the first block barrier PC32.
The two logical32 groups retain their exact down/max trees, 3584 input reads and two shared stores.
Race freedom, global-memory frames and unchanged epochs are proved for the first wave.
Block/grid composition, later passes, the complete launch and reference bridge remain open. Source certificates0.
