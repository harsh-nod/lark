from pathlib import Path
from lark_kernels import native_softmax as native
from reproduction.production_softmax.check_program import statement, HERE
from reproduction.production_softmax.prepare import source
root = Path(__file__).resolve().parent
original = (HERE / "cases/native_race/kernel.hip").read_text()
fixed = (HERE / "cases/native_fixed/kernel.hip").read_text()
assert original == source(False) and fixed == source(True)
task = native.parse_task((HERE / "cases/native_race/task.json").read_text())
assert (root / "Main.lean").read_text() == statement(original,fixed,task)
print("Frozen reader, exact readback and both complete source-to-Main program/interface bindings passed.")
