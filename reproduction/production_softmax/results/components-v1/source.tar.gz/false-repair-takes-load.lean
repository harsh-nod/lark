import Main
open LarkNativeSoftmax LarkNonlinear
example : (sourceStep ⟨1, by decide, by decide⟩ true unitOps 0 guardStart).map
    (fun s => (s.pc 0,s.trace)) = some (100,[]) := by
  rewrite [source_guard_trace]
  decide
