import Main
open LarkNativeSoftmax LarkNonlinear
example : raceFree (sourceGeometry ⟨1, by decide, by decide⟩) [reader,writerAccess] = true := by decide
