Check source/reader binding: python3 validate_source.py. Fresh proof: lake build.
The nine other root Lean files intentionally fail.
Full source identity, loop-address coverage, conditional footprint RF and single-instruction trace witness only.
The witness states are explicit intermediates; full initializer reachability/reference equivalence remains open.
No source certificate or original-paper completion is claimed.
