import Main
open LarkNativeSoftmax LarkNonlinear
def wrongWriter : Access := ⟨79,globalCell 0 (column 79 6 1),true,⟨0,4,0⟩⟩
example : conflict (sourceGeometry ⟨1, by decide, by decide⟩) reader wrongWriter = true := by decide
