import RealMain
open LarkNonlinear LarkNativeSoftmax LarkReal.NativeSoftmax
example : Real.exp ((0 : ℝ)-1)=Real.exp 0 := by
  apply Real.exp_injective.eq_iff.mpr
  norm_num
