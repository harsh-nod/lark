import RealMain
open LarkNonlinear LarkNativeSoftmax LarkReal.NativeSoftmax
example : (softmaxOps 0).exp 0=0 := by
  change Real.exp (0 : ℝ)=0
  norm_num
