import RealMain
open LarkNonlinear LarkNativeSoftmax LarkReal.NativeSoftmax
example (p : Shape) (seed : ℝ) (outside : Location → Option ℝ)
    (offset : Nat) (ho : offset<p.rows*50257) :
    (sourceFixedGrid p (softmaxOps seed) (fun _ _ => 0) outside).memory (globalCell 0 offset)=some (1/50256) := by
  rewrite [source_uniform_output p seed outside offset ho]
  norm_num
