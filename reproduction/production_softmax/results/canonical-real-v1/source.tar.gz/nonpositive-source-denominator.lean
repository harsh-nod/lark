import RealMain
open LarkNonlinear LarkNativeSoftmax LarkReal.NativeSoftmax
example (seed : ℝ) (input : Nat → Nat → ℝ) (row : Nat) :
    (0<rowExpSum (softmaxOps seed) input row)=False := by
  have hp := source_denominator_pos seed input row
  simp only [hp]
  decide
