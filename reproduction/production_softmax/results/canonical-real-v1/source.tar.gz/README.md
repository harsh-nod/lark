Fresh source check: python3 validate_source.py. Fresh owned proof build: lake build.
Requires exactly the locked Mathlib dependencies; no owned compiled cache is archived.
Main binds both full sources and the repaired complete grid under the original geometry/fuel.
RealMain proves complete-launch Correct against the independent canonical dense softmax reference.
Every supported shape, all real inputs and any finite seed. Half conversions are identities.
The original source is proved through a complete block, without original race freedom.
IEEE/error bounds and original-paper completion are not asserted. Other root Lean files intentionally fail.
