from pathlib import Path
from reproduction.production_softmax import check_whole_grid as grid
from reproduction.production_softmax.canonical_statement import EXTRA
root=Path(__file__).resolve().parent
original=(grid.HERE/"cases/native_race/kernel.hip").read_text()
fixed=(grid.HERE/"cases/native_fixed/kernel.hip").read_text()
assert original==grid.source(False) and fixed==grid.source(True)
task=grid.native.parse_task((grid.HERE/"cases/native_race/task.json").read_text())
assert grid.statement(original,fixed,task)==(root/"Main.lean").read_text()
assert EXTRA==(root/"RealMain.lean").read_text()
print("Both full-source bindings, repaired complete grid and canonical-real reference bridge match.")
