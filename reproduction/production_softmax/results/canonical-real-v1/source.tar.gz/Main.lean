import Lark.NativeSoftmaxWitness
import Lark.NativeSoftmaxMaxPrefixCost
import Lark.NativeSoftmaxMaxWaveTree
import Lark.NativeSoftmaxMaxBarrier
import Lark.NativeSoftmaxMaximum
import Lark.NativeSoftmaxExpPrefixCounts
import Lark.NativeSoftmaxExpWave
import Lark.NativeSoftmaxReductionPrefix
import Lark.NativeSoftmaxWholeBlock
import Lark.NativeSoftmaxCorrect
open LarkNonlinear LarkNativeSoftmax
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def sourceOriginal : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.div (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (-1) 4294967296))),
(.scalar (.index 4 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (50257))) 19)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)),
(.scalar (.index 6 (.add (.ivar (4)) (.mul (.ivar (5)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (6))) 12)),
(.scalar (.index 6 (.const (50256)))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (6))))),
(.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (1))))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 8)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (8192))))),
(.scalar (.jump 6)),
(.scalar (.assign 2 (.lit (0) 1))),
(.shuffle .down 2 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 32)),
(.scalar (.store .shared 0 (.ivar (2)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 42)),
(.scalar (.assign 3 (.load .shared 0 (.const (0))))),
(.scalar (.index 8 (.const (1)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (32))) 41)),
(.scalar (.assign 4 (.load .shared 0 (.ivar (8))))),
(.scalar (.assign 3 (.bin .max (.reg (3)) (.reg (4))))),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 36)),
(.scalar (.store .shared 0 (.const (0)) (.reg (3)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.lit (0) 1))),
(.scalar (.index 9 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (50257))) 69)),
(.scalar (.index 10 (.const (0)))),
(.scalar (.branch (.lt (.ivar (10)) (.const (8))) 56)),
(.scalar (.index 11 (.add (.ivar (9)) (.mul (.ivar (10)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (11))) 52)),
(.scalar (.index 11 (.const (50256)))),
(.scalar (.index 12 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (11))))),
(.scalar (.store .local 0 (.ivar (10)) (.un .fromHalf (.load .global 1 (.ivar (12)))))),
(.scalar (.index 10 (.add (.ivar (10)) (.const (1))))),
(.scalar (.jump 48)),
(.scalar (.index 13 (.const (0)))),
(.scalar (.branch (.lt (.ivar (13)) (.const (8))) 67)),
(.scalar (.index 14 (.add (.ivar (9)) (.mul (.ivar (13)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (14)) (.const (50257))) 65)),
(.scalar (.assign 7 (.load .local 0 (.ivar (13))))),
(.scalar (.assign 8 (.un .exp (.bin .sub (.reg (7)) (.reg (5)))))),
(.scalar (.index 15 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (14))))),
(.scalar (.store .global 0 (.ivar (15)) (.un .toHalf (.reg (8))))),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (8))))),
(.scalar (.index 13 (.add (.ivar (13)) (.const (1))))),
(.scalar (.jump 57)),
(.scalar (.index 9 (.add (.ivar (9)) (.const (8192))))),
(.scalar (.jump 46)),
(.scalar (.assign 9 (.lit (0) 1))),
(.shuffle .xor 9 6 (.const (16)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (8)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (4)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (2)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (1)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 82)),
(.scalar (.store .shared 1 (.ivar (2)) (.reg (6)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 92)),
(.scalar (.assign 10 (.load .shared 1 (.const (0))))),
(.scalar (.index 16 (.const (1)))),
(.scalar (.branch (.lt (.ivar (16)) (.const (32))) 91)),
(.scalar (.assign 11 (.load .shared 1 (.ivar (16))))),
(.scalar (.assign 10 (.bin .add (.reg (10)) (.reg (11))))),
(.scalar (.index 16 (.add (.ivar (16)) (.const (1))))),
(.scalar (.jump 86)),
(.scalar (.store .shared 1 (.const (0)) (.reg (10)))),
(.scalar (.barrier .block)),
(.scalar (.assign 12 (.load .shared 1 (.const (0))))),
(.scalar (.index 17 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (17)) (.const (50257))) 116)),
(.scalar (.index 18 (.const (0)))),
(.scalar (.branch (.lt (.ivar (18)) (.const (8))) 105)),
(.scalar (.index 19 (.add (.ivar (17)) (.mul (.ivar (18)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (19))) 101)),
(.scalar (.index 19 (.const (50256)))),
(.scalar (.index 20 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (19))))),
(.scalar (.store .local 1 (.ivar (18)) (.un .fromHalf (.load .global 0 (.ivar (20)))))),
(.scalar (.index 18 (.add (.ivar (18)) (.const (1))))),
(.scalar (.jump 97)),
(.scalar (.index 21 (.const (0)))),
(.scalar (.branch (.lt (.ivar (21)) (.const (8))) 114)),
(.scalar (.index 22 (.add (.ivar (17)) (.mul (.ivar (21)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (22)) (.const (50257))) 112)),
(.scalar (.assign 13 (.load .local 1 (.ivar (21))))),
(.scalar (.index 23 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (22))))),
(.scalar (.store .global 0 (.ivar (23)) (.un .toHalf (.bin .div (.reg (13)) (.reg (12)))))),
(.scalar (.index 21 (.add (.ivar (21)) (.const (1))))),
(.scalar (.jump 106)),
(.scalar (.index 17 (.add (.ivar (17)) (.const (8192))))),
(.scalar (.jump 95)),
(.scalar .halt)
]
def sourceFixed : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.div (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (-1) 4294967296))),
(.scalar (.index 4 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (50257))) 19)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)),
(.scalar (.index 6 (.add (.ivar (4)) (.mul (.ivar (5)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (6))) 12)),
(.scalar (.index 6 (.const (50256)))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (6))))),
(.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (1))))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 8)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (8192))))),
(.scalar (.jump 6)),
(.scalar (.assign 2 (.lit (0) 1))),
(.shuffle .down 2 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 32)),
(.scalar (.store .shared 0 (.ivar (2)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 42)),
(.scalar (.assign 3 (.load .shared 0 (.const (0))))),
(.scalar (.index 8 (.const (1)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (32))) 41)),
(.scalar (.assign 4 (.load .shared 0 (.ivar (8))))),
(.scalar (.assign 3 (.bin .max (.reg (3)) (.reg (4))))),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 36)),
(.scalar (.store .shared 0 (.const (0)) (.reg (3)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.lit (0) 1))),
(.scalar (.index 9 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (50257))) 69)),
(.scalar (.index 10 (.const (0)))),
(.scalar (.branch (.lt (.ivar (10)) (.const (8))) 56)),
(.scalar (.index 11 (.add (.ivar (9)) (.mul (.ivar (10)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (11))) 52)),
(.scalar (.index 11 (.const (50256)))),
(.scalar (.index 12 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (11))))),
(.scalar (.store .local 0 (.ivar (10)) (.un .fromHalf (.load .global 1 (.ivar (12)))))),
(.scalar (.index 10 (.add (.ivar (10)) (.const (1))))),
(.scalar (.jump 48)),
(.scalar (.index 13 (.const (0)))),
(.scalar (.branch (.lt (.ivar (13)) (.const (8))) 67)),
(.scalar (.index 14 (.add (.ivar (9)) (.mul (.ivar (13)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (14)) (.const (50257))) 65)),
(.scalar (.assign 7 (.load .local 0 (.ivar (13))))),
(.scalar (.assign 8 (.un .exp (.bin .sub (.reg (7)) (.reg (5)))))),
(.scalar (.index 15 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (14))))),
(.scalar (.store .global 0 (.ivar (15)) (.un .toHalf (.reg (8))))),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (8))))),
(.scalar (.index 13 (.add (.ivar (13)) (.const (1))))),
(.scalar (.jump 57)),
(.scalar (.index 9 (.add (.ivar (9)) (.const (8192))))),
(.scalar (.jump 46)),
(.scalar (.assign 9 (.lit (0) 1))),
(.shuffle .xor 9 6 (.const (16)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (8)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (4)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (2)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (1)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 82)),
(.scalar (.store .shared 1 (.ivar (2)) (.reg (6)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 92)),
(.scalar (.assign 10 (.load .shared 1 (.const (0))))),
(.scalar (.index 16 (.const (1)))),
(.scalar (.branch (.lt (.ivar (16)) (.const (32))) 91)),
(.scalar (.assign 11 (.load .shared 1 (.ivar (16))))),
(.scalar (.assign 10 (.bin .add (.reg (10)) (.reg (11))))),
(.scalar (.index 16 (.add (.ivar (16)) (.const (1))))),
(.scalar (.jump 86)),
(.scalar (.store .shared 1 (.const (0)) (.reg (10)))),
(.scalar (.barrier .block)),
(.scalar (.assign 12 (.load .shared 1 (.const (0))))),
(.scalar (.index 17 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (17)) (.const (50257))) 115)),
(.scalar (.index 18 (.const (0)))),
(.scalar (.branch (.lt (.ivar (18)) (.const (8))) 104)),
(.scalar (.index 19 (.add (.ivar (17)) (.mul (.ivar (18)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (19)) (.const (50257))) 102)),
(.scalar (.index 20 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (19))))),
(.scalar (.store .local 1 (.ivar (18)) (.un .fromHalf (.load .global 0 (.ivar (20)))))),
(.scalar (.index 18 (.add (.ivar (18)) (.const (1))))),
(.scalar (.jump 97)),
(.scalar (.index 21 (.const (0)))),
(.scalar (.branch (.lt (.ivar (21)) (.const (8))) 113)),
(.scalar (.index 22 (.add (.ivar (17)) (.mul (.ivar (21)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (22)) (.const (50257))) 111)),
(.scalar (.assign 13 (.load .local 1 (.ivar (21))))),
(.scalar (.index 23 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (22))))),
(.scalar (.store .global 0 (.ivar (23)) (.un .toHalf (.bin .div (.reg (13)) (.reg (12)))))),
(.scalar (.index 21 (.add (.ivar (21)) (.const (1))))),
(.scalar (.jump 105)),
(.scalar (.index 17 (.add (.ivar (17)) (.const (8192))))),
(.scalar (.jump 95)),
(.scalar .halt)
]
def sourceShared : List Nat := [32, 32]
def sourceLocals : List Nat := [8, 8]
def sourceLayout (p : Shape) : Layout := ⟨[⟨.output,p.rows * 50257⟩, ⟨.input,p.rows * 50257⟩],sourceShared,sourceLocals⟩
def sourceGeometry (p : Shape) : Geometry := ⟨p.rows,1024,64⟩
def sourceFuel : Fuel := ⟨4096,8,5,1⟩
theorem source_program_data : sourceOriginal = racyProgram ∧ sourceFixed = fixedProgram := by decide
theorem source_interface_data (p : Shape) :
    sourceLayout p = layout p ∧ sourceGeometry p = geometry p ∧ sourceFuel = fuel := ⟨rfl,rfl,rfl⟩
def sourceStep (p : Shape) (guarded : Bool) (ops : Ops α) (t : Nat) (s : State α) : Option (State α) := do
  match ← (if guarded then sourceFixed else sourceOriginal)[s.pc t]? with
  | .scalar i => execute ops (sourceLayout p) (sourceGeometry p) t i s
  | .shuffle .. => none
theorem source_step_data (p : Shape) (guarded : Bool) (ops : Ops α) (t : Nat) (s : State α) :
    sourceStep p guarded ops t s = sourceScalarStep p guarded ops t s := by
  simp only [sourceStep,sourceScalarStep,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1]
  cases h : (if guarded then fixedProgram else racyProgram)[s.pc t]? with
  | none => rfl
  | some i => cases i <;> rfl
theorem source_seed_code : sourceOriginal[4]? = some (.scalar (.assign 0 (.lit (-1) 4294967296))) ∧
    sourceFixed[4]? = some (.scalar (.assign 0 (.lit (-1) 4294967296))) := by decide
theorem source_seed_evaluates (p : Shape) (ops : Ops α) (seed : α) (t : Nat) (s : State α) :
    evalExpr (withSeed ops seed) (sourceLayout p) (sourceGeometry p) t (.lit (-1) 4294967296) s =
      some (seed,s) := seed_expr ops seed (sourceLayout p) (sourceGeometry p) t s
theorem source_reader_trace (p : Shape) (ops : Ops α) (x : α) :
    (sourceStep p false ops 0 (readerStart 50256 2 x)).map State.trace =
      some [⟨0,⟨.local,0,1,2⟩,true,⟨0,4,0⟩⟩,reader] := by
  rewrite [source_step_data]
  exact reader_step p ops x
theorem source_writer_trace (p : Shape) (ops : Ops α) (x denominator : α) :
    (sourceStep p false ops 80 (writerStart 50256 x denominator)).map State.trace = some [writerAccess] := by
  rewrite [source_step_data]
  exact writer_step p ops x denominator
theorem source_guard_trace (p : Shape) :
    (sourceStep p true unitOps 0 guardStart).map (fun s => (s.pc 0,s.trace)) = some (102,[]) := by
  rewrite [source_step_data]
  exact guard_step p
theorem source_pair_conflicts (p : Shape) : conflict (sourceGeometry p) reader writerAccess = true := by
  rewrite [(source_interface_data p).2.1]
  exact pair_conflict p
theorem source_sufficient_rf (p : Shape) (trace : List Access) (h : ∀ a ∈ trace, Good a) :
    raceFree (sourceGeometry p) trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact race_free p trace h
#print axioms source_program_data
#print axioms source_interface_data
#print axioms source_step_data
#print axioms source_seed_code
#print axioms source_seed_evaluates
#print axioms source_reader_trace
#print axioms source_writer_trace
#print axioms source_guard_trace
#print axioms source_pair_conflicts
#print axioms source_sufficient_rf

def sourceInitial (p : Shape) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  initial (sourceLayout p) input outside
def sourceLane (p : Shape) (guarded : Bool) (ops : Ops α) (t budget : Nat) (s : State α) : Option (State α) :=
  LarkCollective.runLane ops (sourceLayout p) (sourceGeometry p)
    (if guarded then sourceFixed else sourceOriginal) t budget s
theorem source_lane_data (p : Shape) (guarded : Bool) (ops : Ops α) (t budget : Nat) (s : State α) :
    sourceLane p guarded ops t budget s =
      LarkCollective.runLane ops (layout p) (geometry p) (program guarded) t budget s := by
  simp only [sourceLane,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1]
theorem source_initial_data (p : Shape) (input : Nat → Nat → α) (outside : Location → Option α) :
    sourceInitial p input outside = initial (layout p) input outside := rfl
theorem source_prefix_initial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (t : Nat) (ht : t < p.rows*1024) :
    sourceLane p guarded ops t sourceFuel.lane (sourceInitial p input outside) =
      some (maxPrefixState ops input t (sourceInitial p input outside)) := by
  rewrite [source_lane_data,source_initial_data,(source_interface_data p).2.2]
  exact initial_max_prefix_run p guarded ops input outside t ht
theorem source_prefix_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (maxPrefixState ops input t (sourceInitial p input outside)).pc t = 20 :=
  max_prefix_pc ops input t _
theorem source_prefix_initial_value (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (maxPrefixState ops input t (sourceInitial p input outside)).regs t 0 =
      some (threadMaximum ops input (t/1024) (t%1024)) := by
  rewrite [source_initial_data]
  exact initial_max_prefix_value p ops input outside t
theorem source_prefix_initial_frames (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (maxPrefixState ops input t (sourceInitial p input outside)).memory = (sourceInitial p input outside).memory ∧
    (maxPrefixState ops input t (sourceInitial p input outside)).epochs = (sourceInitial p input outside).epochs ∧
    (maxPrefixState ops input t (sourceInitial p input outside)).trace.length = 56 := by
  have frame := max_prefix_frames ops input t (sourceInitial p input outside)
  exact ⟨frame.1,frame.2.1,by simpa only [sourceInitial,initial,List.length_nil,Nat.zero_add] using frame.2.2⟩
theorem source_prefix_initial_inputs (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    ∀ a ∈ (maxPrefixState ops input t (sourceInitial p input outside)).trace, MaxInputAccess a := by
  rewrite [source_initial_data]
  exact initial_max_prefix_inputs p ops input outside t
theorem source_prefix_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    raceFree (sourceGeometry p) (maxPrefixState ops input t (sourceInitial p input outside)).trace = true := by
  rewrite [source_initial_data,(source_interface_data p).2.1]
  exact initial_max_prefix_race_free p ops input outside t
theorem source_prefix_cost (tid : Nat) (ht : tid < 1024) :
    maxPrefixCost tid = if tid < 81 then 497 else 498 := max_prefix_cost_exact tid ht
theorem source_register_of_run (run : Option (State α)) (final : State α) (t : Nat) (value : α)
    (hr : run = some final) (hv : final.regs t 0 = some value) :
    run.map (fun s => s.regs t 0) = some (some value) := by
  rewrite [hr]
  change some (final.regs t 0) = some (some value)
  rewrite [hv]
  rfl
def prefixOne : Shape := ⟨1,by decide,by decide⟩
def wordInput : Nat → Nat → List Nat := fun _ offset => [offset]
def wordOps : Ops (List Nat) where
  literal := fun n d => if n = -1 ∧ d = 4294967296 then [3] else [4]
  add := fun a b => a ++ b
  sub := fun a b => a ++ b
  mul := fun a b => a ++ b
  max := fun a b => a ++ [1] ++ b
  div := fun a b => a ++ b
  exp := id
  tanh := id
  rsqrt := id
  fromHalf := fun a => 2 :: a
  toHalf := id
theorem source_maximum_word_0 :
    threadMaximum wordOps wordInput 0 0 = [3, 1, 2, 0, 1, 2, 1024, 1, 2, 2048, 1, 2, 3072, 1, 2, 4096, 1, 2, 5120, 1, 2, 6144, 1, 2, 7168, 1, 2, 8192, 1, 2, 9216, 1, 2, 10240, 1, 2, 11264, 1, 2, 12288, 1, 2, 13312, 1, 2, 14336, 1, 2, 15360, 1, 2, 16384, 1, 2, 17408, 1, 2, 18432, 1, 2, 19456, 1, 2, 20480, 1, 2, 21504, 1, 2, 22528, 1, 2, 23552, 1, 2, 24576, 1, 2, 25600, 1, 2, 26624, 1, 2, 27648, 1, 2, 28672, 1, 2, 29696, 1, 2, 30720, 1, 2, 31744, 1, 2, 32768, 1, 2, 33792, 1, 2, 34816, 1, 2, 35840, 1, 2, 36864, 1, 2, 37888, 1, 2, 38912, 1, 2, 39936, 1, 2, 40960, 1, 2, 41984, 1, 2, 43008, 1, 2, 44032, 1, 2, 45056, 1, 2, 46080, 1, 2, 47104, 1, 2, 48128, 1, 2, 49152, 1, 2, 50176, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256] := by decide
theorem source_prefix_word_0 :
    (sourceLane prefixOne false wordOps 0 sourceFuel.lane
      (sourceInitial prefixOne wordInput (fun _ => none))).map (fun s => s.regs 0 0) =
      some (some [3, 1, 2, 0, 1, 2, 1024, 1, 2, 2048, 1, 2, 3072, 1, 2, 4096, 1, 2, 5120, 1, 2, 6144, 1, 2, 7168, 1, 2, 8192, 1, 2, 9216, 1, 2, 10240, 1, 2, 11264, 1, 2, 12288, 1, 2, 13312, 1, 2, 14336, 1, 2, 15360, 1, 2, 16384, 1, 2, 17408, 1, 2, 18432, 1, 2, 19456, 1, 2, 20480, 1, 2, 21504, 1, 2, 22528, 1, 2, 23552, 1, 2, 24576, 1, 2, 25600, 1, 2, 26624, 1, 2, 27648, 1, 2, 28672, 1, 2, 29696, 1, 2, 30720, 1, 2, 31744, 1, 2, 32768, 1, 2, 33792, 1, 2, 34816, 1, 2, 35840, 1, 2, 36864, 1, 2, 37888, 1, 2, 38912, 1, 2, 39936, 1, 2, 40960, 1, 2, 41984, 1, 2, 43008, 1, 2, 44032, 1, 2, 45056, 1, 2, 46080, 1, 2, 47104, 1, 2, 48128, 1, 2, 49152, 1, 2, 50176, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256]) := by
  have run := source_prefix_initial_run prefixOne false wordOps wordInput (fun _ => none) 0 (by decide)
  have value := source_prefix_initial_value prefixOne wordOps wordInput (fun _ => none) 0
  have mapped := source_register_of_run _ _ 0 _ run value
  exact mapped.trans (congrArg (fun value : List Nat => some (some value)) source_maximum_word_0)
theorem source_maximum_word_81 :
    threadMaximum wordOps wordInput 0 81 = [3, 1, 2, 81, 1, 2, 1105, 1, 2, 2129, 1, 2, 3153, 1, 2, 4177, 1, 2, 5201, 1, 2, 6225, 1, 2, 7249, 1, 2, 8273, 1, 2, 9297, 1, 2, 10321, 1, 2, 11345, 1, 2, 12369, 1, 2, 13393, 1, 2, 14417, 1, 2, 15441, 1, 2, 16465, 1, 2, 17489, 1, 2, 18513, 1, 2, 19537, 1, 2, 20561, 1, 2, 21585, 1, 2, 22609, 1, 2, 23633, 1, 2, 24657, 1, 2, 25681, 1, 2, 26705, 1, 2, 27729, 1, 2, 28753, 1, 2, 29777, 1, 2, 30801, 1, 2, 31825, 1, 2, 32849, 1, 2, 33873, 1, 2, 34897, 1, 2, 35921, 1, 2, 36945, 1, 2, 37969, 1, 2, 38993, 1, 2, 40017, 1, 2, 41041, 1, 2, 42065, 1, 2, 43089, 1, 2, 44113, 1, 2, 45137, 1, 2, 46161, 1, 2, 47185, 1, 2, 48209, 1, 2, 49233, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256] := by decide
theorem source_prefix_word_81 :
    (sourceLane prefixOne false wordOps 81 sourceFuel.lane
      (sourceInitial prefixOne wordInput (fun _ => none))).map (fun s => s.regs 81 0) =
      some (some [3, 1, 2, 81, 1, 2, 1105, 1, 2, 2129, 1, 2, 3153, 1, 2, 4177, 1, 2, 5201, 1, 2, 6225, 1, 2, 7249, 1, 2, 8273, 1, 2, 9297, 1, 2, 10321, 1, 2, 11345, 1, 2, 12369, 1, 2, 13393, 1, 2, 14417, 1, 2, 15441, 1, 2, 16465, 1, 2, 17489, 1, 2, 18513, 1, 2, 19537, 1, 2, 20561, 1, 2, 21585, 1, 2, 22609, 1, 2, 23633, 1, 2, 24657, 1, 2, 25681, 1, 2, 26705, 1, 2, 27729, 1, 2, 28753, 1, 2, 29777, 1, 2, 30801, 1, 2, 31825, 1, 2, 32849, 1, 2, 33873, 1, 2, 34897, 1, 2, 35921, 1, 2, 36945, 1, 2, 37969, 1, 2, 38993, 1, 2, 40017, 1, 2, 41041, 1, 2, 42065, 1, 2, 43089, 1, 2, 44113, 1, 2, 45137, 1, 2, 46161, 1, 2, 47185, 1, 2, 48209, 1, 2, 49233, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256]) := by
  have run := source_prefix_initial_run prefixOne false wordOps wordInput (fun _ => none) 81 (by decide)
  have value := source_prefix_initial_value prefixOne wordOps wordInput (fun _ => none) 81
  have mapped := source_register_of_run _ _ 81 _ run value
  exact mapped.trans (congrArg (fun value : List Nat => some (some value)) source_maximum_word_81)
#print axioms source_lane_data
#print axioms source_initial_data
#print axioms source_prefix_initial_run
#print axioms source_prefix_initial_pc
#print axioms source_prefix_initial_value
#print axioms source_prefix_initial_frames
#print axioms source_prefix_initial_inputs
#print axioms source_prefix_initial_rf
#print axioms source_prefix_cost
#print axioms source_register_of_run
#print axioms source_maximum_word_0
#print axioms source_maximum_word_81
#print axioms source_prefix_word_0
#print axioms source_prefix_word_81

def sourceWarp (p : Shape) (guarded : Bool) (ops : Ops α) (ts : List Nat) (budget : Nat)
    (s : State α) : Option (State α) :=
  LarkPartitionCollective.runWarp ops (sourceLayout p) (sourceGeometry p) sourceFuel
    (if guarded then sourceFixed else sourceOriginal) ts budget s
def sourceWave (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) : State α :=
  firstWave p ops input row warp (sourceInitial p input outside)
theorem source_warp_data (p : Shape) (guarded : Bool) (ops : Ops α) (ts : List Nat)
    (budget : Nat) (s : State α) :
    sourceWarp p guarded ops ts budget s =
      LarkPartitionCollective.runWarp ops (layout p) (geometry p) fuel (program guarded) ts budget s := by
  simp only [sourceWarp,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1,(source_interface_data p).2.2]
theorem source_wave_initial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row warp : Nat)
    (hr : row < p.rows) (hw : warp < 16) :
    sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceInitial p input outside) = some (sourceWave p ops input outside row warp) := by
  rewrite [source_warp_data,(source_interface_data p).2.1,(source_interface_data p).2.2,source_initial_data]
  exact first_wave_initial p guarded ops input outside row warp hr hw
theorem source_wave_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp lane : Nat) (hl : lane < 64) :
    (sourceWave p ops input outside row warp).pc (cohortBase row warp+lane) = 32 :=
  first_wave_pc p ops input row warp _ lane hl
theorem source_wave_initial_partial (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp half : Nat) (hw : warp < 16) (hh : half < 2) :
    (sourceWave p ops input outside row warp).memory ⟨.shared,row,0,warp*2+half⟩ =
      some (downTree ops.max (fun lane => threadMaximum ops input row (warp*64+lane)) 5 (half*32)) :=
  first_wave_partial_tree p ops input row warp half _ hw hh
theorem source_wave_initial_epochs (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) :
    (sourceWave p ops input outside row warp).epochs = (sourceInitial p input outside).epochs :=
  first_wave_epochs p ops input row warp _
theorem source_wave_initial_memory_frame (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (l : Location)
    (hl : l.space = .global ∨ l.buffer ≠ 0) :
    (sourceWave p ops input outside row warp).memory l = (sourceInitial p input outside).memory l :=
  first_wave_memory_frame p ops input row warp _ l hl
theorem source_wave_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) :
    ∀ a ∈ (sourceWave p ops input outside row warp).trace, Good a :=
  first_wave_initial_good p ops input outside row warp
theorem source_wave_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) :
    raceFree (sourceGeometry p) (sourceWave p ops input outside row warp).trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact first_wave_initial_race_free p ops input outside row warp
theorem source_wave_initial_trace_length (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hw : warp < 16) :
    (sourceWave p ops input outside row warp).trace.length = 3586 :=
  first_wave_trace_length p ops input row warp _ hw
theorem source_memory_of_run (run : Option (State α)) (final : State α) (l : Location)
    (value : α) (hr : run = some final) (hv : final.memory l = some value) :
    run.map (fun s => s.memory l) = some (some value) := by
  rewrite [hr]
  change some (final.memory l) = some (some value)
  rewrite [hv]
  rfl
theorem source_wave_initial_partial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row warp half : Nat)
    (hr : row < p.rows) (hw : warp < 16) (hh : half < 2) :
    (sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceInitial p input outside)).map (fun s => s.memory ⟨.shared,row,0,warp*2+half⟩) =
        some (some (downTree ops.max (fun lane => threadMaximum ops input row (warp*64+lane)) 5 (half*32))) :=
  source_memory_of_run _ _ _ _ (source_wave_initial_run p guarded ops input outside row warp hr hw)
    (source_wave_initial_partial p ops input outside row warp half hw hh)
#print axioms source_warp_data
#print axioms source_wave_initial_run
#print axioms source_wave_initial_pc
#print axioms source_wave_initial_partial
#print axioms source_wave_initial_epochs
#print axioms source_wave_initial_memory_frame
#print axioms source_wave_initial_good
#print axioms source_wave_initial_rf
#print axioms source_wave_initial_trace_length
#print axioms source_memory_of_run
#print axioms source_wave_initial_partial_run

def sourceBlockFold (p : Shape) (guarded : Bool) (ops : Ops α) (row : Nat) (s : State α) : Option (State α) :=
  (List.range (((sourceGeometry p).block+(sourceGeometry p).warp-1)/(sourceGeometry p).warp)).foldlM
    (fun s w => sourceWarp p guarded ops (warpThreads (sourceGeometry p) row w) sourceFuel.warp s) s
def sourceBlock (p : Shape) (guarded : Bool) (ops : Ops α) (row budget : Nat) (s : State α) : Option (State α) :=
  LarkPartitionCollective.runBlock ops (sourceLayout p) (sourceGeometry p) sourceFuel
    (if guarded then sourceFixed else sourceOriginal) row budget s
def sourceBlockState (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : State α :=
  firstBlock p ops input row (sourceInitial p input outside)
def sourceMidState (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : State α :=
  midState p ops input row (sourceInitial p input outside)
theorem source_block_fold_data (p : Shape) (guarded : Bool) (ops : Ops α) (row : Nat) (s : State α) :
    sourceBlockFold p guarded ops row s =
      (List.range 16).foldlM (fun s w => LarkPartitionCollective.runWarp ops (layout p) (geometry p) fuel
        (program guarded) (warpThreads (geometry p) row w) fuel.warp s) s := by
  simp only [sourceBlockFold,source_warp_data,(source_interface_data p).2.1,(source_interface_data p).2.2]
  have hcount : ((geometry p).block+(geometry p).warp-1)/(geometry p).warp = 16 := by
    change (1024+64-1)/64 = 16
    decide
  rewrite [hcount]
  rfl
theorem source_block_data (p : Shape) (guarded : Bool) (ops : Ops α) (row budget : Nat) (s : State α) :
    sourceBlock p guarded ops row budget s =
      LarkPartitionCollective.runBlock ops (layout p) (geometry p) fuel (program guarded) row budget s := by
  simp only [sourceBlock,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1,(source_interface_data p).2.2]
theorem source_block_initial_fold_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    sourceBlockFold p guarded ops row (sourceInitial p input outside) =
      some (sourceBlockState p ops input outside row) := by
  rewrite [source_block_fold_data,source_initial_data]
  exact first_block_initial_run p guarded ops input outside row hr
theorem source_block_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row < p.rows) (ht : tid < 1024) :
    (sourceBlockState p ops input outside row).pc (row*1024+tid) = 32 :=
  (first_block_member p ops input row tid _ (initial_block_entry p input outside row hr) ht).pc
theorem source_block_initial_partial (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row logicalWarp : Nat) (hw : logicalWarp < 32) :
    (sourceBlockState p ops input outside row).memory ⟨.shared,row,0,logicalWarp⟩ =
      some (blockPartial ops input row logicalWarp) :=
  first_block_partial p ops input row logicalWarp _ hw
theorem source_block_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    ∀ a ∈ (sourceBlockState p ops input outside row).trace, Good a :=
  first_block_good p ops input row _ (initial_block_entry p input outside row hr)
theorem source_block_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    raceFree (sourceGeometry p) (sourceBlockState p ops input outside row).trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact first_block_initial_race_free p ops input outside row hr
theorem source_trace_length_of_nil (start final : State α) (n : Nat) (hempty : start.trace = [])
    (h : final.trace.length = start.trace.length+n) : final.trace.length = n := by
  rewrite [hempty] at h
  simpa only [List.length_nil,Nat.zero_add] using h
theorem source_block_initial_trace_length (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) :
    (firstBlock p ops input row (sourceInitial p input outside)).trace.length = 57376 :=
  source_trace_length_of_nil (sourceInitial p input outside)
    (firstBlock p ops input row (sourceInitial p input outside)) 57376 rfl
    (first_block_trace_length p ops input row (sourceInitial p input outside))
theorem source_block_initial_partial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row logicalWarp : Nat)
    (hr : row < p.rows) (hw : logicalWarp < 32) :
    (sourceBlockFold p guarded ops row (sourceInitial p input outside)).map
      (fun s => s.memory ⟨.shared,row,0,logicalWarp⟩) = some (some (blockPartial ops input row logicalWarp)) :=
  source_memory_of_run _ _ _ _ (source_block_initial_fold_run p guarded ops input outside row hr)
    (source_block_initial_partial p ops input outside row logicalWarp hw)
theorem source_mid_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row < p.rows) (ht : tid < 1024) :
    (sourceMidState p ops input outside row).pc (row*1024+tid) = 33 :=
  (initial_mid_ready p ops input outside row hr).pc tid ht
theorem source_mid_initial_epoch (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row < p.rows) (ht : tid < 1024) :
    ((sourceMidState p ops input outside row).epochs (row*1024+tid)).block = 1 :=
  (initial_mid_ready p ops input outside row hr).epoch tid ht
theorem source_mid_initial_memory_frame (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (l : Location) (hl : l.space = .global ∨ l.buffer ≠ 0) :
    (sourceMidState p ops input outside row).memory l = (sourceInitial p input outside).memory l :=
  mid_memory_frame p ops input row _ l hl
theorem source_mid_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    raceFree (sourceGeometry p) (sourceMidState p ops input outside row).trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact initial_mid_race_free p ops input outside row hr
theorem source_initial_block_barrier (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    sourceBlock p guarded ops row sourceFuel.block (sourceInitial p input outside) =
      sourceBlock p guarded ops row 4 (sourceMidState p ops input outside row) := by
  rewrite [source_block_data,source_block_data,(source_interface_data p).2.2,source_initial_data]
  exact initial_first_barrier p guarded ops input outside row hr
def checksumOps : Ops Nat where
  literal := fun _ _ => 0
  add := Nat.add
  sub := Nat.sub
  mul := Nat.mul
  max := fun a b => 3*a+b
  div := Nat.div
  exp := id
  tanh := id
  rsqrt := id
  fromHalf := id
  toHalf := id
def checksumInput : Nat → Nat → Nat := fun _ offset => offset+1
theorem source_checksum_last_partial : blockPartial checksumOps checksumInput 0 31 = 405347395513415502166905022412032 := by decide
theorem source_checksum_last_partial_run (guarded : Bool) :
    (sourceBlockFold prefixOne guarded checksumOps 0 (sourceInitial prefixOne checksumInput (fun _ => none))).map
      (fun s => s.memory ⟨.shared,0,0,31⟩) = some (some 405347395513415502166905022412032) := by
  exact (source_block_initial_partial_run prefixOne guarded checksumOps checksumInput (fun _ => none) 0 31
    (by decide) (by decide)).trans (congrArg (fun v : Nat => some (some v)) source_checksum_last_partial)
#print axioms source_block_fold_data
#print axioms source_block_data
#print axioms source_block_initial_fold_run
#print axioms source_block_initial_pc
#print axioms source_block_initial_partial
#print axioms source_block_initial_good
#print axioms source_block_initial_rf
#print axioms source_trace_length_of_nil
#print axioms source_block_initial_trace_length
#print axioms source_block_initial_partial_run
#print axioms source_mid_initial_pc
#print axioms source_mid_initial_epoch
#print axioms source_mid_initial_memory_frame
#print axioms source_mid_initial_rf
#print axioms source_initial_block_barrier
#print axioms source_checksum_last_partial
#print axioms source_checksum_last_partial_run

def sourceMaximumState (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : State α :=
  maximumState p ops input row (sourceInitial p input outside)
theorem source_serial_initial_fold_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    sourceBlockFold p guarded ops row (sourceMidState p ops input outside row) =
      some (serialBlock ops input row (sourceMidState p ops input outside row)) := by
  rewrite [source_block_fold_data]
  have h := serial_block_fold_run p guarded ops input row (sourceMidState p ops input outside row)
    (initial_mid_ready p ops input outside row hr)
  have hcount : ((geometry p).block+(geometry p).warp-1)/(geometry p).warp=16 := by
    change (1024+64-1)/64=16
    decide
  rewrite [hcount] at h
  exact h
theorem source_serial_initial_maximum_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    (sourceBlockFold p guarded ops row (sourceMidState p ops input outside row)).map
      (fun s => s.memory ⟨.shared,row,0,0⟩) = some (some (rowMaximum ops input row)) :=
  source_memory_of_run _ _ _ _ (source_serial_initial_fold_run p guarded ops input outside row hr)
    (serial_block_value ops input row _)
theorem source_maximum_initial_ready (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    MaximumReady p ops input row (sourceMaximumState p ops input outside row) :=
  initial_maximum_ready p ops input outside row hr
theorem source_maximum_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    (sourceMaximumState p ops input outside row).pc (row*1024+tid)=43 :=
  (source_maximum_initial_ready p ops input outside row hr).pc tid ht
theorem source_maximum_initial_epoch (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceMaximumState p ops input outside row).epochs (row*1024+tid)).block=2 :=
  (source_maximum_initial_ready p ops input outside row hr).epoch tid ht
theorem source_maximum_initial_value (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    (sourceMaximumState p ops input outside row).memory ⟨.shared,row,0,0⟩=some (rowMaximum ops input row) :=
  (source_maximum_initial_ready p ops input outside row hr).maximum
theorem source_maximum_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    ∀ a ∈ (sourceMaximumState p ops input outside row).trace, Good a :=
  (source_maximum_initial_ready p ops input outside row hr).good
theorem source_maximum_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    raceFree (sourceGeometry p) (sourceMaximumState p ops input outside row).trace=true := by
  rewrite [(source_interface_data p).2.1]
  exact initial_maximum_race_free p ops input outside row hr
theorem source_maximum_initial_trace_length (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) :
    (maximumState p ops input row (sourceInitial p input outside)).trace.length=57409 :=
  source_trace_length_of_nil (sourceInitial p input outside)
    (maximumState p ops input row (sourceInitial p input outside)) 57409 rfl
    (maximum_trace_length p ops input row (sourceInitial p input outside))
theorem source_maximum_initial_memory_frame (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (l : Location) (hl : l.space=.global ∨ l.buffer ≠ 0) :
    (sourceMaximumState p ops input outside row).memory l=(sourceInitial p input outside).memory l :=
  maximum_memory_frame p ops input row _ l hl
theorem source_initial_maximum_block (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    sourceBlock p guarded ops row sourceFuel.block (sourceInitial p input outside) =
      sourceBlock p guarded ops row 3 (sourceMaximumState p ops input outside row) := by
  rewrite [source_block_data,source_block_data,(source_interface_data p).2.2,source_initial_data]
  exact initial_maximum_block p guarded ops input outside row hr
theorem source_checksum_partial_0 : blockPartial checksumOps checksumInput 0 0 = 139537039308286975874014723701760 := by decide
theorem source_checksum_partial_1 : blockPartial checksumOps checksumInput 0 1 = 148111566927807250915720884517888 := by decide
theorem source_checksum_partial_2 : blockPartial checksumOps checksumInput 0 2 = 156686094547327525957427044634176 := by decide
theorem source_checksum_partial_3 : blockPartial checksumOps checksumInput 0 3 = 165260622166847800999133188420864 := by decide
theorem source_checksum_partial_4 : blockPartial checksumOps checksumInput 0 4 = 173835149786368076040839325349120 := by decide
theorem source_checksum_partial_5 : blockPartial checksumOps checksumInput 0 5 = 182409677405888351082545462277376 := by decide
theorem source_checksum_partial_6 : blockPartial checksumOps checksumInput 0 6 = 190984205025408626124251599205632 := by decide
theorem source_checksum_partial_7 : blockPartial checksumOps checksumInput 0 7 = 199558732644928901165957736133888 := by decide
theorem source_checksum_partial_8 : blockPartial checksumOps checksumInput 0 8 = 208133260264449176207663873062144 := by decide
theorem source_checksum_partial_9 : blockPartial checksumOps checksumInput 0 9 = 216707787883969451249370009990400 := by decide
theorem source_checksum_partial_10 : blockPartial checksumOps checksumInput 0 10 = 225282315503489726291076146918656 := by decide
theorem source_checksum_partial_11 : blockPartial checksumOps checksumInput 0 11 = 233856843123010001332782283846912 := by decide
theorem source_checksum_partial_12 : blockPartial checksumOps checksumInput 0 12 = 242431370742530276374488420775168 := by decide
theorem source_checksum_partial_13 : blockPartial checksumOps checksumInput 0 13 = 251005898362050551416194557703424 := by decide
theorem source_checksum_partial_14 : blockPartial checksumOps checksumInput 0 14 = 259580425981570826457900694631680 := by decide
theorem source_checksum_partial_15 : blockPartial checksumOps checksumInput 0 15 = 268154953601091101499606831559936 := by decide
theorem source_checksum_partial_16 : blockPartial checksumOps checksumInput 0 16 = 276729481220611376541312968488192 := by decide
theorem source_checksum_partial_17 : blockPartial checksumOps checksumInput 0 17 = 285304008840131651583019105416448 := by decide
theorem source_checksum_partial_18 : blockPartial checksumOps checksumInput 0 18 = 293878536459651926624725242344704 := by decide
theorem source_checksum_partial_19 : blockPartial checksumOps checksumInput 0 19 = 302453064079172201666431379272960 := by decide
theorem source_checksum_partial_20 : blockPartial checksumOps checksumInput 0 20 = 311027591698692476708137516201216 := by decide
theorem source_checksum_partial_21 : blockPartial checksumOps checksumInput 0 21 = 319602119318212751749843653129472 := by decide
theorem source_checksum_partial_22 : blockPartial checksumOps checksumInput 0 22 = 328176646937733026791549790057728 := by decide
theorem source_checksum_partial_23 : blockPartial checksumOps checksumInput 0 23 = 336751174557253301833255926985984 := by decide
theorem source_checksum_partial_24 : blockPartial checksumOps checksumInput 0 24 = 345325702176773576874962063914240 := by decide
theorem source_checksum_partial_25 : blockPartial checksumOps checksumInput 0 25 = 353900229796293851916668200842496 := by decide
theorem source_checksum_partial_26 : blockPartial checksumOps checksumInput 0 26 = 362474757415814126958374337770752 := by decide
theorem source_checksum_partial_27 : blockPartial checksumOps checksumInput 0 27 = 371049285035334402000080474699008 := by decide
theorem source_checksum_partial_28 : blockPartial checksumOps checksumInput 0 28 = 379623812654854677041786611627264 := by decide
theorem source_checksum_partial_29 : blockPartial checksumOps checksumInput 0 29 = 388198340274374952083492748555520 := by decide
theorem source_checksum_partial_30 : blockPartial checksumOps checksumInput 0 30 = 396772867893895227125198885483776 := by decide
theorem source_checksum_maximum : rowMaximum checksumOps checksumInput 0 = 133254668662643834119504341449835759241818635200 := by
  simp only [rowMaximum,serialMaximum,serialFold,source_checksum_partial_0, source_checksum_partial_1, source_checksum_partial_2, source_checksum_partial_3, source_checksum_partial_4, source_checksum_partial_5, source_checksum_partial_6, source_checksum_partial_7, source_checksum_partial_8, source_checksum_partial_9, source_checksum_partial_10, source_checksum_partial_11, source_checksum_partial_12, source_checksum_partial_13, source_checksum_partial_14, source_checksum_partial_15, source_checksum_partial_16, source_checksum_partial_17, source_checksum_partial_18, source_checksum_partial_19, source_checksum_partial_20, source_checksum_partial_21, source_checksum_partial_22, source_checksum_partial_23, source_checksum_partial_24, source_checksum_partial_25, source_checksum_partial_26, source_checksum_partial_27, source_checksum_partial_28, source_checksum_partial_29, source_checksum_partial_30, source_checksum_last_partial]
  decide
theorem source_checksum_maximum_run (guarded : Bool) :
    (sourceBlockFold prefixOne guarded checksumOps 0 (sourceMidState prefixOne checksumOps checksumInput (fun _ => none) 0)).map
      (fun s => s.memory ⟨.shared,0,0,0⟩) = some (some 133254668662643834119504341449835759241818635200) := by
  exact (source_serial_initial_maximum_run prefixOne guarded checksumOps checksumInput (fun _ => none) 0
    (by decide)).trans (congrArg (fun v : Nat => some (some v)) source_checksum_maximum)
#print axioms LarkNativeSoftmax.initial_maximum_block
#print axioms LarkNativeSoftmax.initial_maximum_race_free
#print axioms LarkNativeSoftmax.initial_maximum_ready
#print axioms LarkNativeSoftmax.maximum_trace_length
#print axioms LarkNativeSoftmax.serial_block_fold_run
#print axioms LarkNativeSoftmax.serial_block_step
#print axioms source_block_initial_fold_run
#print axioms source_checksum_last_partial
#print axioms source_checksum_last_partial_run
#print axioms source_checksum_maximum
#print axioms source_checksum_maximum_run
#print axioms source_checksum_partial_0
#print axioms source_checksum_partial_1
#print axioms source_checksum_partial_10
#print axioms source_checksum_partial_11
#print axioms source_checksum_partial_12
#print axioms source_checksum_partial_13
#print axioms source_checksum_partial_14
#print axioms source_checksum_partial_15
#print axioms source_checksum_partial_16
#print axioms source_checksum_partial_17
#print axioms source_checksum_partial_18
#print axioms source_checksum_partial_19
#print axioms source_checksum_partial_2
#print axioms source_checksum_partial_20
#print axioms source_checksum_partial_21
#print axioms source_checksum_partial_22
#print axioms source_checksum_partial_23
#print axioms source_checksum_partial_24
#print axioms source_checksum_partial_25
#print axioms source_checksum_partial_26
#print axioms source_checksum_partial_27
#print axioms source_checksum_partial_28
#print axioms source_checksum_partial_29
#print axioms source_checksum_partial_3
#print axioms source_checksum_partial_30
#print axioms source_checksum_partial_4
#print axioms source_checksum_partial_5
#print axioms source_checksum_partial_6
#print axioms source_checksum_partial_7
#print axioms source_checksum_partial_8
#print axioms source_checksum_partial_9
#print axioms source_initial_block_barrier
#print axioms source_initial_maximum_block
#print axioms source_maximum_initial_epoch
#print axioms source_maximum_initial_good
#print axioms source_maximum_initial_memory_frame
#print axioms source_maximum_initial_pc
#print axioms source_maximum_initial_ready
#print axioms source_maximum_initial_rf
#print axioms source_maximum_initial_trace_length
#print axioms source_maximum_initial_value
#print axioms source_serial_initial_fold_run
#print axioms source_serial_initial_maximum_run

def sourceExpState (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) : State α :=
  expPrefixState ops input row tid (sourceMaximumState p ops input outside row)
theorem source_exp_initial_entry (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ExpLaneEntry p ops input row tid (sourceMaximumState p ops input outside row) :=
  exp_lane_entry_of_maximum p ops input row tid _ (source_maximum_initial_ready p ops input outside row hr) ht
theorem source_exp_initial_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    sourceLane p guarded ops (row*1024+tid) sourceFuel.lane (sourceMaximumState p ops input outside row) =
      some (sourceExpState p ops input outside row tid) := by
  rewrite [source_lane_data,(source_interface_data p).2.2]
  exact exp_prefix_run p guarded ops input row tid _ (source_exp_initial_entry p ops input outside row tid hr ht)
theorem source_exp_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) :
    (sourceExpState p ops input outside row tid).pc (row*1024+tid)=70 :=
  exp_prefix_pc ops input row tid (sourceMaximumState p ops input outside row)
theorem source_exp_initial_epoch (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceExpState p ops input outside row tid).epochs (row*1024+tid)).block=2 :=
  (congrArg (fun epochs => (epochs (row*1024+tid)).block)
    (exp_prefix_epochs ops input row tid (sourceMaximumState p ops input outside row))).trans
    (source_maximum_initial_epoch p ops input outside row tid hr ht)
theorem source_exp_initial_sum (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    (sourceExpState p ops input outside row tid).regs (row*1024+tid) 6=some (threadExpSum ops input row tid) :=
  exp_prefix_sum p ops input row tid _ (source_exp_initial_entry p ops input outside row tid hr ht)
theorem source_exp_initial_outputs (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (ht : tid<1024) :
    ExpPastOutputs ops input (rowMaximum ops input row) row tid 7 (sourceExpState p ops input outside row tid) :=
  exp_prefix_outputs ops input row tid (sourceMaximumState p ops input outside row) ht
theorem source_exp_output_value (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid iteration component : Nat) (ht : tid<1024)
    (hi : iteration<7) (hc : component<8) (hcol : column tid iteration component<50257) :
    (sourceExpState p ops input outside row tid).memory (globalCell 0 (address row (column tid iteration component)))=
      some (ops.toHalf (expComponentValue ops input (rowMaximum ops input row) row tid iteration component)) :=
  source_exp_initial_outputs p ops input outside row tid ht iteration hi component hc hcol
theorem source_exp_output_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid iteration component : Nat) (hr : row<p.rows) (ht : tid<1024)
    (hi : iteration<7) (hc : component<8) (hcol : column tid iteration component<50257) :
    (sourceLane p guarded ops (row*1024+tid) sourceFuel.lane (sourceMaximumState p ops input outside row)).map
      (fun s => s.memory (globalCell 0 (address row (column tid iteration component))))=
        some (some (ops.toHalf (expComponentValue ops input (rowMaximum ops input row) row tid iteration component))) :=
  source_memory_of_run _ (sourceExpState p ops input outside row tid) _ _
    (source_exp_initial_run p guarded ops input outside row tid hr ht)
    (source_exp_output_value p ops input outside row tid iteration component ht hi hc hcol)
theorem source_exp_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ∀ a ∈ (sourceExpState p ops input outside row tid).trace, Good a :=
  exp_prefix_good p ops input row tid _ (source_exp_initial_entry p ops input outside row tid hr ht)
theorem source_exp_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    raceFree (sourceGeometry p) (sourceExpState p ops input outside row tid).trace=true := by
  rewrite [(source_interface_data p).2.1]
  exact exp_prefix_race_free p ops input row tid _ (source_exp_initial_entry p ops input outside row tid hr ht)
theorem source_exp_initial_native (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    MaxNativeIndices (row*1024+tid) (sourceExpState p ops input outside row tid) :=
  exp_prefix_native ops input row tid (sourceMaximumState p ops input outside row)
    ((source_maximum_initial_ready p ops input outside row hr).indices tid ht)
theorem source_exp_initial_trace_length (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (ht : tid<1024) :
    (sourceExpState p ops input outside row tid).trace.length=
      (sourceMaximumState p ops input outside row).trace.length+(if tid<81 then 213 else 211) :=
  exp_prefix_trace_exact ops input row tid (sourceMaximumState p ops input outside row) ht
theorem source_exp_trace_total_of_start (start final : State α) (n k : Nat)
    (hstart : start.trace.length=n) (hfinal : final.trace.length=start.trace.length+k) :
    final.trace.length=n+k := by
  rewrite [hstart] at hfinal
  exact hfinal
theorem source_exp_initial_trace_total (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (ht : tid<1024) :
    (sourceExpState p ops input outside row tid).trace.length=57409+(if tid<81 then 213 else 211) :=
  source_exp_trace_total_of_start (sourceMaximumState p ops input outside row)
    (sourceExpState p ops input outside row tid) 57409 (if tid<81 then 213 else 211)
    (source_maximum_initial_trace_length p ops input outside row) (source_exp_initial_trace_length p ops input outside row tid ht)
theorem source_exp_register_of_run (run : Option (State α)) (final : State α) (t r : Nat) (value : α)
    (hr : run=some final) (hv : final.regs t r=some value) :
    run.map (fun s => s.regs t r)=some (some value) := by
  rewrite [hr]
  change some (final.regs t r)=some (some value)
  rewrite [hv]
  rfl
theorem source_exp_sum_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    (sourceLane p guarded ops (row*1024+tid) sourceFuel.lane (sourceMaximumState p ops input outside row)).map
      (fun s => s.regs (row*1024+tid) 6)=some (some (threadExpSum ops input row tid)) :=
  source_exp_register_of_run _ (sourceExpState p ops input outside row tid) (row*1024+tid) 6 _
    (source_exp_initial_run p guarded ops input outside row tid hr ht)
    (source_exp_initial_sum p ops input outside row tid hr ht)
def expWordOps : Ops Nat where
  literal := fun _ _ => 0
  add := fun a b => 7*a+b
  sub := fun a b => 2*a+b
  mul := Nat.mul
  max := fun _ b => b
  div := Nat.div
  exp := fun a => 5*a+3
  tanh := id
  rsqrt := id
  fromHalf := fun a => 3*a+1
  toHalf := fun a => 7*a+1
def expWordInput : Nat → Nat → Nat := fun _ offset => offset+1
def expWordOne : Shape := ⟨1,by decide,by decide⟩
theorem exp_word_maximum : rowMaximum expWordOps expWordInput 0=150772 := by decide
theorem exp_word_sum_0 : threadExpSum expWordOps expWordInput 0 0=227512722010894451627360840823366159669454745784 := by
  simp only [threadExpSum,exp_word_maximum]
  decide
theorem exp_word_output_0 :
    expWordOps.toHalf (expComponentValue expWordOps expWordInput (rowMaximum expWordOps expWordInput 0) 0 0 0 0)=5277322 := by
  simp only [exp_word_maximum]
  decide
theorem exp_word_sum_80 : threadExpSum expWordOps expWordInput 0 80=228232108027953416486008952959594019409155244984 := by
  simp only [threadExpSum,exp_word_maximum]
  decide
theorem exp_word_output_80 :
    expWordOps.toHalf (expComponentValue expWordOps expWordInput (rowMaximum expWordOps expWordInput 0) 0 80 0 0)=5294122 := by
  simp only [exp_word_maximum]
  decide
theorem exp_word_sum_81 : threadExpSum expWordOps expWordInput 0 81=32605871479023807649534579194470981093699891373 := by
  simp only [threadExpSum,exp_word_maximum]
  decide
theorem exp_word_output_81 :
    expWordOps.toHalf (expComponentValue expWordOps expWordInput (rowMaximum expWordOps expWordInput 0) 0 81 0 0)=5294332 := by
  simp only [exp_word_maximum]
  decide
theorem exp_word_sum_1023 : threadExpSum expWordOps expWordInput 0 1023=33815981529147994965331939252197130870124655633 := by
  simp only [threadExpSum,exp_word_maximum]
  decide
theorem exp_word_output_1023 :
    expWordOps.toHalf (expComponentValue expWordOps expWordInput (rowMaximum expWordOps expWordInput 0) 0 1023 0 0)=5492152 := by
  simp only [exp_word_maximum]
  decide
theorem source_exp_word_sum_run (guarded : Bool) (tid n : Nat) (ht : tid<1024)
    (hsum : threadExpSum expWordOps expWordInput 0 tid=n) :
    (sourceLane expWordOne guarded expWordOps (0*1024+tid) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+tid) 6)=some (some n) :=
  (source_exp_sum_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 tid (by decide) ht).trans
    (congrArg (fun value : Nat => some (some value)) hsum)
theorem source_exp_word_output_run (guarded : Bool) (tid n : Nat) (ht : tid<1024)
    (hout : expWordOps.toHalf (expComponentValue expWordOps expWordInput (rowMaximum expWordOps expWordInput 0) 0 tid 0 0)=n) :
    (sourceLane expWordOne guarded expWordOps (0*1024+tid) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory (globalCell 0 (address 0 (column tid 0 0))))=some (some n) :=
  (source_exp_output_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 tid 0 0
    (by decide) ht (by decide) (by decide) (by unfold column; omega)).trans
    (congrArg (fun value : Nat => some (some value)) hout)
theorem source_exp_word_sum_0 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+0) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+0) 6)=some (some 227512722010894451627360840823366159669454745784) :=
  source_exp_word_sum_run guarded 0 227512722010894451627360840823366159669454745784 (by decide) exp_word_sum_0
theorem source_exp_word_output_0 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+0) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory (globalCell 0 (address 0 (column 0 0 0))))=some (some 5277322) :=
  source_exp_word_output_run guarded 0 5277322 (by decide) exp_word_output_0
theorem source_exp_word_sum_80 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+80) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+80) 6)=some (some 228232108027953416486008952959594019409155244984) :=
  source_exp_word_sum_run guarded 80 228232108027953416486008952959594019409155244984 (by decide) exp_word_sum_80
theorem source_exp_word_output_80 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+80) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory (globalCell 0 (address 0 (column 80 0 0))))=some (some 5294122) :=
  source_exp_word_output_run guarded 80 5294122 (by decide) exp_word_output_80
theorem source_exp_word_sum_81 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+81) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+81) 6)=some (some 32605871479023807649534579194470981093699891373) :=
  source_exp_word_sum_run guarded 81 32605871479023807649534579194470981093699891373 (by decide) exp_word_sum_81
theorem source_exp_word_output_81 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+81) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory (globalCell 0 (address 0 (column 81 0 0))))=some (some 5294332) :=
  source_exp_word_output_run guarded 81 5294332 (by decide) exp_word_output_81
theorem source_exp_word_sum_1023 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+1023) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+1023) 6)=some (some 33815981529147994965331939252197130870124655633) :=
  source_exp_word_sum_run guarded 1023 33815981529147994965331939252197130870124655633 (by decide) exp_word_sum_1023
theorem source_exp_word_output_1023 (guarded : Bool) :
    (sourceLane expWordOne guarded expWordOps (0*1024+1023) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory (globalCell 0 (address 0 (column 1023 0 0))))=some (some 5492152) :=
  source_exp_word_output_run guarded 1023 5492152 (by decide) exp_word_output_1023
#print axioms LarkNativeSoftmax.exp_prefix_cost_exact
#print axioms LarkNativeSoftmax.exp_prefix_outputs
#print axioms LarkNativeSoftmax.exp_prefix_run
#print axioms LarkNativeSoftmax.exp_prefix_trace_exact
#print axioms LarkNativeSoftmax.initial_exp_prefix_race_free
#print axioms LarkNativeSoftmax.initial_exp_prefix_run
#print axioms exp_word_maximum
#print axioms exp_word_output_0
#print axioms exp_word_output_1023
#print axioms exp_word_output_80
#print axioms exp_word_output_81
#print axioms exp_word_sum_0
#print axioms exp_word_sum_1023
#print axioms exp_word_sum_80
#print axioms exp_word_sum_81
#print axioms source_exp_initial_entry
#print axioms source_exp_initial_epoch
#print axioms source_exp_initial_good
#print axioms source_exp_initial_native
#print axioms source_exp_initial_outputs
#print axioms source_exp_initial_pc
#print axioms source_exp_initial_rf
#print axioms source_exp_initial_run
#print axioms source_exp_initial_sum
#print axioms source_exp_initial_trace_length
#print axioms source_exp_initial_trace_total
#print axioms source_exp_output_run
#print axioms source_exp_output_value
#print axioms source_exp_register_of_run
#print axioms source_exp_sum_run
#print axioms source_exp_trace_total_of_start
#print axioms source_exp_word_output_0
#print axioms source_exp_word_output_1023
#print axioms source_exp_word_output_80
#print axioms source_exp_word_output_81
#print axioms source_exp_word_output_run
#print axioms source_exp_word_sum_0
#print axioms source_exp_word_sum_1023
#print axioms source_exp_word_sum_80
#print axioms source_exp_word_sum_81
#print axioms source_exp_word_sum_run

def sourceExpWaveState (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) : State α :=
  expWave p ops input row warp (sourceMaximumState p ops input outside row)
theorem source_exp_wave_initial_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row<p.rows) (hw : warp<16) :
    sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceMaximumState p ops input outside row)=some (sourceExpWaveState p ops input outside row warp) := by
  rewrite [source_warp_data,(source_interface_data p).2.1,(source_interface_data p).2.2]
  exact exp_wave_of_maximum p guarded ops input row warp _ hw (source_maximum_initial_ready p ops input outside row hr)
theorem source_exp_wave_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp lane : Nat) (hl : lane<64) :
    (sourceExpWaveState p ops input outside row warp).pc (cohortBase row warp+lane)=82 :=
  exp_wave_pc p ops input row warp lane _ hl
theorem source_exp_wave_initial_epoch (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp lane : Nat) (hr : row<p.rows) (hw : warp<16) (hl : lane<64) :
    ((sourceExpWaveState p ops input outside row warp).epochs (cohortBase row warp+lane)).block=2 := by
  have h := congrArg (fun epochs => (epochs (cohortBase row warp+lane)).block)
    (exp_wave_epochs p ops input row warp (sourceMaximumState p ops input outside row))
  apply h.trans
  simpa only [cohortBase,Nat.add_assoc] using
    source_maximum_initial_epoch p ops input outside row (warp*64+lane) hr (by omega)
theorem source_exp_wave_initial_partial (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp half : Nat) (hw : warp<16) (hh : half<2) :
    (sourceExpWaveState p ops input outside row warp).memory ⟨.shared,row,1,warp*2+half⟩=
      some (sumWaveValues ops input row warp 5 (half*32)) :=
  exp_wave_partial p ops input row warp half _ hw hh
theorem source_exp_wave_partial_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp half : Nat) (hr : row<p.rows) (hw : warp<16) (hh : half<2) :
    (sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceMaximumState p ops input outside row)).map (fun s => s.memory ⟨.shared,row,1,warp*2+half⟩)=
        some (some (sumWaveValues ops input row warp 5 (half*32))) :=
  source_memory_of_run _ (sourceExpWaveState p ops input outside row warp) _ _
    (source_exp_wave_initial_run p guarded ops input outside row warp hr hw)
    (source_exp_wave_initial_partial p ops input outside row warp half hw hh)
theorem source_exp_wave_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row<p.rows) (hw : warp<16) :
    ∀ a ∈ (sourceExpWaveState p ops input outside row warp).trace, Good a :=
  exp_wave_good p ops input row warp _ hw (exp_cohort_entry_of_maximum p ops input row warp _ hw
    (source_maximum_initial_ready p ops input outside row hr))
theorem source_exp_wave_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row<p.rows) (hw : warp<16) :
    raceFree (sourceGeometry p) (sourceExpWaveState p ops input outside row warp).trace=true := by
  rewrite [(source_interface_data p).2.1]
  exact race_free p _ (source_exp_wave_initial_good p ops input outside row warp hr hw)
theorem source_exp_wave_initial_sum (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp lane : Nat) (hw : warp<16) (hl : lane<64) :
    (sourceExpWaveState p ops input outside row warp).regs (cohortBase row warp+lane) 6=
      some (sumWaveValues ops input row warp 5 lane) :=
  exp_wave_sum p ops input row warp lane _ hw hl
theorem source_exp_wave_sum_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp lane : Nat) (hr : row<p.rows) (hw : warp<16) (hl : lane<64) :
    (sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceMaximumState p ops input outside row)).map (fun s => s.regs (cohortBase row warp+lane) 6)=
        some (some (sumWaveValues ops input row warp 5 lane)) :=
  source_exp_register_of_run _ (sourceExpWaveState p ops input outside row warp) _ _ _
    (source_exp_wave_initial_run p guarded ops input outside row warp hr hw)
    (source_exp_wave_initial_sum p ops input outside row warp lane hw hl)
theorem exp_wave_word_0_0 : sumWaveValues expWordOps expWordInput 0 0 5 (0*32)=7456278684339265379949006315682683179027545742180352 := by
  simp only [sumWaveValues,threadExpSum,exp_word_maximum]
  decide
theorem source_exp_wave_word_0_0 (guarded : Bool) :
    (sourceWarp expWordOne guarded expWordOps (warpThreads (sourceGeometry expWordOne) 0 0) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,0*2+0⟩)=some (some 7456278684339265379949006315682683179027545742180352) :=
  (source_exp_wave_partial_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 0 0
    (by decide) (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) exp_wave_word_0_0)
theorem exp_wave_word_0_1 : sumWaveValues expWordOps expWordInput 0 0 5 (1*32)=7465707820742060644144278851074648982207748125294592 := by
  simp only [sumWaveValues,threadExpSum,exp_word_maximum]
  decide
theorem source_exp_wave_word_0_1 (guarded : Bool) :
    (sourceWarp expWordOne guarded expWordOps (warpThreads (sourceGeometry expWordOne) 0 0) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,0*2+1⟩)=some (some 7465707820742060644144278851074648982207748125294592) :=
  (source_exp_wave_partial_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 0 1
    (by decide) (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) exp_wave_word_0_1)
theorem exp_wave_word_1_0 : sumWaveValues expWordOps expWordInput 0 1 5 (0*32)=7143489113574839878422223905868109296159210485174537 := by
  simp only [sumWaveValues,threadExpSum,exp_word_maximum]
  decide
theorem source_exp_wave_word_1_0 (guarded : Bool) :
    (sourceWarp expWordOne guarded expWordOps (warpThreads (sourceGeometry expWordOne) 0 1) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,1*2+0⟩)=some (some 7143489113574839878422223905868109296159210485174537) :=
  (source_exp_wave_partial_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 1 0
    (by decide) (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) exp_wave_word_1_0)
theorem exp_wave_word_1_1 : sumWaveValues expWordOps expWordInput 0 1 5 (1*32)=1069223727649664453219260560265511512652582680633344 := by
  simp only [sumWaveValues,threadExpSum,exp_word_maximum]
  decide
theorem source_exp_wave_word_1_1 (guarded : Bool) :
    (sourceWarp expWordOne guarded expWordOps (warpThreads (sourceGeometry expWordOne) 0 1) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,1*2+1⟩)=some (some 1069223727649664453219260560265511512652582680633344) :=
  (source_exp_wave_partial_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 1 1
    (by decide) (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) exp_wave_word_1_1)
theorem exp_wave_word_15_0 : sumWaveValues expWordOps expWordInput 0 15 5 (0*32)=1105593253774731900829597482491665324919077465595904 := by
  simp only [sumWaveValues,threadExpSum,exp_word_maximum]
  decide
theorem source_exp_wave_word_15_0 (guarded : Bool) :
    (sourceWarp expWordOne guarded expWordOps (warpThreads (sourceGeometry expWordOne) 0 15) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,15*2+0⟩)=some (some 1105593253774731900829597482491665324919077465595904) :=
  (source_exp_wave_partial_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 15 0
    (by decide) (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) exp_wave_word_15_0)
theorem exp_wave_word_15_1 : sumWaveValues expWordOps expWordInput 0 15 5 (1*32)=1106940273260845510000350701833374725373392087261184 := by
  simp only [sumWaveValues,threadExpSum,exp_word_maximum]
  decide
theorem source_exp_wave_word_15_1 (guarded : Bool) :
    (sourceWarp expWordOne guarded expWordOps (warpThreads (sourceGeometry expWordOne) 0 15) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,15*2+1⟩)=some (some 1106940273260845510000350701833374725373392087261184) :=
  (source_exp_wave_partial_run expWordOne guarded expWordOps expWordInput (fun _ => none) 0 15 1
    (by decide) (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) exp_wave_word_15_1)
#print axioms LarkNativeSoftmax.cohort_sum_xor_shuffle
#print axioms LarkNativeSoftmax.exp_wave_of_maximum
#print axioms LarkNativeSoftmax.exp_wave_partial
#print axioms LarkNativeSoftmax.exp_wave_race_free
#print axioms LarkNativeSoftmax.exp_wave_run
#print axioms LarkNativeSoftmax.exp_wave_sum
#print axioms LarkNativeSoftmax.initial_exp_wave
#print axioms LarkNativeSoftmax.native_sum_first_four_of_cohort
#print axioms LarkNativeSoftmax.sum_last_wave_warp
#print axioms LarkNativeSoftmax.sum_xor_peer_partition
#print axioms exp_wave_word_0_0
#print axioms exp_wave_word_0_1
#print axioms exp_wave_word_15_0
#print axioms exp_wave_word_15_1
#print axioms exp_wave_word_1_0
#print axioms exp_wave_word_1_1
#print axioms source_exp_wave_initial_epoch
#print axioms source_exp_wave_initial_good
#print axioms source_exp_wave_initial_partial
#print axioms source_exp_wave_initial_pc
#print axioms source_exp_wave_initial_rf
#print axioms source_exp_wave_initial_run
#print axioms source_exp_wave_initial_sum
#print axioms source_exp_wave_partial_run
#print axioms source_exp_wave_sum_run
#print axioms source_exp_wave_word_0_0
#print axioms source_exp_wave_word_0_1
#print axioms source_exp_wave_word_15_0
#print axioms source_exp_wave_word_15_1
#print axioms source_exp_wave_word_1_0
#print axioms source_exp_wave_word_1_1

def sourceSumState (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : State α :=
  sumState p ops input row (sourceInitial p input outside)
def sourceReductionPhase (p : Shape) (guarded : Bool) (ops : Ops α) (row : Nat) (s : State α) : Option (State α) := do
  let next ← sourceBlockFold p guarded ops row s
  let cut ← LarkCollective.converged (if guarded then sourceFixed else sourceOriginal)
    (blockThreads (sourceGeometry p) row) next
  if cut=.block then some (resume (blockThreads (sourceGeometry p) row) .block next) else none
def sourceReductionPrefix (p : Shape) (guarded : Bool) (ops : Ops α) (row : Nat) : Nat → State α → Option (State α)
  | 0,s => some s
  | count+1,s => (sourceReductionPhase p guarded ops row s).bind (sourceReductionPrefix p guarded ops row count)
theorem source_reduction_phase_data (p : Shape) (guarded : Bool) (ops : Ops α) (row : Nat) (s : State α) :
    sourceReductionPhase p guarded ops row s=reductionPhase p guarded ops row s := by
  simp only [sourceReductionPhase,reductionPhase,source_block_fold_data,(source_interface_data p).2.1,
    program,source_program_data.1,source_program_data.2]
  have hc : ((geometry p).block+(geometry p).warp-1)/(geometry p).warp=16 := by
    change (1024+64-1)/64=16
    decide
  rewrite [hc]
  rfl
theorem source_reduction_prefix_data (p : Shape) (guarded : Bool) (ops : Ops α) (row count : Nat) (s : State α) :
    sourceReductionPrefix p guarded ops row count s=reductionPrefix p guarded ops row count s := by
  induction count generalizing s with
  | zero => rfl
  | succ count ih =>
    simp only [sourceReductionPrefix,reductionPrefix,source_reduction_phase_data]
    have hf : sourceReductionPrefix p guarded ops row count=reductionPrefix p guarded ops row count := by
      funext next
      exact ih next
    rewrite [hf]
    rfl
theorem source_reduction_initial_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    sourceReductionPrefix p guarded ops row 4 (sourceInitial p input outside)=some (sourceSumState p ops input outside row) := by
  rewrite [source_reduction_prefix_data]
  exact reduction_prefix_run p guarded ops input row _ (by
    rewrite [source_initial_data]
    exact initial_block_entry p input outside row hr)
theorem source_reduction_continuation (p : Shape) (guarded : Bool) (ops : Ops α) (row count extra : Nat)
    (s next : State α) (h : sourceReductionPrefix p guarded ops row count s=some next) :
    sourceBlock p guarded ops row (extra+count) s=sourceBlock p guarded ops row extra next := by
  rewrite [source_reduction_prefix_data] at h
  rewrite [source_block_data,source_block_data]
  exact reduction_prefix_continue p guarded ops row count extra s next h
theorem source_sum_initial_ready (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    SumReady p ops input row (sourceSumState p ops input outside row) := by
  change SumReady p ops input row (sumState p ops input row (sourceInitial p input outside))
  rewrite [source_initial_data]
  exact initial_sum_ready p ops input outside row hr
theorem source_sum_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    (sourceSumState p ops input outside row).pc (row*1024+tid)=93 :=
  (source_sum_initial_ready p ops input outside row hr).pc tid ht
theorem source_sum_initial_epoch (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceSumState p ops input outside row).epochs (row*1024+tid)).block=4 :=
  (source_sum_initial_ready p ops input outside row hr).epoch tid ht
theorem source_sum_initial_total (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    (sourceSumState p ops input outside row).memory ⟨.shared,row,1,0⟩=some (rowExpSum ops input row) :=
  (source_sum_initial_ready p ops input outside row hr).total
theorem source_sum_initial_outputs (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : ExpOutputRow ops input row (sourceSumState p ops input outside row) :=
  sum_state_outputs p ops input row (sourceInitial p input outside)
theorem source_sum_initial_output (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row col : Nat) (hc : col<50257) :
    (sourceSumState p ops input outside row).memory (globalCell 0 (address row col))=some (expOutputValue ops input row col) :=
  source_sum_initial_outputs p ops input outside row col hc
theorem source_sum_initial_trace (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : (sourceSumState p ops input outside row).trace.length=273700 := by
  change (sumState p ops input row (sourceInitial p input outside)).trace.length=273700
  rewrite [source_initial_data]
  exact initial_sum_trace_length p ops input outside row
theorem source_sum_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    ∀ a ∈ (sourceSumState p ops input outside row).trace, Good a :=
  (source_sum_initial_ready p ops input outside row hr).good
theorem source_sum_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    raceFree (sourceGeometry p) (sourceSumState p ops input outside row).trace=true := by
  rewrite [(source_interface_data p).2.1]
  exact race_free p _ (source_sum_initial_good p ops input outside row hr)
theorem source_sum_total_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    (sourceReductionPrefix p guarded ops row 4 (sourceInitial p input outside)).map (fun s => s.memory ⟨.shared,row,1,0⟩)=
      some (some (rowExpSum ops input row)) :=
  source_memory_of_run _ (sourceSumState p ops input outside row) _ _
    (source_reduction_initial_run p guarded ops input outside row hr) (source_sum_initial_total p ops input outside row hr)
theorem source_sum_output_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row col : Nat) (hr : row<p.rows) (hc : col<50257) :
    (sourceReductionPrefix p guarded ops row 4 (sourceInitial p input outside)).map (fun s => s.memory (globalCell 0 (address row col)))=
      some (some (expOutputValue ops input row col)) :=
  source_memory_of_run _ (sourceSumState p ops input outside row) _ _
    (source_reduction_initial_run p guarded ops input outside row hr) (source_sum_initial_output p ops input outside row col hc)
theorem source_initial_sum_block (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    sourceBlock p guarded ops row sourceFuel.block (sourceInitial p input outside)=
      sourceBlock p guarded ops row 1 (sourceSumState p ops input outside row) := by
  rewrite [show sourceFuel.block=1+4 by decide]
  exact source_reduction_continuation p guarded ops row 4 1 _ _ (source_reduction_initial_run p guarded ops input outside row hr)

def reductionProjectionOps : Ops Nat where
  literal := fun _ _ => 0
  add := fun _ b => b
  sub := fun a b => 2*a+b
  mul := Nat.mul
  max := fun _ b => b
  div := Nat.div
  exp := fun a => 5*a+3
  tanh := id
  rsqrt := id
  fromHalf := fun a => 3*a+1
  toHalf := fun a => 7*a+1

def reductionProjectionInput : Nat → Nat → Nat := fun _ offset => offset+1

theorem reduction_projection_maximum : rowMaximum reductionProjectionOps reductionProjectionInput 0=150772 := by decide

theorem reduction_projection_total : rowExpSum reductionProjectionOps reductionProjectionInput 0=2259153 := by decide

theorem source_reduction_projection_total (guarded : Bool) :
    (sourceReductionPrefix expWordOne guarded reductionProjectionOps 0 4
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map (fun s => s.memory ⟨.shared,0,1,0⟩)=
      some (some 2259153) :=
  (source_sum_total_run expWordOne guarded reductionProjectionOps reductionProjectionInput (fun _ => none) 0 (by decide)).trans
    (congrArg (fun n : Nat => some (some n)) reduction_projection_total)
theorem reduction_projection_output_0 : expOutputValue reductionProjectionOps reductionProjectionInput 0 0=5277322 := by decide
theorem source_reduction_projection_output_0 (guarded : Bool) :
    (sourceReductionPrefix expWordOne guarded reductionProjectionOps 0 4
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 0)))=some (some 5277322) :=
  (source_sum_output_run expWordOne guarded reductionProjectionOps reductionProjectionInput (fun _ => none) 0 0 (by decide) (by decide)).trans
    (congrArg (fun n : Nat => some (some n)) reduction_projection_output_0)
theorem reduction_projection_output_50256 : expOutputValue reductionProjectionOps reductionProjectionInput 0 50256=15831082 := by decide
theorem source_reduction_projection_output_50256 (guarded : Bool) :
    (sourceReductionPrefix expWordOne guarded reductionProjectionOps 0 4
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 50256)))=some (some 15831082) :=
  (source_sum_output_run expWordOne guarded reductionProjectionOps reductionProjectionInput (fun _ => none) 0 50256 (by decide) (by decide)).trans
    (congrArg (fun n : Nat => some (some n)) reduction_projection_output_50256)
def sumChecksumState : State Nat where
  pc := fun _ => 83
  indices := fun t r => if r=0 then some ((t/1024 : Nat) : Int)
    else if r=1 then some ((t%1024 : Nat) : Int)
    else if r=2 then some ((t%1024/32 : Nat) : Int)
    else if r=3 then some ((t%1024%32 : Nat) : Int) else none
  regs := fun _ _ => none
  memory := fun l => if l.space=.shared ∧ l.owner=0 ∧ l.buffer=1 ∧ l.offset<32 then some (l.offset+1) else none
  epochs := fun _ => ⟨0,3,0⟩
  trace := []
theorem sum_checksum_entry : SumSerialWavesEntry (fun slot : Nat => slot+1) 0 (List.range 16) sumChecksumState := by
  exact {
    pc := by intro w hw t ht; rfl
    native := by intro w hw t ht; simp [MaxNativeIndices,sumChecksumState]
    pending := by intro h slot hs; simp [sumPartialCell,sumChecksumState,hs]
    epoch := by intro w hw t ht; rfl
    good := by intro a ha; cases ha }
theorem source_sum_checksum_fold (guarded : Bool) :
    sourceBlockFold expWordOne guarded expWordOps 0 sumChecksumState=
      some (sumSerialWaves expWordOps (fun slot : Nat => slot+1) 0 (List.range 16) sumChecksumState) := by
  rewrite [source_block_fold_data]
  exact sum_serial_waves_run expWordOne guarded expWordOps (fun slot : Nat => slot+1) 0 _ sumChecksumState
    List.nodup_range (fun _w hw => List.mem_range.mp hw) sum_checksum_entry
theorem sum_checksum_closed : sumSerialTotal expWordOps (fun slot : Nat => slot+1)=214749825547429014559363728 := by decide
theorem source_sum_checksum_run (guarded : Bool) :
    (sourceBlockFold expWordOne guarded expWordOps 0 sumChecksumState).map (fun s => s.memory ⟨.shared,0,1,0⟩)=some (some 214749825547429014559363728) := by
  apply source_memory_of_run _ (sumSerialWaves expWordOps (fun slot : Nat => slot+1) 0 (List.range 16) sumChecksumState) _ _
    (source_sum_checksum_fold guarded)
  exact (sum_serial_waves_value expWordOps (fun slot : Nat => slot+1) 0 (List.range 16) sumChecksumState (by decide)).trans
    (congrArg some sum_checksum_closed)
#print axioms source_reduction_phase_data
#print axioms source_reduction_prefix_data
#print axioms source_reduction_initial_run
#print axioms source_reduction_continuation
#print axioms source_sum_initial_ready
#print axioms source_sum_initial_pc
#print axioms source_sum_initial_epoch
#print axioms source_sum_initial_total
#print axioms source_sum_initial_outputs
#print axioms source_sum_initial_output
#print axioms source_sum_initial_trace
#print axioms source_sum_initial_good
#print axioms source_sum_initial_rf
#print axioms source_sum_total_run
#print axioms source_sum_output_run
#print axioms source_initial_sum_block
#print axioms reduction_projection_maximum
#print axioms reduction_projection_total
#print axioms source_reduction_projection_total
#print axioms reduction_projection_output_0
#print axioms source_reduction_projection_output_0
#print axioms reduction_projection_output_50256
#print axioms source_reduction_projection_output_50256
#print axioms sum_checksum_entry
#print axioms source_sum_checksum_fold
#print axioms sum_checksum_closed
#print axioms source_sum_checksum_run


def sourceWholeBlock (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) : State α :=
  wholeBlock p guarded ops input row (sourceInitial p input outside)

theorem source_whole_block_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    sourceBlock p guarded ops row sourceFuel.block (sourceInitial p input outside)=
      some (sourceWholeBlock p guarded ops input outside row) := by
  rewrite [source_block_data,(source_interface_data p).2.2]
  exact whole_block_run p guarded ops input row _ (by
    rewrite [source_initial_data]
    exact initial_block_entry p input outside row hr)

theorem source_whole_block_pc (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (ht : tid<1024) :
    (sourceWholeBlock p guarded ops input outside row).pc (row*1024+tid)=normPc guarded 115 :=
  whole_block_pc p guarded ops input row tid _ ht

theorem source_whole_block_epoch (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceWholeBlock p guarded ops input outside row).epochs (row*1024+tid)).block=4 :=
  (congrArg (fun epochs => (epochs (row*1024+tid)).block)
    (whole_block_normalization_epochs p guarded ops input row (sourceInitial p input outside))).trans
      (source_sum_initial_epoch p ops input outside row tid hr ht)

theorem source_whole_block_outputs (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) :
    NormOutputRow ops input row (sourceWholeBlock p guarded ops input outside row) :=
  whole_block_outputs p guarded ops input row _

theorem source_whole_block_output (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row col : Nat) (hc : col<50257) :
    (sourceWholeBlock p guarded ops input outside row).memory (globalCell 0 (address row col))=
      some (normOutputValue ops input row col) := source_whole_block_outputs p guarded ops input outside row col hc

theorem source_whole_block_trace (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) :
    (sourceWholeBlock p guarded ops input outside row).trace.length=(if guarded then 475752 else 489926) := by
  change (wholeBlock p guarded ops input row (sourceInitial p input outside)).trace.length=_
  rewrite [source_initial_data]
  exact initial_whole_block_trace_length p guarded ops input outside row

theorem source_whole_block_fixed_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    ∀ a ∈ (sourceWholeBlock p true ops input outside row).trace, Good a :=
  whole_block_fixed_good p ops input row _ (by
    rewrite [source_initial_data]
    exact initial_block_entry p input outside row hr)

theorem source_whole_block_fixed_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    raceFree (sourceGeometry p) (sourceWholeBlock p true ops input outside row).trace=true := by
  rewrite [(source_interface_data p).2.1]
  exact race_free p _ (source_whole_block_fixed_good p ops input outside row hr)

theorem source_whole_block_output_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row col : Nat) (hr : row<p.rows) (hc : col<50257) :
    (sourceBlock p guarded ops row sourceFuel.block (sourceInitial p input outside)).map
      (fun s => s.memory (globalCell 0 (address row col)))=some (some (normOutputValue ops input row col)) :=
  source_memory_of_run _ (sourceWholeBlock p guarded ops input outside row) _ _
    (source_whole_block_run p guarded ops input outside row hr) (source_whole_block_output p guarded ops input outside row col hc)

theorem source_whole_block_not_none (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row<p.rows) :
    sourceBlock p guarded ops row sourceFuel.block (sourceInitial p input outside) ≠ none := by
  rewrite [source_whole_block_run p guarded ops input outside row hr]
  simp only [ne_eq,reduceCtorEq,not_false_eq_true]

theorem source_normalization_lane_run (p : Shape) (guarded : Bool) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    sourceLane p guarded ops (row*1024+tid) sourceFuel.lane (sourceSumState p ops input outside row)=
      some (normLaneState guarded ops input row tid (sourceSumState p ops input outside row)) := by
  rewrite [source_lane_data,(source_interface_data p).2.2]
  exact norm_lane_run p guarded ops input row tid _
    (norm_entry_of_sum p ops input row tid _ ht (source_sum_initial_ready p ops input outside row hr)
      (source_sum_initial_outputs p ops input outside row))

theorem source_normalization_lane_cost (guarded : Bool) (tid : Nat) (ht : tid<1024) :
    normLaneCost guarded tid=(if guarded then (if tid<81 then 862 else 857) else (if tid<81 then 880 else 878)) :=
  norm_lane_cost_exact guarded tid ht

theorem whole_projection_value_0 : normOutputValue reductionProjectionOps reductionProjectionInput 0 0=50 := by
  unfold normOutputValue
  rewrite [reduction_projection_output_0,reduction_projection_total]
  decide

theorem whole_projection_value_50256 : normOutputValue reductionProjectionOps reductionProjectionInput 0 50256=148 := by
  unfold normOutputValue
  rewrite [reduction_projection_output_50256,reduction_projection_total]
  decide

theorem source_whole_projection_output_0 (guarded : Bool) :
    (sourceBlock expWordOne guarded reductionProjectionOps 0 sourceFuel.block
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 0)))=some (some 50) :=
  (source_whole_block_output_run expWordOne guarded reductionProjectionOps reductionProjectionInput (fun _ => none) 0 0
    (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) whole_projection_value_0)

theorem source_whole_projection_output_50256 (guarded : Bool) :
    (sourceBlock expWordOne guarded reductionProjectionOps 0 sourceFuel.block
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 50256)))=some (some 148) :=
  (source_whole_block_output_run expWordOne guarded reductionProjectionOps reductionProjectionInput (fun _ => none) 0 50256
    (by decide) (by decide)).trans (congrArg (fun n : Nat => some (some n)) whole_projection_value_50256)

#print axioms source_whole_block_run
#print axioms source_whole_block_pc
#print axioms source_whole_block_epoch
#print axioms source_whole_block_outputs
#print axioms source_whole_block_output
#print axioms source_whole_block_trace
#print axioms source_whole_block_fixed_good
#print axioms source_whole_block_fixed_rf
#print axioms source_whole_block_output_run
#print axioms source_whole_block_not_none
#print axioms source_normalization_lane_run
#print axioms source_normalization_lane_cost
#print axioms whole_projection_value_0
#print axioms whole_projection_value_50256
#print axioms source_whole_projection_output_0
#print axioms source_whole_projection_output_50256


def sourceLaunch (p : Shape) (guarded : Bool) (ops : Ops α) (s : State α) : Option (State α) :=
  LarkPartitionCollective.runLaunch ops (sourceLayout p) (sourceGeometry p) sourceFuel
    (if guarded then sourceFixed else sourceOriginal) s

def sourceFixedGrid (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  fixedInitialGrid p ops input outside

theorem source_launch_data (p : Shape) (guarded : Bool) (ops : Ops α) (s : State α) :
    sourceLaunch p guarded ops s=
      LarkPartitionCollective.runLaunch ops (layout p) (geometry p) fuel (program guarded) s := by
  simp only [sourceLaunch,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1,(source_interface_data p).2.2]

theorem source_fixed_grid_launch (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    sourceLaunch p true ops (sourceInitial p input outside)=some (sourceFixedGrid p ops input outside) := by
  rewrite [source_launch_data,source_initial_data]
  exact initial_fixed_launch p ops input outside

theorem source_fixed_grid_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    (sourceFixedGrid p ops input outside).pc (row*1024+tid)=115 :=
  fixed_grid_pc p ops input row tid (initial (layout p) input outside) hr ht

theorem source_fixed_grid_epoch (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceFixedGrid p ops input outside).epochs (row*1024+tid)).block=4 :=
  fixed_grid_epoch p ops input row tid (initial (layout p) input outside)
    (initial_grid_rows_entry p input outside) hr ht

theorem source_fixed_grid_trace (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    (sourceFixedGrid p ops input outside).trace.length=475752*p.rows :=
  initial_fixed_grid_trace_length p ops input outside

theorem source_fixed_grid_output (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (offset : Nat) (ho : offset<p.rows*50257) :
    (sourceFixedGrid p ops input outside).memory (globalCell 0 offset)=some (sourceOutputValue ops input offset) :=
  initial_fixed_grid_flat_output p ops input outside offset ho

theorem source_fixed_grid_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    raceFree (sourceGeometry p) (sourceFixedGrid p ops input outside).trace=true := by
  rewrite [(source_interface_data p).2.1]
  exact initial_fixed_grid_race_free p ops input outside

theorem source_fixed_grid_extract (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    extract (sourceLayout p) (sourceFixedGrid p ops input outside)=some (sourceOrderedSpec p ops input) := by
  rewrite [(source_interface_data p).1]
  exact initial_fixed_grid_extract p ops input outside

theorem source_fixed_grid_correct (p : Shape) (ops : Ops α) :
    LarkPartitionCollective.Correct ops (sourceLayout p) (sourceGeometry p) sourceFuel sourceFixed (sourceOrderedSpec p ops) := by
  rewrite [(source_interface_data p).1,(source_interface_data p).2.1,(source_interface_data p).2.2,source_program_data.2]
  exact source_order_correct p ops

#print axioms source_launch_data
#print axioms source_fixed_grid_launch
#print axioms source_fixed_grid_pc
#print axioms source_fixed_grid_epoch
#print axioms source_fixed_grid_trace
#print axioms source_fixed_grid_output
#print axioms source_fixed_grid_rf
#print axioms source_fixed_grid_extract
#print axioms source_fixed_grid_correct
