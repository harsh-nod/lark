import RealMain
open LarkNonlinear LarkNativeSoftmax LarkReal.NativeSoftmax
example :
    (sumTree 5 0).leaves.Perm (List.range' 0 31) := by decide
