import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) :
    ((sourceFixedGrid p ops input outside).trace.length == 475752*p.rows)=false := by
  rewrite [source_fixed_grid_trace p ops input outside]
  simp only [beq_self_eq_true]
  decide
