import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat) :
    ((sourceOrderedSpec p ops input).length == p.rows*50257)=false := by
  rewrite [source_ordered_spec_length]
  simp only [beq_self_eq_true]
  decide
