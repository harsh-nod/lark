import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) :
    (extract (sourceLayout p) (sourceFixedGrid p ops input outside)).isSome=false := by
  rewrite [source_fixed_grid_extract p ops input outside]
  simp only [Option.isSome_some]
  decide
