import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) :
    (sourceLaunch p true ops (sourceInitial p input outside)).isSome=false := by
  rewrite [source_fixed_grid_launch p ops input outside]
  simp only [Option.isSome_some]
  decide
