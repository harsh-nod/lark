import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat)
    (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceFixedGrid p ops input outside).epochs (row*1024+tid)).block=5 := by
  rewrite [source_fixed_grid_epoch p ops input outside row tid hr ht]
  decide
