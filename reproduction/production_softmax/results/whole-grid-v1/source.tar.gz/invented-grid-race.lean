import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) :
    raceFree (sourceGeometry p) (sourceFixedGrid p ops input outside).trace=false := by
  rewrite [source_fixed_grid_rf p ops input outside]
  decide
