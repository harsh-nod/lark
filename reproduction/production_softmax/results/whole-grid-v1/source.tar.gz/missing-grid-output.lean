import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat)
    (offset : Nat) (ho : offset<p.rows*50257) :
    ((sourceFixedGrid p ops input outside).memory (globalCell 0 offset)).isSome=false := by
  rewrite [source_fixed_grid_output p ops input outside offset ho]
  simp only [Option.isSome_some]
  decide
