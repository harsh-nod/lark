import Main
open LarkNonlinear LarkNativeSoftmax
example : downLeaves 5 0 = List.range 32 := by decide
