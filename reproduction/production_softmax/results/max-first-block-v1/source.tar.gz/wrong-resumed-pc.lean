import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceMidState prefixOne wordOps wordInput (fun _ => none) 0).pc (0*1024+0) = 32 := by
  rewrite [source_mid_initial_pc prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
