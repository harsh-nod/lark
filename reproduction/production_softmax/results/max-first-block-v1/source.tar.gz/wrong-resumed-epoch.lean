import Main
open LarkNonlinear LarkNativeSoftmax
example :
    ((sourceMidState prefixOne wordOps wordInput (fun _ => none) 0).epochs (0*1024+0)).block = 0 := by
  rewrite [source_mid_initial_epoch prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
