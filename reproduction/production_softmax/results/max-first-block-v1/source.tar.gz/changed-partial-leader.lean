import Lark.NativeSoftmaxWitness
import Lark.NativeSoftmaxMaxPrefixCost
import Lark.NativeSoftmaxMaxWaveTree
open LarkNonlinear LarkNativeSoftmax
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def sourceOriginal : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.div (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (-1) 4294967296))),
(.scalar (.index 4 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (50257))) 19)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)),
(.scalar (.index 6 (.add (.ivar (4)) (.mul (.ivar (5)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (6))) 12)),
(.scalar (.index 6 (.const (50256)))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (6))))),
(.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (1))))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 8)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (8192))))),
(.scalar (.jump 6)),
(.scalar (.assign 2 (.lit (0) 1))),
(.shuffle .down 2 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (1))) 32)),
(.scalar (.store .shared 0 (.ivar (2)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 42)),
(.scalar (.assign 3 (.load .shared 0 (.const (0))))),
(.scalar (.index 8 (.const (1)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (32))) 41)),
(.scalar (.assign 4 (.load .shared 0 (.ivar (8))))),
(.scalar (.assign 3 (.bin .max (.reg (3)) (.reg (4))))),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 36)),
(.scalar (.store .shared 0 (.const (0)) (.reg (3)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.lit (0) 1))),
(.scalar (.index 9 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (50257))) 69)),
(.scalar (.index 10 (.const (0)))),
(.scalar (.branch (.lt (.ivar (10)) (.const (8))) 56)),
(.scalar (.index 11 (.add (.ivar (9)) (.mul (.ivar (10)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (11))) 52)),
(.scalar (.index 11 (.const (50256)))),
(.scalar (.index 12 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (11))))),
(.scalar (.store .local 0 (.ivar (10)) (.un .fromHalf (.load .global 1 (.ivar (12)))))),
(.scalar (.index 10 (.add (.ivar (10)) (.const (1))))),
(.scalar (.jump 48)),
(.scalar (.index 13 (.const (0)))),
(.scalar (.branch (.lt (.ivar (13)) (.const (8))) 67)),
(.scalar (.index 14 (.add (.ivar (9)) (.mul (.ivar (13)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (14)) (.const (50257))) 65)),
(.scalar (.assign 7 (.load .local 0 (.ivar (13))))),
(.scalar (.assign 8 (.un .exp (.bin .sub (.reg (7)) (.reg (5)))))),
(.scalar (.index 15 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (14))))),
(.scalar (.store .global 0 (.ivar (15)) (.un .toHalf (.reg (8))))),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (8))))),
(.scalar (.index 13 (.add (.ivar (13)) (.const (1))))),
(.scalar (.jump 57)),
(.scalar (.index 9 (.add (.ivar (9)) (.const (8192))))),
(.scalar (.jump 46)),
(.scalar (.assign 9 (.lit (0) 1))),
(.shuffle .xor 9 6 (.const (16)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (8)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (4)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (2)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (1)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 82)),
(.scalar (.store .shared 1 (.ivar (2)) (.reg (6)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 92)),
(.scalar (.assign 10 (.load .shared 1 (.const (0))))),
(.scalar (.index 16 (.const (1)))),
(.scalar (.branch (.lt (.ivar (16)) (.const (32))) 91)),
(.scalar (.assign 11 (.load .shared 1 (.ivar (16))))),
(.scalar (.assign 10 (.bin .add (.reg (10)) (.reg (11))))),
(.scalar (.index 16 (.add (.ivar (16)) (.const (1))))),
(.scalar (.jump 86)),
(.scalar (.store .shared 1 (.const (0)) (.reg (10)))),
(.scalar (.barrier .block)),
(.scalar (.assign 12 (.load .shared 1 (.const (0))))),
(.scalar (.index 17 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (17)) (.const (50257))) 116)),
(.scalar (.index 18 (.const (0)))),
(.scalar (.branch (.lt (.ivar (18)) (.const (8))) 105)),
(.scalar (.index 19 (.add (.ivar (17)) (.mul (.ivar (18)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (19))) 101)),
(.scalar (.index 19 (.const (50256)))),
(.scalar (.index 20 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (19))))),
(.scalar (.store .local 1 (.ivar (18)) (.un .fromHalf (.load .global 0 (.ivar (20)))))),
(.scalar (.index 18 (.add (.ivar (18)) (.const (1))))),
(.scalar (.jump 97)),
(.scalar (.index 21 (.const (0)))),
(.scalar (.branch (.lt (.ivar (21)) (.const (8))) 114)),
(.scalar (.index 22 (.add (.ivar (17)) (.mul (.ivar (21)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (22)) (.const (50257))) 112)),
(.scalar (.assign 13 (.load .local 1 (.ivar (21))))),
(.scalar (.index 23 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (22))))),
(.scalar (.store .global 0 (.ivar (23)) (.un .toHalf (.bin .div (.reg (13)) (.reg (12)))))),
(.scalar (.index 21 (.add (.ivar (21)) (.const (1))))),
(.scalar (.jump 106)),
(.scalar (.index 17 (.add (.ivar (17)) (.const (8192))))),
(.scalar (.jump 95)),
(.scalar .halt)
]
def sourceFixed : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.div (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (-1) 4294967296))),
(.scalar (.index 4 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (50257))) 19)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 17)),
(.scalar (.index 6 (.add (.ivar (4)) (.mul (.ivar (5)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (6))) 12)),
(.scalar (.index 6 (.const (50256)))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (6))))),
(.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (1))))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 8)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (8192))))),
(.scalar (.jump 6)),
(.scalar (.assign 2 (.lit (0) 1))),
(.shuffle .down 2 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.shuffle .down 2 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .max (.reg (0)) (.reg (2))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 32)),
(.scalar (.store .shared 0 (.ivar (2)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 42)),
(.scalar (.assign 3 (.load .shared 0 (.const (0))))),
(.scalar (.index 8 (.const (1)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (32))) 41)),
(.scalar (.assign 4 (.load .shared 0 (.ivar (8))))),
(.scalar (.assign 3 (.bin .max (.reg (3)) (.reg (4))))),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 36)),
(.scalar (.store .shared 0 (.const (0)) (.reg (3)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.lit (0) 1))),
(.scalar (.index 9 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (50257))) 69)),
(.scalar (.index 10 (.const (0)))),
(.scalar (.branch (.lt (.ivar (10)) (.const (8))) 56)),
(.scalar (.index 11 (.add (.ivar (9)) (.mul (.ivar (10)) (.const (1024)))))),
(.scalar (.branch (.le (.const (50257)) (.ivar (11))) 52)),
(.scalar (.index 11 (.const (50256)))),
(.scalar (.index 12 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (11))))),
(.scalar (.store .local 0 (.ivar (10)) (.un .fromHalf (.load .global 1 (.ivar (12)))))),
(.scalar (.index 10 (.add (.ivar (10)) (.const (1))))),
(.scalar (.jump 48)),
(.scalar (.index 13 (.const (0)))),
(.scalar (.branch (.lt (.ivar (13)) (.const (8))) 67)),
(.scalar (.index 14 (.add (.ivar (9)) (.mul (.ivar (13)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (14)) (.const (50257))) 65)),
(.scalar (.assign 7 (.load .local 0 (.ivar (13))))),
(.scalar (.assign 8 (.un .exp (.bin .sub (.reg (7)) (.reg (5)))))),
(.scalar (.index 15 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (14))))),
(.scalar (.store .global 0 (.ivar (15)) (.un .toHalf (.reg (8))))),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (8))))),
(.scalar (.index 13 (.add (.ivar (13)) (.const (1))))),
(.scalar (.jump 57)),
(.scalar (.index 9 (.add (.ivar (9)) (.const (8192))))),
(.scalar (.jump 46)),
(.scalar (.assign 9 (.lit (0) 1))),
(.shuffle .xor 9 6 (.const (16)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (8)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (4)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (2)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.shuffle .xor 9 6 (.const (1)) 32),
(.scalar (.assign 6 (.bin .add (.reg (6)) (.reg (9))))),
(.scalar (.branch (.eq (.ivar (3)) (.const (0))) 82)),
(.scalar (.store .shared 1 (.ivar (2)) (.reg (6)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 92)),
(.scalar (.assign 10 (.load .shared 1 (.const (0))))),
(.scalar (.index 16 (.const (1)))),
(.scalar (.branch (.lt (.ivar (16)) (.const (32))) 91)),
(.scalar (.assign 11 (.load .shared 1 (.ivar (16))))),
(.scalar (.assign 10 (.bin .add (.reg (10)) (.reg (11))))),
(.scalar (.index 16 (.add (.ivar (16)) (.const (1))))),
(.scalar (.jump 86)),
(.scalar (.store .shared 1 (.const (0)) (.reg (10)))),
(.scalar (.barrier .block)),
(.scalar (.assign 12 (.load .shared 1 (.const (0))))),
(.scalar (.index 17 (.ivar (1)))),
(.scalar (.branch (.lt (.ivar (17)) (.const (50257))) 115)),
(.scalar (.index 18 (.const (0)))),
(.scalar (.branch (.lt (.ivar (18)) (.const (8))) 104)),
(.scalar (.index 19 (.add (.ivar (17)) (.mul (.ivar (18)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (19)) (.const (50257))) 102)),
(.scalar (.index 20 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (19))))),
(.scalar (.store .local 1 (.ivar (18)) (.un .fromHalf (.load .global 0 (.ivar (20)))))),
(.scalar (.index 18 (.add (.ivar (18)) (.const (1))))),
(.scalar (.jump 97)),
(.scalar (.index 21 (.const (0)))),
(.scalar (.branch (.lt (.ivar (21)) (.const (8))) 113)),
(.scalar (.index 22 (.add (.ivar (17)) (.mul (.ivar (21)) (.const (1024)))))),
(.scalar (.branch (.lt (.ivar (22)) (.const (50257))) 111)),
(.scalar (.assign 13 (.load .local 1 (.ivar (21))))),
(.scalar (.index 23 (.add (.mul (.ivar (0)) (.const (50257))) (.ivar (22))))),
(.scalar (.store .global 0 (.ivar (23)) (.un .toHalf (.bin .div (.reg (13)) (.reg (12)))))),
(.scalar (.index 21 (.add (.ivar (21)) (.const (1))))),
(.scalar (.jump 105)),
(.scalar (.index 17 (.add (.ivar (17)) (.const (8192))))),
(.scalar (.jump 95)),
(.scalar .halt)
]
def sourceShared : List Nat := [32, 32]
def sourceLocals : List Nat := [8, 8]
def sourceLayout (p : Shape) : Layout := ⟨[⟨.output,p.rows * 50257⟩, ⟨.input,p.rows * 50257⟩],sourceShared,sourceLocals⟩
def sourceGeometry (p : Shape) : Geometry := ⟨p.rows,1024,64⟩
def sourceFuel : Fuel := ⟨4096,8,5,1⟩
theorem source_program_data : sourceOriginal = racyProgram ∧ sourceFixed = fixedProgram := by decide
theorem source_interface_data (p : Shape) :
    sourceLayout p = layout p ∧ sourceGeometry p = geometry p ∧ sourceFuel = fuel := ⟨rfl,rfl,rfl⟩
def sourceStep (p : Shape) (guarded : Bool) (ops : Ops α) (t : Nat) (s : State α) : Option (State α) := do
  match ← (if guarded then sourceFixed else sourceOriginal)[s.pc t]? with
  | .scalar i => execute ops (sourceLayout p) (sourceGeometry p) t i s
  | .shuffle .. => none
theorem source_step_data (p : Shape) (guarded : Bool) (ops : Ops α) (t : Nat) (s : State α) :
    sourceStep p guarded ops t s = sourceScalarStep p guarded ops t s := by
  simp only [sourceStep,sourceScalarStep,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1]
  cases h : (if guarded then fixedProgram else racyProgram)[s.pc t]? with
  | none => rfl
  | some i => cases i <;> rfl
theorem source_seed_code : sourceOriginal[4]? = some (.scalar (.assign 0 (.lit (-1) 4294967296))) ∧
    sourceFixed[4]? = some (.scalar (.assign 0 (.lit (-1) 4294967296))) := by decide
theorem source_seed_evaluates (p : Shape) (ops : Ops α) (seed : α) (t : Nat) (s : State α) :
    evalExpr (withSeed ops seed) (sourceLayout p) (sourceGeometry p) t (.lit (-1) 4294967296) s =
      some (seed,s) := seed_expr ops seed (sourceLayout p) (sourceGeometry p) t s
theorem source_reader_trace (p : Shape) (ops : Ops α) (x : α) :
    (sourceStep p false ops 0 (readerStart 50256 2 x)).map State.trace =
      some [⟨0,⟨.local,0,1,2⟩,true,⟨0,4,0⟩⟩,reader] := by
  rewrite [source_step_data]
  exact reader_step p ops x
theorem source_writer_trace (p : Shape) (ops : Ops α) (x denominator : α) :
    (sourceStep p false ops 80 (writerStart 50256 x denominator)).map State.trace = some [writerAccess] := by
  rewrite [source_step_data]
  exact writer_step p ops x denominator
theorem source_guard_trace (p : Shape) :
    (sourceStep p true unitOps 0 guardStart).map (fun s => (s.pc 0,s.trace)) = some (102,[]) := by
  rewrite [source_step_data]
  exact guard_step p
theorem source_pair_conflicts (p : Shape) : conflict (sourceGeometry p) reader writerAccess = true := by
  rewrite [(source_interface_data p).2.1]
  exact pair_conflict p
theorem source_sufficient_rf (p : Shape) (trace : List Access) (h : ∀ a ∈ trace, Good a) :
    raceFree (sourceGeometry p) trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact race_free p trace h
#print axioms source_program_data
#print axioms source_interface_data
#print axioms source_step_data
#print axioms source_seed_code
#print axioms source_seed_evaluates
#print axioms source_reader_trace
#print axioms source_writer_trace
#print axioms source_guard_trace
#print axioms source_pair_conflicts
#print axioms source_sufficient_rf

def sourceInitial (p : Shape) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  initial (sourceLayout p) input outside
def sourceLane (p : Shape) (guarded : Bool) (ops : Ops α) (t budget : Nat) (s : State α) : Option (State α) :=
  LarkCollective.runLane ops (sourceLayout p) (sourceGeometry p)
    (if guarded then sourceFixed else sourceOriginal) t budget s
theorem source_lane_data (p : Shape) (guarded : Bool) (ops : Ops α) (t budget : Nat) (s : State α) :
    sourceLane p guarded ops t budget s =
      LarkCollective.runLane ops (layout p) (geometry p) (program guarded) t budget s := by
  simp only [sourceLane,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1]
theorem source_initial_data (p : Shape) (input : Nat → Nat → α) (outside : Location → Option α) :
    sourceInitial p input outside = initial (layout p) input outside := rfl
theorem source_prefix_initial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (t : Nat) (ht : t < p.rows*1024) :
    sourceLane p guarded ops t sourceFuel.lane (sourceInitial p input outside) =
      some (maxPrefixState ops input t (sourceInitial p input outside)) := by
  rewrite [source_lane_data,source_initial_data,(source_interface_data p).2.2]
  exact initial_max_prefix_run p guarded ops input outside t ht
theorem source_prefix_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (maxPrefixState ops input t (sourceInitial p input outside)).pc t = 20 :=
  max_prefix_pc ops input t _
theorem source_prefix_initial_value (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (maxPrefixState ops input t (sourceInitial p input outside)).regs t 0 =
      some (threadMaximum ops input (t/1024) (t%1024)) := by
  rewrite [source_initial_data]
  exact initial_max_prefix_value p ops input outside t
theorem source_prefix_initial_frames (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (maxPrefixState ops input t (sourceInitial p input outside)).memory = (sourceInitial p input outside).memory ∧
    (maxPrefixState ops input t (sourceInitial p input outside)).epochs = (sourceInitial p input outside).epochs ∧
    (maxPrefixState ops input t (sourceInitial p input outside)).trace.length = 56 := by
  have frame := max_prefix_frames ops input t (sourceInitial p input outside)
  exact ⟨frame.1,frame.2.1,by simpa only [sourceInitial,initial,List.length_nil,Nat.zero_add] using frame.2.2⟩
theorem source_prefix_initial_inputs (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    ∀ a ∈ (maxPrefixState ops input t (sourceInitial p input outside)).trace, MaxInputAccess a := by
  rewrite [source_initial_data]
  exact initial_max_prefix_inputs p ops input outside t
theorem source_prefix_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    raceFree (sourceGeometry p) (maxPrefixState ops input t (sourceInitial p input outside)).trace = true := by
  rewrite [source_initial_data,(source_interface_data p).2.1]
  exact initial_max_prefix_race_free p ops input outside t
theorem source_prefix_cost (tid : Nat) (ht : tid < 1024) :
    maxPrefixCost tid = if tid < 81 then 497 else 498 := max_prefix_cost_exact tid ht
theorem source_register_of_run (run : Option (State α)) (final : State α) (t : Nat) (value : α)
    (hr : run = some final) (hv : final.regs t 0 = some value) :
    run.map (fun s => s.regs t 0) = some (some value) := by
  rewrite [hr]
  change some (final.regs t 0) = some (some value)
  rewrite [hv]
  rfl
def prefixOne : Shape := ⟨1,by decide,by decide⟩
def wordInput : Nat → Nat → List Nat := fun _ offset => [offset]
def wordOps : Ops (List Nat) where
  literal := fun n d => if n = -1 ∧ d = 4294967296 then [3] else [4]
  add := fun a b => a ++ b
  sub := fun a b => a ++ b
  mul := fun a b => a ++ b
  max := fun a b => a ++ [1] ++ b
  div := fun a b => a ++ b
  exp := id
  tanh := id
  rsqrt := id
  fromHalf := fun a => 2 :: a
  toHalf := id
theorem source_maximum_word_0 :
    threadMaximum wordOps wordInput 0 0 = [3, 1, 2, 0, 1, 2, 1024, 1, 2, 2048, 1, 2, 3072, 1, 2, 4096, 1, 2, 5120, 1, 2, 6144, 1, 2, 7168, 1, 2, 8192, 1, 2, 9216, 1, 2, 10240, 1, 2, 11264, 1, 2, 12288, 1, 2, 13312, 1, 2, 14336, 1, 2, 15360, 1, 2, 16384, 1, 2, 17408, 1, 2, 18432, 1, 2, 19456, 1, 2, 20480, 1, 2, 21504, 1, 2, 22528, 1, 2, 23552, 1, 2, 24576, 1, 2, 25600, 1, 2, 26624, 1, 2, 27648, 1, 2, 28672, 1, 2, 29696, 1, 2, 30720, 1, 2, 31744, 1, 2, 32768, 1, 2, 33792, 1, 2, 34816, 1, 2, 35840, 1, 2, 36864, 1, 2, 37888, 1, 2, 38912, 1, 2, 39936, 1, 2, 40960, 1, 2, 41984, 1, 2, 43008, 1, 2, 44032, 1, 2, 45056, 1, 2, 46080, 1, 2, 47104, 1, 2, 48128, 1, 2, 49152, 1, 2, 50176, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256] := by decide
theorem source_prefix_word_0 :
    (sourceLane prefixOne false wordOps 0 sourceFuel.lane
      (sourceInitial prefixOne wordInput (fun _ => none))).map (fun s => s.regs 0 0) =
      some (some [3, 1, 2, 0, 1, 2, 1024, 1, 2, 2048, 1, 2, 3072, 1, 2, 4096, 1, 2, 5120, 1, 2, 6144, 1, 2, 7168, 1, 2, 8192, 1, 2, 9216, 1, 2, 10240, 1, 2, 11264, 1, 2, 12288, 1, 2, 13312, 1, 2, 14336, 1, 2, 15360, 1, 2, 16384, 1, 2, 17408, 1, 2, 18432, 1, 2, 19456, 1, 2, 20480, 1, 2, 21504, 1, 2, 22528, 1, 2, 23552, 1, 2, 24576, 1, 2, 25600, 1, 2, 26624, 1, 2, 27648, 1, 2, 28672, 1, 2, 29696, 1, 2, 30720, 1, 2, 31744, 1, 2, 32768, 1, 2, 33792, 1, 2, 34816, 1, 2, 35840, 1, 2, 36864, 1, 2, 37888, 1, 2, 38912, 1, 2, 39936, 1, 2, 40960, 1, 2, 41984, 1, 2, 43008, 1, 2, 44032, 1, 2, 45056, 1, 2, 46080, 1, 2, 47104, 1, 2, 48128, 1, 2, 49152, 1, 2, 50176, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256]) := by
  have run := source_prefix_initial_run prefixOne false wordOps wordInput (fun _ => none) 0 (by decide)
  have value := source_prefix_initial_value prefixOne wordOps wordInput (fun _ => none) 0
  have mapped := source_register_of_run _ _ 0 _ run value
  exact mapped.trans (congrArg (fun value : List Nat => some (some value)) source_maximum_word_0)
theorem source_maximum_word_81 :
    threadMaximum wordOps wordInput 0 81 = [3, 1, 2, 81, 1, 2, 1105, 1, 2, 2129, 1, 2, 3153, 1, 2, 4177, 1, 2, 5201, 1, 2, 6225, 1, 2, 7249, 1, 2, 8273, 1, 2, 9297, 1, 2, 10321, 1, 2, 11345, 1, 2, 12369, 1, 2, 13393, 1, 2, 14417, 1, 2, 15441, 1, 2, 16465, 1, 2, 17489, 1, 2, 18513, 1, 2, 19537, 1, 2, 20561, 1, 2, 21585, 1, 2, 22609, 1, 2, 23633, 1, 2, 24657, 1, 2, 25681, 1, 2, 26705, 1, 2, 27729, 1, 2, 28753, 1, 2, 29777, 1, 2, 30801, 1, 2, 31825, 1, 2, 32849, 1, 2, 33873, 1, 2, 34897, 1, 2, 35921, 1, 2, 36945, 1, 2, 37969, 1, 2, 38993, 1, 2, 40017, 1, 2, 41041, 1, 2, 42065, 1, 2, 43089, 1, 2, 44113, 1, 2, 45137, 1, 2, 46161, 1, 2, 47185, 1, 2, 48209, 1, 2, 49233, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256] := by decide
theorem source_prefix_word_81 :
    (sourceLane prefixOne false wordOps 81 sourceFuel.lane
      (sourceInitial prefixOne wordInput (fun _ => none))).map (fun s => s.regs 81 0) =
      some (some [3, 1, 2, 81, 1, 2, 1105, 1, 2, 2129, 1, 2, 3153, 1, 2, 4177, 1, 2, 5201, 1, 2, 6225, 1, 2, 7249, 1, 2, 8273, 1, 2, 9297, 1, 2, 10321, 1, 2, 11345, 1, 2, 12369, 1, 2, 13393, 1, 2, 14417, 1, 2, 15441, 1, 2, 16465, 1, 2, 17489, 1, 2, 18513, 1, 2, 19537, 1, 2, 20561, 1, 2, 21585, 1, 2, 22609, 1, 2, 23633, 1, 2, 24657, 1, 2, 25681, 1, 2, 26705, 1, 2, 27729, 1, 2, 28753, 1, 2, 29777, 1, 2, 30801, 1, 2, 31825, 1, 2, 32849, 1, 2, 33873, 1, 2, 34897, 1, 2, 35921, 1, 2, 36945, 1, 2, 37969, 1, 2, 38993, 1, 2, 40017, 1, 2, 41041, 1, 2, 42065, 1, 2, 43089, 1, 2, 44113, 1, 2, 45137, 1, 2, 46161, 1, 2, 47185, 1, 2, 48209, 1, 2, 49233, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256, 1, 2, 50256]) := by
  have run := source_prefix_initial_run prefixOne false wordOps wordInput (fun _ => none) 81 (by decide)
  have value := source_prefix_initial_value prefixOne wordOps wordInput (fun _ => none) 81
  have mapped := source_register_of_run _ _ 81 _ run value
  exact mapped.trans (congrArg (fun value : List Nat => some (some value)) source_maximum_word_81)
#print axioms source_lane_data
#print axioms source_initial_data
#print axioms source_prefix_initial_run
#print axioms source_prefix_initial_pc
#print axioms source_prefix_initial_value
#print axioms source_prefix_initial_frames
#print axioms source_prefix_initial_inputs
#print axioms source_prefix_initial_rf
#print axioms source_prefix_cost
#print axioms source_register_of_run
#print axioms source_maximum_word_0
#print axioms source_maximum_word_81
#print axioms source_prefix_word_0
#print axioms source_prefix_word_81

def sourceWarp (p : Shape) (guarded : Bool) (ops : Ops α) (ts : List Nat) (budget : Nat)
    (s : State α) : Option (State α) :=
  LarkPartitionCollective.runWarp ops (sourceLayout p) (sourceGeometry p) sourceFuel
    (if guarded then sourceFixed else sourceOriginal) ts budget s
def sourceWave (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) : State α :=
  firstWave p ops input row warp (sourceInitial p input outside)
theorem source_warp_data (p : Shape) (guarded : Bool) (ops : Ops α) (ts : List Nat)
    (budget : Nat) (s : State α) :
    sourceWarp p guarded ops ts budget s =
      LarkPartitionCollective.runWarp ops (layout p) (geometry p) fuel (program guarded) ts budget s := by
  simp only [sourceWarp,program,source_program_data.1,source_program_data.2,
    (source_interface_data p).1,(source_interface_data p).2.1,(source_interface_data p).2.2]
theorem source_wave_initial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row warp : Nat)
    (hr : row < p.rows) (hw : warp < 16) :
    sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceInitial p input outside) = some (sourceWave p ops input outside row warp) := by
  rewrite [source_warp_data,(source_interface_data p).2.1,(source_interface_data p).2.2,source_initial_data]
  exact first_wave_initial p guarded ops input outside row warp hr hw
theorem source_wave_initial_pc (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp lane : Nat) (hl : lane < 64) :
    (sourceWave p ops input outside row warp).pc (cohortBase row warp+lane) = 32 :=
  first_wave_pc p ops input row warp _ lane hl
theorem source_wave_initial_partial (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp half : Nat) (hw : warp < 16) (hh : half < 2) :
    (sourceWave p ops input outside row warp).memory ⟨.shared,row,0,warp*2+half⟩ =
      some (downTree ops.max (fun lane => threadMaximum ops input row (warp*64+lane)) 5 (half*32)) :=
  first_wave_partial_tree p ops input row warp half _ hw hh
theorem source_wave_initial_epochs (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) :
    (sourceWave p ops input outside row warp).epochs = (sourceInitial p input outside).epochs :=
  first_wave_epochs p ops input row warp _
theorem source_wave_initial_memory_frame (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (l : Location)
    (hl : l.space = .global ∨ l.buffer ≠ 0) :
    (sourceWave p ops input outside row warp).memory l = (sourceInitial p input outside).memory l :=
  first_wave_memory_frame p ops input row warp _ l hl
theorem source_wave_initial_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) :
    ∀ a ∈ (sourceWave p ops input outside row warp).trace, Good a :=
  first_wave_initial_good p ops input outside row warp
theorem source_wave_initial_rf (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) :
    raceFree (sourceGeometry p) (sourceWave p ops input outside row warp).trace = true := by
  rewrite [(source_interface_data p).2.1]
  exact first_wave_initial_race_free p ops input outside row warp
theorem source_wave_initial_trace_length (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hw : warp < 16) :
    (sourceWave p ops input outside row warp).trace.length = 3586 :=
  first_wave_trace_length p ops input row warp _ hw
theorem source_memory_of_run (run : Option (State α)) (final : State α) (l : Location)
    (value : α) (hr : run = some final) (hv : final.memory l = some value) :
    run.map (fun s => s.memory l) = some (some value) := by
  rewrite [hr]
  change some (final.memory l) = some (some value)
  rewrite [hv]
  rfl
theorem source_wave_initial_partial_run (p : Shape) (guarded : Bool) (ops : Ops α)
    (input : Nat → Nat → α) (outside : Location → Option α) (row warp half : Nat)
    (hr : row < p.rows) (hw : warp < 16) (hh : half < 2) :
    (sourceWarp p guarded ops (warpThreads (sourceGeometry p) row warp) sourceFuel.warp
      (sourceInitial p input outside)).map (fun s => s.memory ⟨.shared,row,0,warp*2+half⟩) =
        some (some (downTree ops.max (fun lane => threadMaximum ops input row (warp*64+lane)) 5 (half*32))) :=
  source_memory_of_run _ _ _ _ (source_wave_initial_run p guarded ops input outside row warp hr hw)
    (source_wave_initial_partial p ops input outside row warp half hw hh)
#print axioms source_warp_data
#print axioms source_wave_initial_run
#print axioms source_wave_initial_pc
#print axioms source_wave_initial_partial
#print axioms source_wave_initial_epochs
#print axioms source_wave_initial_memory_frame
#print axioms source_wave_initial_good
#print axioms source_wave_initial_rf
#print axioms source_wave_initial_trace_length
#print axioms source_memory_of_run
#print axioms source_wave_initial_partial_run
