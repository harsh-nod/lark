import Main
open LarkNonlinear LarkNativeSoftmax
example : maxPrefixCost 0 = 496 := by
  rewrite [max_prefix_cost_exact 0 (by decide)]
  decide
