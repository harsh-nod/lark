import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWave prefixOne wordOps wordInput (fun _ => none) 0 0).pc (cohortBase 0 0+0) = 33 := by
  rewrite [source_wave_initial_pc prefixOne wordOps wordInput (fun _ => none) 0 0 0 (by decide)]
  decide
