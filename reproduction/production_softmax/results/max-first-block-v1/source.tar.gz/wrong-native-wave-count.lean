import Main
open LarkNonlinear LarkNativeSoftmax
example : ((sourceGeometry prefixOne).block+(sourceGeometry prefixOne).warp-1)/(sourceGeometry prefixOne).warp = 15 := by decide
