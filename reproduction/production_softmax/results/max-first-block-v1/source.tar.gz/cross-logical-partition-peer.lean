import Main
open LarkNonlinear LarkNativeSoftmax
example : downPeer32 31 16 = 47 := by decide
