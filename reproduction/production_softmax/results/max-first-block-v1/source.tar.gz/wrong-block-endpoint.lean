import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceBlockState prefixOne wordOps wordInput (fun _ => none) 0).pc (0*1024+0) = 31 := by
  rewrite [source_block_initial_pc prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
