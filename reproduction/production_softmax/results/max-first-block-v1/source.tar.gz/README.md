Fresh checks: python3 validate_source.py; lake build. All other root Lean files intentionally fail.
Both full sources execute the actual first block wave-fold: sixteen physical waves, thirty-two partial values.
The 57376-access trace is race-free and every lane parks at PC32 before the first barrier.
The scheduler resumes the barrier at PC33/epoch1 with four remaining block phases explicit.
Later serial reduction and passes, the complete launch and reference bridge remain open. Source certificates0.
