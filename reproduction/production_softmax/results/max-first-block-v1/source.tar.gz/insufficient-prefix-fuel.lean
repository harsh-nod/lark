import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceLane prefixOne false wordOps 0 1 (sourceInitial prefixOne wordInput (fun _ => none))).isSome = true := by
  change false = true
  decide
