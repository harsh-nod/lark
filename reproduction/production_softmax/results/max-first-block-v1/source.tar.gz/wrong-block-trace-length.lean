import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (firstBlock prefixOne wordOps wordInput 0 (sourceInitial prefixOne wordInput (fun _ => none))).trace.length = 57344 := by
  rewrite [source_block_initial_trace_length]
  decide
