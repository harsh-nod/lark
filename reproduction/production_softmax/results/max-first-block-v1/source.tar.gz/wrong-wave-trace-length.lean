import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWave prefixOne wordOps wordInput (fun _ => none) 0 0).trace.length = 3584 := by
  rewrite [source_wave_initial_trace_length prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide)]
  decide
