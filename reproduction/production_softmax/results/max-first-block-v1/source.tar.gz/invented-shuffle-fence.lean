import Main
open LarkNonlinear LarkNativeSoftmax
example :
    ((sourceWave prefixOne wordOps wordInput (fun _ => none) 0 0).epochs 0).block = 1 := by
  rewrite [source_wave_initial_epochs]
  change 0 = 1
  decide
