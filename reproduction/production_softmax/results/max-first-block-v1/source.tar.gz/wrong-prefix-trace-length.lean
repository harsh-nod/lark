import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (maxPrefixState wordOps wordInput 0 (sourceInitial prefixOne wordInput (fun _ => none))).trace.length = 55 := by
  rewrite [(source_prefix_initial_frames prefixOne wordOps wordInput (fun _ => none) 0).2.2]
  decide
