import Main
open LarkNonlinear LarkNativeSoftmax
example : downLeaves 5 31 = [31] := by decide
