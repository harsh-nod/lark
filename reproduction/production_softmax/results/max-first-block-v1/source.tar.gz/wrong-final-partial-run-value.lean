import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceBlockFold prefixOne true checksumOps 0 (sourceInitial prefixOne checksumInput (fun _ => none))).map
      (fun s => s.memory ⟨.shared,0,0,31⟩) = some (some 396772867893895227125198885483776) := by
  rewrite [source_checksum_last_partial_run]
  decide
