import Main
open LarkNonlinear LarkNativeSoftmax
example : downLeaves 5 32 = downLeaves 5 0 := by decide
