import Main
open LarkNonlinear LarkNativeSoftmax
example : blockPartial checksumOps checksumInput 0 31 = 396772867893895227125198885483776 := by
  rewrite [source_checksum_last_partial]
  decide
