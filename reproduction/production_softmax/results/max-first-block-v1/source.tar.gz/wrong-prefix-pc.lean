import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (maxPrefixState wordOps wordInput 0 (sourceInitial prefixOne wordInput (fun _ => none))).pc 0 = 19 := by
  rewrite [source_prefix_initial_pc]
  decide
