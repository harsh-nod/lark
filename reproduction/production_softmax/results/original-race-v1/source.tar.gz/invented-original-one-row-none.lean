import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (hrows : p.rows=1) :
    (sourceLaunch p false ops (sourceInitial p input outside)).isSome=false := by
  rewrite [source_original_single_row_launch p ops input outside hrows]
  simp only [Option.isSome_some]
  decide
