import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row : Nat) :
    (originalWriter row∈(sourceWholeBlock p false ops input outside row).trace)=False := by
  have hp := source_original_writer_member p ops input outside row
  simp only [hp]
  decide
