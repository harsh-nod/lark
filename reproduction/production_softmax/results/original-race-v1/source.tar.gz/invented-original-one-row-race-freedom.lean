import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (hrows : p.rows=1) :
    (sourceLaunch p false ops (sourceInitial p input outside)).map (fun s => raceFree (sourceGeometry p) s.trace)=some true := by
  rewrite [source_original_single_row_racy_launch p ops input outside hrows]
  decide
