import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (row : Nat) :
    conflict (sourceGeometry p) (originalReader row) (originalWriter row)=false := by
  rewrite [source_original_pair_conflicts p row]
  decide
