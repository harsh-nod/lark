import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row : Nat) (hr : row<p.rows) :
    (sourceBlock p false ops row sourceFuel.block (sourceInitial p input outside)).isSome=false := by
  rewrite [source_whole_block_run p false ops input outside row hr]
  simp only [Option.isSome_some]
  decide
