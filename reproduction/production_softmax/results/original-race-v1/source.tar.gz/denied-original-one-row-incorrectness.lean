import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat)
    (spec : (Nat → Nat → Nat) → List Nat) (hrows : p.rows=1) :
    (LarkPartitionCollective.Correct ops (sourceLayout p) (sourceGeometry p) sourceFuel sourceOriginal spec)=True := by
  have hp := source_original_single_row_not_correct p ops spec hrows
  simp only [hp]
  decide
