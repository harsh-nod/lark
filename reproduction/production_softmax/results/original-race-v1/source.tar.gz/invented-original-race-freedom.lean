import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row : Nat) :
    raceFree (sourceGeometry p) (sourceWholeBlock p false ops input outside row).trace=true := by
  rewrite [source_original_block_race_false p ops input outside row]
  decide
