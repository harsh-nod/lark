Fresh checks: python3 validate_source.py; lake build. All other root Lean files intentionally fail.
Both full sources execute the actual maximum pass, with all32 source-ordered partials reduced by thread0.
All1024 participating threads resume both block barriers and reach PC43/epoch2.
The57409-access trace is race-free; the original scheduler retains three remaining block phases.
Later exponentiation/sum/normalization, whole launch and reference bridge remain open. Source certificates0.
