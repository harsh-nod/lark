import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceExpWaveState expWordOne expWordOps expWordInput (fun _ => none) 0 0).pc (cohortBase 0 0+0)=83 := by
  rewrite [source_exp_wave_initial_pc expWordOne expWordOps expWordInput (fun _ => none) 0 0 0 (by decide)]
  decide
