import Main
open LarkNonlinear LarkNativeSoftmax
example :
    ((sourceMaximumState prefixOne wordOps wordInput (fun _ => none) 0).epochs (0*1024+0)).block=1 := by
  rewrite [source_maximum_initial_epoch prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
