Fresh checks: python3 validate_source.py; lake build. Other root Lean files intentionally fail.
The maximum pass resumes both block barriers from the actual initializer.
From that proved state each selected lane executes seven scalar exponential/sum rounds and parks at PC70.
All valid exponential outputs and the unrounded source-ordered sum are proved, with the original fuel.
Every native64 wave also executes all five source-ordered logical32 XOR/add stages, writes two partials and parks at PC82.
All16 exp waves and all16 serial-sum waves execute; both later block barriers resume through PC93/epoch4.
The constructive four-phase prefix returns Some and links to runBlock with its original one remaining phase.
All50257 converted exp outputs and the unrounded source-ordered row total are retained.
Normalization executes all16 waves, halts all1024 lanes, and retains all50257 converted division outputs.
The repaired actual whole block trace is classified Good and proved race-free.
Grid composition, original conflict reachability and canonical/IEEE bridges remain open.
Source certificates0. Canonical/IEEE equivalence and original-paper completion remain open.
