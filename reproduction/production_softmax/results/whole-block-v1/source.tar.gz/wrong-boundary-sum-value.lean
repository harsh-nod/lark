import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWarp expWordOne true expWordOps (warpThreads (sourceGeometry expWordOne) 0 1) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,1*2+1⟩)=some (some 7143489113574839878422223905868109296159210485174537) := by
  rewrite [source_exp_wave_word_1_1]
  decide
