import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceLane expWordOne false expWordOps (0*1024+0) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).isSome=false := by
  rewrite [source_exp_initial_run expWordOne false expWordOps expWordInput (fun _ => none) 0 0 (by decide) (by decide)]
  change true=false
  decide
