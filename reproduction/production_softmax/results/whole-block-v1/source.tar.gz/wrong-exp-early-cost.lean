import Main
open LarkNonlinear LarkNativeSoftmax
example : expPrefixCost 0=978 := by
  rewrite [exp_prefix_cost_exact 0 (by decide)]
  decide
