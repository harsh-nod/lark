import Main
open LarkNonlinear LarkNativeSoftmax
example :
    ((sourceExpState prefixOne wordOps wordInput (fun _ => none) 0 0).epochs (0*1024+0)).block=3 := by
  rewrite [source_exp_initial_epoch prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
