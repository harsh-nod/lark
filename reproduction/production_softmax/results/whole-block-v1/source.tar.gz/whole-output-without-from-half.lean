import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceBlock expWordOne true reductionProjectionOps 0 sourceFuel.block
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 0)))=some (some 15) := by
  rewrite [source_whole_projection_output_0]
  decide
