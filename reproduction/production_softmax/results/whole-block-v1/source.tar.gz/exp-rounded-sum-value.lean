import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceLane expWordOne true expWordOps (0*1024+0) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+0) 6)=some (some 1592589353820434935960216989143619879294408095696) := by
  rewrite [source_exp_word_sum_0]
  decide
