import Main
open LarkNonlinear LarkNativeSoftmax
example : expPrefixCost 81=982 := by
  rewrite [exp_prefix_cost_exact 81 (by decide)]
  decide
