import Main
open LarkNonlinear LarkNativeSoftmax
example :
    ((sourceSumState expWordOne expWordOps expWordInput (fun _ => none) 0).epochs (0*1024+0)).block=3 := by
  rewrite [source_sum_initial_epoch expWordOne expWordOps expWordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
