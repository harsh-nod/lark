import Main
open LarkNonlinear LarkNativeSoftmax
example : normLaneCost false 81=879 := by
  rewrite [source_normalization_lane_cost false 81 (by decide)]
  decide
