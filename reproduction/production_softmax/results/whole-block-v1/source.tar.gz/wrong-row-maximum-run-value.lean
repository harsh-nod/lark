import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceBlockFold prefixOne true checksumOps 0 (sourceMidState prefixOne checksumOps checksumInput (fun _ => none) 0)).map
      (fun s => s.memory ⟨.shared,0,0,0⟩) = some (some 405347395513415502166905022412032) := by
  rewrite [source_checksum_maximum_run]
  decide
