import Main
open LarkNonlinear LarkNativeSoftmax
example : expRoundsCount 0 0 7=49 := by
  rewrite [exp_rounds_count_exact 0 (by decide)]
  decide
