import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceSumState expWordOne expWordOps expWordInput (fun _ => none) 0).pc (0*1024+0)=94 := by
  rewrite [source_sum_initial_pc expWordOne expWordOps expWordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
