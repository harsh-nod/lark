import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row tid : Nat) (hr : row<p.rows) (ht : tid<1024) :
    ((sourceWholeBlock p true ops input outside row).epochs (row*1024+tid)).block=5 := by
  rewrite [source_whole_block_epoch p true ops input outside row tid hr ht]
  decide
