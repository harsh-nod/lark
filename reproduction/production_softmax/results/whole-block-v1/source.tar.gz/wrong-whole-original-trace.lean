import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row : Nat) :
    (sourceWholeBlock p false ops input outside row).trace.length=489925 := by
  rewrite [source_whole_block_trace]
  decide
