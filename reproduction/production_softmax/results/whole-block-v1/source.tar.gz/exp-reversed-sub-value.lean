import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceLane expWordOne true expWordOps (0*1024+0) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+0) 6)=some (some 452704524884252417879508209867227186853701140024) := by
  rewrite [source_exp_word_sum_0]
  decide
