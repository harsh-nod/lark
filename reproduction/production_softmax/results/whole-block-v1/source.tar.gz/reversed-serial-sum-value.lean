import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceBlockFold expWordOne true expWordOps 0 sumChecksumState).map
      (fun s => s.memory ⟨.shared,0,1,0⟩)=some (some 3690) := by
  rewrite [source_sum_checksum_run]
  decide
