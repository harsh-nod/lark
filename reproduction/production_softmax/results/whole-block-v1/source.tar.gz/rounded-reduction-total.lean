import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceReductionPrefix expWordOne true reductionProjectionOps 0 4
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map (fun s => s.memory ⟨.shared,0,1,0⟩)=
      some (some 15814072) := by
  rewrite [source_reduction_projection_total]
  decide
