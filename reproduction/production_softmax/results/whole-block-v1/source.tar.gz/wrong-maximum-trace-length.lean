import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (maximumState prefixOne wordOps wordInput 0 (sourceInitial prefixOne wordInput (fun _ => none))).trace.length=57376 := by
  rewrite [source_maximum_initial_trace_length]
  decide
