import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWarp expWordOne true expWordOps (warpThreads (sourceGeometry expWordOne) 0 0) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,0*2+0⟩)=some (some 7463129541256921314090884017178408332900661536161792) := by
  rewrite [source_exp_wave_word_0_0]
  decide
