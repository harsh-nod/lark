import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWarp expWordOne true expWordOps (warpThreads (sourceGeometry expWordOne) 0 0) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,0*2+1⟩)=some (some 7461114972654749388900725843952115834485604258202112) := by
  rewrite [source_exp_wave_word_0_1]
  decide
