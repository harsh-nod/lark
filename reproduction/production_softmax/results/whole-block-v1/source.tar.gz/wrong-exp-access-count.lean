import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceExpState prefixOne wordOps wordInput (fun _ => none) 0 0).trace.length=57620 := by
  rewrite [source_exp_initial_trace_total prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide)]
  change 57622=57620
  decide
