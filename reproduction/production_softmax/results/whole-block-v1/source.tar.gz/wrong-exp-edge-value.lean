import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceLane expWordOne true expWordOps (0*1024+81) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.regs (0*1024+81) 6)=some (some 228232108027953416486008952959594019409155244984) := by
  rewrite [source_exp_word_sum_81]
  decide
