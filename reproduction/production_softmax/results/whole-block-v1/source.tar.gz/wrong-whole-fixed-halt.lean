import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row tid : Nat) (ht : tid<1024) :
    (sourceWholeBlock p true ops input outside row).pc (row*1024+tid)=116 := by
  rewrite [source_whole_block_pc p true ops input outside row tid ht]
  decide
