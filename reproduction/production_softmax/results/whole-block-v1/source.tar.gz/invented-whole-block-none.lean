import Main
open LarkNonlinear LarkNativeSoftmax
example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat)
    (outside : Location → Option Nat) (row : Nat) (hr : row<p.rows) :
    (sourceBlock p true ops row sourceFuel.block (sourceInitial p input outside)).isSome=false := by
  rewrite [source_whole_block_run p true ops input outside row hr]
  change true=false
  decide
