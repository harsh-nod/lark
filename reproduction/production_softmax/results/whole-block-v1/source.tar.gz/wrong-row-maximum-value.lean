import Main
open LarkNonlinear LarkNativeSoftmax
example : rowMaximum checksumOps checksumInput 0 = 405347395513415502166905022412032 := by
  rewrite [source_checksum_maximum]
  decide
