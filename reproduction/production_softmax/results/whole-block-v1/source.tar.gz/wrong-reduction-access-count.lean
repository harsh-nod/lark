import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceSumState expWordOne expWordOps expWordInput (fun _ => none) 0).trace.length=273667 := by
  rewrite [source_sum_initial_trace]
  decide
