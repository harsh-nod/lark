import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWarp expWordOne false expWordOps (warpThreads (sourceGeometry expWordOne) 0 0) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).isSome=false := by
  rewrite [source_exp_wave_initial_run expWordOne false expWordOps expWordInput (fun _ => none) 0 0 (by decide) (by decide)]
  change true=false
  decide
