import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceReductionPrefix expWordOne false reductionProjectionOps 0 4
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).isSome=false := by
  rewrite [source_reduction_initial_run expWordOne false reductionProjectionOps reductionProjectionInput (fun _ => none) 0 (by decide)]
  change true=false
  decide
