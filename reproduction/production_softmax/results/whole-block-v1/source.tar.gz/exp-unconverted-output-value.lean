import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceLane expWordOne true expWordOps (0*1024+0) sourceFuel.lane
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory (globalCell 0 (address 0 (column 0 0 0))))=some (some 753903) := by
  rewrite [source_exp_word_output_0]
  decide
