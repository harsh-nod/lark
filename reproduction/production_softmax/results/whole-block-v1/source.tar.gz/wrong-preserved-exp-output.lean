import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceReductionPrefix expWordOne true reductionProjectionOps 0 4
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 50256)))=some (some 2261583) := by
  rewrite [source_reduction_projection_output_50256]
  decide
