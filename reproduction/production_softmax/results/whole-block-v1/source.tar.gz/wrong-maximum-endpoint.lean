import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceMaximumState prefixOne wordOps wordInput (fun _ => none) 0).pc (0*1024+0)=42 := by
  rewrite [source_maximum_initial_pc prefixOne wordOps wordInput (fun _ => none) 0 0 (by decide) (by decide)]
  decide
