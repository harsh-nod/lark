import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceExpState prefixOne wordOps wordInput (fun _ => none) 0 0).pc (0*1024+0)=69 := by
  rewrite [source_exp_initial_pc]
  decide
