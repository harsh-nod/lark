import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceWarp expWordOne true expWordOps (warpThreads (sourceGeometry expWordOne) 0 0) sourceFuel.warp
      (sourceMaximumState expWordOne expWordOps expWordInput (fun _ => none) 0)).map
        (fun s => s.memory ⟨.shared,0,1,0*2+0⟩)=some (some 172866259589693641589843215586325529769654038786275000) := by
  rewrite [source_exp_wave_word_0_0]
  decide
