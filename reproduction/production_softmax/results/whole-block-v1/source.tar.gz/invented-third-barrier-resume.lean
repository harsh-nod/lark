import Main
open LarkNonlinear LarkNativeSoftmax
example :
    ((sourceExpWaveState expWordOne expWordOps expWordInput (fun _ => none) 0 0).epochs (cohortBase 0 0+0)).block=3 := by
  rewrite [source_exp_wave_initial_epoch expWordOne expWordOps expWordInput (fun _ => none) 0 0 0
    (by decide) (by decide) (by decide)]
  decide
