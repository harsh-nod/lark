import Main
open LarkNonlinear LarkNativeSoftmax
example : normLaneCost true 81=858 := by
  rewrite [source_normalization_lane_cost true 81 (by decide)]
  decide
