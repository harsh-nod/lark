import Main
open LarkNonlinear LarkNativeSoftmax
example :
    (sourceBlock expWordOne false reductionProjectionOps 0 sourceFuel.block
      (sourceInitial expWordOne reductionProjectionInput (fun _ => none))).map
        (fun s => s.memory (globalCell 0 (address 0 50256)))=some (some 147) := by
  rewrite [source_whole_projection_output_50256]
  decide
