#include <stdlib.h>
#include <stdio.h>
float* make_random_float(size_t N) {
    float* arr = (float*)malloc(N * sizeof(float));
    for (size_t i = 0; i < N; i++) {
        arr[i] = ((float)rand() / RAND_MAX) * 2.0 - 1.0; // range -1..1
    }
    return arr;
}
int* make_random_int(size_t N, int V) {
    int* arr = (int*)malloc(N * sizeof(int));
    for (size_t i = 0; i < N; i++) {
        arr[i] = rand() % V; // range 0..V-1
    }
    return arr;
}

int main(int argc,char** argv) {
  if(argc!=3)return 1;
  const int B=8,T=1024,V=50257;
  srand(0);
  float* inp=make_random_float((size_t)B*T*V);
  if(!inp)return 2;
  const int* outliers=make_random_int(B*T*3,V);
  if(!outliers)return 3;
  for(int k=0;k<3;++k) {
    for(int j=0;j<B*T;++j) {
      inp[j*V+outliers[j*3+k]]*=20;
    }
  }
  FILE* f=fopen(argv[1],"wb");if(!f)return 4;
  if(fwrite(inp,sizeof(float),(size_t)B*T*V,f)!=(size_t)B*T*V)return 5;
  fclose(f);
  f=fopen(argv[2],"wb");if(!f)return 6;
  if(fwrite(outliers,sizeof(int),B*T*3,f)!=(size_t)B*T*3)return 7;
  fclose(f);
  free(inp);free((void*)outliers);return 0;
}
