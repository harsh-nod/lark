Source replay: python3 validate_source.py. Fresh proof: lake build.
Requires Lean4.19.0 and the exact locked Mathlib dependencies/cache.
rows-{3,256,65535}.lean specialize the universal rows1..65535 theorem.
The other top-level Lean files intentionally fail.
The complete split-half launch, actual trace race freedom and dense real Q/K output are proved.
Half conversions are identities here; no IEEE error bound or original-paper completion is claimed.
