#pragma once

#ifdef USE_ROCM
  #include <hip/hip_runtime.h>
#endif

#ifdef USE_ROCM
struct Utils {
  static __host__ int get_warp_size() {
    static bool is_cached = false;
    static int result;

    if (!is_cached) {
      int device_id;
      cudaDeviceProp deviceProp;
      cudaGetDevice(&device_id);
      cudaGetDeviceProperties(&deviceProp, device_id);

      result = deviceProp.warpSize;
      is_cached = true;
    }

    return result;
  }

  static __device__ constexpr int get_warp_size() {
  #ifdef __GFX9__
    return 64;
  #else
    return 32;
  #endif
  }
};

  #define WARP_SIZE Utils::get_warp_size()
#else
  #define WARP_SIZE 32
#endif

#ifndef USE_ROCM
  #define VLLM_LDG(arg) __ldg(arg)
#else
  #define VLLM_LDG(arg) *(arg)
#endif

#ifndef USE_ROCM
  #define VLLM_SHFL_XOR_SYNC(var, lane_mask) \
    __shfl_xor_sync(uint32_t(-1), var, lane_mask)
  #define VLLM_SHFL_XOR_SYNC_WIDTH(var, lane_mask, width) \
    __shfl_xor_sync(uint32_t(-1), var, lane_mask, width)
#else
  #define VLLM_SHFL_XOR_SYNC(var, lane_mask) __shfl_xor(var, lane_mask)
  #define VLLM_SHFL_XOR_SYNC_WIDTH(var, lane_mask, width) \
    __shfl_xor(var, lane_mask, width)
#endif

#ifndef USE_ROCM
  #define VLLM_SHFL_DOWN_SYNC(var, lane_delta) \
    __shfl_down_sync(uint32_t(-1), var, lane_delta)
  #define VLLM_SHFL_DOWN_SYNC_WIDTH(var, lane_delta, width) \
    __shfl_down_sync(uint32_t(-1), var, lane_delta, width)
#else
  #define VLLM_SHFL_DOWN_SYNC(var, lane_delta) __shfl_down(var, lane_delta)
  #define VLLM_SHFL_DOWN_SYNC_WIDTH(var, lane_delta, width) \
    __shfl_down(var, lane_delta, width)
#endif

#ifndef USE_ROCM
  #define VLLM_SHFL_SYNC_WIDTH(var, src_lane, width) \
    __shfl_sync(uint32_t(-1), var, src_lane, width)
  #define VLLM_SHFL_UP_SYNC_WIDTH(var, lane_delta, width) \
    __shfl_up_sync(uint32_t(-1), var, lane_delta, width)
#else
  #define VLLM_SHFL_SYNC_WIDTH(var, src_lane, width) \
    __shfl(var, src_lane, width)
  #define VLLM_SHFL_UP_SYNC_WIDTH(var, lane_delta, width) \
    __shfl_up(var, lane_delta, width)
#endif

// Ballot over the 32-lane group holding the calling lane (on wave64, its half
// of the wavefront), restricted to the lanes in mask.
#ifndef USE_ROCM
  #define VLLM_BALLOT_SYNC_32(mask, pred) __ballot_sync(mask, pred)
#else
  #define VLLM_BALLOT_SYNC_32(mask, pred)                          \
    (static_cast<uint32_t>(__ballot(pred) >> (__lane_id() & 32)) & \
     static_cast<uint32_t>(mask))
#endif

#ifndef USE_ROCM
  #define VLLM_DevFuncAttribute_SET_MaxDynamicSharedMemorySize(FUNC, VAL) \
    cudaFuncSetAttribute(FUNC, cudaFuncAttributeMaxDynamicSharedMemorySize, VAL)
#else
  #define VLLM_DevFuncAttribute_SET_MaxDynamicSharedMemorySize(FUNC, VAL) \
    hipFuncSetAttribute(FUNC, hipFuncAttributeMaxDynamicSharedMemorySize, VAL)
#endif

// FP8 quant kernels convert two values per saturating `cvt`, see
// scaled_fp8_conversion_vec and per_token_group_quant_8bit_packed. The
// instruction exists from sm_89; lower the minimum arch once validated there.
#define VLLM_FP8_CVT_X2_MIN_ARCH 1000
#if !defined(USE_ROCM) && defined(__CUDA_ARCH__) && \
    __CUDA_ARCH__ >= VLLM_FP8_CVT_X2_MIN_ARCH
  #define VLLM_FP8_CVT_X2 1
#else
  #define VLLM_FP8_CVT_X2 0
#endif
