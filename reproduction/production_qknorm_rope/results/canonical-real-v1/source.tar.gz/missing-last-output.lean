import LarkReal.NativeQKNormRopeInterleaved
open LarkReal.NativeQKNormRope
example (input : Nat → Nat → ℝ) :
    (denseSpec ⟨1, by decide, by decide⟩ input).length = 5119 := by
  simp [denseSpec]
