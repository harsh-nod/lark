from pathlib import Path
from lark_kernels import native_qknorm_rope_certificate as native
root = Path(__file__).resolve().parent
contract, translation = native.prepare(*((root / name).read_text() for name in ("kernel.hip", "reference.py", "task.json")))
assert (root / "Main.lean").read_text() == native.render(contract, translation)
print("Frozen reader, exact readback, dense Q/K reference and source-to-Main binding passed.")
