import LarkReal.NativeQKNormRopeInterleaved
namespace LarkCertificate
open LarkNonlinear
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeQKNormRope.Shape := ⟨1, by decide, by decide⟩
def layout : Layout := ⟨[⟨.output, 5120⟩, ⟨.input, 6144⟩, ⟨.input, 128⟩, ⟨.input, 128⟩, ⟨.input, 128⟩], [], []⟩
def geometry : Geometry := ⟨5, 256, 64⟩
def fuel : Fuel := ⟨256, 16, 1, 1⟩
def program : List LarkCollective.Instr := [(.scalar (.index 0 (.add (.mul .bid (.const (8))) (.div .tid (.const (32)))))), (.scalar (.index 1 (.div (.ivar (0)) (.const (40))))), (.scalar (.index 2 (.mod (.ivar (0)) (.const (40))))), (.scalar (.index 3 (.mod .tid (.const (32))))), (.scalar (.index 4 (.mul (.ivar (3)) (.const (4))))), (.scalar (.index 5 (.add (.add (.mul (.ivar (1)) (.const (6144))) (.mul (.ivar (2)) (.const (128)))) (.ivar (4))))), (.scalar (.index 6 (.add (.add (.mul (.ivar (1)) (.const (5120))) (.mul (.ivar (2)) (.const (128)))) (.ivar (4))))), (.scalar (.index 7 (.add (.ivar (5)) (.const (0))))), (.scalar (.assign 0 (.un .fromHalf (.load .global 1 (.ivar (7)))))), (.scalar (.index 8 (.add (.ivar (5)) (.const (1))))), (.scalar (.assign 1 (.un .fromHalf (.load .global 1 (.ivar (8)))))), (.scalar (.index 9 (.add (.ivar (5)) (.const (2))))), (.scalar (.assign 2 (.un .fromHalf (.load .global 1 (.ivar (9)))))), (.scalar (.index 10 (.add (.ivar (5)) (.const (3))))), (.scalar (.assign 3 (.un .fromHalf (.load .global 1 (.ivar (10)))))), (.scalar (.assign 4 (.lit (0) 1))), (.scalar (.assign 5 (.bin .mul (.reg (0)) (.reg (0))))), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (5))))), (.scalar (.assign 6 (.bin .mul (.reg (1)) (.reg (1))))), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (6))))), (.scalar (.assign 7 (.bin .mul (.reg (2)) (.reg (2))))), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (7))))), (.scalar (.assign 8 (.bin .mul (.reg (3)) (.reg (3))))), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (8))))), (.shuffle .xor 9 4 (.const (16)) 32), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (9))))), (.shuffle .xor 9 4 (.const (8)) 32), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (9))))), (.shuffle .xor 9 4 (.const (4)) 32), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (9))))), (.shuffle .xor 9 4 (.const (2)) 32), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (9))))), (.shuffle .xor 9 4 (.const (1)) 32), (.scalar (.assign 4 (.bin .add (.reg (4)) (.reg (9))))), (.scalar (.assign 10 (.bin .div (.reg (4)) (.lit (128) 1)))), (.scalar (.assign 11 (.bin .add (.reg (10)) (.lit (1) 100000)))), (.scalar (.assign 12 (.un .rsqrt (.reg (11))))), (.scalar (.index 11 (.add (.ivar (4)) (.const (0))))), (.scalar (.index 12 (.add (.ivar (4)) (.const (1))))), (.scalar (.index 13 (.add (.ivar (4)) (.const (2))))), (.scalar (.index 14 (.add (.ivar (4)) (.const (3))))), (.scalar (.branch (.lt (.ivar (2)) (.const (32))) 47)), (.scalar (.assign 13 (.un .fromHalf (.load .global 2 (.ivar (11)))))), (.scalar (.assign 14 (.un .fromHalf (.load .global 2 (.ivar (12)))))), (.scalar (.assign 15 (.un .fromHalf (.load .global 2 (.ivar (13)))))), (.scalar (.assign 16 (.un .fromHalf (.load .global 2 (.ivar (14)))))), (.scalar (.jump 51)), (.scalar (.assign 13 (.un .fromHalf (.load .global 3 (.ivar (11)))))), (.scalar (.assign 14 (.un .fromHalf (.load .global 3 (.ivar (12)))))), (.scalar (.assign 15 (.un .fromHalf (.load .global 3 (.ivar (13)))))), (.scalar (.assign 16 (.un .fromHalf (.load .global 3 (.ivar (14)))))), (.scalar (.assign 17 (.bin .mul (.reg (12)) (.reg (13))))), (.scalar (.assign 18 (.bin .mul (.reg (0)) (.reg (17))))), (.scalar (.assign 19 (.bin .mul (.reg (12)) (.reg (14))))), (.scalar (.assign 20 (.bin .mul (.reg (1)) (.reg (19))))), (.scalar (.assign 21 (.bin .mul (.reg (12)) (.reg (15))))), (.scalar (.assign 22 (.bin .mul (.reg (2)) (.reg (21))))), (.scalar (.assign 23 (.bin .mul (.reg (12)) (.reg (16))))), (.scalar (.assign 24 (.bin .mul (.reg (3)) (.reg (23))))), (.scalar (.index 15 (.add (.add (.mul (.ivar (1)) (.const (128))) (.mul (.ivar (3)) (.const (2)))) (.const (0))))), (.scalar (.index 16 (.add (.ivar (15)) (.const (63))))), (.scalar (.assign 25 (.un .fromHalf (.load .global 4 (.ivar (15)))))), (.scalar (.assign 26 (.un .fromHalf (.load .global 4 (.ivar (16)))))), (.scalar (.assign 27 (.bin .mul (.reg (18)) (.reg (25))))), (.scalar (.assign 28 (.bin .mul (.reg (20)) (.reg (26))))), (.scalar (.assign 29 (.bin .mul (.reg (18)) (.reg (26))))), (.scalar (.assign 30 (.bin .mul (.reg (20)) (.reg (25))))), (.scalar (.assign 31 (.bin .sub (.reg (27)) (.reg (28))))), (.scalar (.assign 32 (.bin .add (.reg (29)) (.reg (30))))), (.scalar (.index 17 (.add (.add (.mul (.ivar (1)) (.const (128))) (.mul (.ivar (3)) (.const (2)))) (.const (1))))), (.scalar (.index 18 (.add (.ivar (17)) (.const (64))))), (.scalar (.assign 33 (.un .fromHalf (.load .global 4 (.ivar (17)))))), (.scalar (.assign 34 (.un .fromHalf (.load .global 4 (.ivar (18)))))), (.scalar (.assign 35 (.bin .mul (.reg (22)) (.reg (33))))), (.scalar (.assign 36 (.bin .mul (.reg (24)) (.reg (34))))), (.scalar (.assign 37 (.bin .mul (.reg (22)) (.reg (34))))), (.scalar (.assign 38 (.bin .mul (.reg (24)) (.reg (33))))), (.scalar (.assign 39 (.bin .sub (.reg (35)) (.reg (36))))), (.scalar (.assign 40 (.bin .add (.reg (37)) (.reg (38))))), (.scalar (.index 19 (.add (.ivar (6)) (.const (0))))), (.scalar (.store .global 0 (.ivar (19)) (.un .toHalf (.reg (31))))), (.scalar (.index 20 (.add (.ivar (6)) (.const (1))))), (.scalar (.store .global 0 (.ivar (20)) (.un .toHalf (.reg (32))))), (.scalar (.index 21 (.add (.ivar (6)) (.const (2))))), (.scalar (.store .global 0 (.ivar (21)) (.un .toHalf (.reg (39))))), (.scalar (.index 22 (.add (.ivar (6)) (.const (3))))), (.scalar (.store .global 0 (.ivar (22)) (.un .toHalf (.reg (40))))), (.scalar .halt)]
-- The closed reference AST is checked before this independent dense interpretation.
-- Half/float conversions are identities in the exact-real operation model.
def referenceSquare (input : Nat → Nat → ℝ) (row head col : Nat) : ℝ :=
  let x := input 1 (row * 6144 + head * 128 + col)
  x * x
noncomputable def referenceScale (input : Nat → Nat → ℝ) (row head : Nat) : ℝ :=
  1 / Real.sqrt ((((List.range 128).map (referenceSquare input row head)).sum) / 128 + 1 / 100000)
noncomputable def referenceNormalized (input : Nat → Nat → ℝ) (row head col : Nat) : ℝ :=
  input 1 (row * 6144 + head * 128 + col) *
    (referenceScale input row head * input (if head < 32 then 2 else 3) col)
noncomputable def reference (input : Nat → Nat → ℝ) (row head col : Nat) : ℝ :=
  let pair := col / 2
  let x := referenceNormalized input row head (pair * 2)
  let y := referenceNormalized input row head (pair * 2 + 1)
  let cosine := input 4 (row * 128 + pair)
  let sine := input 4 (row * 128 + pair + 64)
  if col % 2 = 0 then x * cosine - y * sine else x * sine + y * cosine
noncomputable def spec (input : Nat → Nat → ℝ) : List ℝ :=
  (List.range (1 * 5120)).map (fun i => reference input (i / 5120) (i % 5120 / 128) (i % 128))
theorem reference_data (input : Nat → Nat → ℝ) :
    spec input = LarkReal.NativeQKNormRope.denseSpec shape input := by rfl
theorem layout_data : layout = LarkNativeQKNormRope.layout shape := by rfl
theorem geometry_data : geometry = LarkNativeQKNormRope.geometry shape := by rfl
theorem fuel_data : fuel = LarkNativeQKNormRope.fuel := by rfl
theorem program_data : program = LarkNativeQKNormRope.program false := by decide
theorem segmentation_data : program = LarkNativeQKNormRope.program false := program_data
theorem segmentation (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program
      (initial layout input outside) =
      some (LarkNativeQKNormRope.interleavedFinalState shape LarkReal.ops input outside) := by
  rw [segmentation_data, layout_data, geometry_data, fuel_data]
  exact LarkNativeQKNormRope.interleaved_final_launch shape LarkReal.ops input outside
theorem race_free (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    raceFree geometry (LarkNativeQKNormRope.interleavedFinalState shape LarkReal.ops input outside).trace = true := by
  rw [geometry_data]
  exact LarkNativeQKNormRope.interleaved_final_race_free shape LarkReal.ops input outside
theorem readonly_inputs (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    LarkNativeQKNormRope.Reads shape input
      (LarkNativeQKNormRope.interleavedFinalState shape LarkReal.ops input outside) :=
  LarkNativeQKNormRope.interleaved_final_readonly shape LarkReal.ops input outside
theorem segment_equivalence (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    extract layout (LarkNativeQKNormRope.interleavedFinalState shape LarkReal.ops input outside) = some (spec input) := by
  rw [layout_data]
  exact (LarkReal.NativeQKNormRope.final_extract shape input outside).trans
    (congrArg some (reference_data input).symm)
theorem kernel_eq_spec :
    LarkPartitionCollective.Correct LarkReal.ops layout geometry fuel program spec := by
  intro input outside
  exact ⟨LarkNativeQKNormRope.interleavedFinalState shape LarkReal.ops input outside,
    segmentation input outside, race_free input outside, segment_equivalence input outside⟩
theorem kernel_eq_spec_pre (input : Nat → Nat → ℝ) (s : State ℝ) (pre : StdPre layout input s) :
    ∃ final, LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec input) := by
  obtain ⟨outside, rfl⟩ := pre
  exact kernel_eq_spec input outside
#print axioms reference_data
#print axioms layout_data
#print axioms geometry_data
#print axioms fuel_data
#print axioms program_data
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms readonly_inputs
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
