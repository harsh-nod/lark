import Lark.PtxDot
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkPtxDotCertificate
open LarkNonlinear
def program : List LarkPtxDot.Instruction := [(.parameter (8) (0)), (.parameter (9) (1)), (.parameter (7) (2)), (.toGlobal (16) (9)), (.blockId (1)), (.shiftLeft32 (5) (1) (10)), (.toGlobal (10) (8)), (.mulWideSigned32 (11) (5) (2)), (.addSigned64 (12) (10) (.reg (11))), (.addSigned64 (17) (12) (.imm (16))), (.literalFloat (68) (0) (1)), (.literal32 (6) (0)), (.loadHalf (1) (17) (-16)), (.fromHalf (4) (1)), (.loadHalf (2) (16) (0)), (.fromHalf (5) (2)), (.binaryFloat (36) .mul (4) (5)), (.binaryFloat (37) .add (68) (36)), (.loadHalf (3) (17) (-14)), (.fromHalf (6) (3)), (.loadHalf (4) (16) (2)), (.fromHalf (7) (4)), (.binaryFloat (38) .mul (6) (7)), (.binaryFloat (39) .add (37) (38)), (.loadHalf (5) (17) (-12)), (.fromHalf (8) (5)), (.loadHalf (6) (16) (4)), (.fromHalf (9) (6)), (.binaryFloat (40) .mul (8) (9)), (.binaryFloat (41) .add (39) (40)), (.loadHalf (7) (17) (-10)), (.fromHalf (10) (7)), (.loadHalf (8) (16) (6)), (.fromHalf (11) (8)), (.binaryFloat (42) .mul (10) (11)), (.binaryFloat (43) .add (41) (42)), (.loadHalf (9) (17) (-8)), (.fromHalf (12) (9)), (.loadHalf (10) (16) (8)), (.fromHalf (13) (10)), (.binaryFloat (44) .mul (12) (13)), (.binaryFloat (45) .add (43) (44)), (.loadHalf (11) (17) (-6)), (.fromHalf (14) (11)), (.loadHalf (12) (16) (10)), (.fromHalf (15) (12)), (.binaryFloat (46) .mul (14) (15)), (.binaryFloat (47) .add (45) (46)), (.loadHalf (13) (17) (-4)), (.fromHalf (16) (13)), (.loadHalf (14) (16) (12)), (.fromHalf (17) (14)), (.binaryFloat (48) .mul (16) (17)), (.binaryFloat (49) .add (47) (48)), (.loadHalf (15) (17) (-2)), (.fromHalf (18) (15)), (.loadHalf (16) (16) (14)), (.fromHalf (19) (16)), (.binaryFloat (50) .mul (18) (19)), (.binaryFloat (51) .add (49) (50)), (.loadHalf (17) (17) (0)), (.fromHalf (20) (17)), (.loadHalf (18) (16) (16)), (.fromHalf (21) (18)), (.binaryFloat (52) .mul (20) (21)), (.binaryFloat (53) .add (51) (52)), (.loadHalf (19) (17) (2)), (.fromHalf (22) (19)), (.loadHalf (20) (16) (18)), (.fromHalf (23) (20)), (.binaryFloat (54) .mul (22) (23)), (.binaryFloat (55) .add (53) (54)), (.loadHalf (21) (17) (4)), (.fromHalf (24) (21)), (.loadHalf (22) (16) (20)), (.fromHalf (25) (22)), (.binaryFloat (56) .mul (24) (25)), (.binaryFloat (57) .add (55) (56)), (.loadHalf (23) (17) (6)), (.fromHalf (26) (23)), (.loadHalf (24) (16) (22)), (.fromHalf (27) (24)), (.binaryFloat (58) .mul (26) (27)), (.binaryFloat (59) .add (57) (58)), (.loadHalf (25) (17) (8)), (.fromHalf (28) (25)), (.loadHalf (26) (16) (24)), (.fromHalf (29) (26)), (.binaryFloat (60) .mul (28) (29)), (.binaryFloat (61) .add (59) (60)), (.loadHalf (27) (17) (10)), (.fromHalf (30) (27)), (.loadHalf (28) (16) (26)), (.fromHalf (31) (28)), (.binaryFloat (62) .mul (30) (31)), (.binaryFloat (63) .add (61) (62)), (.loadHalf (29) (17) (12)), (.fromHalf (32) (29)), (.loadHalf (30) (16) (28)), (.fromHalf (33) (30)), (.binaryFloat (64) .mul (32) (33)), (.binaryFloat (65) .add (63) (64)), (.loadHalf (31) (17) (14)), (.fromHalf (34) (31)), (.loadHalf (32) (16) (30)), (.fromHalf (35) (32)), (.binaryFloat (66) .mul (34) (35)), (.binaryFloat (68) .add (65) (66)), (.addSigned64 (17) (17) (.imm (32))), (.addSigned64 (16) (16) (.imm (32))), (.addSigned32 (6) (6) (.imm (16))), (.compareNeSigned32 (1) (6) (.imm (512))), (.branch (1) (12)), (.toGlobal (13) (7)), (.toHalf (33) (68)), (.mulWideSigned32 (14) (1) (2)), (.addSigned64 (15) (13) (.reg (14))), (.storeHalf (15) (0) (33)), (.ret)]
def referenceBody : LarkPtxDot.Gemv.TensorReference := (.toHalf (.matmul (.fromHalf (.input 0)) (.fromHalf (.input 1))))
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  (LarkPtxDot.Gemv.evaluateReference ops input referenceBody).getD []
theorem source_program : program = LarkPtxDot.Gemv.program := by rfl
theorem reference_body : referenceBody = LarkPtxDot.Gemv.referenceBody := by rfl
theorem launch (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    LarkPtxDot.Gemv.LaneSequence ops program 0 512
      (initial (LarkPtxDot.Gemv.layout 512) input outside)
      (LarkPtxDot.Gemv.finalState ops input outside) := by
  rw [source_program]
  exact LarkPtxDot.Gemv.launch_execution ops input outside
theorem race_free (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    raceFree (LarkPtxDot.Gemv.geometry 512)
      (LarkPtxDot.Gemv.finalState ops input outside).trace = true :=
  LarkPtxDot.Gemv.launch_raceFree ops input outside
theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    extract (LarkPtxDot.Gemv.layout 512) (LarkPtxDot.Gemv.finalState ops input outside) =
      some (spec ops input) := by
  unfold spec
  rw [reference_body, LarkPtxDot.Gemv.evaluate_reference_body]
  exact LarkPtxDot.Gemv.final_extract ops input outside
theorem kernel_eq_spec (ops : Ops α) : LarkPtxDot.Gemv.Correct ops program (spec ops) := by
  intro input outside
  exact ⟨LarkPtxDot.Gemv.finalState ops input outside, launch ops input outside,
    race_free ops input outside, segment_equivalence ops input outside⟩
#print axioms LarkPtxDotCertificate.source_program
#print axioms LarkPtxDotCertificate.reference_body
#print axioms LarkPtxDotCertificate.launch
#print axioms LarkPtxDotCertificate.race_free
#print axioms LarkPtxDotCertificate.segment_equivalence
#print axioms LarkPtxDotCertificate.kernel_eq_spec
end LarkPtxDotCertificate
