import hashlib,json,os,shutil,sys
from pathlib import Path
from lark_kernels import ptx_dot_certificate as checker
from lark_kernels import ptx_pointwise_certificate as legacy,ptx_pointwise
root=Path('/tmp/lark-ptx-dot-refinement-20261113')
module=Path(checker.__file__).resolve()
assert str(module).startswith('/tmp/lark-ptx-dot-wheel-installed-v1-20261113/') and not module.is_relative_to(root)
assert not any(str(root) in str(p) for p in sys.path)
assert shutil.which('git') is None
expected=checker.read(Path('/tmp/lark-ptx-dot-source-export-v1-20261113/source-bindings.json'))
assert {n:checker.sha(v)for n,v in checker.own_sources().items()}==expected
prior=Path('/tmp/lark-ptx-pointwise-source-export-v1-20261113')
assert {n:checker.sha(v)for n,v in legacy.own_sources().items()}==checker.read(prior/'source-bindings.json')
old_inputs=[(prior/n).read_text()for n in legacy.INPUTS]
assert ptx_pointwise.render(*ptx_pointwise.prepare(*old_inputs)).encode()==(prior/'Main.lean').read_bytes()
print(json.dumps({'installed_module':str(module),'checkout_imported':False,'isolated_mode':bool(sys.flags.isolated),
 'git_on_PATH':False,'all_owned_source_bindings_match':True,'legacy_ReLU_owned_source_bindings_match':True,
 'legacy_ReLU_Main_regenerated_identically':True,'cwd':os.getcwd()}))
