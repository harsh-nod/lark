"""Check the new wheel offline, in isolated Python outside the checkout and Git."""

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/tmp/lark-ptx-dot-refinement-20261113')
OUT = Path('/tmp/lark-ptx-dot-wheel-validation-v1-20261113')
ENV = Path('/tmp/lark-ptx-dot-wheel-installed-v1-20261113')
WHEEL = Path('/tmp/lark-ptx-dot-wheel-v1-20261113/lark_kernels-0.1.0-py3-none-any.whl')


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, command, environment, timeout=None):
    with (OUT / (name + '.stdout')).open('w') as stdout, (OUT / (name + '.stderr')).open('w') as stderr:
        child = subprocess.Popen(command, cwd=OUT, env=environment, stdout=stdout, stderr=stderr)
        write('progress.json', {'observer_pid': os.getpid(), 'child_pid': child.pid,
              'stage': name, 'command': command, 'at_utc': datetime.now(timezone.utc).isoformat()})
        code = child.wait(timeout=timeout)
    write(name + '.json', {'exit_code': code, 'command': command})
    assert code == 0, name + ' failed; inspect original logs before any next action'


def main():
    assert not OUT.exists() and not ENV.exists()
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    assert hashlib.sha256(WHEEL.read_bytes()).hexdigest() == '084fad0a195d446b2fb6436bd5d683ca9a82f5ac3aba32ed087674fb2b338aa4'
    environment = dict(os.environ, PATH='/nonexistent', PYTHONNOUSERSITE='1',
                       PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_CONFIG_FILE='/dev/null')
    environment.pop('PYTHONPATH', None)
    environment.pop('LEAN_PATH', None)
    run('venv', ['/usr/bin/python3', '-I', '-m', 'venv', str(ENV)], environment, 120)
    python = str(ENV / 'bin/python')
    run('install', [python, '-I', '-m', 'pip', 'install', '--no-index', '--no-deps', str(WHEEL)], environment, 120)
    probe = '''import hashlib,json,os,shutil,sys
from pathlib import Path
from lark_kernels import ptx_dot_certificate as checker
from lark_kernels import ptx_pointwise_certificate as legacy,ptx_pointwise
root=Path('/tmp/lark-ptx-dot-refinement-20261113')
module=Path(checker.__file__).resolve()
assert str(module).startswith('/tmp/lark-ptx-dot-wheel-installed-v1-20261113/') and not module.is_relative_to(root)
assert not any(str(root) in str(p) for p in sys.path)
assert shutil.which('git') is None
expected=checker.read(Path('/tmp/lark-ptx-dot-source-export-v1-20261113/source-bindings.json'))
assert {n:checker.sha(v)for n,v in checker.own_sources().items()}==expected
prior=Path('/tmp/lark-ptx-pointwise-source-export-v1-20261113')
assert {n:checker.sha(v)for n,v in legacy.own_sources().items()}==checker.read(prior/'source-bindings.json')
old_inputs=[(prior/n).read_text()for n in legacy.INPUTS]
assert ptx_pointwise.render(*ptx_pointwise.prepare(*old_inputs)).encode()==(prior/'Main.lean').read_bytes()
print(json.dumps({'installed_module':str(module),'checkout_imported':False,'isolated_mode':bool(sys.flags.isolated),
 'git_on_PATH':False,'all_owned_source_bindings_match':True,'legacy_ReLU_owned_source_bindings_match':True,
 'legacy_ReLU_Main_regenerated_identically':True,'cwd':os.getcwd()}))
'''
    (OUT / 'probe.py').write_text(probe)
    run('probe', [python, '-I', str(OUT / 'probe.py')], environment, 120)
    start = time.monotonic()
    run('replay', [python, '-I', '-m', 'lark_kernels.ptx_dot_certificate', 'replay',
                  '--recording', '/tmp/lark-ptx-dot-source-export-v1-20261113',
                  '--output', str(OUT / 'source-only-replay'),
                  '--lean', '/tmp/lean-4.19.0-linux/bin/lean'], environment)
    result = json.loads((OUT / 'source-only-replay/replay.json').read_text())
    assert result['status'] == 'fresh-source-only-PTX-GEMV-proof-replay-passed'
    assert result['owned_modules_freshly_compiled'] == 4 and result['old_owned_olean_cache_used'] is False
    probe_result = json.loads((OUT / 'probe.stdout').read_text())
    report = {'schema': 1, 'status': 'installed-wheel-source-only-PTX-GEMV-replay-passed',
              'exit_code': 0, 'seconds': time.monotonic() - start,
              'wheel_sha256': hashlib.sha256(WHEEL.read_bytes()).hexdigest(), 'wheel_bytes': WHEEL.stat().st_size,
              **probe_result, 'network_during_install_and_replay': False,
              'owned_modules_freshly_compiled': 4, 'source_bound_proofs_added': 0,
              'model_calls': 0, 'gpu_trials': 0, 'nvidia_execution': False,
              'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False}
    write('results.json', report)
    write('manifest.json', {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(OUT.rglob('*')) if p.is_file()})
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
