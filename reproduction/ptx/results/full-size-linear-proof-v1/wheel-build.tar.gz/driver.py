"""Build the frozen LINEAR SDK wheel offline and compare every owned source byte."""
from pathlib import Path
import subprocess,os,time,json,hashlib,zipfile,sys
ROOT=Path('/tmp/lark-ptx-linear-refinement-20261113')
OUT=Path('/tmp/lark-ptx-linear-wheel-v1-20261113')
PYTHON=Path('/tmp/lark-ptx-pointwise-build-env-20261113/bin/python')
sys.path.insert(0,str(ROOT))
from lark_kernels import ptx_linear_certificate as checker
assert not OUT.exists();OUT.mkdir()
(OUT/'driver.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,PIP_NO_INDEX='1',PIP_DISABLE_PIP_VERSION_CHECK='1',PIP_CONFIG_FILE='/dev/null')
env.pop('PYTHONPATH',None)
backend=json.loads(subprocess.check_output([str(PYTHON),'-c','import json,importlib.metadata as m;print(json.dumps({n:m.version(n)for n in ["setuptools","wheel"]}))'],env=env,text=True))
assert backend=={'setuptools':'80.9.0','wheel':'0.45.1'}
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
start=time.monotonic()
command=[str(PYTHON),'-m','pip','wheel','--no-index','--no-deps','--no-build-isolation','--wheel-dir',str(OUT),str(ROOT)]
with (OUT/'build.stdout').open('w')as stdout,(OUT/'build.stderr').open('w')as stderr:
 result=subprocess.run(command,env=env,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=120)
assert result.returncode==0,'Inspect actual build logs; do not restart on lost output'
files=list(OUT.glob('*.whl'));assert len(files)==1
wheel=files[0];assert wheel.name=='lark_kernels-0.4.0-py3-none-any.whl'
sources=checker.own_sources();assert len(sources)==64
with zipfile.ZipFile(wheel)as archive:
 for name,content in sources.items():
  if name.startswith('python/'):
   path='lark_kernels/'+name.removeprefix('python/')
  else:
   path='lark_kernels-0.4.0.data/data/share/lark/'+name
  assert archive.read(path)==content,(name,path)
report={'schema':1,'status':'wheel-built-and-all64-LINEAR-owned-sources-byte-checked','exit_code':0,
 'seconds':time.monotonic()-start,'source_commit':commit,'backend':backend,'command':command,
 'wheel_filename':wheel.name,'wheel_sha256':checker.sha(wheel.read_bytes()),'wheel_bytes':wheel.stat().st_size,
 'all_ten_owned_Lean_files_included':True,'owned_source_bindings_checked':64,'network_during_build':False,
 'model_calls':0,'gpu_trials':0,'nvidia_execution':False,'new_registered_source_certificates':0,
 'original_paper_fully_reproduced':False}
checker.write(OUT/'build-results.json',report);checker.manifest(OUT)
print(json.dumps(report),flush=True)
