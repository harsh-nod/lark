"""Development-only Linear model and first15source steps; reuse five pinned imports."""

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback

ROOT = Path('/tmp/lark-ptx-linear-refinement-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_batched_certificate as common
from reproduction.ptx.linear_frontend import prepare

OUT = Path('/tmp/lark-ptx-linear-initialization-v2-20261113')
CACHE = Path('/tmp/lark-ptx-batched-source-export-v3-20261113')
LEAN = Path('/tmp/lean-4.19.0-linux/bin/lean')
IMPORTS = ('Nonlinear', 'Pointwise', 'PtxPointwise', 'PtxDot', 'PtxMatrix')


def main():
    assert not OUT.exists(), 'Inspect original output/handle before another run'
    lean, version = common.toolchain(LEAN)
    common.check_inventory(CACHE)
    sources = common.own_sources()
    assert {n: common.sha(v) for n, v in sources.items()} == common.read(CACHE / 'source-bindings.json')
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    modules = OUT / 'modules'
    (modules / 'Lark').mkdir(parents=True)
    for name in IMPORTS:
        source = 'Lark/' + name + '.lean'
        assert (CACHE / 'modules' / source).read_bytes() == sources['lean/' + source]
        for extension in ('lean', 'olean'):
            shutil.copyfile(CACHE / 'modules/Lark' / (name + '.' + extension),
                            modules / 'Lark' / (name + '.' + extension))
    common.write(OUT / 'cached-source-bindings.json', common.read(CACHE / 'source-bindings.json'))
    module = ROOT / 'lean/Lark/PtxLinearInit.lean'
    common.check_inventory(Path('/tmp/lark-ptx-linear-prefix15-v2-20261113'))
    for extension in ('lean', 'olean'):
        shutil.copyfile(Path('/tmp/lark-ptx-linear-prefix15-v2-20261113/modules/Lark') / ('PtxLinear.' + extension), modules / 'Lark' / ('PtxLinear.' + extension))
    assert (modules / 'Lark/PtxLinear.lean').read_bytes() == (ROOT / 'lean/Lark/PtxLinear.lean').read_bytes()
    (modules / 'Lark/PtxLinearInit.lean').write_bytes(module.read_bytes())
    env = dict(os.environ, LEAN_PATH=str(modules))
    start = time.monotonic()
    row, log = common.run_lean(lean, ['-o', 'Lark/PtxLinearInit.olean', 'Lark/PtxLinearInit.lean'],
                               modules, env, OUT / 'PtxLinearInit.log')
    common.write(OUT / 'module-check.json', row)
    if row['exit_code'] != 0 or row['timed_out']:
        common.write(OUT / 'results.json', {'status': 'Linear-address43-module-failed',
             'module_check': row, 'source_bound_development_proofs': 0,
             'original_paper_fully_reproduced': False})
        common.manifest(OUT)
        raise RuntimeError('Actual Lean module failed; retained full log: ' + str(OUT / 'PtxLinearInit.log'))
    audits = common.common.audits(log, re.findall(r'^#print axioms (\S+)', module.read_text(), re.M))
    folder = ROOT / 'reproduction/ptx/full-size/linear'
    data = {name: (folder / path).read_bytes() for name, path in (
        ('kernel.ptx', 'kernel.ptx'), ('reference.py', 'reference.py'), ('contract.json', 'task.json'))}
    for name, content in data.items():
        (OUT / name).write_bytes(content)

    def render(source):
        _, parsed = prepare(source, data['reference.py'].decode(), data['contract.json'].decode())
        return ('import Lark.PtxLinearInit\nset_option maxRecDepth 10000\nset_option maxHeartbeats 2000000\n'
            'namespace LarkPtxLinearSource\nopen LarkNonlinear LarkPtxPointwise\n'
            'def program : List LarkPtxLinear.Instruction := ' + parsed.lean_program() + '\n'
            'theorem source_program : program = LarkPtxLinear.Linear.program := by decide\n'
            'theorem actual_prefix (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :\n'
            '    ∃ final, LarkPtxLinear.Steps ops LarkPtxLinear.Linear.layout LarkPtxLinear.Linear.geometry t program\n'
            '      (LarkPtxLinear.Linear.start s) final ∧ LarkPtxLinear.Linear.Init.Ready ops t s final := by\n'
            '  rw [source_program]\n  exact LarkPtxLinear.Linear.Init.prologue_ready ops t s ht\n'
            '#print axioms LarkPtxLinearSource.source_program\n'
            '#print axioms LarkPtxLinearSource.actual_prefix\nend LarkPtxLinearSource\n')

    (OUT / 'Main.lean').write_text(render(data['kernel.ptx'].decode()))
    check, log = common.run_lean(lean, ['Main.lean'], OUT, env, OUT / 'Main.log')
    common.write(OUT / 'Main-check.json', check)
    assert check['exit_code'] == 0 and not check['timed_out'], log
    audits.update(common.common.audits(log, ['LarkPtxLinearSource.source_program', 'LarkPtxLinearSource.actual_prefix']))
    original = data['kernel.ptx'].decode()
    changes = {
        'wrong-product': ('mul.rn.f32', 'add.rn.f32'),
        'wrong-sign-source': ('cvt.s64.s32 \t%rd18, %r11;', 'cvt.s64.s32 \t%rd18, %r10;'),
        'wrong-bias-shift': ('shl.b64 \t%rd48, %rd18, 1;', 'shl.b64 \t%rd48, %rd18, 2;'),
        'wrong-bias-operation': ('add.rn.f32 \t%f68, %f69, %f67;', 'mul.rn.f32 \t%f68, %f69, %f67;'),
    }
    negative = []
    for name, (before, after) in changes.items():
        assert before in original, (name, before)
        altered = original.replace(before, after, 1)
        assert altered != original
        folder = OUT / name
        folder.mkdir()
        (folder / 'kernel.ptx').write_text(altered)
        (folder / 'Main.lean').write_text(render(altered))
        failed, log = common.run_lean(lean, ['Main.lean'], folder, env, folder / 'Main.log')
        common.write(folder / 'check.json', failed)
        assert failed['exit_code'] != 0 and not failed['timed_out']
        assert "tactic 'decide' proved that" in log and 'is false' in log, log
        assert not any(x in log for x in ('maximum recursion', 'maximum number of heartbeats', 'Stack overflow')), log
        negative.append({'name': name, **failed})
    result = {'schema': 1, 'status': 'actual-Linear-complete50instruction-prologue-checked-kernel-incomplete',
        'seconds': time.monotonic() - start, 'actual_instructions': 179, 'actual_backward_branch': [167, 50],
        'actual_registers': 189, 'shapes': [[64, 256], [256, 512], [512], [64, 512]],
        'launch': {'grid': 32768, 'block': 1, 'warp': 32}, 'unchanged_CUDA_fuel': [1030, 1, 1, 1],
        'module_check': row, 'Main_check': check, 'negative_source_binding_controls': negative,
        'axiom_audits': audits, 'source_verified_cached_owned_modules_reused': 6,
        'fresh_owned_modules_built': 1, 'old_owned_olean_cache_used': True,
        'Lean_binary_sha256': common.sha(lean.read_bytes()), 'Lean_version': version,
        'input_bindings': {n: common.sha(v) for n, v in data.items()},
        'Lean_module_sha256': common.sha(module.read_bytes()), 'source_bound_kernel_proved': False,
        'source_bound_development_proofs': 0, 'model_calls': 0, 'gpu_trials': 0,
        'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False,
        'scope': 'Development execution of the unchanged complete50instruction compiled prologue for every original '
            'active lane, plus guarded signed32-to-signed64 conversion and actual clamped64bit logical '
            'left-shift semantics including negative/overflow examples. Full179instruction source binding '
            'and four one-fragment source-binding refusals do not establish loop, bias '
            'epilogue, launch, reference extraction, memory preservation or race correctness. Six pinned '
            'previously checked owned imports reused deliberately. No complete independent kernel added.'}
    common.write(OUT / 'results.json', result)
    common.manifest(OUT)
    print(json.dumps({'output': str(OUT), 'status': result['status'], 'seconds': result['seconds'],
                     'axiom_audits': len(audits), 'whole_kernel_proved': False}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        if OUT.exists():
            (OUT / 'exception.txt').write_text(traceback.format_exc())
            common.manifest(OUT)
        raise
