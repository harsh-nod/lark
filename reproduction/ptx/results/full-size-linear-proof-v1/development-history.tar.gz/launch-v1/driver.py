"""Development actual Linear loop check; eight byte/inventory-bound cached imports."""

import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback

ROOT = Path('/tmp/lark-ptx-linear-refinement-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_matrix_certificate as common
from reproduction.ptx.linear_frontend import prepare

OUT = Path('/tmp/lark-ptx-linear-launch-v1-20261113')
CACHE = Path('/tmp/lark-ptx-linear-exit-v1-20261113')
LEAN = Path('/tmp/lean-4.19.0-linux/bin/lean')
IMPORTS = (*common.MODULES, 'PtxLinear', 'PtxLinearInit', 'PtxLinearBody', 'PtxLinearExit')


def main():
    assert not OUT.exists(), 'Inspect original output/handle before another run'
    lean, version = common.toolchain(LEAN)
    common.check_inventory(CACHE)
    previous = common.read(CACHE / 'results.json')
    assert previous['status'] == 'actual-Linear-complete-source-lane-checked-launch-reference-race-incomplete'
    assert previous['fresh_owned_modules_built'] == 1 and previous['old_owned_olean_cache_used'] is True
    assert previous['module_check']['exit_code'] == 0 and previous['Main_check']['exit_code'] == 0
    sources = common.own_sources()
    for name in ('PtxLinear', 'PtxLinearInit'):
        sources['lean/Lark/' + name + '.lean'] = (ROOT / 'lean/Lark' / (name + '.lean')).read_bytes()
    sources['reproduction/ptx/linear_frontend.py'] = (ROOT / 'reproduction/ptx/linear_frontend.py').read_bytes()
    assert {n: common.sha(v) for n, v in sorted(sources.items())} == common.read(CACHE / 'cached-source-bindings.json')
    sources['lean/Lark/PtxLinearBody.lean'] = (ROOT / 'lean/Lark/PtxLinearBody.lean').read_bytes()
    loop_cache = Path('/tmp/lark-ptx-linear-loop-v1-20261113')
    common.check_inventory(loop_cache)
    assert common.sha(sources['lean/Lark/PtxLinearBody.lean']) == common.read(loop_cache / 'results.json')['Lean_module_sha256']
    sources['lean/Lark/PtxLinearExit.lean'] = (ROOT / 'lean/Lark/PtxLinearExit.lean').read_bytes()
    assert common.sha(sources['lean/Lark/PtxLinearExit.lean']) == previous['Lean_module_sha256']
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    modules = OUT / 'modules'
    (modules / 'Lark').mkdir(parents=True)
    for name in IMPORTS:
        source = 'Lark/' + name + '.lean'
        assert (CACHE / 'modules' / source).read_bytes() == sources['lean/' + source]
        for extension in ('lean', 'olean'):
            shutil.copyfile(CACHE / 'modules/Lark' / (name + '.' + extension),
                            modules / 'Lark' / (name + '.' + extension))
    common.write(OUT / 'cached-source-bindings.json', common.read(CACHE / 'cached-source-bindings.json'))
    module = ROOT / 'lean/Lark/PtxLinearLaunch.lean'
    source_bytes = module.read_bytes()
    (modules / 'Lark/PtxLinearLaunch.lean').write_bytes(source_bytes)
    env = dict(os.environ, LEAN_PATH=str(modules))
    start = time.monotonic()
    row, log = common.run_lean(lean, ['-o', 'Lark/PtxLinearLaunch.olean', 'Lark/PtxLinearLaunch.lean'],
                               modules, env, OUT / 'PtxLinearLaunch.log')
    common.write(OUT / 'module-check.json', row)
    if row['exit_code'] != 0 or row['timed_out']:
        common.write(OUT / 'results.json', {'status': 'Linear-launch-module-failed',
             'module_check': row, 'source_bound_development_proofs': 0,
             'original_paper_fully_reproduced': False})
        raise RuntimeError('Actual Lean module failed; retained full log: ' + str(OUT / 'PtxLinearLaunch.log'))
    audits = common.common.audits(log, re.findall(r'^#print axioms (\S+)', source_bytes.decode(), re.M))
    folder = ROOT / 'reproduction/ptx/full-size/linear'
    data = {name: (folder / path).read_bytes() for name, path in (
        ('kernel.ptx', 'kernel.ptx'), ('reference.py', 'reference.py'), ('contract.json', 'task.json'))}
    for name, content in data.items():
        (OUT / name).write_bytes(content)
    _, translation = prepare(*(data[n].decode() for n in data))
    main = (
        'import Lark.PtxLinearLaunch\nset_option maxRecDepth 10000\nset_option maxHeartbeats 2000000\n'
        'namespace LarkPtxLinearFullSource\nopen LarkNonlinear LarkPtxPointwise\n'
        'def program : List LarkPtxLinear.Instruction := ' + translation.lean_program() + '\n'
        'def referenceBody : LarkPtxLinear.Linear.Launch.TensorReference :=\n'
        '  .toHalf (.add (.matmul (.fromHalf (.input 0)) (.fromHalf (.input 1))) (.fromHalf (.input 2)))\n'
        'def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=\n'
        '  LarkPtxLinear.Linear.Launch.referenceSpec ops input\n'
        'theorem source_program : program = LarkPtxLinear.Linear.program := by decide\n'
        'theorem source_reference : referenceBody = LarkPtxLinear.Linear.Launch.referenceBody := by decide\n'
        'theorem reference_denotation (ops : Ops α) (input : Nat → Nat → α) :\n'
        '    LarkPtxLinear.Linear.Launch.evaluateReference ops input referenceBody = some (spec ops input) := by\n'
        '  rw [source_reference]\n  exact LarkPtxLinear.Linear.Launch.evaluate_reference_body ops input\n'
        'theorem source_bound_kernel_correct (ops : Ops α) :\n'
        '    LarkPtxLinear.Linear.Launch.Correct ops program (spec ops) := by\n'
        '  rw [source_program]\n  exact LarkPtxLinear.Linear.Launch.kernel_correct ops\n'
        'theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :\n'
        '    ∃ final, LarkPtxLinear.Linear.Launch.LaneSequence ops program 0 32768\n'
        '      (initial LarkPtxLinear.Linear.layout input outside) final ∧\n'
        '      raceFree LarkPtxLinear.Linear.geometry final.trace = true ∧\n'
        '      extract LarkPtxLinear.Linear.layout final = LarkPtxLinear.Linear.Launch.evaluateReference ops input referenceBody ∧\n'
        '      (∀ l, (∀ i, i < 32768 → l ≠ LarkPtxLinear.Linear.Exit.outputCell i) →\n'
        '        final.memory l = (initial LarkPtxLinear.Linear.layout input outside).memory l) := by\n'
        '  obtain ⟨final, execution, race, extracted, preserved⟩ := source_bound_kernel_correct ops input outside\n'
        '  refine ⟨final, execution, race, ?_, preserved⟩\n'
        '  rw [reference_denotation]\n  exact extracted\n'
        'theorem source_launch_geometry : LarkPtxLinear.Linear.geometry = ⟨32768, 1, 32⟩ := rfl\n'
        + '\n'.join('#print axioms LarkPtxLinearFullSource.' + name for name in (
            'source_program', 'source_reference', 'reference_denotation', 'source_bound_kernel_correct',
            'segment_equivalence', 'source_launch_geometry'))
        + '\nend LarkPtxLinearFullSource\n'
    )
    (OUT / 'Main.lean').write_text(main)
    check, log = common.run_lean(lean, ['Main.lean'], OUT, env, OUT / 'Main.log')
    common.write(OUT / 'Main-check.json', check)
    assert check['exit_code'] == 0 and not check['timed_out'], log
    audits.update(common.common.audits(log, ['LarkPtxLinearFullSource.' + n for n in ('source_program', 'source_reference', 'reference_denotation', 'source_bound_kernel_correct', 'segment_equivalence', 'source_launch_geometry')]))
    result = {'schema': 1, 'status': 'complete-Linear-original-source-launch-reference-and-race-library-proved',
        'seconds': time.monotonic() - start, 'actual_instructions': 179,
        'actual_backward_branch': [167, 50], 'proved_initial_instructions': 179,
        'actual_loop_iterations': 16, 'terms_per_iteration': 16, 'actual_PC_at_exit': 179,
        'actual_registers': 189, 'shapes': [[64, 256], [256, 512], [512], [64, 512]],
        'launch': {'grid': 32768, 'block': 1, 'warp': 32}, 'unchanged_CUDA_fuel': [1030, 1, 1, 1],
        'module_check': row, 'Main_check': check, 'axiom_audits': audits,
        'source_verified_cached_owned_modules_reused': 9, 'fresh_owned_modules_built': 1,
        'old_owned_olean_cache_used': True, 'Lean_binary_sha256': common.sha(lean.read_bytes()),
        'Lean_version': version, 'input_bindings': {n: common.sha(v) for n, v in data.items()},
        'Lean_module_sha256': common.sha(source_bytes), 'source_bound_kernel_proved': True,
        'source_bound_development_proofs': 0, 'model_calls': 0, 'gpu_trials': 0,
        'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False,
        'complete_independent_library_theorems': 1, 'fresh_source_only_SDK_exports': 0,
        'scope': 'Complete original179instruction compiled Linear source theorem: actual50prologue '
            'and all16 real113body/fivecontrol iterations consume256terms, all11 actual bias/store/ret '
            'instructions preserve bias-before-half order, every active lane stops atPC179. Whole32768lane '
            'source launch, extracted outputs equal the closed matrix-plus-bias reference AST, actual '
            'access-trace race freedom and preservation outside output hold for the same launch witness. '
            'Abstract scalar correspondence, parsing/reference formalization and logical aligned '
            'disjoint nonwrapping allocations remain trusted. No IEEE/PyTorch/NVIDIA-conformance, '
            'hardware execution, original optimized model result or full-paper reproduction claim. '
            'Nine source/inventory-bound prior modules deliberately reused plus one fresh Launch. '
            'Fresh complete SDK export/replay, wheel, adversarial checks and publication remain required.'}

    common.write(OUT / 'results.json', result)
    common.manifest(OUT)
    print(json.dumps({'output': str(OUT), 'status': result['status'], 'seconds': result['seconds'],
                     'axiom_audits': len(audits), 'whole_kernel_proved': True}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        if OUT.exists():
            (OUT / 'exception.txt').write_text(traceback.format_exc())
            common.manifest(OUT)
        raise
