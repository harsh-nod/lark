"""Development actual Linear loop check; eight byte/inventory-bound cached imports."""

import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback

ROOT = Path('/tmp/lark-ptx-linear-refinement-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_matrix_certificate as common
from reproduction.ptx.linear_frontend import prepare

OUT = Path('/tmp/lark-ptx-linear-exit-v1-20261113')
CACHE = Path('/tmp/lark-ptx-linear-loop-v1-20261113')
LEAN = Path('/tmp/lean-4.19.0-linux/bin/lean')
IMPORTS = (*common.MODULES, 'PtxLinear', 'PtxLinearInit', 'PtxLinearBody')


def main():
    assert not OUT.exists(), 'Inspect original output/handle before another run'
    lean, version = common.toolchain(LEAN)
    common.check_inventory(CACHE)
    previous = common.read(CACHE / 'results.json')
    assert previous['status'] == 'actual-Linear-full256term-loop-checked-bias-epilogue-incomplete'
    assert previous['fresh_owned_modules_built'] == 1 and previous['old_owned_olean_cache_used'] is True
    assert previous['module_check']['exit_code'] == 0 and previous['Main_check']['exit_code'] == 0
    sources = common.own_sources()
    for name in ('PtxLinear', 'PtxLinearInit'):
        sources['lean/Lark/' + name + '.lean'] = (ROOT / 'lean/Lark' / (name + '.lean')).read_bytes()
    sources['reproduction/ptx/linear_frontend.py'] = (ROOT / 'reproduction/ptx/linear_frontend.py').read_bytes()
    assert {n: common.sha(v) for n, v in sorted(sources.items())} == common.read(CACHE / 'cached-source-bindings.json')
    sources['lean/Lark/PtxLinearBody.lean'] = (ROOT / 'lean/Lark/PtxLinearBody.lean').read_bytes()
    assert common.sha(sources['lean/Lark/PtxLinearBody.lean']) == previous['Lean_module_sha256']
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    modules = OUT / 'modules'
    (modules / 'Lark').mkdir(parents=True)
    for name in IMPORTS:
        source = 'Lark/' + name + '.lean'
        assert (CACHE / 'modules' / source).read_bytes() == sources['lean/' + source]
        for extension in ('lean', 'olean'):
            shutil.copyfile(CACHE / 'modules/Lark' / (name + '.' + extension),
                            modules / 'Lark' / (name + '.' + extension))
    common.write(OUT / 'cached-source-bindings.json', common.read(CACHE / 'cached-source-bindings.json'))
    module = ROOT / 'lean/Lark/PtxLinearExit.lean'
    source_bytes = module.read_bytes()
    (modules / 'Lark/PtxLinearExit.lean').write_bytes(source_bytes)
    env = dict(os.environ, LEAN_PATH=str(modules))
    start = time.monotonic()
    row, log = common.run_lean(lean, ['-o', 'Lark/PtxLinearExit.olean', 'Lark/PtxLinearExit.lean'],
                               modules, env, OUT / 'PtxLinearExit.log')
    common.write(OUT / 'module-check.json', row)
    if row['exit_code'] != 0 or row['timed_out']:
        common.write(OUT / 'results.json', {'status': 'Linear-exit-module-failed',
             'module_check': row, 'source_bound_development_proofs': 0,
             'original_paper_fully_reproduced': False})
        raise RuntimeError('Actual Lean module failed; retained full log: ' + str(OUT / 'PtxLinearExit.log'))
    audits = common.common.audits(log, re.findall(r'^#print axioms (\S+)', source_bytes.decode(), re.M))
    folder = ROOT / 'reproduction/ptx/full-size/linear'
    data = {name: (folder / path).read_bytes() for name, path in (
        ('kernel.ptx', 'kernel.ptx'), ('reference.py', 'reference.py'), ('contract.json', 'task.json'))}
    for name, content in data.items():
        (OUT / name).write_bytes(content)
    _, translation = prepare(*(data[n].decode() for n in data))
    main = (
        'import Lark.PtxLinearExit\nset_option maxRecDepth 10000\nset_option maxHeartbeats 2000000\n'
        'namespace LarkPtxLinearLaneSource\nopen LarkNonlinear LarkPtxPointwise\n'
        'def program : List LarkPtxLinear.Instruction := ' + translation.lean_program() + '\n'
        'theorem source_program : program = LarkPtxLinear.Linear.program := by decide\n'
        'theorem actual_lane (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α)\n'
        '    (t : Nat) (ht : t < 32768) :\n'
        '    ∃ final, LarkPtxLinear.Steps ops LarkPtxLinear.Linear.layout LarkPtxLinear.Linear.geometry\n'
        '      t program (LarkPtxLinear.Linear.start (initial LarkPtxLinear.Linear.layout input outside)) final ∧\n'
        '      final.registers.stopped = true ∧ final.pc = 179 ∧\n'
        '      final.registers.base.memory = (fun l => if l = LarkPtxLinear.Linear.Exit.outputCell t\n'
        '        then some (LarkPtxLinear.Linear.Exit.laneValue ops input t)\n'
        '        else (initial LarkPtxLinear.Linear.layout input outside).memory l) := by\n'
        '  rw [source_program]\n'
        '  exact LarkPtxLinear.Linear.Exit.source_lane ops input t _ ht\n'
        '    (LarkPtxLinear.Linear.Exit.initial_inputs input outside)\n'
        '#print axioms LarkPtxLinearLaneSource.source_program\n'
        '#print axioms LarkPtxLinearLaneSource.actual_lane\nend LarkPtxLinearLaneSource\n'
    )
    (OUT / 'Main.lean').write_text(main)
    check, log = common.run_lean(lean, ['Main.lean'], OUT, env, OUT / 'Main.log')
    common.write(OUT / 'Main-check.json', check)
    assert check['exit_code'] == 0 and not check['timed_out'], log
    audits.update(common.common.audits(log, ['LarkPtxLinearLaneSource.source_program', 'LarkPtxLinearLaneSource.actual_lane']))
    result = {'schema': 1, 'status': 'actual-Linear-complete-source-lane-checked-launch-reference-race-incomplete',
        'seconds': time.monotonic() - start, 'actual_instructions': 179,
        'actual_backward_branch': [167, 50], 'proved_initial_instructions': 179,
        'actual_loop_iterations': 16, 'terms_per_iteration': 16, 'actual_PC_at_exit': 179,
        'actual_registers': 189, 'shapes': [[64, 256], [256, 512], [512], [64, 512]],
        'launch': {'grid': 32768, 'block': 1, 'warp': 32}, 'unchanged_CUDA_fuel': [1030, 1, 1, 1],
        'module_check': row, 'Main_check': check, 'axiom_audits': audits,
        'source_verified_cached_owned_modules_reused': 8, 'fresh_owned_modules_built': 1,
        'old_owned_olean_cache_used': True, 'Lean_binary_sha256': common.sha(lean.read_bytes()),
        'Lean_version': version, 'input_bindings': {n: common.sha(v) for n, v in data.items()},
        'Lean_module_sha256': common.sha(source_bytes), 'source_bound_kernel_proved': False,
        'source_bound_development_proofs': 0, 'model_calls': 0, 'gpu_trials': 0,
        'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False,
        'scope': 'Development complete179instruction compiled Linear lane execution, actual50prologue, '
            'all16 real113body/fivecontrol iterations consuming256terms, all11 bias epilogue '
            'instructions including shl.b64 and bias addition before finalhalf, actual output '
            'store/ret, stopped PC179 and exact single-output/full-other-memory update for every '
            'original active lane and arbitrary initialized inputs/outside memory. All use one '
            'actual successful source-transition witness; no assumed loop summary or new fuel. '
            'Whole32768lane launch composition, closedreference extraction and actualtrace race '
            'proofs remain required. Eight inventory/source-bound prior imports deliberately reused. '
            'No complete independent kernel certificate or original paper result added.'}

    common.write(OUT / 'results.json', result)
    common.manifest(OUT)
    print(json.dumps({'output': str(OUT), 'status': result['status'], 'seconds': result['seconds'],
                     'axiom_audits': len(audits), 'whole_kernel_proved': False}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        if OUT.exists():
            (OUT / 'exception.txt').write_text(traceback.format_exc())
            common.manifest(OUT)
        raise
