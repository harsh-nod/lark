"""Development actual Linear loop check; seven byte/inventory-bound cached imports."""

import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback

ROOT = Path('/tmp/lark-ptx-linear-refinement-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_matrix_certificate as common
from reproduction.ptx.linear_frontend import prepare

OUT = Path('/tmp/lark-ptx-linear-loop-v1-20261113')
CACHE = Path('/tmp/lark-ptx-linear-initialization-cold-v2-20261113')
LEAN = Path('/tmp/lean-4.19.0-linux/bin/lean')
IMPORTS = (*common.MODULES, 'PtxLinear', 'PtxLinearInit')


def main():
    assert not OUT.exists(), 'Inspect original output/handle before another run'
    lean, version = common.toolchain(LEAN)
    common.check_inventory(CACHE)
    previous = common.read(CACHE / 'results.json')
    assert previous['status'] == 'cold-source-complete-Linear-initialization-passed-kernel-incomplete'
    assert previous['fresh_owned_modules_built'] == 7 and previous['old_owned_olean_cache_used'] is False
    sources = common.own_sources()
    for name in ('PtxLinear', 'PtxLinearInit'):
        sources['lean/Lark/' + name + '.lean'] = (ROOT / 'lean/Lark' / (name + '.lean')).read_bytes()
    sources['reproduction/ptx/linear_frontend.py'] = (ROOT / 'reproduction/ptx/linear_frontend.py').read_bytes()
    assert {n: common.sha(v) for n, v in sorted(sources.items())} == common.read(CACHE / 'source-bindings.json')
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    modules = OUT / 'modules'
    (modules / 'Lark').mkdir(parents=True)
    for name in IMPORTS:
        source = 'Lark/' + name + '.lean'
        assert (CACHE / 'modules' / source).read_bytes() == sources['lean/' + source]
        for extension in ('lean', 'olean'):
            shutil.copyfile(CACHE / 'modules/Lark' / (name + '.' + extension),
                            modules / 'Lark' / (name + '.' + extension))
    common.write(OUT / 'cached-source-bindings.json', common.read(CACHE / 'source-bindings.json'))
    module = ROOT / 'lean/Lark/PtxLinearBody.lean'
    source_bytes = module.read_bytes()
    (modules / 'Lark/PtxLinearBody.lean').write_bytes(source_bytes)
    env = dict(os.environ, LEAN_PATH=str(modules))
    start = time.monotonic()
    row, log = common.run_lean(lean, ['-o', 'Lark/PtxLinearBody.olean', 'Lark/PtxLinearBody.lean'],
                               modules, env, OUT / 'PtxLinearBody.log')
    common.write(OUT / 'module-check.json', row)
    if row['exit_code'] != 0 or row['timed_out']:
        common.write(OUT / 'results.json', {'status': 'Linear-loop-module-failed',
             'module_check': row, 'source_bound_development_proofs': 0,
             'original_paper_fully_reproduced': False})
        raise RuntimeError('Actual Lean module failed; retained full log: ' + str(OUT / 'PtxLinearBody.log'))
    audits = common.common.audits(log, re.findall(r'^#print axioms (\S+)', source_bytes.decode(), re.M))
    folder = ROOT / 'reproduction/ptx/full-size/linear'
    data = {name: (folder / path).read_bytes() for name, path in (
        ('kernel.ptx', 'kernel.ptx'), ('reference.py', 'reference.py'), ('contract.json', 'task.json'))}
    for name, content in data.items():
        (OUT / name).write_bytes(content)
    _, translation = prepare(*(data[n].decode() for n in data))
    main = (
        'import Lark.PtxLinearBody\nset_option maxRecDepth 10000\nset_option maxHeartbeats 2000000\n'
        'namespace LarkPtxLinearLoopSource\nopen LarkNonlinear LarkPtxPointwise\n'
        'def program : List LarkPtxLinear.Instruction := ' + translation.lean_program() + '\n'
        'theorem source_program : program = LarkPtxLinear.Linear.program := by decide\n'
        'theorem actual_loop (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α)\n'
        '    (t : Nat) (ht : t < 32768) :\n'
        '    ∃ final, LarkPtxLinear.Steps ops LarkPtxLinear.Linear.layout LarkPtxLinear.Linear.geometry\n'
        '      t program (LarkPtxLinear.Linear.start (initial LarkPtxLinear.Linear.layout input outside)) final ∧\n'
        '      LarkPtxLinear.Linear.Body.LoopInvariant input t 16 (LarkPtxLinear.Linear.Body.dotValue ops input t) final := by\n'
        '  rw [source_program]\n'
        '  exact LarkPtxLinear.Linear.Body.source_to_loop_exit ops input t _ ht\n'
        '    (LarkPtxLinear.Linear.Body.initial_reads input outside)\n'
        '#print axioms LarkPtxLinearLoopSource.source_program\n'
        '#print axioms LarkPtxLinearLoopSource.actual_loop\nend LarkPtxLinearLoopSource\n'
    )
    (OUT / 'Main.lean').write_text(main)
    check, log = common.run_lean(lean, ['Main.lean'], OUT, env, OUT / 'Main.log')
    common.write(OUT / 'Main-check.json', check)
    assert check['exit_code'] == 0 and not check['timed_out'], log
    audits.update(common.common.audits(log, ['LarkPtxLinearLoopSource.source_program', 'LarkPtxLinearLoopSource.actual_loop']))
    result = {'schema': 1, 'status': 'actual-Linear-full256term-loop-checked-bias-epilogue-incomplete',
        'seconds': time.monotonic() - start, 'actual_instructions': 179,
        'actual_backward_branch': [167, 50], 'proved_initial_instructions': 168,
        'actual_loop_iterations': 16, 'terms_per_iteration': 16, 'actual_PC_at_exit': 168,
        'actual_registers': 189, 'shapes': [[64, 256], [256, 512], [512], [64, 512]],
        'launch': {'grid': 32768, 'block': 1, 'warp': 32}, 'unchanged_CUDA_fuel': [1030, 1, 1, 1],
        'module_check': row, 'Main_check': check, 'axiom_audits': audits,
        'source_verified_cached_owned_modules_reused': 7, 'fresh_owned_modules_built': 1,
        'old_owned_olean_cache_used': True, 'Lean_binary_sha256': common.sha(lean.read_bytes()),
        'Lean_version': version, 'input_bindings': {n: common.sha(v) for n, v in data.items()},
        'Lean_module_sha256': common.sha(source_bytes), 'source_bound_kernel_proved': False,
        'source_bound_development_proofs': 0, 'model_calls': 0, 'gpu_trials': 0,
        'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False,
        'scope': 'Development full compiled Linear50instruction prologue and all16 real113instruction '
            'matrix iterations with all5 actual controls/backward branches, linked for every original '
            'active lane and arbitrary initialized input/outside memory. The actual saved bias column '
            'and bias/output pointers are preserved by the loop invariant. Finite source transitions '
            'use no new fuel. Bias epilogue, store/ret, launch composition, reference AST extraction, '
            'outside-memory and race proofs remain required. Seven inventory/source-bound prior owned '
            'imports reused deliberately. No complete independent kernel certificate added.'}
    common.write(OUT / 'results.json', result)
    common.manifest(OUT)
    print(json.dumps({'output': str(OUT), 'status': result['status'], 'seconds': result['seconds'],
                     'axiom_audits': len(audits), 'whole_kernel_proved': False}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        if OUT.exists():
            (OUT / 'exception.txt').write_text(traceback.format_exc())
            common.manifest(OUT)
        raise
