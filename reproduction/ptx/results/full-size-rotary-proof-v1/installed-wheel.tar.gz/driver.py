"""Install the byte-checked wheel offline and recheck the existing proof outside Git."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/lark-ptx-rotary-refinement-20261113')
BASE = Path('/tmp/lark-ptx-rotary-wheel-installed-v1-20261113')
WHEEL_BASE = Path('/tmp/lark-ptx-rotary-wheel-v2-20261113')
ORIGINAL = Path('/tmp/lark-full-size-ptx-rotary-proof-v1-20261113')
REPLAY = Path('/tmp/lark-full-size-ptx-rotary-proof-wheel-replay-v1-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_rotary_certificate as checker  # noqa: E402


def call(name, command, *, cwd=BASE, timeout=120):
    with (BASE / (name + '.stdout')).open('w') as stdout, (BASE / (name + '.stderr')).open('w') as stderr:
        child = subprocess.Popen(command, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr)
        checker.write(BASE / 'progress.json', {'pid': os.getpid(), 'stage': name, 'child_pid': child.pid,
                      'command': command, 'at_utc': datetime.now(timezone.utc).isoformat()})
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            checker.write(BASE / 'progress.json', {'pid': os.getpid(), 'stage': 'inspect-original-child-do-not-restart',
                          'child_pid': child.pid, 'command': command})
            raise
    checker.write(BASE / (name + '.json'), {'exit_code': code, 'command': command})
    assert code == 0, name
    return (BASE / (name + '.stdout')).read_text()


ENV = dict(os.environ, PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_CONFIG_FILE='/dev/null',
           PYTHONNOUSERSITE='1')
for key in ['PYTHONPATH', 'LEAN_PATH']:
    ENV.pop(key, None)


def main():
    assert not BASE.exists() and not REPLAY.exists(), 'Inspect existing installation/replay/PID'
    assert not any((p / '.git').exists() for p in [BASE, *BASE.parents])
    checker.check_inventory(WHEEL_BASE)
    build = checker.read(WHEEL_BASE / 'build-results.json')
    assert build['status'] == 'wheel-built-and-all64-ROTARY-owned-sources-byte-checked'
    wheel = WHEEL_BASE / build['wheel_filename']
    assert checker.sha(wheel.read_bytes()) == build['wheel_sha256']
    BASE.mkdir()
    (BASE / 'driver.py').write_bytes(Path(__file__).read_bytes())
    call('create-venv', [sys.executable, '-m', 'venv', str(BASE / 'venv')])
    python = BASE / 'venv/bin/python'
    call('install-wheel-offline', [str(python), '-I', '-m', 'pip', 'install', '--no-index', '--no-deps', str(wheel)])
    inspect = (
        'import json; from pathlib import Path; '
        'from lark_kernels import ptx_rotary_certificate as c; '
        'from lark_kernels import pointwise; '
        'print(json.dumps({"checker":str(Path(c.__file__).resolve()),'
        '"library":str(pointwise.induction_path().resolve()),'
        '"source_bindings":{n:c.sha(v)for n,v in c.own_sources().items()},"limits":c.LIMITS}))'
    )
    identity = json.loads(call('installed-identity', [str(python), '-I', '-c', inspect]))
    assert Path(identity['checker']).is_relative_to(BASE / 'venv')
    assert Path(identity['library']).is_relative_to(BASE / 'venv')
    assert identity['source_bindings'] == checker.read(ORIGINAL / 'source-bindings.json')
    assert len(identity['source_bindings']) == 64 and identity['limits'] == checker.LIMITS
    checker.write(BASE / 'installed-identity.json', identity)
    call('installed-source-only-replay', [str(python), '-I', '-m', 'lark_kernels.ptx_rotary_certificate',
         'replay', '--recording', str(ORIGINAL), '--output', str(REPLAY),
         '--lean', '/tmp/lean-4.19.0-linux/bin/lean'], timeout=900)
    result = checker.read(REPLAY / 'replay.json')
    assert result['status'] == 'fresh-source-only-PTX-ROTARY-proof-replay-passed'
    assert result['owned_modules_freshly_compiled'] == 8 and not result['old_owned_olean_cache_used']
    assert result['main_regenerated_identically'] and len(result['fresh_export_axiom_audits']) == 7
    checker.write(BASE / 'results.json', {'status': 'installed-wheel-outside-Git-full-RoPE-replay-passed',
                  'wheel_sha256': build['wheel_sha256'], 'wheel_source_commit': build['source_commit'],
                  'matched_owned_sources': 64, 'fresh_owned_Lean_modules': 8, 'positive_rechecks': 1,
                  'replay_manifest_sha256': checker.sha((REPLAY / 'manifest.json').read_bytes()),
                  'installed_runtime': str(python), 'checker_path': identity['checker'],
                  'network_during_install': False, 'source_bound_proofs_added': 0,
                  'model_calls': 0, 'GPU_trials': 0, 'original_paper_fully_reproduced': False})
    checker.manifest(BASE)
    print((BASE / 'results.json').read_text(), flush=True)


if __name__ == '__main__':
    main()
