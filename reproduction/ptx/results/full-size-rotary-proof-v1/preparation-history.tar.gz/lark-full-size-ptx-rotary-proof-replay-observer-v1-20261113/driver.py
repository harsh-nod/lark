"""Two distinct fresh source-only rechecks of the existing full RoPE proof."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/lark-ptx-rotary-refinement-20261113')
BASE = Path('/tmp/lark-full-size-ptx-rotary-proof-replay-observer-v1-20261113')
ORIGINAL = Path('/tmp/lark-full-size-ptx-rotary-proof-v1-20261113')
SOURCE = '538500cbb1a0374f798eded3a83199bbf630ada6'
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_rotary_certificate as checker  # noqa: E402


def main():
    assert not BASE.exists(), 'Inspect the same replay observer/PID; do not launch again'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
    checker.check_inventory(ORIGINAL)
    assert checker.read(ORIGINAL / 'results.json')['source_bound_proof_accepted'] is True
    BASE.mkdir()
    (BASE / 'driver.py').write_bytes(Path(__file__).read_bytes())
    checks = []
    for number in [1, 2]:
        destination = Path(f'/tmp/lark-full-size-ptx-rotary-proof-replay-v{number}-20261113')
        assert not destination.exists(), 'Inspect existing replay instead of overwriting or repeating it'
        checker.write(BASE / 'progress.json', {'pid': os.getpid(), 'source_commit': SOURCE,
                      'stage': 'fresh-source-only-replay', 'recheck': number, 'output': str(destination),
                      'at_utc': datetime.now(timezone.utc).isoformat(), 'completed_rechecks': checks})
        result = checker.check_export(ORIGINAL, destination, '/tmp/lean-4.19.0-linux/bin/lean')
        assert result['status'] == 'fresh-source-only-PTX-ROTARY-proof-replay-passed'
        assert result['owned_modules_freshly_compiled'] == 8 and not result['old_owned_olean_cache_used']
        assert len(result['fresh_export_axiom_audits']) == 7 and result['source_bound_proofs_added'] == 0
        checks.append({'recheck': number, 'output': str(destination),
                       'manifest_sha256': checker.sha((destination / 'manifest.json').read_bytes()),
                       'main_sha256': result['main_sha256'], 'fresh_modules': 8})
    checker.write(BASE / 'results.json', {'status': 'two-fresh-source-only-RoPE-rechecks-passed',
                  'source_commit': SOURCE, 'checks': checks, 'positive_rechecks': 2,
                  'owned_modules_freshly_compiled': 16, 'source_bound_proofs_added': 0,
                  'model_calls': 0, 'GPU_trials': 0, 'original_paper_fully_reproduced': False})
    checker.manifest(BASE)
    print((BASE / 'results.json').read_text(), flush=True)


if __name__ == '__main__':
    main()
