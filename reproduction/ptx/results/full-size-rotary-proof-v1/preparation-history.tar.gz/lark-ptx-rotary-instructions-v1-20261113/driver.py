"""Fresh bounded builds for RoPE instruction semantics, with all attempts retained."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback

ROOT = Path('/tmp/lark-ptx-rotary-refinement-20261113')
OUT = Path('/tmp/lark-ptx-rotary-instructions-v1-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_matrix_certificate as base  # noqa: E402


def main():
    assert not OUT.exists(), 'Inspect original build/PID instead of repeating it'
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    sources = base.own_sources()
    sources['lean/Lark/PtxRotary.lean'] = (ROOT / 'lean/Lark/PtxRotary.lean').read_bytes()
    for name, content in sources.items():
        target = OUT / 'owned-sources' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    base.write(OUT / 'source-bindings.json', {name: base.sha(content) for name, content in sorted(sources.items())})
    lean, version = base.toolchain('/tmp/lean-4.19.0-linux/bin/lean')
    modules = OUT / 'modules'
    (modules / 'Lark').mkdir(parents=True)
    environment = dict(os.environ, LEAN_PATH=str(modules))
    report = {'schema': 1, 'status': 'fresh-instruction-library-build-in-progress', 'pid': os.getpid(),
              'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'base_commit': 'ce5611655946a0a8cca76f97beb8f85bf8f4fc2b',
              'new_sources_uncommitted': True, 'limits': base.LIMITS,
              'lean_binary_sha256': base.sha(lean.read_bytes()), 'lean_version': version,
              'old_owned_olean_cache_used': False, 'module_checks': [], 'library_axiom_audits': {},
              'new_kernel_proofs': 0, 'new_registered_source_certificates': 0,
              'model_calls': 0, 'GPU_trials': 0, 'original_paper_fully_reproduced': False,
              'scope': 'Freshly compiled instruction semantics and their local transition/initialization lemmas only. '
                       'No full RoPE instruction-sequence execution, launch, race-freedom, reference-extraction, '
                       'kernel theorem, IEEE/conformance or model-outcome claim.'}
    base.write(OUT / 'results.json', report)
    started = time.monotonic()
    for name in (*base.MODULES, 'PtxRotary'):
        relative = 'Lark/' + name + '.lean'
        (modules / relative).write_bytes(sources['lean/' + relative])
        remaining = base.LIMITS['source_import_build_seconds'] - (time.monotonic() - started)
        assert remaining > 0, 'Existing 600-second source-import aggregate cap'
        base.write(OUT / 'progress.json', {'pid': os.getpid(), 'module': name,
                   'stage': 'fresh-module-build', 'seconds': time.monotonic() - started})
        row, log = base.run_lean(lean, ['-o', 'Lark/' + name + '.olean', relative], modules,
                                  environment, OUT / (name + '.log'), min(180, remaining))
        row['module'] = 'Lark.' + name
        report['module_checks'].append(row)
        report['seconds'] = time.monotonic() - started
        base.write(OUT / 'results.json', report)
        if row['exit_code'] != 0 or row['timed_out']:
            report['status'] = 'fresh-instruction-library-build-failed'
            base.write(OUT / 'results.json', report)
            base.manifest(OUT)
            print(json.dumps({'status': report['status'], 'module': name, 'check': row}), flush=True)
            raise SystemExit(1)
        if name == 'PtxRotary':
            tags = ['LarkPtxRotary.' + tag for tag in
                    re.findall(r'^#print axioms (\S+)', sources['lean/' + relative].decode(), re.M)]
        else:
            tags = base.library_tags(sources, name)
        report['library_axiom_audits'].update(base.common.audits(log, tags))
        base.write(OUT / 'results.json', report)
        print(json.dumps({'module': name, 'exit_code': 0, 'seconds': row['seconds'], 'audits': len(tags)}), flush=True)
    report['status'] = 'fresh-instruction-library-and-all-axiom-audits-passed'
    report['seconds'] = time.monotonic() - started
    report['owned_modules_freshly_compiled'] = len(report['module_checks'])
    report['new_instruction_lemma_audits'] = len(tags)
    base.write(OUT / 'results.json', report)
    base.write(OUT / 'progress.json', {'pid': os.getpid(), 'stage': 'terminal', 'status': report['status']})
    base.manifest(OUT)
    print(json.dumps({key: report[key] for key in ['status', 'seconds', 'owned_modules_freshly_compiled',
                     'new_instruction_lemma_audits', 'new_kernel_proofs']}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        if OUT.exists():
            (OUT / 'exception.log').write_text(traceback.format_exc())
        raise
