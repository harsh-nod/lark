"""Record one pinned, clean-source full RoPE export; never restart on observation loss."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/lark-ptx-rotary-refinement-20261113')
OUT = Path('/tmp/lark-full-size-ptx-rotary-proof-v1-20261113')
OBSERVER = Path('/tmp/lark-full-size-ptx-rotary-proof-observer-v1-20261113')
SOURCE = '538500cbb1a0374f798eded3a83199bbf630ada6'
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_rotary_certificate as checker  # noqa: E402


def main():
    assert not OUT.exists() and not OBSERVER.exists(), 'Inspect the existing original export/PID'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
    packet = ROOT / 'reproduction/ptx/results/full-size-compilation-v1'
    assert checker.sha((packet / 'raw.tar.gz').read_bytes()) == checker.read(packet / 'manifest.json')['raw.tar.gz']
    names = ['cases/rope/kernel/kernel.ptx', 'cases/rope/original/reference.py', 'cases/rope/original/task.json']
    with tarfile.open(packet / 'raw.tar.gz') as archive:
        inputs = {name: archive.extractfile(path).read() for name, path in zip(checker.INPUTS, names, strict=True)}
    assert checker.sha(inputs['kernel.ptx']) == '7bb0398eebef5e3b4a196f9caae8da45f439a6b076c4d5bdb1e37222f7924180'
    OBSERVER.mkdir()
    (OBSERVER / 'driver.py').write_bytes(Path(__file__).read_bytes())
    checker.write(OBSERVER / 'progress.json', {'pid': os.getpid(), 'stage': 'single-clean-source-full-RoPE-export',
                  'at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': SOURCE,
                  'output': str(OUT), 'fresh_owned_modules': list(checker.MODULES), 'limits': checker.LIMITS,
                  'model_calls': 0, 'GPU_trials': 0})
    report = checker.export_bytes(inputs, OUT, '/tmp/lean-4.19.0-linux/bin/lean')
    accepted = report.get('source_bound_proof_accepted') is True
    if accepted:
        assert report['status'] == 'verified-source-bound-full-PTX-ROTARY'
        assert report['owned_Lean_modules_freshly_compiled'] == 8
        assert len(report['axiom_audits']) == 7 and len(report['library_axiom_audits']) == 265
        assert report['old_owned_olean_cache_used'] is False
        assert report['source_bound_development_proofs'] == 1
        assert report['original_paper_fully_reproduced'] is report['nvidia_execution'] is False
    checker.write(OBSERVER / 'results.json', {'status': 'official-clean-source-RoPE-export-passed' if accepted
                  else 'official-clean-source-RoPE-export-failed', 'source_commit': SOURCE,
                  'source_bound_proof_accepted': accepted, 'export_status': report['status'],
                  'fresh_owned_modules': report['owned_Lean_modules_freshly_compiled'],
                  'export_manifest_sha256': checker.sha((OUT / 'manifest.json').read_bytes()),
                  'model_calls': 0, 'GPU_trials': 0, 'original_paper_fully_reproduced': False})
    checker.manifest(OBSERVER)
    print((OBSERVER / 'results.json').read_text(), flush=True)
    if not accepted and (OUT / 'Main.log').exists():
        print((OUT / 'Main.log').read_text()[-8000:], flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
