import Lark.PtxRotaryReference
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkPtxRotaryCertificate
open LarkNonlinear
def program : List LarkPtxRotary.Instruction := [(.base (.base (.parameter (4) (0)))), (.base (.base (.parameter (5) (1)))), (.base (.base (.parameter (6) (2)))), (.base (.base (.parameter (7) (3)))), (.base (.base (.toGlobal (8) (7)))), (.base (.base (.blockId (1)))), (.base (.shiftRightUnsigned32 2 1 31)), (.base (.base (.addSigned32 (3) (1) (.reg (2))))), (.base (.shiftRightSigned32 4 3 1)), (.base (.andBits32 5 3 (.imm (-2)))), (.base (.base (.toGlobal (9) (4)))), (.base (.base (.mulWideSigned32 (10) (5) (2)))), (.base (.base (.addSigned64 (11) (9) (.reg (10))))), (.base (.base (.loadHalf (1) (11) (0)))), (.base (.base (.fromHalf (3) (1)))), (.base (.base (.loadHalf (2) (11) (2)))), (.base (.base (.fromHalf (4) (2)))), (.base (.andBits32 6 1 (.imm (1)))), (.compareEqBits32 1 6 (.imm (1))), (.predicateLiteral 2 false), (.predicateXor 3 1 2), (.predicateNot 4 3), (.base (.base (.toGlobal (12) (6)))), (.base (.base (.mulWideSigned32 (13) (4) (2)))), (.base (.base (.addSigned64 (1) (12) (.reg (13))))), (.base (.base (.toGlobal (14) (5)))), (.base (.base (.addSigned64 (2) (14) (.reg (13))))), (.base (.base (.mulWideSigned32 (15) (1) (2)))), (.base (.base (.addSigned64 (3) (8) (.reg (15))))), (.base (.base (.branch (4) (31)))), (.branchAlways 41), (.base (.base (.loadHalf (6) (2) (0)))), (.base (.base (.fromHalf (10) (6)))), (.base (.base (.binaryFloat (13) .mul (3) (10)))), (.base (.base (.loadHalf (7) (1) (0)))), (.base (.base (.fromHalf (11) (7)))), (.base (.base (.binaryFloat (14) .mul (4) (11)))), (.base (.base (.binaryFloat (12) .sub (13) (14)))), (.base (.base (.toHalf (8) (12)))), (.base (.base (.storeHalf (3) (0) (8)))), (.branchAlways 50), (.base (.base (.loadHalf (3) (1) (0)))), (.base (.base (.fromHalf (5) (3)))), (.base (.base (.binaryFloat (8) .mul (3) (5)))), (.base (.base (.loadHalf (4) (2) (0)))), (.base (.base (.fromHalf (6) (4)))), (.base (.base (.binaryFloat (9) .mul (4) (6)))), (.base (.base (.binaryFloat (7) .add (8) (9)))), (.base (.base (.toHalf (5) (7)))), (.base (.base (.storeHalf (3) (0) (5)))), (.base (.base (.ret)))]
def referenceBody : LarkPtxRotary.Reference.TensorReference := (.toHalf (.reshape [256, 128] (.stackLast (.binary .add (.binary .mul (.select 2 0 (.reshape [256, 64, 2] (.fromHalf (.input 0)))) (.fromHalf (.input 1))) (.binary .mul (.select 2 1 (.reshape [256, 64, 2] (.fromHalf (.input 0)))) (.fromHalf (.input 2)))) (.binary .add (.binary .mul (.select 2 0 (.reshape [256, 64, 2] (.fromHalf (.input 0)))) (.fromHalf (.input 2))) (.binary .mul (.select 2 1 (.reshape [256, 64, 2] (.fromHalf (.input 0)))) (.fromHalf (.input 1)))))))
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  (LarkPtxRotary.Reference.extractReference ops input referenceBody).getD []
theorem source_program : program = LarkPtxRotary.Kernel.program := by decide
theorem reference_body : referenceBody = LarkPtxRotary.Reference.referenceBody := by rfl
theorem reference_denotation (ops : Ops α) (input : Nat → Nat → α) :
    LarkPtxRotary.Reference.extractReference ops input referenceBody =
      some (LarkPtxRotary.Kernel.referenceSpec ops input) := by
  rw [reference_body]
  exact LarkPtxRotary.Reference.extract_reference_body ops input
theorem kernel_eq_spec (ops : Ops α) : LarkPtxRotary.Kernel.Correct ops program (spec ops) := by
  have hs : spec ops = LarkPtxRotary.Reference.spec ops := by
    funext input
    simp only [spec, LarkPtxRotary.Reference.spec, reference_body]
  rw [source_program, hs]
  exact LarkPtxRotary.Reference.closed_reference_correct ops
theorem launch (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    ∃ final, LarkPtxRotary.Kernel.LaneSequence ops program 0 32768
      (initial LarkPtxRotary.Kernel.layout input outside) final ∧
    raceFree LarkPtxRotary.Kernel.geometry final.trace = true ∧
    extract LarkPtxRotary.Kernel.layout final = some (spec ops input) ∧
    (∀ l, (∀ i, i < 32768 → l ≠ LarkPtxRotary.Kernel.outputCell i) →
      final.memory l = (initial LarkPtxRotary.Kernel.layout input outside).memory l) :=
  kernel_eq_spec ops input outside
theorem race_free (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    ∃ final, LarkPtxRotary.Kernel.LaneSequence ops program 0 32768
      (initial LarkPtxRotary.Kernel.layout input outside) final ∧
      raceFree LarkPtxRotary.Kernel.geometry final.trace = true := by
  obtain ⟨final, execution, race, _, _⟩ := launch ops input outside
  exact ⟨final, execution, race⟩
theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    ∃ final, LarkPtxRotary.Kernel.LaneSequence ops program 0 32768
      (initial LarkPtxRotary.Kernel.layout input outside) final ∧
      extract LarkPtxRotary.Kernel.layout final =
        LarkPtxRotary.Reference.extractReference ops input referenceBody := by
  obtain ⟨final, execution, _, values, _⟩ := launch ops input outside
  have hs : spec ops input = LarkPtxRotary.Kernel.referenceSpec ops input := by
    simp only [spec, reference_denotation, Option.getD_some]
  rw [hs] at values
  exact ⟨final, execution, values.trans (reference_denotation ops input).symm⟩
#print axioms LarkPtxRotaryCertificate.source_program
#print axioms LarkPtxRotaryCertificate.reference_body
#print axioms LarkPtxRotaryCertificate.reference_denotation
#print axioms LarkPtxRotaryCertificate.launch
#print axioms LarkPtxRotaryCertificate.race_free
#print axioms LarkPtxRotaryCertificate.segment_equivalence
#print axioms LarkPtxRotaryCertificate.kernel_eq_spec
end LarkPtxRotaryCertificate
