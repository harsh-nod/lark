import Lark.PtxRotary

/-!
The complete unchanged 51-instruction compiled interleaved RoPE program.
The following proofs build actual successful transitions at the original
32768-lane launch. No new execution fuel or reduced CUDA contract is used.
-/
namespace LarkPtxRotary
namespace Kernel
open LarkNonlinear LarkPtxPointwise LarkPtxDot
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

def program : List Instruction :=
  [(.base (.base (.parameter (4) (0)))),
   (.base (.base (.parameter (5) (1)))),
   (.base (.base (.parameter (6) (2)))),
   (.base (.base (.parameter (7) (3)))),
   (.base (.base (.toGlobal (8) (7)))),
   (.base (.base (.blockId (1)))),
   (.base (.shiftRightUnsigned32 2 1 31)),
   (.base (.base (.addSigned32 (3) (1) (.reg (2))))),
   (.base (.shiftRightSigned32 4 3 1)),
   (.base (.andBits32 5 3 (.imm (-2)))),
   (.base (.base (.toGlobal (9) (4)))),
   (.base (.base (.mulWideSigned32 (10) (5) (2)))),
   (.base (.base (.addSigned64 (11) (9) (.reg (10))))),
   (.base (.base (.loadHalf (1) (11) (0)))),
   (.base (.base (.fromHalf (3) (1)))),
   (.base (.base (.loadHalf (2) (11) (2)))),
   (.base (.base (.fromHalf (4) (2)))),
   (.base (.andBits32 6 1 (.imm (1)))),
   (.compareEqBits32 1 6 (.imm (1))),
   (.predicateLiteral 2 false),
   (.predicateXor 3 1 2),
   (.predicateNot 4 3),
   (.base (.base (.toGlobal (12) (6)))),
   (.base (.base (.mulWideSigned32 (13) (4) (2)))),
   (.base (.base (.addSigned64 (1) (12) (.reg (13))))),
   (.base (.base (.toGlobal (14) (5)))),
   (.base (.base (.addSigned64 (2) (14) (.reg (13))))),
   (.base (.base (.mulWideSigned32 (15) (1) (2)))),
   (.base (.base (.addSigned64 (3) (8) (.reg (15))))),
   (.base (.base (.branch (4) (31)))),
   (.branchAlways 41),
   (.base (.base (.loadHalf (6) (2) (0)))),
   (.base (.base (.fromHalf (10) (6)))),
   (.base (.base (.binaryFloat (13) .mul (3) (10)))),
   (.base (.base (.loadHalf (7) (1) (0)))),
   (.base (.base (.fromHalf (11) (7)))),
   (.base (.base (.binaryFloat (14) .mul (4) (11)))),
   (.base (.base (.binaryFloat (12) .sub (13) (14)))),
   (.base (.base (.toHalf (8) (12)))),
   (.base (.base (.storeHalf (3) (0) (8)))),
   (.branchAlways 50),
   (.base (.base (.loadHalf (3) (1) (0)))),
   (.base (.base (.fromHalf (5) (3)))),
   (.base (.base (.binaryFloat (8) .mul (3) (5)))),
   (.base (.base (.loadHalf (4) (2) (0)))),
   (.base (.base (.fromHalf (6) (4)))),
   (.base (.base (.binaryFloat (9) .mul (4) (6)))),
   (.base (.base (.binaryFloat (7) .add (8) (9)))),
   (.base (.base (.toHalf (5) (7)))),
   (.base (.base (.storeHalf (3) (0) (5)))),
   (.base (.base (.ret)))]

def layout : Layout :=
  ⟨[⟨.input, 256*128⟩, ⟨.input, 256*64⟩, ⟨.input, 256*64⟩,
     ⟨.output, 256*128⟩], [], []⟩

def geometry : Geometry := ⟨32768, 1, 32⟩

theorem bits32_negative2 : LarkPtxMatrix.bits32 (-2) = 4294967294 := by decide

theorem clear_low1 (n : Nat) (hn : n < 4294967296) :
    n &&& 4294967294 = (n / 2) * 2 := by
  have hd : (n &&& 4294967294) / 2 = n / 2 := by
    have hdiv : n / 2 < 2147483648 := by omega
    change (n &&& 4294967294) / 2^1 = n / 2
    rw [Nat.and_div_two_pow]
    change n / 2 &&& (2^31-1) = n / 2
    exact Nat.and_two_pow_sub_one_of_lt_two_pow hdiv
  have hm : (n &&& 4294967294) % 2 = 0 := by
    change (n &&& 4294967294) % 2^1 = 0
    rw [Nat.and_mod_two_pow]
    change n % 2 &&& 0 = 0
    simp
  have hs := Nat.mod_add_div (n &&& 4294967294) 2
  rw [hm, hd] at hs
  omega

def start (s : State α) : Machine α := { registers := { base := s } }
def parameterX (s : State α) : Machine α := setPointer (start s) 4 ⟨0, 0, false⟩
def parameterCosine (s : State α) : Machine α := setPointer (parameterX s) 5 ⟨1, 0, false⟩
def parameterSine (s : State α) : Machine α := setPointer (parameterCosine s) 6 ⟨2, 0, false⟩
def parameters (s : State α) : Machine α := setPointer (parameterSine s) 7 ⟨3, 0, false⟩
def globalOutput (s : State α) : Machine α := setPointer (parameters s) 8 ⟨3, 0, true⟩
def indexed (t : Nat) (s : State α) : Machine α := setIndex32 (globalOutput s) 1 (t : Int)
def corrected (t : Nat) (s : State α) : Machine α := setIndex32 (indexed t s) 2 0
def adjusted (t : Nat) (s : State α) : Machine α := setIndex32 (corrected t s) 3 (t : Int)
def paired (t : Nat) (s : State α) : Machine α := setIndex32 (adjusted t s) 4 ((t/2 : Nat) : Int)
def masked (t : Nat) (s : State α) : Machine α := setIndex32 (paired t s) 5 ((t/2*2 : Nat) : Int)
def globalX (t : Nat) (s : State α) : Machine α := setPointer (masked t s) 9 ⟨0, 0, true⟩
def wideX (t : Nat) (s : State α) : Machine α :=
  LarkPtxMatrix.setIndex64 (globalX t s) 10 ((t/2*4 : Nat) : Int)
def xPointer (t : Nat) (s : State α) : Machine α :=
  setPointer (wideX t s) 11 ⟨0, ((t/2*4 : Nat) : Int), true⟩

theorem parameters_execute (ops : Ops α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (start s) (globalOutput s) :=
  .next (by rfl) (.next (by rfl) (.next (by rfl) (.next (by rfl) (.next (by rfl) (.refl _)))))

theorem index_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (globalOutput s) (indexed t s) := by
  have hb : 0 < geometry.block ∧ t / geometry.block < 4294967296 := by
    simp only [geometry, Nat.div_one]; omega
  have e := blockId_step ops layout geometry t 1 (globalOutput s) hb
  apply one_step
  rw [transition_at ops layout geometry t program (globalOutput s)
    (.base (.base (.blockId 1))) (by rfl) (by rfl)]
  change LarkPtxDot.execute ops layout geometry t (.blockId 1) (globalOutput s) = some (indexed t s)
  simpa only [geometry, Nat.div_one] using e

theorem correction_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (indexed t s) (corrected t s) := by
  have hb : unsigned32 (t : Int) := by unfold unsigned32; omega
  have e := LarkPtxMatrix.unsigned_right_step ops layout geometry t 2 1 31
    (t : Int) (indexed t s) (by rfl) hb
  have hp : (2 : Int)^min 31 32 = 2147483648 := by decide
  have hz : (t : Int) / 2147483648 = 0 := by omega
  rw [hp, hz] at e
  apply one_step
  rw [transition_at ops layout geometry t program (indexed t s)
    (.base (.shiftRightUnsigned32 2 1 31)) (by rfl) (by rfl), base_step]
  exact e

theorem adjustment_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (corrected t s) (adjusted t s) := by
  have hb : signed32 (t : Int) ∧ signed32 0 ∧ signed32 ((t : Int)+0) := by
    unfold signed32; omega
  have e := add32_step ops layout geometry t 3 1 (.reg 2) (corrected t s) (t : Int) 0
    (by rfl) (by rfl) hb
  simp only [Int.add_zero] at e
  apply one_step
  rw [transition_at ops layout geometry t program (corrected t s)
    (.base (.base (.addSigned32 3 1 (.reg 2)))) (by rfl) (by rfl)]
  exact e

theorem pair_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (adjusted t s) (paired t s) := by
  have hb : signed32 (t : Int) := by unfold signed32; omega
  have e := LarkPtxMatrix.signed_right_step ops layout geometry t 4 3 1
    (t : Int) (adjusted t s) (by rfl) hb
  have hp : (2 : Int)^min 1 32 = 2 := by decide
  have he : (t : Int)/2 = ((t/2 : Nat) : Int) := by omega
  rw [hp, he] at e
  apply one_step
  rw [transition_at ops layout geometry t program (adjusted t s)
    (.base (.shiftRightSigned32 4 3 1)) (by rfl) (by rfl), base_step]
  exact e

theorem mask_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (paired t s) (masked t s) := by
  have hb : unsigned32 (t : Int) ∧ signed32 (-2) := by unfold unsigned32 signed32; omega
  have e := LarkPtxMatrix.and_step ops layout geometry t 5 3 (.imm (-2))
    (t : Int) (-2) (paired t s) (by rfl) (by rfl) hb
  have htbits : LarkPtxMatrix.bits32 (t : Int) = t := by
    unfold LarkPtxMatrix.bits32
    have he : (t : Int) % 4294967296 = (t : Int) := by omega
    rw [he]; rfl
  rw [htbits, bits32_negative2, clear_low1 t (by omega)] at e
  apply one_step
  rw [transition_at ops layout geometry t program (paired t s)
    (.base (.andBits32 5 3 (.imm (-2)))) (by rfl) (by rfl), base_step]
  exact e

theorem globalX_execute (ops : Ops α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (masked t s) (globalX t s) :=
  .next (by rfl) (.refl _)

theorem wideX_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (globalX t s) (wideX t s) := by
  have htdiv : t/2 < 16384 := by omega
  have hb : signed32 ((t/2*2 : Nat) : Int) ∧ signed32 2 ∧
      signed64 (((t/2*2 : Nat) : Int)*2) := by
    unfold signed32 signed64; simp only [Int.natCast_mul]; omega
  have e := wide_step ops layout geometry t 10 5 2 ((t/2*2 : Nat) : Int)
    (globalX t s) (by rfl) hb
  have he : (((t/2*2 : Nat) : Int)*2) = ((t/2*4 : Nat) : Int) := by
    simp only [Int.natCast_mul]; omega
  rw [he] at e
  apply one_step
  rw [transition_at ops layout geometry t program (globalX t s)
    (.base (.base (.mulWideSigned32 10 5 2))) (by rfl) (by rfl)]
  exact e

theorem xPointer_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (wideX t s) (xPointer t s) := by
  have htdiv : t/2 < 16384 := by omega
  have hb : signed64 ((t/2*4 : Nat) : Int) ∧ signed64 (0+((t/2*4 : Nat) : Int)) := by
    unfold signed64; simp only [Int.natCast_mul]; omega
  have e := pointer_add_step ops layout geometry t 11 9 (.reg 10) ⟨0, 0, true⟩
    ((t/2*4 : Nat) : Int) (wideX t s) (by rfl) (by rfl) hb
  simp only [Int.zero_add] at e
  apply one_step
  rw [transition_at ops layout geometry t program (wideX t s)
    (.base (.base (.addSigned64 11 9 (.reg 10)))) (by rfl) (by rfl)]
  exact e

theorem coordinates_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (start s) (xPointer t s) := by
  apply steps_trans _ _ _ _ _ _ _ _ (parameters_execute ops t s)
  apply steps_trans _ _ _ _ _ _ _ _ (index_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (correction_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (adjustment_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (pair_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (mask_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (globalX_execute ops t s)
  exact steps_trans _ _ _ _ _ _ _ _ (wideX_execute ops t s ht) (xPointer_execute ops t s ht)

theorem xPointer_pc (t : Nat) (s : State α) : (xPointer t s).pc = 13 := rfl
theorem xPointer_base (t : Nat) (s : State α) : (xPointer t s).registers.base = s := rfl

theorem instruction_step (ops : Ops α) (t pc : Nat) (s u : Machine α) (i : Instruction)
    (hpc : s.pc = pc) (hs : s.registers.stopped = false)
    (hf : program[pc]? = some i) (he : execute ops layout geometry t i s = some u) :
    Steps ops layout geometry t program s u := by
  apply one_step
  rw [transition_at ops layout geometry t program s i hs (by rw [hpc]; exact hf)]
  exact he

def Reads (input : Nat → Nat → α) (s : State α) : Prop :=
  (∀ i, i < 32768 → s.memory ⟨.global, 0, 0, i⟩ = some (input 0 i)) ∧
  (∀ i, i < 16384 → s.memory ⟨.global, 0, 1, i⟩ = some (input 1 i)) ∧
  (∀ i, i < 16384 → s.memory ⟨.global, 0, 2, i⟩ = some (input 2 i))

def xCell (t j : Nat) : Location := ⟨.global, 0, 0, t/2*2+j⟩
def cosineCell (t : Nat) : Location := ⟨.global, 0, 1, t/2⟩
def sineCell (t : Nat) : Location := ⟨.global, 0, 2, t/2⟩
def outputCell (t : Nat) : Location := ⟨.global, 0, 3, t⟩

theorem x_address (t j : Nat) (ht : t < 32768) (hj : j < 2) :
    address layout geometry t ⟨0, ((t/2*4 : Nat) : Int), true⟩ ((2*j : Nat) : Int) false =
      some (xCell t j) := by
  have hr : t/2 < 16384 := by omega
  have he : ((t/2*4 : Nat) : Int) + ((2*j : Nat) : Int) =
      ((t/2*2+j : Nat) : Int)*2 := by
    simp only [Int.natCast_add, Int.natCast_mul]; omega
  have hs : signed64 (((t/2*2+j : Nat) : Int)*2) := by
    unfold signed64; simp only [Int.natCast_add, Int.natCast_mul]; omega
  have hb : t/2*2+j < 256*128 := by omega
  rw [aligned_address layout geometry t 0 (t/2*2+j) _ _ false he hs]
  exact read_location layout geometry t 0 _ ⟨.input, 256*128⟩ (by rfl) hb

def loadX0 (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  loadedHalf (xPointer t s) t 1 (xCell t 0) (input 0 (t/2*2))
def castX0 (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setFloat (loadX0 input t s) 3 (ops.fromHalf (input 0 (t/2*2)))
def loadX1 (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  loadedHalf (castX0 ops input t s) t 2 (xCell t 1) (input 0 (t/2*2+1))
def castX1 (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setFloat (loadX1 ops input t s) 4 (ops.fromHalf (input 0 (t/2*2+1)))

theorem input_loads_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α)
    (ht : t < 32768) (hr : Reads input s) :
    Steps ops layout geometry t program (xPointer t s) (castX1 ops input t s) := by
  have hdiv : t/2 < 16384 := by omega
  have ha0 : (xPointer t s).registers.base.memory (xCell t 0) = some (input 0 (t/2*2)) := by
    simpa [xCell, xPointer_base] using hr.1 (t/2*2) (by omega)
  have h0 := instruction_step ops t 13 (xPointer t s) (loadX0 input t s)
    (.base (.base (.loadHalf 1 11 0))) (by rfl) (by rfl) (by rfl)
    (loadHalf_step ops layout geometry t 1 11 0 (xPointer t s)
      ⟨0, ((t/2*4 : Nat) : Int), true⟩ (xCell t 0) (input 0 (t/2*2))
      (by rfl) (by simpa using x_address t 0 ht (by decide)) ha0)
  have h1 := instruction_step ops t 14 (loadX0 input t s) (castX0 ops input t s)
    (.base (.base (.fromHalf 3 1))) (by rfl) (by rfl) (by rfl)
    (fromHalf_step ops layout geometry t 3 1 (loadX0 input t s) _ (by simp [loadX0]))
  have ha1 : (castX0 ops input t s).registers.base.memory (xCell t 1) =
      some (input 0 (t/2*2+1)) := by
    simpa [castX0, loadX0, xCell, xPointer_base] using hr.1 (t/2*2+1) (by omega)
  have h2 := instruction_step ops t 15 (castX0 ops input t s) (loadX1 ops input t s)
    (.base (.base (.loadHalf 2 11 2))) (by rfl) (by rfl) (by rfl)
    (loadHalf_step ops layout geometry t 2 11 2 (castX0 ops input t s)
      ⟨0, ((t/2*4 : Nat) : Int), true⟩ (xCell t 1) (input 0 (t/2*2+1))
      (by simp [castX0, loadX0, xPointer]) (by simpa using x_address t 1 ht (by decide)) ha1)
  have h3 := instruction_step ops t 16 (loadX1 ops input t s) (castX1 ops input t s)
    (.base (.base (.fromHalf 4 2))) (by rfl) (by rfl) (by rfl)
    (fromHalf_step ops layout geometry t 4 2 (loadX1 ops input t s) _ (by simp [loadX1]))
  exact steps_trans _ _ _ _ _ _ _ _ h0
    (steps_trans _ _ _ _ _ _ _ _ h1 (steps_trans _ _ _ _ _ _ _ _ h2 h3))

theorem inputs_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α)
    (ht : t < 32768) (hr : Reads input s) :
    Steps ops layout geometry t program (start s) (castX1 ops input t s) :=
  steps_trans _ _ _ _ _ _ _ _ (coordinates_execute ops t s ht) (input_loads_execute ops input t s ht hr)

theorem inputs_memory (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    (castX1 ops input t s).registers.base.memory = s.memory := rfl

def oddBit (t : Nat) : Bool := t%2 == 1
def evenBit (t : Nat) : Bool := t%2 == 0
def lowBit (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setIndex32 (castX1 ops input t s) 6 ((t%2 : Nat) : Int)
def compared (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setPredicate (lowBit ops input t s) 1 (oddBit t)
def literalFalse (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setPredicate (compared ops input t s) 2 false
def xored (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setPredicate (literalFalse ops input t s) 3 (oddBit t)
def inverted (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) : Machine α :=
  setPredicate (xored ops input t s) 4 (evenBit t)

theorem lowBit_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α)
    (ht : t < 32768) :
    Steps ops layout geometry t program (castX1 ops input t s) (lowBit ops input t s) := by
  have hb : unsigned32 (t : Int) ∧ signed32 1 := by unfold unsigned32 signed32; omega
  have e := LarkPtxMatrix.and_step ops layout geometry t 6 1 (.imm 1)
    (t : Int) 1 (castX1 ops input t s) (by rfl) (by rfl) hb
  have htbits : LarkPtxMatrix.bits32 (t : Int) = t := by
    unfold LarkPtxMatrix.bits32
    have he : (t : Int) % 4294967296 = (t : Int) := by omega
    rw [he]; simp
  rw [htbits, show LarkPtxMatrix.bits32 1 = 1 by decide, Nat.and_one_is_mod] at e
  exact instruction_step ops t 17 _ _ (.base (.andBits32 6 1 (.imm 1)))
    (by rfl) (by rfl) (by rfl) e

theorem compare_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (lowBit ops input t s) (compared ops input t s) := by
  have hm : t%2 < 2 := Nat.mod_lt _ (by decide)
  have hb : validBits32 ((t%2 : Nat) : Int) ∧ validBits32 1 := by unfold validBits32; omega
  have e := compare_step ops layout geometry t 1 6 (.imm 1)
    ((t%2 : Nat) : Int) 1 (lowBit ops input t s) (by rfl) (by rfl) hb
  have hbits : LarkPtxMatrix.bits32 ((t%2 : Nat) : Int) = t%2 := by
    unfold LarkPtxMatrix.bits32
    have he : ((t%2 : Nat) : Int) % 4294967296 = ((t%2 : Nat) : Int) := by omega
    rw [he]; rfl
  rw [hbits, show LarkPtxMatrix.bits32 1 = 1 by decide] at e
  exact instruction_step ops t 18 _ _ (.compareEqBits32 1 6 (.imm 1))
    (by rfl) (by rfl) (by rfl) e

theorem literalFalse_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (compared ops input t s) (literalFalse ops input t s) :=
  .next (by rfl) (.refl _)

theorem xor_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (literalFalse ops input t s) (xored ops input t s) := by
  have e := predicate_xor_step ops layout geometry t 3 1 2 (oddBit t) false
    (literalFalse ops input t s) (by rfl) (by rfl)
  have he : ((oddBit t) != false) = oddBit t := by cases h : oddBit t <;> rfl
  rw [he] at e
  exact instruction_step ops t 20 _ _ (.predicateXor 3 1 2) (by rfl) (by rfl) (by rfl) e

theorem not_odd_even (t : Nat) : (!(oddBit t)) = evenBit t := by
  rcases Nat.mod_two_eq_zero_or_one t with h | h <;> simp [oddBit, evenBit, h]

theorem invert_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (xored ops input t s) (inverted ops input t s) := by
  have e := predicate_not_step ops layout geometry t 4 3 (oddBit t)
    (xored ops input t s) (by rfl)
  rw [not_odd_even] at e
  exact instruction_step ops t 21 _ _ (.predicateNot 4 3) (by rfl) (by rfl) (by rfl) e

theorem predicates_execute (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α)
    (ht : t < 32768) :
    Steps ops layout geometry t program (castX1 ops input t s) (inverted ops input t s) := by
  apply steps_trans _ _ _ _ _ _ _ _ (lowBit_execute ops input t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (compare_execute ops input t s)
  apply steps_trans _ _ _ _ _ _ _ _ (literalFalse_execute ops input t s)
  exact steps_trans _ _ _ _ _ _ _ _ (xor_execute ops input t s) (invert_execute ops input t s)

theorem inverted_memory (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    (inverted ops input t s).registers.base.memory = s.memory := rfl

#print axioms lowBit_execute
#print axioms compare_execute
#print axioms literalFalse_execute
#print axioms xor_execute
#print axioms not_odd_even
#print axioms invert_execute
#print axioms predicates_execute
#print axioms inverted_memory
#print axioms instruction_step
#print axioms x_address
#print axioms input_loads_execute
#print axioms inputs_execute
#print axioms inputs_memory
#print axioms bits32_negative2
#print axioms clear_low1
#print axioms parameters_execute
#print axioms index_execute
#print axioms correction_execute
#print axioms adjustment_execute
#print axioms pair_execute
#print axioms mask_execute
#print axioms globalX_execute
#print axioms wideX_execute
#print axioms xPointer_execute
#print axioms coordinates_execute
#print axioms xPointer_pc
#print axioms xPointer_base

end Kernel
end LarkPtxRotary
