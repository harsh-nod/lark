import Lark.PtxRotary

/-!
The complete unchanged 51-instruction compiled interleaved RoPE program.
The following proofs build actual successful transitions at the original
32768-lane launch. No new execution fuel or reduced CUDA contract is used.
-/
namespace LarkPtxRotary
namespace Kernel
open LarkNonlinear LarkPtxPointwise LarkPtxDot
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

def program : List Instruction :=
  [(.base (.base (.parameter (4) (0)))),
   (.base (.base (.parameter (5) (1)))),
   (.base (.base (.parameter (6) (2)))),
   (.base (.base (.parameter (7) (3)))),
   (.base (.base (.toGlobal (8) (7)))),
   (.base (.base (.blockId (1)))),
   (.base (.shiftRightUnsigned32 2 1 31)),
   (.base (.base (.addSigned32 (3) (1) (.reg (2))))),
   (.base (.shiftRightSigned32 4 3 1)),
   (.base (.andBits32 5 3 (.imm (-2)))),
   (.base (.base (.toGlobal (9) (4)))),
   (.base (.base (.mulWideSigned32 (10) (5) (2)))),
   (.base (.base (.addSigned64 (11) (9) (.reg (10))))),
   (.base (.base (.loadHalf (1) (11) (0)))),
   (.base (.base (.fromHalf (3) (1)))),
   (.base (.base (.loadHalf (2) (11) (2)))),
   (.base (.base (.fromHalf (4) (2)))),
   (.base (.andBits32 6 1 (.imm (1)))),
   (.compareEqBits32 1 6 (.imm (1))),
   (.predicateLiteral 2 false),
   (.predicateXor 3 1 2),
   (.predicateNot 4 3),
   (.base (.base (.toGlobal (12) (6)))),
   (.base (.base (.mulWideSigned32 (13) (4) (2)))),
   (.base (.base (.addSigned64 (1) (12) (.reg (13))))),
   (.base (.base (.toGlobal (14) (5)))),
   (.base (.base (.addSigned64 (2) (14) (.reg (13))))),
   (.base (.base (.mulWideSigned32 (15) (1) (2)))),
   (.base (.base (.addSigned64 (3) (8) (.reg (15))))),
   (.base (.base (.branch (4) (31)))),
   (.branchAlways 41),
   (.base (.base (.loadHalf (6) (2) (0)))),
   (.base (.base (.fromHalf (10) (6)))),
   (.base (.base (.binaryFloat (13) .mul (3) (10)))),
   (.base (.base (.loadHalf (7) (1) (0)))),
   (.base (.base (.fromHalf (11) (7)))),
   (.base (.base (.binaryFloat (14) .mul (4) (11)))),
   (.base (.base (.binaryFloat (12) .sub (13) (14)))),
   (.base (.base (.toHalf (8) (12)))),
   (.base (.base (.storeHalf (3) (0) (8)))),
   (.branchAlways 50),
   (.base (.base (.loadHalf (3) (1) (0)))),
   (.base (.base (.fromHalf (5) (3)))),
   (.base (.base (.binaryFloat (8) .mul (3) (5)))),
   (.base (.base (.loadHalf (4) (2) (0)))),
   (.base (.base (.fromHalf (6) (4)))),
   (.base (.base (.binaryFloat (9) .mul (4) (6)))),
   (.base (.base (.binaryFloat (7) .add (8) (9)))),
   (.base (.base (.toHalf (5) (7)))),
   (.base (.base (.storeHalf (3) (0) (5)))),
   (.base (.base (.ret)))]

def layout : Layout :=
  ⟨[⟨.input, 256*128⟩, ⟨.input, 256*64⟩, ⟨.input, 256*64⟩,
     ⟨.output, 256*128⟩], [], []⟩

def geometry : Geometry := ⟨32768, 1, 32⟩

theorem bits32_negative2 : LarkPtxMatrix.bits32 (-2) = 4294967294 := by decide

theorem clear_low1 (n : Nat) (hn : n < 4294967296) :
    n &&& 4294967294 = (n / 2) * 2 := by
  have hd : (n &&& 4294967294) / 2 = n / 2 := by
    have hdiv : n / 2 < 2147483648 := by omega
    change (n &&& 4294967294) / 2^1 = n / 2
    rw [Nat.and_div_two_pow]
    change n / 2 &&& (2^31-1) = n / 2
    exact Nat.and_two_pow_sub_one_of_lt_two_pow hdiv
  have hm : (n &&& 4294967294) % 2 = 0 := by
    change (n &&& 4294967294) % 2^1 = 0
    rw [Nat.and_mod_two_pow]
    change n % 2 &&& 0 = 0
    simp
  have hs := Nat.mod_add_div (n &&& 4294967294) 2
  rw [hm, hd] at hs
  omega

def start (s : State α) : Machine α := { registers := { base := s } }
def parameterX (s : State α) : Machine α := setPointer (start s) 4 ⟨0, 0, false⟩
def parameterCosine (s : State α) : Machine α := setPointer (parameterX s) 5 ⟨1, 0, false⟩
def parameterSine (s : State α) : Machine α := setPointer (parameterCosine s) 6 ⟨2, 0, false⟩
def parameters (s : State α) : Machine α := setPointer (parameterSine s) 7 ⟨3, 0, false⟩
def globalOutput (s : State α) : Machine α := setPointer (parameters s) 8 ⟨3, 0, true⟩
def indexed (t : Nat) (s : State α) : Machine α := setIndex32 (globalOutput s) 1 (t : Int)
def corrected (t : Nat) (s : State α) : Machine α := setIndex32 (indexed t s) 2 0
def adjusted (t : Nat) (s : State α) : Machine α := setIndex32 (corrected t s) 3 (t : Int)
def paired (t : Nat) (s : State α) : Machine α := setIndex32 (adjusted t s) 4 ((t/2 : Nat) : Int)
def masked (t : Nat) (s : State α) : Machine α := setIndex32 (paired t s) 5 ((t/2*2 : Nat) : Int)
def globalX (t : Nat) (s : State α) : Machine α := setPointer (masked t s) 9 ⟨0, 0, true⟩
def wideX (t : Nat) (s : State α) : Machine α :=
  LarkPtxMatrix.setIndex64 (globalX t s) 10 ((t/2*4 : Nat) : Int)
def xPointer (t : Nat) (s : State α) : Machine α :=
  setPointer (wideX t s) 11 ⟨0, ((t/2*4 : Nat) : Int), true⟩

theorem parameters_execute (ops : Ops α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (start s) (globalOutput s) :=
  .next (by rfl) (.next (by rfl) (.next (by rfl) (.next (by rfl) (.next (by rfl) (.refl _)))))

theorem index_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (globalOutput s) (indexed t s) := by
  have hb : 0 < geometry.block ∧ t / geometry.block < 4294967296 := by
    simp only [geometry, Nat.div_one]; omega
  have e := blockId_step ops layout geometry t 1 (globalOutput s) hb
  apply one_step
  rw [transition_at ops layout geometry t program (globalOutput s)
    (.base (.base (.blockId 1))) (by rfl) (by rfl)]
  change LarkPtxDot.execute ops layout geometry t (.blockId 1) (globalOutput s) = some (indexed t s)
  simpa only [geometry, Nat.div_one] using e

theorem correction_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (indexed t s) (corrected t s) := by
  have hb : unsigned32 (t : Int) := by unfold unsigned32; omega
  have e := LarkPtxMatrix.unsigned_right_step ops layout geometry t 2 1 31
    (t : Int) (indexed t s) (by rfl) hb
  have hp : (2 : Int)^min 31 32 = 2147483648 := by decide
  have hz : (t : Int) / 2147483648 = 0 := by omega
  rw [hp, hz] at e
  apply one_step
  rw [transition_at ops layout geometry t program (indexed t s)
    (.base (.shiftRightUnsigned32 2 1 31)) (by rfl) (by rfl), base_step]
  exact e

theorem adjustment_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (corrected t s) (adjusted t s) := by
  have hb : signed32 (t : Int) ∧ signed32 0 ∧ signed32 ((t : Int)+0) := by
    unfold signed32; omega
  have e := add32_step ops layout geometry t 3 1 (.reg 2) (corrected t s) (t : Int) 0
    (by rfl) (by rfl) hb
  simp only [Int.add_zero] at e
  apply one_step
  rw [transition_at ops layout geometry t program (corrected t s)
    (.base (.base (.addSigned32 3 1 (.reg 2)))) (by rfl) (by rfl)]
  exact e

theorem pair_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (adjusted t s) (paired t s) := by
  have hb : signed32 (t : Int) := by unfold signed32; omega
  have e := LarkPtxMatrix.signed_right_step ops layout geometry t 4 3 1
    (t : Int) (adjusted t s) (by rfl) hb
  have hp : (2 : Int)^min 1 32 = 2 := by decide
  have he : (t : Int)/2 = ((t/2 : Nat) : Int) := by omega
  rw [hp, he] at e
  apply one_step
  rw [transition_at ops layout geometry t program (adjusted t s)
    (.base (.shiftRightSigned32 4 3 1)) (by rfl) (by rfl), base_step]
  exact e

theorem mask_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (paired t s) (masked t s) := by
  have hb : unsigned32 (t : Int) ∧ signed32 (-2) := by unfold unsigned32 signed32; omega
  have e := LarkPtxMatrix.and_step ops layout geometry t 5 3 (.imm (-2))
    (t : Int) (-2) (paired t s) (by rfl) (by rfl) hb
  have htbits : LarkPtxMatrix.bits32 (t : Int) = t := by
    unfold LarkPtxMatrix.bits32
    have he : (t : Int) % 4294967296 = (t : Int) := by omega
    rw [he]; simp
  rw [htbits, bits32_negative2, clear_low1 t (by omega)] at e
  apply one_step
  rw [transition_at ops layout geometry t program (paired t s)
    (.base (.andBits32 5 3 (.imm (-2)))) (by rfl) (by rfl), base_step]
  exact e

theorem globalX_execute (ops : Ops α) (t : Nat) (s : State α) :
    Steps ops layout geometry t program (masked t s) (globalX t s) :=
  .next (by rfl) (.refl _)

theorem wideX_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (globalX t s) (wideX t s) := by
  have htdiv : t/2 < 16384 := by omega
  have hb : signed32 ((t/2*2 : Nat) : Int) ∧ signed32 2 ∧
      signed64 (((t/2*2 : Nat) : Int)*2) := by
    unfold signed32 signed64; simp only [Int.natCast_mul]; omega
  have e := wide_step ops layout geometry t 10 5 2 ((t/2*2 : Nat) : Int)
    (globalX t s) (by rfl) hb
  have he : (((t/2*2 : Nat) : Int)*2) = ((t/2*4 : Nat) : Int) := by
    simp only [Int.natCast_mul]; omega
  rw [he] at e
  apply one_step
  rw [transition_at ops layout geometry t program (globalX t s)
    (.base (.base (.mulWideSigned32 10 5 2))) (by rfl) (by rfl)]
  exact e

theorem xPointer_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (wideX t s) (xPointer t s) := by
  have htdiv : t/2 < 16384 := by omega
  have hb : signed64 ((t/2*4 : Nat) : Int) ∧ signed64 (0+((t/2*4 : Nat) : Int)) := by
    unfold signed64; simp only [Int.natCast_mul]; omega
  have e := pointer_add_step ops layout geometry t 11 9 (.reg 10) ⟨0, 0, true⟩
    ((t/2*4 : Nat) : Int) (wideX t s) (by rfl) (by rfl) hb
  simp only [Int.zero_add] at e
  apply one_step
  rw [transition_at ops layout geometry t program (wideX t s)
    (.base (.base (.addSigned64 11 9 (.reg 10)))) (by rfl) (by rfl)]
  exact e

theorem coordinates_execute (ops : Ops α) (t : Nat) (s : State α) (ht : t < 32768) :
    Steps ops layout geometry t program (start s) (xPointer t s) := by
  apply steps_trans _ _ _ _ _ _ _ _ (parameters_execute ops t s)
  apply steps_trans _ _ _ _ _ _ _ _ (index_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (correction_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (adjustment_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (pair_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (mask_execute ops t s ht)
  apply steps_trans _ _ _ _ _ _ _ _ (globalX_execute ops t s)
  exact steps_trans _ _ _ _ _ _ _ _ (wideX_execute ops t s ht) (xPointer_execute ops t s ht)

theorem xPointer_pc (t : Nat) (s : State α) : (xPointer t s).pc = 13 := rfl
theorem xPointer_base (t : Nat) (s : State α) : (xPointer t s).registers.base = s := rfl

#print axioms bits32_negative2
#print axioms clear_low1
#print axioms parameters_execute
#print axioms index_execute
#print axioms correction_execute
#print axioms adjustment_execute
#print axioms pair_execute
#print axioms mask_execute
#print axioms globalX_execute
#print axioms wideX_execute
#print axioms xPointer_execute
#print axioms coordinates_execute
#print axioms xPointer_pc
#print axioms xPointer_base

end Kernel
end LarkPtxRotary
