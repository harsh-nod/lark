"""Retain each bounded RoPE development check against exact previously built imports."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path('/tmp/lark-ptx-rotary-refinement-20261113')
BASE = Path('/tmp/lark-ptx-rotary-instructions-v1-20261113')
sys.path.insert(0, str(ROOT))
from lark_kernels import ptx_matrix_certificate as common  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--module', default='PtxRotaryKernel')
    args = parser.parse_args()
    assert re.fullmatch('[a-z0-9-]+', args.attempt)
    assert re.fullmatch('PtxRotary[A-Za-z]*', args.module)
    out = Path('/tmp/lark-ptx-rotary-development-' + args.attempt + '-20261113')
    assert not out.exists(), 'Inspect the same attempt/PID instead of repeating it'
    base_report = common.read(BASE / 'results.json')
    assert base_report['status'] == 'fresh-instruction-library-and-all-axiom-audits-passed'
    common.check_inventory(BASE)
    lean, version = common.toolchain('/tmp/lean-4.19.0-linux/bin/lean')
    assert common.sha(lean.read_bytes()) == base_report['lean_binary_sha256']
    sources = {name: (ROOT / 'lean/Lark' / (name + '.lean')).read_bytes()
               for name in (*common.MODULES, 'PtxRotary', args.module)}
    for name in (*common.MODULES, 'PtxRotary'):
        assert sources[name] == (BASE / 'modules/Lark' / (name + '.lean')).read_bytes()
    out.mkdir()
    (out / 'driver.py').write_bytes(Path(__file__).read_bytes())
    modules = out / 'modules'
    (modules / 'Lark').mkdir(parents=True)
    bindings = {}
    for name, source in sources.items():
        (modules / 'Lark' / (name + '.lean')).write_bytes(source)
        binding = {'source_sha256': common.sha(source), 'freshly_built_in_this_attempt': name == args.module}
        if name != args.module:
            compiled = BASE / 'modules/Lark' / (name + '.olean')
            shutil.copyfile(compiled, modules / 'Lark' / compiled.name)
            binding['compiled_sha256'] = common.sha(compiled.read_bytes())
        bindings[name] = binding
    common.write(out / 'import-bindings.json', bindings)
    report = {'schema': 1, 'status': 'bounded-development-module-check-in-progress', 'pid': os.getpid(),
              'started_at_utc': datetime.now(timezone.utc).isoformat(), 'module': args.module,
              'HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'module_source_uncommitted': True, 'limits': common.LIMITS,
              'lean_version': version, 'lean_binary_sha256': common.sha(lean.read_bytes()),
              'module_source_sha256': common.sha(sources[args.module]),
              'six_hash_matched_cached_development_imports': True,
              'fresh_source_only_SDK_validation': False, 'new_kernel_proofs': 0,
              'GPU_trials': 0, 'model_calls': 0, 'original_paper_fully_reproduced': False}
    common.write(out / 'results.json', report)
    print(json.dumps({'pid': os.getpid(), 'attempt': args.attempt, 'module': args.module}), flush=True)
    environment = dict(os.environ, LEAN_PATH=str(modules))
    row, log = common.run_lean(lean, ['-o', 'Lark/' + args.module + '.olean',
                                    'Lark/' + args.module + '.lean'], modules, environment,
                               out / 'check.log', 180)
    report['check'] = row
    accepted = row['exit_code'] == 0 and not row['timed_out']
    if accepted:
        tags = re.findall(r'^#print axioms (\S+)', sources[args.module].decode(), re.M)
        tags = [tag if tag.startswith('LarkPtxRotary.') else 'LarkPtxRotary.Kernel.' + tag for tag in tags]
        report['axiom_audits'] = common.common.audits(log, tags)
    report['status'] = 'bounded-development-module-typecheck-passed' if accepted else 'bounded-development-module-typecheck-failed'
    common.write(out / 'results.json', report)
    common.manifest(out)
    print(json.dumps({'status': report['status'], 'seconds': row['seconds'],
                      'exit_code': row['exit_code'], 'timed_out': row['timed_out'],
                      'audits': len(report.get('axiom_audits', {})), 'new_kernel_proofs': 0}), flush=True)
    if not accepted:
        lines = log.splitlines()
        errors = [i for i, line in enumerate(lines) if ': error:' in line]
        for i in errors[:4]:
            print('\n'.join(lines[i:i+25]), flush=True)
        print(json.dumps({'full_failure_log': str(out / 'check.log'), 'error_headers': len(errors)}), flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
