import hashlib,json,os,shutil,sys
from pathlib import Path
from lark_kernels import ptx_matrix_certificate as checker
from lark_kernels import ptx_pointwise_certificate as legacy,ptx_pointwise
from lark_kernels import ptx_dot_certificate as old_dot,ptx_dot
from lark_kernels.ir import Refusal
root=Path('/tmp/lark-ptx-matrix-refinement-20261113')
module=Path(checker.__file__).resolve()
assert str(module).startswith('/tmp/lark-ptx-matrix-wheel-installed-v2-20261113/') and not module.is_relative_to(root)
assert not any(str(root) in str(p) for p in sys.path)
assert shutil.which('git') is None
expected=checker.read(Path('/tmp/lark-ptx-matrix-source-export-v2-20261113/source-bindings.json'))
assert {n:checker.sha(v)for n,v in checker.own_sources().items()}==expected
prior=Path('/tmp/lark-ptx-pointwise-source-export-v1-20261113')
assert {n:checker.sha(v)for n,v in legacy.own_sources().items()}==checker.read(prior/'source-bindings.json')
old_inputs=[(prior/n).read_text()for n in legacy.INPUTS]
assert ptx_pointwise.render(*ptx_pointwise.prepare(*old_inputs)).encode()==(prior/'Main.lean').read_bytes()
prior_dot=Path('/tmp/lark-ptx-dot-source-export-v1-20261113')
old_bindings=checker.read(prior_dot/'source-bindings.json')
current_dot={n:checker.sha(v)for n,v in old_dot.own_sources().items()}
assert len(old_bindings)==52 and len(current_dot)==54
assert all(current_dot.get(n)==digest for n,digest in old_bindings.items())
assert set(current_dot)-set(old_bindings)=={'python/ptx_matrix.py','python/ptx_matrix_certificate.py'}
assert ptx_dot.render(*ptx_dot.prepare(*[(prior_dot/n).read_text()for n in old_dot.INPUTS])).encode()==(prior_dot/'Main.lean').read_bytes()
rejected=Path.cwd()/'refused-legacy-GEMV-recording'
try:
 old_dot.check_export(prior_dot,rejected,'/tmp/lean-4.19.0-linux/bin/lean')
except Refusal as error:
 assert 'Exact export file roster differs' in str(error),str(error)
 assert not rejected.exists()
else:
 raise AssertionError('Frozen0.1GEMV must require its exact SDK roster')
frozen_wheel=Path('/tmp/lark-ptx-dot-wheel-v1-20261113/lark_kernels-0.1.0-py3-none-any.whl')
assert checker.sha(frozen_wheel.read_bytes())=='084fad0a195d446b2fb6436bd5d683ca9a82f5ac3aba32ed087674fb2b338aa4'
print(json.dumps({'installed_module':str(module),'checkout_imported':False,'isolated_mode':bool(sys.flags.isolated),
 'git_on_PATH':False,'all_owned_source_bindings_match':True,'legacy_ReLU_owned_source_bindings_match':True,
 'legacy_ReLU_Main_regenerated_identically':True,'legacy_GEMV_52_source_bindings_unchanged':True,
 'legacy_GEMV_Main_regenerated_identically':True,'legacy_GEMV_new_source_roster_refused_before_output':True,
 'legacy_GEMV_frozen_0_1_wheel_hash_unchanged':True,'cwd':os.getcwd()}))
