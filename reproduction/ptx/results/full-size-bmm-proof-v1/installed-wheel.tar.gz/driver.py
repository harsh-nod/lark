"""Check the BMM wheel offline and isolated, including strict legacy source pins."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/tmp/lark-ptx-batched-refinement-20261113')
OUT = Path('/tmp/lark-ptx-batched-wheel-validation-v1-20261113')
ENV = Path('/tmp/lark-ptx-batched-wheel-installed-v1-20261113')
WHEEL = Path('/tmp/lark-ptx-batched-wheel-v1-20261113/lark_kernels-0.3.0-py3-none-any.whl')


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, command, environment, timeout=None):
    with (OUT / (name + '.stdout')).open('w') as stdout, (OUT / (name + '.stderr')).open('w') as stderr:
        child = subprocess.Popen(command, cwd=OUT, env=environment, stdout=stdout, stderr=stderr)
        write('progress.json', {'observer_pid': os.getpid(), 'child_pid': child.pid,
              'stage': name, 'command': command, 'at_utc': datetime.now(timezone.utc).isoformat()})
        code = child.wait(timeout=timeout)
    write(name + '.json', {'exit_code': code, 'command': command})
    assert code == 0, name + ' failed; inspect original logs and child before any next action'


def main():
    assert not OUT.exists() and not ENV.exists()
    assert not any((p / '.git').exists() for p in (OUT, *OUT.parents))
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    assert hashlib.sha256(WHEEL.read_bytes()).hexdigest() == '456d0e3f8f2a24c1cb978d0ee6f5455d918387a417f03c39256299106ea10173'
    environment = dict(os.environ, PATH='/nonexistent', PYTHONNOUSERSITE='1',
                       PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_CONFIG_FILE='/dev/null')
    environment.pop('PYTHONPATH', None)
    environment.pop('LEAN_PATH', None)
    run('venv', ['/usr/bin/python3', '-I', '-m', 'venv', str(ENV)], environment, 120)
    python = str(ENV / 'bin/python')
    run('install', [python, '-I', '-m', 'pip', 'install', '--no-index', '--no-deps', str(WHEEL)], environment, 120)
    probe = '''import json,os,shutil,sys
from pathlib import Path
from lark_kernels import ptx_batched_certificate as checker
from lark_kernels import ptx_pointwise_certificate as legacy,ptx_pointwise
from lark_kernels import ptx_dot_certificate as old_dot,ptx_dot
from lark_kernels import ptx_matrix_certificate as old_matrix,ptx_matrix
from lark_kernels.ir import Refusal
root=Path('/tmp/lark-ptx-batched-refinement-20261113')
module=Path(checker.__file__).resolve()
assert str(module).startswith('/tmp/lark-ptx-batched-wheel-installed-v1-20261113/') and not module.is_relative_to(root)
assert not any(str(root) in str(p) for p in sys.path)
assert bool(sys.flags.isolated) and shutil.which('git') is None
expected=checker.read(Path('/tmp/lark-ptx-batched-source-export-v3-20261113/source-bindings.json'))
current={n:checker.sha(v)for n,v in checker.own_sources().items()}
assert current==expected and len(current)==60
prior=Path('/tmp/lark-ptx-pointwise-source-export-v1-20261113')
assert {n:checker.sha(v)for n,v in legacy.own_sources().items()}==checker.read(prior/'source-bindings.json')
assert ptx_pointwise.render(*ptx_pointwise.prepare(*[(prior/n).read_text()for n in legacy.INPUTS])).encode()==(prior/'Main.lean').read_bytes()
def prior_profile(check,reader,recording,old_count,current_count,extra):
 old=checker.read(recording/'source-bindings.json')
 now={n:checker.sha(v)for n,v in check.own_sources().items()}
 assert len(old)==old_count and len(now)==current_count
 assert all(now.get(n)==digest for n,digest in old.items())
 assert set(now)-set(old)==extra
 assert reader.render(*reader.prepare_certificate(*[(recording/n).read_text()for n in check.INPUTS])).encode()==(recording/'Main.lean').read_bytes()
 destination=Path.cwd()/('refused-'+str(old_count)+'-source-profile')
 try:check.check_export(recording,destination,'/tmp/lean-4.19.0-linux/bin/lean')
 except Refusal as error:
  assert 'Exact export file roster differs' in str(error),str(error)
  assert not destination.exists()
 else:raise AssertionError('Earlier profile must require its exact frozen SDK roster')
prior_dot=Path('/tmp/lark-ptx-dot-source-export-v1-20261113')
# GEMV has prepare rather than prepare_certificate.
class DotReader:
 prepare_certificate=staticmethod(ptx_dot.prepare)
 render=staticmethod(ptx_dot.render)
prior_profile(old_dot,DotReader,prior_dot,52,56,{'python/ptx_matrix.py','python/ptx_matrix_certificate.py','python/ptx_batched.py','python/ptx_batched_certificate.py'})
prior_matrix=Path('/tmp/lark-ptx-matrix-source-export-v2-20261113')
prior_profile(old_matrix,ptx_matrix,prior_matrix,55,57,{'python/ptx_batched.py','python/ptx_batched_certificate.py'})
initial=Path('/tmp/lark-ptx-batched-source-export-v1-20261113')
initial_bindings=checker.read(initial/'source-bindings.json')
assert set(initial_bindings)==set(current)
assert {n for n in current if current[n]!=initial_bindings[n]}=={'python/ptx_batched.py'}
destination=Path.cwd()/'refused-initial-BMM-renderer-recording'
try:checker.check_export(initial,destination,'/tmp/lean-4.19.0-linux/bin/lean')
except Refusal as error:
 assert 'Current trusted SDK/library differs from captured source' in str(error),str(error)
 assert not destination.exists()
else:raise AssertionError('Earlier renderer must retain its exact source pins')
assert checker.sha(Path('/tmp/lark-ptx-dot-wheel-v1-20261113/lark_kernels-0.1.0-py3-none-any.whl').read_bytes())=='084fad0a195d446b2fb6436bd5d683ca9a82f5ac3aba32ed087674fb2b338aa4'
assert checker.sha(Path('/tmp/lark-ptx-matrix-wheel-v1-20261113/lark_kernels-0.2.0-py3-none-any.whl').read_bytes())=='c34f21d56e780f3fd715c18ab41723ad26ff72d228f8cb4e9337dc92d17f79b2'
print(json.dumps({'installed_module':str(module),'checkout_imported':False,'isolated_mode':bool(sys.flags.isolated),
 'git_on_PATH':False,'all60_owned_source_bindings_match':True,'legacy_ReLU_source_and_Main_unchanged':True,
 'legacy_GEMV52_source_bytes_and_Main_unchanged':True,'legacy_GEMM55_source_bytes_and_Main_unchanged':True,
 'legacy_GEMV_and_GEMM_enlarged_rosters_refused_before_output':True,
 'initial_BMM_renderer_source_change_refused_before_output':True,
 'frozen_0_1_and_0_2_wheel_hashes_unchanged':True,'cwd':os.getcwd()}))
'''
    (OUT / 'probe.py').write_text(probe)
    run('probe', [python, '-I', str(OUT / 'probe.py')], environment, 120)
    start = time.monotonic()
    run('replay', [python, '-I', '-m', 'lark_kernels.ptx_batched_certificate', 'replay',
                  '--recording', '/tmp/lark-ptx-batched-source-export-v3-20261113',
                  '--output', str(OUT / 'source-only-replay'),
                  '--lean', '/tmp/lean-4.19.0-linux/bin/lean'], environment)
    result = json.loads((OUT / 'source-only-replay/replay.json').read_text())
    assert result['status'] == 'fresh-source-only-PTX-BMM-proof-replay-passed'
    assert result['owned_modules_freshly_compiled'] == 8 and result['old_owned_olean_cache_used'] is False
    probe_result = json.loads((OUT / 'probe.stdout').read_text())
    report = {'schema': 1, 'status': 'installed-wheel-source-only-PTX-BMM-replay-passed',
              'exit_code': 0, 'seconds': time.monotonic() - start,
              'wheel_sha256': hashlib.sha256(WHEEL.read_bytes()).hexdigest(), 'wheel_bytes': WHEEL.stat().st_size,
              **probe_result, 'network_during_install_and_replay': False,
              'owned_modules_freshly_compiled': 8, 'source_bound_proofs_added': 0,
              'model_calls': 0, 'gpu_trials': 0, 'nvidia_execution': False,
              'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False}
    write('results.json', report)
    write('manifest.json', {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(OUT.rglob('*')) if p.is_file() and p != OUT / 'manifest.json'})
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
