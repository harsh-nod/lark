import json,os,shutil,sys
from pathlib import Path
from lark_kernels import ptx_batched_certificate as checker
from lark_kernels import ptx_pointwise_certificate as legacy,ptx_pointwise
from lark_kernels import ptx_dot_certificate as old_dot,ptx_dot
from lark_kernels import ptx_matrix_certificate as old_matrix,ptx_matrix
from lark_kernels.ir import Refusal
root=Path('/tmp/lark-ptx-batched-refinement-20261113')
module=Path(checker.__file__).resolve()
assert str(module).startswith('/tmp/lark-ptx-batched-wheel-installed-v1-20261113/') and not module.is_relative_to(root)
assert not any(str(root) in str(p) for p in sys.path)
assert bool(sys.flags.isolated) and shutil.which('git') is None
expected=checker.read(Path('/tmp/lark-ptx-batched-source-export-v3-20261113/source-bindings.json'))
current={n:checker.sha(v)for n,v in checker.own_sources().items()}
assert current==expected and len(current)==60
prior=Path('/tmp/lark-ptx-pointwise-source-export-v1-20261113')
assert {n:checker.sha(v)for n,v in legacy.own_sources().items()}==checker.read(prior/'source-bindings.json')
assert ptx_pointwise.render(*ptx_pointwise.prepare(*[(prior/n).read_text()for n in legacy.INPUTS])).encode()==(prior/'Main.lean').read_bytes()
def prior_profile(check,reader,recording,old_count,current_count,extra):
 old=checker.read(recording/'source-bindings.json')
 now={n:checker.sha(v)for n,v in check.own_sources().items()}
 assert len(old)==old_count and len(now)==current_count
 assert all(now.get(n)==digest for n,digest in old.items())
 assert set(now)-set(old)==extra
 assert reader.render(*reader.prepare_certificate(*[(recording/n).read_text()for n in check.INPUTS])).encode()==(recording/'Main.lean').read_bytes()
 destination=Path.cwd()/('refused-'+str(old_count)+'-source-profile')
 try:check.check_export(recording,destination,'/tmp/lean-4.19.0-linux/bin/lean')
 except Refusal as error:
  assert 'Exact export file roster differs' in str(error),str(error)
  assert not destination.exists()
 else:raise AssertionError('Earlier profile must require its exact frozen SDK roster')
prior_dot=Path('/tmp/lark-ptx-dot-source-export-v1-20261113')
# GEMV has prepare rather than prepare_certificate.
class DotReader:
 prepare_certificate=staticmethod(ptx_dot.prepare)
 render=staticmethod(ptx_dot.render)
prior_profile(old_dot,DotReader,prior_dot,52,56,{'python/ptx_matrix.py','python/ptx_matrix_certificate.py','python/ptx_batched.py','python/ptx_batched_certificate.py'})
prior_matrix=Path('/tmp/lark-ptx-matrix-source-export-v2-20261113')
prior_profile(old_matrix,ptx_matrix,prior_matrix,55,57,{'python/ptx_batched.py','python/ptx_batched_certificate.py'})
initial=Path('/tmp/lark-ptx-batched-source-export-v1-20261113')
initial_bindings=checker.read(initial/'source-bindings.json')
assert set(initial_bindings)==set(current)
assert {n for n in current if current[n]!=initial_bindings[n]}=={'python/ptx_batched.py'}
destination=Path.cwd()/'refused-initial-BMM-renderer-recording'
try:checker.check_export(initial,destination,'/tmp/lean-4.19.0-linux/bin/lean')
except Refusal as error:
 assert 'Current trusted SDK/library differs from captured source' in str(error),str(error)
 assert not destination.exists()
else:raise AssertionError('Earlier renderer must retain its exact source pins')
assert checker.sha(Path('/tmp/lark-ptx-dot-wheel-v1-20261113/lark_kernels-0.1.0-py3-none-any.whl').read_bytes())=='084fad0a195d446b2fb6436bd5d683ca9a82f5ac3aba32ed087674fb2b338aa4'
assert checker.sha(Path('/tmp/lark-ptx-matrix-wheel-v1-20261113/lark_kernels-0.2.0-py3-none-any.whl').read_bytes())=='c34f21d56e780f3fd715c18ab41723ad26ff72d228f8cb4e9337dc92d17f79b2'
print(json.dumps({'installed_module':str(module),'checkout_imported':False,'isolated_mode':bool(sys.flags.isolated),
 'git_on_PATH':False,'all60_owned_source_bindings_match':True,'legacy_ReLU_source_and_Main_unchanged':True,
 'legacy_GEMV52_source_bytes_and_Main_unchanged':True,'legacy_GEMM55_source_bytes_and_Main_unchanged':True,
 'legacy_GEMV_and_GEMM_enlarged_rosters_refused_before_output':True,
 'initial_BMM_renderer_source_change_refused_before_output':True,
 'frozen_0_1_and_0_2_wheel_hashes_unchanged':True,'cwd':os.getcwd()}))
