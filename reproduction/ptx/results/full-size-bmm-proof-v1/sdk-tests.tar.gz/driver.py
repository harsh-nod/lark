"""Run the full BMM SDK proof/replay/adversarial integration test once."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/tmp/lark-ptx-batched-refinement-20261113')
OUT = Path('/tmp/lark-ptx-batched-sdk-tests-v1-20261113')


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert not OUT.exists()
    OUT.mkdir()
    (OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
    test_source = ROOT / 'tests/test_ptx_batched.py'
    test_sha = hashlib.sha256(test_source.read_bytes()).hexdigest()
    source_revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    command = ['/usr/bin/python3', '-m', 'unittest',
               'tests.test_ptx_batched.PtxBatchedProofTests', '-v']
    environment = dict(os.environ, LARK_LEAN='/tmp/lean-4.19.0-linux/bin/lean')
    started = time.monotonic()
    with (OUT / 'stdout.log').open('w') as stdout, (OUT / 'stderr.log').open('w') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stdout,
                                 stderr=stderr, start_new_session=True)
        write('progress.json', {'pid': os.getpid(), 'child_pid': child.pid,
              'process_group': child.pid, 'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'command': command, 'test_wrapper_seconds': 600,
              'per_Lean_seconds': 180, 'source_import_aggregate_seconds': 600})
        timed_out = False
        try:
            code = child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
    assert hashlib.sha256(test_source.read_bytes()).hexdigest() == test_sha
    report = {'status': 'BMM-SDK-complete-proof-replay-adversarial-test-passed'
              if code == 0 and not timed_out else 'BMM-SDK-integration-test-failed',
              'exit_code': code, 'timed_out': timed_out, 'seconds': time.monotonic() - started,
              'source_revision': source_revision, 'test_source_sha256': test_sha,
              'scope': 'Fresh eight-module source export, fresh matching source-only replay, '
                       'direct wrong-product Lean source-binding refusal and ten coherently '
                       'rehashed recording/roster/proof/axiom/claim refusals. Temporary unit-test '
                       'proof outputs are not retained positive Main recordings or new independent kernels.',
              'model_calls': 0, 'gpu_trials': 0, 'original_paper_fully_reproduced': False}
    write('results.json', report)
    write('manifest.json', {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'manifest.json'})
    print(json.dumps(report), flush=True)
    raise SystemExit(0 if code == 0 and not timed_out else 1)


if __name__ == '__main__':
    main()
