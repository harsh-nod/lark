import Lark.PtxBatchedBody
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkPtxBatchedCertificate
open LarkNonlinear
def program : List LarkPtxMatrix.Instruction := [(.base (.parameter (10) (0))), (.base (.parameter (11) (1))), (.base (.parameter (9) (2))), (.base (.toGlobal (18) (11))), (.base (.toGlobal (17) (10))), (.base (.blockId (1))), (.shiftRightSigned32 5 1 31), (.shiftRightUnsigned32 6 5 17), (.base (.addSigned32 (7) (1) (.reg (6)))), (.shiftRightSigned32 8 7 15), (.base (.shiftLeft32 (9) (8) (14))), (.shiftRightUnsigned32 10 5 23), (.base (.addSigned32 (11) (1) (.reg (10)))), (.shiftRightSigned32 12 11 9), (.shiftRightSigned32 13 11 31), (.shiftRightUnsigned32 14 13 26), (.base (.addSigned32 (15) (12) (.reg (14)))), (.andBits32 16 15 (.imm (16777152))), (.subSigned32 17 12 (.reg (16))), (.base (.shiftLeft32 (18) (17) (8))), (.andBits32 19 11 (.imm (-512))), (.subSigned32 20 1 (.reg (19))), (.base (.shiftLeft32 (21) (8) (17))), (.base (.addSigned32 (22) (20) (.reg (21)))), (.base (.addSigned32 (23) (9) (.reg (18)))), (.base (.mulWideSigned32 (3) (22) (2))), (.base (.mulWideSigned32 (4) (23) (2))), (.base (.literalFloat (68) (0) (1))), (.base (.literal32 (24) (0))), (.base (.addSigned64 (12) (17) (.reg (4)))), (.base (.loadHalf (1) (12) (0))), (.base (.fromHalf (4) (1))), (.base (.addSigned64 (13) (18) (.reg (3)))), (.base (.loadHalf (2) (13) (0))), (.base (.fromHalf (5) (2))), (.base (.binaryFloat (36) .add (4) (5))), (.base (.binaryFloat (37) .add (68) (36))), (.base (.loadHalf (3) (12) (2))), (.base (.fromHalf (6) (3))), (.base (.loadHalf (4) (13) (1024))), (.base (.fromHalf (7) (4))), (.base (.binaryFloat (38) .mul (6) (7))), (.base (.binaryFloat (39) .add (37) (38))), (.base (.loadHalf (5) (12) (4))), (.base (.fromHalf (8) (5))), (.base (.loadHalf (6) (13) (2048))), (.base (.fromHalf (9) (6))), (.base (.binaryFloat (40) .mul (8) (9))), (.base (.binaryFloat (41) .add (39) (40))), (.base (.loadHalf (7) (12) (6))), (.base (.fromHalf (10) (7))), (.base (.loadHalf (8) (13) (3072))), (.base (.fromHalf (11) (8))), (.base (.binaryFloat (42) .mul (10) (11))), (.base (.binaryFloat (43) .add (41) (42))), (.base (.loadHalf (9) (12) (8))), (.base (.fromHalf (12) (9))), (.base (.loadHalf (10) (13) (4096))), (.base (.fromHalf (13) (10))), (.base (.binaryFloat (44) .mul (12) (13))), (.base (.binaryFloat (45) .add (43) (44))), (.base (.loadHalf (11) (12) (10))), (.base (.fromHalf (14) (11))), (.base (.loadHalf (12) (13) (5120))), (.base (.fromHalf (15) (12))), (.base (.binaryFloat (46) .mul (14) (15))), (.base (.binaryFloat (47) .add (45) (46))), (.base (.loadHalf (13) (12) (12))), (.base (.fromHalf (16) (13))), (.base (.loadHalf (14) (13) (6144))), (.base (.fromHalf (17) (14))), (.base (.binaryFloat (48) .mul (16) (17))), (.base (.binaryFloat (49) .add (47) (48))), (.base (.loadHalf (15) (12) (14))), (.base (.fromHalf (18) (15))), (.base (.loadHalf (16) (13) (7168))), (.base (.fromHalf (19) (16))), (.base (.binaryFloat (50) .mul (18) (19))), (.base (.binaryFloat (51) .add (49) (50))), (.base (.loadHalf (17) (12) (16))), (.base (.fromHalf (20) (17))), (.base (.loadHalf (18) (13) (8192))), (.base (.fromHalf (21) (18))), (.base (.binaryFloat (52) .mul (20) (21))), (.base (.binaryFloat (53) .add (51) (52))), (.base (.loadHalf (19) (12) (18))), (.base (.fromHalf (22) (19))), (.base (.loadHalf (20) (13) (9216))), (.base (.fromHalf (23) (20))), (.base (.binaryFloat (54) .mul (22) (23))), (.base (.binaryFloat (55) .add (53) (54))), (.base (.loadHalf (21) (12) (20))), (.base (.fromHalf (24) (21))), (.base (.loadHalf (22) (13) (10240))), (.base (.fromHalf (25) (22))), (.base (.binaryFloat (56) .mul (24) (25))), (.base (.binaryFloat (57) .add (55) (56))), (.base (.loadHalf (23) (12) (22))), (.base (.fromHalf (26) (23))), (.base (.loadHalf (24) (13) (11264))), (.base (.fromHalf (27) (24))), (.base (.binaryFloat (58) .mul (26) (27))), (.base (.binaryFloat (59) .add (57) (58))), (.base (.loadHalf (25) (12) (24))), (.base (.fromHalf (28) (25))), (.base (.loadHalf (26) (13) (12288))), (.base (.fromHalf (29) (26))), (.base (.binaryFloat (60) .mul (28) (29))), (.base (.binaryFloat (61) .add (59) (60))), (.base (.loadHalf (27) (12) (26))), (.base (.fromHalf (30) (27))), (.base (.loadHalf (28) (13) (13312))), (.base (.fromHalf (31) (28))), (.base (.binaryFloat (62) .mul (30) (31))), (.base (.binaryFloat (63) .add (61) (62))), (.base (.loadHalf (29) (12) (28))), (.base (.fromHalf (32) (29))), (.base (.loadHalf (30) (13) (14336))), (.base (.fromHalf (33) (30))), (.base (.binaryFloat (64) .mul (32) (33))), (.base (.binaryFloat (65) .add (63) (64))), (.base (.loadHalf (31) (12) (30))), (.base (.fromHalf (34) (31))), (.base (.loadHalf (32) (13) (15360))), (.base (.fromHalf (35) (32))), (.base (.binaryFloat (66) .mul (34) (35))), (.base (.binaryFloat (68) .add (65) (66))), (.base (.addSigned64 (18) (18) (.imm (16384)))), (.base (.addSigned64 (17) (17) (.imm (32)))), (.base (.addSigned32 (24) (24) (.imm (16)))), (.base (.compareNeSigned32 (1) (24) (.imm (256)))), (.base (.branch (1) (29))), (.base (.toGlobal (14) (9))), (.base (.toHalf (33) (68))), (.base (.mulWideSigned32 (15) (1) (2))), (.base (.addSigned64 (16) (14) (.reg (15)))), (.base (.storeHalf (16) (0) (33))), (.base (.ret))]
def referenceBody : LarkPtxBatched.Bmm.Body.TensorReference := (.toHalf (.matmul (.fromHalf (.input 0)) (.fromHalf (.input 1))))
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkPtxBatched.Bmm.Body.referenceSpec ops input
theorem source_program : program = LarkPtxBatched.Bmm.program := by decide
theorem reference_body : referenceBody = LarkPtxBatched.Bmm.Body.referenceBody := by rfl
theorem reference_denotation (ops : Ops α) (input : Nat → Nat → α) :
    LarkPtxBatched.Bmm.Body.evaluateReference ops input referenceBody = some (spec ops input) := by
  rw [reference_body]
  exact LarkPtxBatched.Bmm.Body.evaluate_reference_body ops input
theorem kernel_eq_spec (ops : Ops α) :
    LarkPtxBatched.Bmm.Body.Correct ops program (spec ops) := by
  rw [source_program]
  exact LarkPtxBatched.Bmm.Body.kernel_correct ops
theorem launch (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    ∃ final, LarkPtxBatched.Bmm.Body.LaneSequence ops program 0 1048576
      (initial LarkPtxBatched.Bmm.layout input outside) final ∧
    raceFree LarkPtxBatched.Bmm.geometry final.trace = true ∧
    extract LarkPtxBatched.Bmm.layout final = some (spec ops input) ∧
    (∀ l, (∀ i, i < 1048576 → l ≠ LarkPtxBatched.Bmm.Body.outputCell i) →
      final.memory l = (initial LarkPtxBatched.Bmm.layout input outside).memory l) :=
  kernel_eq_spec ops input outside
theorem race_free (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    ∃ final, LarkPtxBatched.Bmm.Body.LaneSequence ops program 0 1048576
      (initial LarkPtxBatched.Bmm.layout input outside) final ∧
      raceFree LarkPtxBatched.Bmm.geometry final.trace = true := by
  obtain ⟨final, execution, race, values, preserved⟩ := launch ops input outside
  exact ⟨final, execution, race⟩
theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    ∃ final, LarkPtxBatched.Bmm.Body.LaneSequence ops program 0 1048576
      (initial LarkPtxBatched.Bmm.layout input outside) final ∧
      extract LarkPtxBatched.Bmm.layout final =
        LarkPtxBatched.Bmm.Body.evaluateReference ops input referenceBody := by
  obtain ⟨final, execution, race, values, preserved⟩ := launch ops input outside
  exact ⟨final, execution, values.trans (reference_denotation ops input).symm⟩
#print axioms LarkPtxBatchedCertificate.source_program
#print axioms LarkPtxBatchedCertificate.reference_body
#print axioms LarkPtxBatchedCertificate.launch
#print axioms LarkPtxBatchedCertificate.race_free
#print axioms LarkPtxBatchedCertificate.segment_equivalence
#print axioms LarkPtxBatchedCertificate.kernel_eq_spec
end LarkPtxBatchedCertificate
