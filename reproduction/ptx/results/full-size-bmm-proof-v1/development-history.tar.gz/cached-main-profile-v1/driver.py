"""Validate current generated Main against eight byte-checked cached owned modules."""
import json,os,time
from pathlib import Path
import sys
ROOT=Path('/tmp/lark-ptx-batched-refinement-20261113')
sys.path.insert(0,str(ROOT))
from lark_kernels import ptx_batched as reader,ptx_batched_certificate as checker
OUT=Path('/tmp/lark-ptx-batched-main-profile-v1-20261113')
CACHE=Path('/tmp/lark-ptx-batched-source-export-v2-20261113')
LEAN=Path('/tmp/lean-4.19.0-linux/bin/lean')
assert not OUT.exists()
checker.check_inventory(CACHE)
sources=checker.own_sources()
for name in checker.MODULES:
 assert (CACHE/'modules/Lark'/(name+'.lean')).read_bytes()==sources['lean/Lark/'+name+'.lean']
case=ROOT/'reproduction/ptx/full-size/bmm'
prepared=reader.prepare_certificate(*[(case/n).read_text()for n in ['kernel.ptx','reference.py','task.json']])
main=reader.render(*prepared)
OUT.mkdir();(OUT/'driver.py').write_bytes(Path(__file__).read_bytes());(OUT/'Main.lean').write_text(main)
checker.write(OUT/'trusted-source-bindings.json',{n:checker.sha(v)for n,v in sources.items()})
row,log=checker.run_lean(LEAN,['-Dprofiler=true','-Dprofiler.threshold=20','Main.lean'],OUT,dict(os.environ,LEAN_PATH=str(CACHE/'modules')),OUT/'Main.log')
checker.write(OUT/'check.json',row)
assert row['exit_code']==0 and not row['timed_out'],log
audits=checker.common.audits(log,['LarkPtxBatchedCertificate.'+n for n in reader.TAGS])
checker.write(OUT/'results.json',{'status':'current-generated-Main-standard-axioms-passed-cached-development-check',
 'check':row,'axiom_audits':audits,'verified_cached_owned_modules':8,'fresh_owned_module_builds':0,
 'old_owned_olean_cache_used':True,'accepted_source_only_certificate':False,'new_kernel_proofs':0,
 'model_calls':0,'gpu_trials':0,'original_paper_fully_reproduced':False})
checker.manifest(OUT)
print(json.dumps({'status':'current-generated-Main-cached-development-check-passed','seconds':row['seconds'],'audits':len(audits)}),flush=True)
