"""Check original-size BMM body addresses and actual six-instruction terms with seven source-verified cached imports."""
import json,os,re,shutil,time,sys
from pathlib import Path
ROOT=Path('/tmp/lark-ptx-batched-refinement-20261113')
sys.path.insert(0,str(ROOT))
from lark_kernels import ptx_matrix_certificate as common
OUT=Path('/tmp/lark-ptx-batched-kernel-correct-v2-20261113')
CACHE=Path('/tmp/lark-ptx-batched-init-PC29-v1-20261113')
ORIGINAL=Path('/tmp/lark-ptx-matrix-source-export-v2-20261113')
LEAN=Path('/tmp/lean-4.19.0-linux/bin/lean')

def main():
 assert not OUT.exists()
 lean,version=common.toolchain(LEAN)
 common.check_inventory(CACHE);common.check_inventory(ORIGINAL)
 trusted=common.own_sources()
 assert {n:common.sha(v)for n,v in trusted.items()}==common.read(ORIGINAL/'source-bindings.json')
 OUT.mkdir();(OUT/'driver.py').write_bytes(Path(__file__).read_bytes())
 modules=OUT/'modules';(modules/'Lark').mkdir(parents=True)
 for name in (*common.MODULES,'PtxBatched','PtxBatchedInit'):
  current=ROOT/'lean/Lark'/(name+'.lean')
  assert (CACHE/'modules/Lark'/(name+'.lean')).read_bytes()==current.read_bytes()
  for extension in ['lean','olean']:
   shutil.copyfile(CACHE/'modules/Lark'/(name+'.'+extension),modules/'Lark'/(name+'.'+extension))
 source=ROOT/'lean/Lark/PtxBatchedBody.lean'
 (modules/'Lark/PtxBatchedBody.lean').write_bytes(source.read_bytes())
 start=time.monotonic();environment=dict(os.environ,LEAN_PATH=str(modules))
 row,log=common.run_lean(lean,['-o','Lark/PtxBatchedBody.olean','Lark/PtxBatchedBody.lean'],modules,environment,OUT/'PtxBatchedBody.log')
 common.write(OUT/'module-check.json',row)
 assert row['exit_code']==0 and not row['timed_out'],log
 tags=re.findall(r'^#print axioms (\S+)',source.read_text(),re.M)
 audits=common.common.audits(log,tags)
 report={'schema':1,'status':'BMM-complete-actual1M-lane-kernel-reference-race-and-memory-theorem-checked-export-pending',
  'seconds':time.monotonic()-start,'module_check':row,'axiom_audits':audits,'Lean_version':version,
  'Lean_binary_sha256':common.sha(lean.read_bytes()),'module_sha256':common.sha(source.read_bytes()),
  'verified_owned_cached_imports_used':7,'fresh_owned_modules_built':1,'old_owned_olean_cache_used':True,
  'source_bound_kernel_proved':True,'source_bound_development_proofs':0,'model_calls':0,'gpu_trials':0,
  'new_registered_source_certificates':0,'original_paper_fully_reproduced':False,
  'scope':'Full-size batch-specific input addresses are proved valid. Every six-instruction source term for unrolled indices1..15 has actual Matrix.Steps, half loads/conversions, product and sum semantics. The complete fifteen-term tail composes actual Steps and invariant preservation from PC37 throughPC127 under input-state preconditions. The actual initial address/load/compute sequence PC29..36 is proved separately. All98actualbodyinstructions compose fromPC29throughPC127 with16orderedproductsandsums, bothbatch-specificaddresses and preserved inputmemory. An actualprologueReady-to-loopinitialinvariant bridge is proved. The actual five-instruction loopcontrol, branch-to29-or-exit132 and sixteen complete iterations are proved. All138actualinstructions throughret and all16iterations are composed for everytbelow1Moutputs withonlyoutputmemorychangedto thedeclaredorderedfold. The sourcevalue is proved equal to the ordered256term half-conversion/scalar-product/scalar-add reference with fullbatchaddresses. All1048576actualsource-lanescomposeusingexistentialStepswitnesses,withalloutputsequalorderedreferenceandallothermemorypreserved. No inventedexecutionsteps or summaryassumptions. Bothactualbodyread-eventsandtheactualepiloguewrite-eventpreservethecheckedTraceSafeinvariant;composedfullsource-lanewitnesshasthatproperty. The sameall1048576actual-lane launchwitnessalsohasTraceSafeandactualraceFree=true,alloutputsextractto theclosedbatchedmatmulreferenceASTandalloutside-outputmemoryispreserved. ThepureLeanlibrarytheorem iscomplete; officialsource-boundMain/export/replay,wheel/directcontrols/publication/CIarepending. Thiscacheddevelopmentcheckdoesnotconstituteanacceptedcertificate. Original32batch1Moutput task unchanged. Seven source-verified owned imports reused explicitly for development; final profile must cold-build all owned modules under180perprocess/600aggregate and2M/10000.'}
 common.write(OUT/'results.json',report);common.manifest(OUT)
 print(json.dumps({'status':report['status'],'seconds':report['seconds'],'audits':len(audits),'output':str(OUT)}),flush=True)

if __name__=='__main__':main()
