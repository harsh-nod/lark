import Lark.PtxPointwise
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkPtxCertificate
open LarkNonlinear
def elements : Nat := 16384
def program : List LarkPtxPointwise.Instruction := [.parameter 1 0, .parameter 2 1, .toGlobal 3 2, .toGlobal 4 1, .blockId 1, .mulWideS32 5 1 2, .addPointerS64 6 4 5, .loadHalf 1 6, .fromHalf 1 1, (.literal 3 (0) 1), (.binary 2 .max 1 3), .toHalf 2 2, .addPointerS64 7 3 5, .storeHalf 6 2, .ret]
def referenceBody : LarkPointwise.Scalar := (.bin .max .input (.lit (0) 1))
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkPointwise.spec ops referenceBody elements input
theorem source_program : program = LarkPtxPointwise.program := by rfl
theorem reference_body : referenceBody = LarkPtxPointwise.body := by rfl
theorem launch (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    LarkPtxPointwise.launch ops elements program input outside =
      some (LarkPtxPointwise.partialState ops elements input outside elements) := by
  rw [source_program]
  exact LarkPtxPointwise.launch_eq ops elements input outside (by dsimp [elements]; omega)
theorem race_free (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    raceFree (LarkPointwise.geometry elements 32)
      (LarkPtxPointwise.partialState ops elements input outside elements).trace = true := by
  exact LarkPtxPointwise.race_free ops elements input outside
theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    extract (LarkPointwise.layout elements)
      (LarkPtxPointwise.partialState ops elements input outside elements) = some (spec ops input) := by
  unfold spec
  rw [reference_body]
  exact LarkPtxPointwise.final_extract ops elements input outside
theorem kernel_eq_spec (ops : Ops α) :
    LarkPtxPointwise.Correct ops elements program (spec ops) := by
  intro input outside
  exact ⟨LarkPtxPointwise.partialState ops elements input outside elements,
    launch ops input outside, race_free ops input outside, segment_equivalence ops input outside⟩
#print axioms LarkPtxCertificate.source_program
#print axioms LarkPtxCertificate.reference_body
#print axioms LarkPtxCertificate.launch
#print axioms LarkPtxCertificate.race_free
#print axioms LarkPtxCertificate.segment_equivalence
#print axioms LarkPtxCertificate.kernel_eq_spec
end LarkPtxCertificate
