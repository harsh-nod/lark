"""Check both actual CPU compiler recordings; execute no captured code or GPU work."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

REPOSITORY = Path('/tmp/lark-full-shape-ptx-compile-20261113')
PREPARED = Path('/tmp/lark-full-shape-cuda-model-preflight-v1-20261113')
FIRST = Path('/tmp/lark-full-shape-ptx-compiled-v1-20261113')
RECORDING = Path('/tmp/lark-full-shape-ptx-compiled-v2-20261113')
OUTPUT = Path('/tmp/lark-full-shape-ptx-compiled-audit-v1-20261113')
sys.path.insert(0, str(REPOSITORY))
from reproduction.ptx import compile_full_shape as producer


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def inventory(root):
    values = read(root / 'manifest.json')
    require(set(values) == {str(p.relative_to(root)) for p in root.rglob('*')
                           if p.is_file() and p != root / 'manifest.json'},
            'Recording inventory differs')
    require(all(sha(root / name) == value for name, value in values.items()),
            'Changed recording file')
    return values


def audit():
    require(not OUTPUT.exists(), 'Fresh output required')
    first, current = inventory(FIRST), inventory(RECORDING)
    require(sha(PREPARED / 'manifest.json') == producer.frozen.CUDA_PREPARATION_SHA256,
            'Pinned CUDA preparation required')
    prepared = inventory(PREPARED)
    report = read(RECORDING / 'results.json')
    require(report['status'] == 'full-size-PTX-compiled-and-assembled-only', 'Wrong scope/status')
    for key in ('model_calls', 'lean_checks', 'gpu_trials', 'new_registered_source_certificates'):
        require(type(report[key]) is int and report[key] == 0, 'Experiment claim differs')
    require(report['original_paper_fully_reproduced'] is False
            and report['nvidia_execution'] is False, 'Original/hardware scope differs')
    require(report['preparation_manifest_sha256'] == producer.frozen.CUDA_PREPARATION_SHA256
            and report['preparation_source_manifest_sha256'] == sha(PREPARED/'source-manifest.json')
            and report['compiler_options'] == producer.OPTIONS
            and report['per_process_timeout_seconds'] == 180, 'Compiler protocol differs')
    for name, expected in report['driver_sources'].items():
        require(sha(RECORDING/'driver-sources'/name) == sha(REPOSITORY/name) == expected,
                'Archived source differs from actual producer/reader')
    require(report['driver_sha256'] == sha(REPOSITORY/'reproduction/ptx/compile_full_shape.py'),
            'Producer identity differs')
    require([row['case'] for row in report['cases']] == list(producer.frozen.TARGETS),
            'Full case roster differs')
    stages = []
    for case in report['cases']:
        base = RECORDING/'cases'/case['case']
        original = PREPARED/'cases'/case['case']/'request.json'
        require((base/'fixed-request.json').read_bytes() == original.read_bytes()
                and case['request_sha256'] == sha(original), 'Frozen request differs')
        request = read(original)
        require(case['source_bindings'] == {name: hashlib.sha256(text.encode()).hexdigest()
                                           for name, text in request['source_files'].items()},
                'Source bindings differ')
        for name, content in request['source_files'].items():
            require((base/'original'/Path(name).name).read_bytes() == content.encode(),
                    'Original fixture changed')
        require([s['source_path'] for s in case['stages']] == sorted(
            name for name in request['source_files'] if name.endswith('.cu')),
            'Stage roster differs')
        for stage in case['stages']:
            folder = base/Path(stage['source_path']).stem
            task = json.loads(request['source_files'][stage['task_path']])
            require(stage['task'] == task, 'Task shape/dtype/fuel/geometry changed')
            require((folder/'compile.cu').read_bytes() == b'#include <cuda_fp16.h>\n'
                    + request['source_files'][stage['source_path']].encode(),
                    'Compiler wrapper changed source')
            require(stage['compile_return_code'] == stage['assembly_return_code'] == 0,
                    'Compilation/assembly failure')
            ptx = (folder/'kernel.ptx').read_text()
            require(hashlib.sha256(ptx.encode()).hexdigest() == stage['ptx_sha256']
                    and len(ptx.encode()) == stage['ptx_bytes']
                    and re.findall(r'\.visible\s+\.entry\s+(\w+)\s*\(', ptx) == [task['entry']]
                    and '.version 8.8' in ptx and '.target sm_80' in ptx,
                    'Generated PTX binding differs')
            require((folder/'kernel.cubin').read_bytes().startswith(b'\x7fELF'),
                    'Missing assembled ELF image')
            probe = producer.reader_probe(ptx, task)
            require(probe == stage['reader_probe'] and probe['status'] == 'reader-refused'
                    and probe['formal_proof'] is False
                    and probe['certificate_profile_validated'] is False,
                    'Reader probe outcome/claim differs')
            prefix = str(folder.relative_to(RECORDING))
            for filename in ('kernel.ptx', 'kernel.cubin'):
                key = prefix+'/'+filename
                require(current[key] == first[key], 'Independent CPU builds produced different bytes')
            stages.append(stage)
    require(len(stages) == report['stages_count'] == report['compiled_stages']
            == report['assembled_stages'] == report['reader_refused_stages'] == 25
            and report['cases_count'] == 17, 'Reported totals differ')
    OUTPUT.mkdir()
    tests = subprocess.run([sys.executable, '-m', 'unittest',
                            'tests.test_full_shape_ptx_compile', '-v'],
                           cwd=REPOSITORY, capture_output=True, text=True, timeout=180)
    (OUTPUT/'unit-tests.stdout').write_text(tests.stdout)
    (OUTPUT/'unit-tests.stderr').write_text(tests.stderr)
    require(tests.returncode == 0 and 'Ran 3 tests' in tests.stderr, 'Compiler-boundary tests failed')
    counts = dict(Counter(s['reader_probe']['code'] for s in stages))
    result = {
        'schema': 1, 'status': 'full-size-PTX-compilation-recordings-checked',
        'driver_sha256': sha(Path(__file__)),
        'producer_commit': subprocess.check_output(['git','rev-parse','HEAD'],
                                                  cwd=REPOSITORY,text=True).strip(),
        'recording_manifest_sha256': sha(RECORDING/'manifest.json'),
        'first_recording_manifest_sha256': sha(FIRST/'manifest.json'),
        'preparation_manifest_sha256': sha(PREPARED/'manifest.json'),
        'recording_files': len(current)+1, 'first_recording_files': len(first)+1,
        'preparation_files': len(prepared)+1,
        'task_families': 17, 'source_stages': 25, 'compiled_stages': 25,
        'assembled_stages': 25, 'reader_refused_stages': 25,
        'regenerated_reader_probes': 25, 'reader_refusal_codes': counts,
        'PTX_and_cubin_pairs_identical_across_actual_builds': 25,
        'unchanged_requests_sources_references_tasks': True,
        'unit_tests_passed': 3, 'model_calls': 0, 'lean_checks': 0, 'gpu_trials': 0,
        'new_registered_source_certificates': 0, 'nvidia_execution': False,
        'original_paper_fully_reproduced': False,
        'scope': 'Recorded byte/inventory, task/source identity, assembler return codes, ELF '
                 'presence, regenerated reader refusals and actual CPU rebuild determinism. '
                 'No fresh compiler, Lean or GPU run by this auditor; no compiler-refinement '
                 'or PTX correctness theorem, hardware conformance or timing claim.',
    }
    (OUTPUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUTPUT/'driver.py').write_bytes(Path(__file__).read_bytes())
    (OUTPUT/'manifest.json').write_text(json.dumps({p.name:sha(p) for p in sorted(OUTPUT.iterdir())
                                                  if p.is_file()},indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    audit()
