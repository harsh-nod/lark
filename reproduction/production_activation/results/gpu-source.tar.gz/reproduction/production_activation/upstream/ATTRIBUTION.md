The unchanged `activation_kernels.cu` and `LICENSE` files are from
[vLLM](https://github.com/vllm-project/vllm) at commit
`83f5de466a889c29ac5fbfbe342d6fe4c09811e8` (Apache License 2.0).

The separate `cases/silu_and_mul/kernel.cu` is a modified, independently prepared
scalar specialization, with the changes and semantic departure recorded in
`../provenance.json`. It is not the original translation unit or the authors'
LARK registry file. The GPU comparison extracts the two helper bodies and scalar
loop from the archived public source, specializes the kernel header, removes the
unselected packed path and replaces the cache-load macro with ordinary loads.
No equivalence theorem for that source rewrite or general upstream program is
claimed; its numerical comparison is finite evidence.
