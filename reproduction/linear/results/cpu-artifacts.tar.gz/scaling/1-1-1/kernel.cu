extern "C" __global__ void induction_linear_hip_1_1_1(const __half* a, const __half* b, const __half* bias, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1) {
    acc = acc + __half2float(a[(i / 1) * 1 + j]) * __half2float(b[j * 1 + i % 1]);
    j++;
  }
  out[i] = __float2half(acc + __half2float(bias[i % 1]));
}
