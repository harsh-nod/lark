import SpecAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
audit_spec (([LarkSpecAudit.input 1 0 + 1] : List ℝ).map (fun x => 2*x)) from "Input.json" at 0
