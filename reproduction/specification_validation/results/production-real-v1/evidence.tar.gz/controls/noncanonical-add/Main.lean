import SpecAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
audit_spec (([@HAdd.hAdd ℝ ℝ ℝ ⟨fun a b => a*b⟩ (LarkSpecAudit.input 1 0) 2] : List ℝ)) from "Input.json" at 0
