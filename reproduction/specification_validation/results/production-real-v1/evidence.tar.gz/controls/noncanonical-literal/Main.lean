import SpecAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
audit_spec (([@OfNat.ofNat ℝ 1 ⟨(2:ℝ)⟩] : List ℝ)) from "Input.json" at 0
