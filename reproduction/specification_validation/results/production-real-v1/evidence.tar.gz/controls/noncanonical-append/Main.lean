import SpecAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
audit_spec ((@HAppend.hAppend (List ℝ) (List ℝ) (List ℝ) ⟨fun _ ys => ys⟩ [1] [2])) from "Input.json" at 0
