import SpecAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
audit_spec (([1,2] : List Nat)) from "Input.json" at 0
