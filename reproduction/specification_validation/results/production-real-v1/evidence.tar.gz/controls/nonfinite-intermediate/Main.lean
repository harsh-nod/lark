import SpecAudit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
audit_spec (([Real.exp 1000000] : List ℝ)) from "Input.json" at 0
