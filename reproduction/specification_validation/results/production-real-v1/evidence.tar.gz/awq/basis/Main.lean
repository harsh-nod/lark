import SpecAudit
import LarkReal.NativeAwqGemm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeAwqGemm.Shape := ⟨17,32,64,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide⟩
audit_spec (LarkReal.NativeAwqGemm.denseSpec shape LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkReal.NativeAwqGemm.denseSpec shape LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkReal.NativeAwqGemm.denseSpec shape LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkReal.NativeAwqGemm.denseSpec shape LarkSpecAudit.input) from "Input.json" at 544
audit_spec (LarkReal.NativeAwqGemm.denseSpec shape LarkSpecAudit.input) from "Input.json" at 1087
