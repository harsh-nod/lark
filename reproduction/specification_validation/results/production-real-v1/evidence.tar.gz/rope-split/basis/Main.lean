import SpecAudit
import Lark.NativeRopeCorrect
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeRope.Shape := ⟨1, by decide, by decide⟩
def neox : Bool := true
audit_spec (LarkNativeRope.spec shape neox LarkReal.ops LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkNativeRope.spec shape neox LarkReal.ops LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkNativeRope.spec shape neox LarkReal.ops LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkNativeRope.spec shape neox LarkReal.ops LarkSpecAudit.input) from "Input.json" at 2560
audit_spec (LarkNativeRope.spec shape neox LarkReal.ops LarkSpecAudit.input) from "Input.json" at 5119
