import SpecAudit
import LarkReal.NativeSglangRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeSglangRmsNorm.Shape := ⟨1, by decide, by decide⟩
audit_spec (LarkReal.NativeSglangRmsNorm.canonical_spec shape LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkReal.NativeSglangRmsNorm.canonical_spec shape LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkReal.NativeSglangRmsNorm.canonical_spec shape LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkReal.NativeSglangRmsNorm.canonical_spec shape LarkSpecAudit.input) from "Input.json" at 8192
audit_spec (LarkReal.NativeSglangRmsNorm.canonical_spec shape LarkSpecAudit.input) from "Input.json" at 16383
