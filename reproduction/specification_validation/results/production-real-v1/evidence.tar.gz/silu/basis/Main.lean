import SpecAudit
import LarkReal.Ops
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkSilu.Shape := {
  rows := 7, width := 65, block := 65, warp := 64,
  rowsPos := by decide, widthPos := by decide, blockPos := by decide,
  warpPos := by decide, blockLe := by decide, dataBound := by decide }
audit_spec (LarkReal.siluSpec shape LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkReal.siluSpec shape LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkReal.siluSpec shape LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkReal.siluSpec shape LarkSpecAudit.input) from "Input.json" at 227
audit_spec (LarkReal.siluSpec shape LarkSpecAudit.input) from "Input.json" at 454
