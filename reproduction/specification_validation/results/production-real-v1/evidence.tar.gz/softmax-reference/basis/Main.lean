import SpecAudit
import LarkReal.NativeSoftmaxCanonical
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeSoftmax.Shape := ⟨1,by decide,by decide⟩
audit_spec (LarkReal.NativeSoftmax.canonicalSpec shape LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkReal.NativeSoftmax.canonicalSpec shape LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkReal.NativeSoftmax.canonicalSpec shape LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkReal.NativeSoftmax.canonicalSpec shape LarkSpecAudit.input) from "Input.json" at 25128
audit_spec (LarkReal.NativeSoftmax.canonicalSpec shape LarkSpecAudit.input) from "Input.json" at 50256
