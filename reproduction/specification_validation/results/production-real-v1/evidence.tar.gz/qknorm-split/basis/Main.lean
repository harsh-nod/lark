import SpecAudit
import LarkReal.NativeQKNormRopeSplit
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeQKNormRope.Shape := ⟨1, by decide, by decide⟩
audit_spec (LarkReal.NativeQKNormRope.Split.denseSpec shape LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkReal.NativeQKNormRope.Split.denseSpec shape LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkReal.NativeQKNormRope.Split.denseSpec shape LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkReal.NativeQKNormRope.Split.denseSpec shape LarkSpecAudit.input) from "Input.json" at 2560
audit_spec (LarkReal.NativeQKNormRope.Split.denseSpec shape LarkSpecAudit.input) from "Input.json" at 5119
