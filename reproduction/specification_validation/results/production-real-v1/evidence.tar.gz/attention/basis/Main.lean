import SpecAudit
import LarkReal.NativeAttention
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeAttention.Shape := ⟨1,by decide,by decide⟩
audit_spec (LarkReal.NativeAttention.denseSpec shape LarkSpecAudit.input) from "Input.json" at 0
audit_spec (LarkReal.NativeAttention.denseSpec shape LarkSpecAudit.input) from "Input.json" at 1
audit_spec (LarkReal.NativeAttention.denseSpec shape LarkSpecAudit.input) from "Input.json" at 127
audit_spec (LarkReal.NativeAttention.denseSpec shape LarkSpecAudit.input) from "Input.json" at 16384
audit_spec (LarkReal.NativeAttention.denseSpec shape LarkSpecAudit.input) from "Input.json" at 32767
