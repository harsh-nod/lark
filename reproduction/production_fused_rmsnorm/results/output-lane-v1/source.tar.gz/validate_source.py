from pathlib import Path
import hashlib
from lark_kernels import collective, native_fused_rmsnorm as native
from lark_kernels.ir import lean_list
root = Path(__file__).resolve().parent
case = root / "native-source"
assert hashlib.sha256((case / "kernel.hip").read_bytes()).hexdigest() == "c297c1842c1a4d2d9be2265aa0d03da759dda22f555947e3483eccb486e5f59e"
contract = native.parse_task((case / "task.json").read_text())
native.check_reference((case / "reference.py").read_text())
translation = native.translate((case / "kernel.hip").read_text(), contract)
main = (root / "Main.lean").read_text()
body = main.split("def sourceProgram : List LarkCollective.Instr := [\n", 1)[1].split("\n]\n", 1)[0]
assert body == ",\n".join(collective.emit(i) for i in translation.program)
task = contract.task
assert f"def sourceShape : Shape := ⟨{task.grid}, by decide, by decide⟩" in main
globals_text = lean_list(f"⟨.{b.role}, {b.size}⟩" for b in task.buffers)
assert f"def sourceGlobal : List Buffer := {globals_text}" in main
assert f"def sourceShared : List Nat := {[n for _, n in translation.shared]}" in main
assert f"def sourceMutable : List Nat := {list(contract.inout)}" in main
assert f"def sourceFuel : Fuel := ⟨{','.join(map(str, task.fuel))}⟩" in main
assert f"def sourceGeometry : Geometry := ⟨{task.grid},{task.block},{task.warp}⟩" in main
print("Frozen source/reader/IR/interface/fuel binding replay passed.")
