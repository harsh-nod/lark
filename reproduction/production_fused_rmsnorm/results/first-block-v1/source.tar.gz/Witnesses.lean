import Lark.NativeFusedRmsNormBarrier
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def p : Shape := ⟨1, by decide, by decide⟩
def ops : Ops Nat := ⟨fun n d => n.toNat / d, (· + ·), (· - ·), (· * ·), Nat.max,
  (· / ·), id, id, id, id, fun x => x + 1000⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
def start : State Nat := initial p values (fun _ => none)
def once : State Nat := componentAfter ops values 0 0 0 0 0 0 start
def orderOps : Ops Nat := { ops with add := fun a b => a * 100 + b }
instance (t : Nat) (l : Location) : Decidable (PartialWrites t l) :=
  inferInstanceAs (Decidable ((t % 1024) % 32 = 0 ∧ l = partialCell t ((t % 1024) / 32)))
def marked : State Nat := { start with trace := [⟨0, globalCell 0 0, false, {}⟩] }
example : once.memory (globalCell 1 0) = some 1009 := by decide
example : once.memory (unroundedCell 0 0) = some 9 := by decide
example : once.memory (globalCell 1 1) = some 9 := by decide
example : once.regs 0 0 = some 81 := by decide
example : (prefixState ops values 0 start).pc 0 = 23 := by decide
example : xorPeer32 32 16 = 48 := by decide
example : xorPeer32 31 16 = 15 := by decide
example : PartialWrites 32 (partialCell 32 1) := by decide
example : (firstLastAfter ops 32 2 3 start).memory (partialCell 32 1) = some 5 := by decide
example : (firstLastAfter ops 32 2 3 start).memory (partialCell 0 0) = none := by decide
example : (addAfter orderOps 0 24 2 3 start).regs 0 0 = some 203 := by decide
example : (warpThreads (geometry p) 0 15).contains 1023 = true := by decide
example : (blockThreads (geometry p) 0).contains 1024 = false := by decide
example : PartialWrites 64 ⟨.shared,0,0,2⟩ := by decide
example : (resume (blockThreads (geometry p) 0) .block start).pc 1023 = 1 := by decide
example : (resume (blockThreads (geometry p) 0) .block start).pc 1024 = 0 := by decide
example : ((resume (blockThreads (geometry p) 0) .block start).epochs 1023).block = 1 := by decide
example : ((resume (blockThreads (geometry p) 0) .block start).epochs 1024).block = 0 := by decide
example : (resume (blockThreads (geometry p) 0) .block marked).trace.length = 1 := by decide
example : ((resume (blockThreads (geometry p) 0) .block marked).trace[0]?).map (fun a => a.epoch.block) = some 0 := by decide
