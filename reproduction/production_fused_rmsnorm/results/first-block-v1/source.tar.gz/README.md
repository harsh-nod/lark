Native fused add RMSNorm first block phase and barrier resume, PC36/epoch1.
Requires Python 3 and Lean 4.19.0; no Git, GPUs or models.
Replay the frozen reader: python3 validate_source.py
Rebuild from source: lake build
Positive concrete witnesses: lake env lean Witnesses.lean
Every other top-level .lean file except Main.lean is a control that must
fail with 'is false' at its assertion. No .lake objects are archived.
All inputs/operations/outside memory and valid lanes/rows1..255 are
quantified by the prefix theorem. This is not a full kernel certificate.
The second reduction, normalization, second barrier, halt/grid,
canonical-real/IEEE equivalence and original-paper results remain open.
