import Lark.NativeFusedRmsNormBarrier
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def sourceProgram : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.div (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (0) 1))),
(.scalar (.assign 1 (.lit (0) 1))),
(.scalar (.index 4 (.const (0)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (2))) 23)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 21)),
(.scalar (.index 6 (.add (.mul (.add (.mul (.ivar (4)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (5))))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (6))))),
(.scalar (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (7)))))),
(.scalar (.assign 3 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 2 (.bin .add (.reg (2)) (.reg (3))))),
(.scalar (.assign 4 (.bin .mul (.reg (2)) (.reg (2))))),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (4))))),
(.scalar (.store .global 1 (.ivar (7)) (.un .toHalf (.reg (2))))),
(.scalar (.store .shared 1 (.ivar (6)) (.reg (2)))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (1))))),
(.scalar (.jump 9)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (1))))),
(.scalar (.jump 7)),
(.shuffle .xor 1 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.scalar (.branch (.eq (.ivar (2)) (.const (0))) 35)),
(.scalar (.store .shared 0 (.ivar (3)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.lt (.ivar (1)) (.const (32))) 50)),
(.scalar (.assign 0 (.load .shared 0 (.ivar (1))))),
(.shuffle .xor 1 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 50)),
(.scalar (.store .shared 0 (.const (0)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.bin .div (.reg (5)) (.lit (16384) 1)))),
(.scalar (.assign 7 (.bin .add (.reg (6)) (.lit (1) 100000)))),
(.scalar (.assign 8 (.un .rsqrt (.reg (7))))),
(.scalar (.index 8 (.const (0)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (2))) 71)),
(.scalar (.index 9 (.const (0)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (8))) 69)),
(.scalar (.index 10 (.add (.mul (.add (.mul (.ivar (8)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (9))))),
(.scalar (.index 11 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (10))))),
(.scalar (.assign 9 (.load .shared 1 (.ivar (10))))),
(.scalar (.assign 10 (.un .fromHalf (.load .global 2 (.ivar (10)))))),
(.scalar (.assign 11 (.bin .add (.lit (0) 1) (.reg (10))))),
(.scalar (.assign 12 (.bin .mul (.reg (9)) (.reg (8))))),
(.scalar (.assign 13 (.bin .mul (.reg (12)) (.reg (11))))),
(.scalar (.store .global 0 (.ivar (11)) (.un .toHalf (.reg (13))))),
(.scalar (.index 9 (.add (.ivar (9)) (.const (1))))),
(.scalar (.jump 58)),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 56)),
(.scalar .halt)
]
def sourceShape : Shape := ⟨1, by decide, by decide⟩
def sourceGlobal : List Buffer := [⟨.output, 16384⟩, ⟨.output, 16384⟩, ⟨.input, 16384⟩]
def sourceShared : List Nat := [32, 16384]
def sourceMutable : List Nat := [0, 1]
def sourceFuel : Fuel := ⟨512,8,3,1⟩
def sourceGeometry : Geometry := ⟨1,1024,64⟩
theorem source_binding : sourceProgram = program ∧
    sourceGlobal = (layout sourceShape).global ∧ sourceShared = (layout sourceShape).shared ∧
    sourceMutable = mutableBuffers ∧ sourceFuel = fuel ∧ sourceGeometry = geometry sourceShape := by decide
theorem source_interface : LarkInOut.Valid (layout sourceShape) mutableBuffers := interface_valid sourceShape
theorem source_pre_satisfiable (input : Nat → Nat → α) :
    ∃ s, LarkInOut.StdPre (layout sourceShape) mutableBuffers input s :=
  LarkInOut.pre_satisfiable _ _ input
#print axioms source_binding
#print axioms source_interface
#print axioms source_pre_satisfiable

theorem source_prefix_all_shapes (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    LarkCollective.runLane ops (layout p) (geometry p) sourceProgram t sourceFuel.lane
      (initial p input outside) = some (prefixState ops input t (initial p input outside)) := by
  simpa only [source_binding.1, source_binding.2.2.2.2.1] using initial_prefix_run p ops input outside t ht
theorem source_prefix_values (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    (prefixState ops input t (initial p input outside)).regs t 0 =
      some (threadSum ops input (t / 1024) (t % 1024)) ∧
    Pending input (t / 1024) (t % 1024) 16 (prefixState ops input t (initial p input outside)) ∧
    Completed ops input (t / 1024) (t % 1024) t 16 (prefixState ops input t (initial p input outside)) :=
  initial_prefix_values p ops input outside t ht
theorem source_prefix_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    ∀ a ∈ (prefixState ops input t (initial p input outside)).trace, Good a :=
  initial_prefix_good p ops input outside t ht
theorem source_prefix_race_free (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    raceFree (geometry p) (prefixState ops input t (initial p input outside)).trace = true :=
  initial_prefix_race_free p ops input outside t ht
theorem source_prefix_access_count (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (prefixState ops input t (initial p input outside)).trace.length = 64 :=
  initial_prefix_trace_length p ops input outside t
#print axioms source_prefix_all_shapes
#print axioms source_prefix_values
#print axioms source_prefix_good
#print axioms source_prefix_race_free
#print axioms source_prefix_access_count

theorem source_first_wave_run (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row < p.rows) (hw : warp < 16) :
    LarkPartitionCollective.runWarp ops (layout p) (geometry p) sourceFuel sourceProgram
      (warpThreads (geometry p) row warp) sourceFuel.warp (initial p input outside) =
      some (firstWave p ops input row warp (initial p input outside)) := by
  simpa only [source_binding.1, source_binding.2.2.2.2.1] using
    first_wave_initial p ops input outside row warp hr hw
theorem source_first_wave_partials (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp half : Nat) (hw : warp < 16) (hh : half < 2) :
    (firstWave p ops input row warp (initial p input outside)).memory ⟨.shared,row,0,warp*2+half⟩ =
      some (waveValues ops input row warp 5 (half*32)) :=
  first_wave_partial p ops input row warp half _ hw hh
theorem source_first_wave_cells (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row < p.rows) (hw : warp < 16)
    (t : Nat) (ht : t ∈ cohortThreads row warp 64) :
    Pending input (t/1024) (t%1024) 16 (firstWave p ops input row warp (initial p input outside)) ∧
    Completed ops input (t/1024) (t%1024) t 16 (firstWave p ops input row warp (initial p input outside)) :=
  first_wave_cells p ops input row warp _ hr hw
    (initial_pending_lanes p input outside _ (cohort_bound p row warp 64 hr hw (by decide)))
    (by intro a ha; cases ha) t ht
theorem source_first_wave_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row < p.rows) (hw : warp < 16) :
    ∀ a ∈ (firstWave p ops input row warp (initial p input outside)).trace, Good a :=
  first_wave_initial_good p ops input outside row warp hr hw
theorem source_first_wave_race_free (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row warp : Nat) (hr : row < p.rows) (hw : warp < 16) :
    raceFree (geometry p) (firstWave p ops input row warp (initial p input outside)).trace = true :=
  first_wave_initial_race_free p ops input outside row warp hr hw
#print axioms source_first_wave_run
#print axioms source_first_wave_partials
#print axioms source_first_wave_cells
#print axioms source_first_wave_good
#print axioms source_first_wave_race_free

theorem source_first_block_run (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    (List.range 16).foldlM (fun s w => LarkPartitionCollective.runWarp ops (layout p) (geometry p)
      sourceFuel sourceProgram (warpThreads (geometry p) row w) sourceFuel.warp s)
      (initial p input outside) = some (firstBlock p ops input row (initial p input outside)) := by
  simpa only [source_binding.1, source_binding.2.2.2.2.1] using first_block_initial_run p ops input outside row hr
theorem source_first_block_values (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row col : Nat) (hr : row < p.rows) (hc : col < 16384) :
    (firstBlock p ops input row (initial p input outside)).memory (globalCell 1 (address row col)) =
      some (ops.toHalf (rowAdded ops input row col)) ∧
    (firstBlock p ops input row (initial p input outside)).memory ⟨.shared,row,1,col⟩ =
      some (rowAdded ops input row col) :=
  first_block_cells p ops input row col _ (initial_block_entry p input outside row hr) hc
theorem source_first_block_partials (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row k : Nat) (hk : k < 32) :
    (firstBlock p ops input row (initial p input outside)).memory ⟨.shared,row,0,k⟩ =
      some (blockPartial ops input row k) := first_block_partial p ops input row k _ hk
theorem source_first_block_participants (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row tid : Nat) (hr : row < p.rows) (ht : tid < 1024) :
    FirstDone ops input (row*1024+tid) (firstBlock p ops input row (initial p input outside)) :=
  first_block_member p ops input row tid _ (initial_block_entry p input outside row hr) ht
theorem source_first_block_cut (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    LarkCollective.converged sourceProgram (blockThreads (geometry p) row)
      (firstBlock p ops input row (initial p input outside)) = some .block := by
  simpa only [source_binding.1] using first_block_cut p ops input row _ (initial_block_entry p input outside row hr)
theorem source_first_barrier_resume (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    LarkPartitionCollective.runBlock ops (layout p) (geometry p) sourceFuel sourceProgram row sourceFuel.block
      (initial p input outside) =
    LarkPartitionCollective.runBlock ops (layout p) (geometry p) sourceFuel sourceProgram row 2
      (midState p ops input row (initial p input outside)) := by
  simpa only [source_binding.1, source_binding.2.2.2.2.1] using initial_first_barrier p ops input outside row hr
theorem source_first_barrier_state (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    MidReady p ops input row (midState p ops input row (initial p input outside)) :=
  initial_mid_ready p ops input outside row hr
theorem source_first_barrier_race_free (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (row : Nat) (hr : row < p.rows) :
    raceFree (geometry p) (midState p ops input row (initial p input outside)).trace = true :=
  initial_mid_race_free p ops input outside row hr
#print axioms source_first_block_run
#print axioms source_first_block_values
#print axioms source_first_block_partials
#print axioms source_first_block_participants
#print axioms source_first_block_cut
#print axioms source_first_barrier_resume
#print axioms source_first_barrier_state
#print axioms source_first_barrier_race_free
