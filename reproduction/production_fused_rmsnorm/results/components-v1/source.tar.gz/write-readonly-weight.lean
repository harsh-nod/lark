import Lark.NativeFusedRmsNormAddress
open LarkNonlinear LarkNativeFusedRmsNorm
def p : Shape := ⟨1, by decide, by decide⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
example : location (layout p) (geometry p) 0 .global 2 0 true = some ⟨.global,0,2,0⟩ := by decide
