import Lark.NativeFusedRmsNormAddress
open LarkNonlinear LarkNativeFusedRmsNorm
def p : Shape := ⟨1, by decide, by decide⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
example : (initial p values (fun _ => none)).memory ⟨.global,1,0,0⟩ = some 1 := by decide
