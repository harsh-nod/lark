Source/reader replay: python3 validate_source.py
Fresh build: lake build
Controls: lake env lean CONTROL.lean (each must fail)
In-out interface, source identity, address coverage and conditional footprints only.
No complete source certificate, actual-trace classification or IEEE theorem.
