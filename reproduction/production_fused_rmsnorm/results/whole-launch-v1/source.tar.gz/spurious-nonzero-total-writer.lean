import Lark.NativeFusedRmsNormCorrect
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def p : Shape := ⟨1, by decide, by decide⟩
def ops : Ops Nat := ⟨fun n d => n.toNat / d, (· + ·), (· - ·), (· * ·), Nat.max,
  (· / ·), id, id, id, id, fun x => x + 1000⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
def start : State Nat := initial p values (fun _ => none)
def once : State Nat := componentAfter ops values 0 0 0 0 0 0 start
def orderOps : Ops Nat := { ops with add := fun a b => a * 100 + b }
instance (t : Nat) (l : Location) : Decidable (PartialWrites t l) :=
  inferInstanceAs (Decidable ((t % 1024) % 32 = 0 ∧ l = partialCell t ((t % 1024) / 32)))
def marked : State Nat := { start with trace := [⟨0, globalCell 0 0, false, {}⟩] }
instance (t : Nat) (l : Location) : Decidable (TopWrites t l) :=
  inferInstanceAs (Decidable (t % 1024 = 0 ∧ l = topCell t))
def mixed : State Nat := { start with pc := fun t => if t < 32 then 38 else 50 }
def phaseOne : State Nat :=
  { start with
    pc := fun t => if t < 1024 then 50 else 0
    epochs := fun t => if t < 1024 then { block := 1 } else {}
    trace := [⟨0, partialSlot 0 0, true, { block := 1 }⟩, ⟨0, globalCell 0 0, false, {}⟩] }
def outOnce : State Nat := outputComponent ops values 0 0 0 0 0 3 start
def outDone : State Nat := outputLane ops values 0 0 0 32768 start
def biasOps : Ops Nat := { ops with add := fun a b => a + b + 7 }
def tiny : Layout := ⟨[⟨.output,1⟩,⟨.output,1⟩,⟨.input,1⟩],[],[]⟩
def seeded : State Nat := LarkInOut.initial tiny [0,1] values (fun _ => none)
def ordinary : State Nat := LarkNonlinear.initial tiny values (fun _ => none)
instance (row : Nat) (l : Location) : Decidable (RowWrites row l) :=
  inferInstanceAs (Decidable ((l.space = .global ∧ l.owner = 0 ∧ (l.buffer = 0 ∨ l.buffer = 1) ∧ l.offset / 16384 = row) ∨ (l.space = .shared ∧ l.owner = row)))
example : (topAfter 1 1 7 start).memory (topCell 1) = some 7 := by decide
