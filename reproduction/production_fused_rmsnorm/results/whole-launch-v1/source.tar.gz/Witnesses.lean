import Lark.NativeFusedRmsNormCorrect
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def p : Shape := ⟨1, by decide, by decide⟩
def ops : Ops Nat := ⟨fun n d => n.toNat / d, (· + ·), (· - ·), (· * ·), Nat.max,
  (· / ·), id, id, id, id, fun x => x + 1000⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
def start : State Nat := initial p values (fun _ => none)
def once : State Nat := componentAfter ops values 0 0 0 0 0 0 start
def orderOps : Ops Nat := { ops with add := fun a b => a * 100 + b }
instance (t : Nat) (l : Location) : Decidable (PartialWrites t l) :=
  inferInstanceAs (Decidable ((t % 1024) % 32 = 0 ∧ l = partialCell t ((t % 1024) / 32)))
def marked : State Nat := { start with trace := [⟨0, globalCell 0 0, false, {}⟩] }
instance (t : Nat) (l : Location) : Decidable (TopWrites t l) :=
  inferInstanceAs (Decidable (t % 1024 = 0 ∧ l = topCell t))
def mixed : State Nat := { start with pc := fun t => if t < 32 then 38 else 50 }
def phaseOne : State Nat :=
  { start with
    pc := fun t => if t < 1024 then 50 else 0
    epochs := fun t => if t < 1024 then { block := 1 } else {}
    trace := [⟨0, partialSlot 0 0, true, { block := 1 }⟩, ⟨0, globalCell 0 0, false, {}⟩] }
def outOnce : State Nat := outputComponent ops values 0 0 0 0 0 3 start
def outDone : State Nat := outputLane ops values 0 0 0 32768 start
def biasOps : Ops Nat := { ops with add := fun a b => a + b + 7 }
def tiny : Layout := ⟨[⟨.output,1⟩,⟨.output,1⟩,⟨.input,1⟩],[],[]⟩
def seeded : State Nat := LarkInOut.initial tiny [0,1] values (fun _ => none)
def ordinary : State Nat := LarkNonlinear.initial tiny values (fun _ => none)
instance (row : Nat) (l : Location) : Decidable (RowWrites row l) :=
  inferInstanceAs (Decidable ((l.space = .global ∧ l.owner = 0 ∧ (l.buffer = 0 ∨ l.buffer = 1) ∧ l.offset / 16384 = row) ∨ (l.space = .shared ∧ l.owner = row)))
example : once.memory (globalCell 1 0) = some 1009 := by decide
example : once.memory (unroundedCell 0 0) = some 9 := by decide
example : once.memory (globalCell 1 1) = some 9 := by decide
example : once.regs 0 0 = some 81 := by decide
example : (prefixState ops values 0 start).pc 0 = 23 := by decide
example : xorPeer32 32 16 = 48 := by decide
example : xorPeer32 31 16 = 15 := by decide
example : PartialWrites 32 (partialCell 32 1) := by decide
example : (firstLastAfter ops 32 2 3 start).memory (partialCell 32 1) = some 5 := by decide
example : (firstLastAfter ops 32 2 3 start).memory (partialCell 0 0) = none := by decide
example : (addAfter orderOps 0 24 2 3 start).regs 0 0 = some 203 := by decide
example : (warpThreads (geometry p) 0 15).contains 1023 = true := by decide
example : (blockThreads (geometry p) 0).contains 1024 = false := by decide
example : PartialWrites 64 ⟨.shared,0,0,2⟩ := by decide
example : (resume (blockThreads (geometry p) 0) .block start).pc 1023 = 1 := by decide
example : (resume (blockThreads (geometry p) 0) .block start).pc 1024 = 0 := by decide
example : ((resume (blockThreads (geometry p) 0) .block start).epochs 1023).block = 1 := by decide
example : ((resume (blockThreads (geometry p) 0) .block start).epochs 1024).block = 0 := by decide
example : (resume (blockThreads (geometry p) 0) .block marked).trace.length = 1 := by decide
example : ((resume (blockThreads (geometry p) 0) .block marked).trace[0]?).map (fun a => a.epoch.block) = some 0 := by decide
example : (midEntered 32 0 32 7 start).pc 32 = 50 := by decide
example : (midEntered 31 0 31 7 start).pc 31 = 38 := by decide
example : (midEntered 32 0 32 7 start).trace.length = 0 := by decide
example : LarkPartitionCollective.nextCohort program (cohortThreads 0 0 64) mixed = some (cohortThreads 0 0 32) := by decide
example : (topAfter 1 1 7 start).memory (topCell 1) = none := by decide
example : (secondLastAfter ops 0 2 3 start).memory (topCell 0) = some 5 := by decide
example : TopWrites 0 (topCell 0) := by decide
example : ((resume (blockThreads (geometry p) 0) .block phaseOne).epochs 1023).block = 2 := by decide
example : (resume (blockThreads (geometry p) 0) .block phaseOne).pc 1023 = 51 := by decide
example : ((resume (blockThreads (geometry p) 0) .block phaseOne).trace[0]?).map (fun a => a.epoch.block) = some 1 := by decide
example : outOnce.memory (globalCell 0 0) = some 1405 := by decide
example : outOnce.regs 0 12 = some 27 := by decide
example : outOnce.memory (globalCell 1 0) = some 8 := by decide
example : outOnce.indices 0 9 = some 1 := by decide
example : outDone.memory (globalCell 0 8199) = some (16407 * 2 * 8214 + 1000) := by decide
example : outDone.pc 0 = 71 := by decide
example : outDone.trace.length = 49 := by decide
example : outputWeighted biasOps values 0 0 3 = 1056 := by decide
example : ordinary.memory (globalCell 0 0) = none := by decide
example : seeded.memory (globalCell 0 0) = some 1 := by decide
example : seeded.memory (globalCell 1 0) = some 8 := by decide
example : extract tiny seeded = some [1,8] := by decide
example : ¬ RowWrites 0 (globalCell 0 (address 1 0)) := by decide
example : ¬ RowWrites 0 (globalCell 2 0) := by decide
example : writer (address 0 16383) = 1023 := by decide
example : outDone.pc 1024 = 0 := by decide
example : ((List.range 16).flatMap (fun w => cohortThreads 0 w 64)).length = 1024 := by decide
example : (cohortThreads 0 0 64 ++ cohortThreads 0 1 64).Nodup := by decide
