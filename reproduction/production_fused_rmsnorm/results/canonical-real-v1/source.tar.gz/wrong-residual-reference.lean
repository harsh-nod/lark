import LarkReal.NativeFusedRmsNorm
open LarkReal.NativeFusedRmsNorm
example : canonical_residual (fun b _ => if b = 0 then 1 else 2) 0 0 = 2 := by
  norm_num [canonical_residual]
