import LarkReal.NativeFusedRmsNorm
namespace LarkCertificate
open LarkNonlinear
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : LarkNativeFusedRmsNorm.Shape := ⟨1, by decide, by decide⟩
def layout : Layout := ⟨[⟨.output, 16384⟩, ⟨.output, 16384⟩, ⟨.input, 16384⟩],
  [32, 16384], []⟩
def mutableBuffers : List Nat := [0, 1]
def geometry : Geometry := ⟨1, 1024, 64⟩
def fuel : Fuel := ⟨512, 8, 3, 1⟩
def program : List LarkCollective.Instr := [(.scalar (.index 0 .bid)), (.scalar (.index 1 .tid)), (.scalar (.index 2 (.mod (.ivar (1)) (.const (32))))), (.scalar (.index 3 (.div (.ivar (1)) (.const (32))))), (.scalar (.assign 0 (.lit (0) 1))), (.scalar (.assign 1 (.lit (0) 1))), (.scalar (.index 4 (.const (0)))), (.scalar (.branch (.lt (.ivar (4)) (.const (2))) 23)), (.scalar (.index 5 (.const (0)))), (.scalar (.branch (.lt (.ivar (5)) (.const (8))) 21)), (.scalar (.index 6 (.add (.mul (.add (.mul (.ivar (4)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (5))))), (.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (6))))), (.scalar (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (7)))))), (.scalar (.assign 3 (.un .fromHalf (.load .global 1 (.ivar (7)))))), (.scalar (.assign 2 (.bin .add (.reg (2)) (.reg (3))))), (.scalar (.assign 4 (.bin .mul (.reg (2)) (.reg (2))))), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (4))))), (.scalar (.store .global 1 (.ivar (7)) (.un .toHalf (.reg (2))))), (.scalar (.store .shared 1 (.ivar (6)) (.reg (2)))), (.scalar (.index 5 (.add (.ivar (5)) (.const (1))))), (.scalar (.jump 9)), (.scalar (.index 4 (.add (.ivar (4)) (.const (1))))), (.scalar (.jump 7)), (.shuffle .xor 1 0 (.const (16)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (8)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (4)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (2)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (1)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (2)) (.const (0))) 35)), (.scalar (.store .shared 0 (.ivar (3)) (.reg (0)))), (.scalar (.barrier .block)), (.scalar (.branch (.lt (.ivar (1)) (.const (32))) 50)), (.scalar (.assign 0 (.load .shared 0 (.ivar (1))))), (.shuffle .xor 1 0 (.const (16)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (8)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (4)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (2)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.shuffle .xor 1 0 (.const (1)) 32), (.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))), (.scalar (.branch (.eq (.ivar (1)) (.const (0))) 50)), (.scalar (.store .shared 0 (.const (0)) (.reg (0)))), (.scalar (.barrier .block)), (.scalar (.assign 5 (.load .shared 0 (.const (0))))), (.scalar (.assign 6 (.bin .div (.reg (5)) (.lit (16384) 1)))), (.scalar (.assign 7 (.bin .add (.reg (6)) (.lit (1) 100000)))), (.scalar (.assign 8 (.un .rsqrt (.reg (7))))), (.scalar (.index 8 (.const (0)))), (.scalar (.branch (.lt (.ivar (8)) (.const (2))) 71)), (.scalar (.index 9 (.const (0)))), (.scalar (.branch (.lt (.ivar (9)) (.const (8))) 69)), (.scalar (.index 10 (.add (.mul (.add (.mul (.ivar (8)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (9))))), (.scalar (.index 11 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (10))))), (.scalar (.assign 9 (.load .shared 1 (.ivar (10))))), (.scalar (.assign 10 (.un .fromHalf (.load .global 2 (.const (0)))))), (.scalar (.assign 11 (.bin .add (.lit (0) 1) (.reg (10))))), (.scalar (.assign 12 (.bin .mul (.reg (9)) (.reg (8))))), (.scalar (.assign 13 (.bin .mul (.reg (12)) (.reg (11))))), (.scalar (.store .global 0 (.ivar (11)) (.un .toHalf (.reg (13))))), (.scalar (.index 9 (.add (.ivar (9)) (.const (1))))), (.scalar (.jump 58)), (.scalar (.index 8 (.add (.ivar (8)) (.const (1))))), (.scalar (.jump 56)), (.scalar .halt)]
-- The closed two-output reference AST is checked before this interpretation.
-- Half/float conversions are identities only in this exact-real model.
def referenceSquare (input : Nat → Nat → ℝ) (row col : Nat) : ℝ :=
  let x := input 0 (row * 16384 + col) + input 1 (row * 16384 + col)
  x * x
noncomputable def reference (input : Nat → Nat → ℝ) (row col : Nat) : ℝ :=
  (input 0 (row * 16384 + col) + input 1 (row * 16384 + col)) *
    (1 / Real.sqrt ((((List.range 16384).map (referenceSquare input row)).sum) / 16384 + 1 / 100000)) *
    input 2 col
def referenceResidual (input : Nat → Nat → ℝ) (row col : Nat) : ℝ :=
  input 0 (row * 16384 + col) + input 1 (row * 16384 + col)
noncomputable def spec (input : Nat → Nat → ℝ) : List ℝ :=
  (List.range (1 * 16384)).map (fun i => reference input (i / 16384) (i % 16384)) ++
  (List.range (1 * 16384)).map (fun i => referenceResidual input (i / 16384) (i % 16384))
theorem reference_data (input : Nat → Nat → ℝ) :
    spec input = LarkReal.NativeFusedRmsNorm.canonical_spec shape input := by rfl
theorem layout_data : layout = LarkNativeFusedRmsNorm.layout shape := by rfl
theorem mutable_data : mutableBuffers = LarkNativeFusedRmsNorm.mutableBuffers := by decide
theorem geometry_data : geometry = LarkNativeFusedRmsNorm.geometry shape := by rfl
theorem fuel_data : fuel = LarkNativeFusedRmsNorm.fuel := by rfl
theorem program_data : program = LarkNativeFusedRmsNorm.program := by decide
theorem interface_data : LarkInOut.Valid layout mutableBuffers := by
  rewrite [layout_data,mutable_data]
  exact LarkNativeFusedRmsNorm.interface_valid shape
theorem segmentation_data : program = LarkNativeFusedRmsNorm.program := program_data
theorem segmentation (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program
      (LarkInOut.initial layout mutableBuffers input outside) =
      some (LarkNativeFusedRmsNorm.finalState shape LarkReal.ops input outside) := by
  rewrite [segmentation_data,layout_data,mutable_data,geometry_data,fuel_data]
  exact (LarkNativeFusedRmsNorm.final_exec shape LarkReal.ops input outside).1
theorem race_free (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    raceFree geometry (LarkNativeFusedRmsNorm.finalState shape LarkReal.ops input outside).trace = true := by
  rewrite [geometry_data]
  exact (LarkNativeFusedRmsNorm.final_exec shape LarkReal.ops input outside).2
theorem segment_equivalence (input : Nat → Nat → ℝ) (outside : Location → Option ℝ) :
    extract layout (LarkNativeFusedRmsNorm.finalState shape LarkReal.ops input outside) = some (spec input) := by
  have hs : LarkNativeFusedRmsNorm.spec shape LarkReal.ops input = spec input :=
    (LarkReal.NativeFusedRmsNorm.spec_eq shape input).trans (reference_data input).symm
  rewrite [layout_data]
  exact (LarkNativeFusedRmsNorm.final_extract shape LarkReal.ops input outside).trans (congrArg some hs)
theorem kernel_eq_spec :
    LarkInOutPartition.Correct LarkReal.ops layout mutableBuffers geometry fuel program spec := by
  refine ⟨interface_data,?_⟩
  intro input outside
  exact ⟨LarkNativeFusedRmsNorm.finalState shape LarkReal.ops input outside,
    segmentation input outside,race_free input outside,segment_equivalence input outside⟩
theorem kernel_eq_spec_pre (input : Nat → Nat → ℝ) (s : State ℝ)
    (pre : LarkInOut.StdPre layout mutableBuffers input s) :
    ∃ final, LarkPartitionCollective.runLaunch LarkReal.ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec input) :=
  LarkInOutPartition.correct_from_pre LarkReal.ops layout mutableBuffers geometry fuel program spec
    kernel_eq_spec input s pre
#print axioms reference_data
#print axioms mutable_data
#print axioms program_data
#print axioms interface_data
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
