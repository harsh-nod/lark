import LarkReal.NativeFusedRmsNorm
open LarkReal.NativeFusedRmsNorm
example (input : Nat → Nat → ℝ) :
    (canonical_spec ⟨1, by decide, by decide⟩ input).length = 16384 := by
  simp [canonical_spec]
