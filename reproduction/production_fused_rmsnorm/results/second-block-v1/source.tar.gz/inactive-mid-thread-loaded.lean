import Lark.NativeFusedRmsNormOutBarrier
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def p : Shape := ⟨1, by decide, by decide⟩
def ops : Ops Nat := ⟨fun n d => n.toNat / d, (· + ·), (· - ·), (· * ·), Nat.max,
  (· / ·), id, id, id, id, fun x => x + 1000⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
def start : State Nat := initial p values (fun _ => none)
def once : State Nat := componentAfter ops values 0 0 0 0 0 0 start
def orderOps : Ops Nat := { ops with add := fun a b => a * 100 + b }
instance (t : Nat) (l : Location) : Decidable (PartialWrites t l) :=
  inferInstanceAs (Decidable ((t % 1024) % 32 = 0 ∧ l = partialCell t ((t % 1024) / 32)))
def marked : State Nat := { start with trace := [⟨0, globalCell 0 0, false, {}⟩] }
instance (t : Nat) (l : Location) : Decidable (TopWrites t l) :=
  inferInstanceAs (Decidable (t % 1024 = 0 ∧ l = topCell t))
def mixed : State Nat := { start with pc := fun t => if t < 32 then 38 else 50 }
def phaseOne : State Nat :=
  { start with
    pc := fun t => if t < 1024 then 50 else 0
    epochs := fun t => if t < 1024 then { block := 1 } else {}
    trace := [⟨0, partialSlot 0 0, true, { block := 1 }⟩, ⟨0, globalCell 0 0, false, {}⟩] }
example : (midEntered 32 0 32 7 start).pc 32 = 38 := by decide
