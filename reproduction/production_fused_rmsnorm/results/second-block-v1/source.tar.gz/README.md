Native fused add RMSNorm first two block phases and both barrier resumes, PC51/epoch2.
Requires Python 3 and Lean 4.19.0; no Git, GPUs or models.
Replay the frozen reader: python3 validate_source.py
Rebuild from source: lake build
Positive concrete witnesses: lake env lean Witnesses.lean
Every other top-level .lean file except Main.lean is a control that must
fail with 'is false' at its assertion. No .lake objects are archived.
All inputs/operations/outside memory and valid lanes/rows1..255 are
quantified by the prefix theorem. This is not a full kernel certificate.
Normalization/output execution, halt/grid, canonical-real/IEEE
equivalence and original-paper results remain open.
