import Lark.NativeFusedRmsNormPrefix
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def sourceProgram : List LarkCollective.Instr := [
(.scalar (.index 0 .bid)),
(.scalar (.index 1 .tid)),
(.scalar (.index 2 (.mod (.ivar (1)) (.const (32))))),
(.scalar (.index 3 (.div (.ivar (1)) (.const (32))))),
(.scalar (.assign 0 (.lit (0) 1))),
(.scalar (.assign 1 (.lit (0) 1))),
(.scalar (.index 4 (.const (0)))),
(.scalar (.branch (.lt (.ivar (4)) (.const (2))) 23)),
(.scalar (.index 5 (.const (0)))),
(.scalar (.branch (.lt (.ivar (5)) (.const (8))) 21)),
(.scalar (.index 6 (.add (.mul (.add (.mul (.ivar (4)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (5))))),
(.scalar (.index 7 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (6))))),
(.scalar (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (7)))))),
(.scalar (.assign 3 (.un .fromHalf (.load .global 1 (.ivar (7)))))),
(.scalar (.assign 2 (.bin .add (.reg (2)) (.reg (3))))),
(.scalar (.assign 4 (.bin .mul (.reg (2)) (.reg (2))))),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (4))))),
(.scalar (.store .global 1 (.ivar (7)) (.un .toHalf (.reg (2))))),
(.scalar (.store .shared 1 (.ivar (6)) (.reg (2)))),
(.scalar (.index 5 (.add (.ivar (5)) (.const (2))))),
(.scalar (.jump 9)),
(.scalar (.index 4 (.add (.ivar (4)) (.const (1))))),
(.scalar (.jump 7)),
(.shuffle .xor 1 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.scalar (.branch (.eq (.ivar (2)) (.const (0))) 35)),
(.scalar (.store .shared 0 (.ivar (3)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.branch (.lt (.ivar (1)) (.const (32))) 50)),
(.scalar (.assign 0 (.load .shared 0 (.ivar (1))))),
(.shuffle .xor 1 0 (.const (16)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (8)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (4)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (2)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.shuffle .xor 1 0 (.const (1)) 32),
(.scalar (.assign 0 (.bin .add (.reg (0)) (.reg (1))))),
(.scalar (.branch (.eq (.ivar (1)) (.const (0))) 50)),
(.scalar (.store .shared 0 (.const (0)) (.reg (0)))),
(.scalar (.barrier .block)),
(.scalar (.assign 5 (.load .shared 0 (.const (0))))),
(.scalar (.assign 6 (.bin .div (.reg (5)) (.lit (16384) 1)))),
(.scalar (.assign 7 (.bin .add (.reg (6)) (.lit (1) 100000)))),
(.scalar (.assign 8 (.un .rsqrt (.reg (7))))),
(.scalar (.index 8 (.const (0)))),
(.scalar (.branch (.lt (.ivar (8)) (.const (2))) 71)),
(.scalar (.index 9 (.const (0)))),
(.scalar (.branch (.lt (.ivar (9)) (.const (8))) 69)),
(.scalar (.index 10 (.add (.mul (.add (.mul (.ivar (8)) (.const (1024))) (.ivar (1))) (.const (8))) (.ivar (9))))),
(.scalar (.index 11 (.add (.mul (.ivar (0)) (.const (16384))) (.ivar (10))))),
(.scalar (.assign 9 (.load .shared 1 (.ivar (10))))),
(.scalar (.assign 10 (.un .fromHalf (.load .global 2 (.ivar (10)))))),
(.scalar (.assign 11 (.bin .add (.lit (0) 1) (.reg (10))))),
(.scalar (.assign 12 (.bin .mul (.reg (9)) (.reg (8))))),
(.scalar (.assign 13 (.bin .mul (.reg (12)) (.reg (11))))),
(.scalar (.store .global 0 (.ivar (11)) (.un .toHalf (.reg (13))))),
(.scalar (.index 9 (.add (.ivar (9)) (.const (1))))),
(.scalar (.jump 58)),
(.scalar (.index 8 (.add (.ivar (8)) (.const (1))))),
(.scalar (.jump 56)),
(.scalar .halt)
]
def sourceShape : Shape := ⟨1, by decide, by decide⟩
def sourceGlobal : List Buffer := [⟨.output, 16384⟩, ⟨.output, 16384⟩, ⟨.input, 16384⟩]
def sourceShared : List Nat := [32, 16384]
def sourceMutable : List Nat := [0, 1]
def sourceFuel : Fuel := ⟨512,8,3,1⟩
def sourceGeometry : Geometry := ⟨1,1024,64⟩
theorem source_binding : sourceProgram = program ∧
    sourceGlobal = (layout sourceShape).global ∧ sourceShared = (layout sourceShape).shared ∧
    sourceMutable = mutableBuffers ∧ sourceFuel = fuel ∧ sourceGeometry = geometry sourceShape := by decide
theorem source_interface : LarkInOut.Valid (layout sourceShape) mutableBuffers := interface_valid sourceShape
theorem source_pre_satisfiable (input : Nat → Nat → α) :
    ∃ s, LarkInOut.StdPre (layout sourceShape) mutableBuffers input s :=
  LarkInOut.pre_satisfiable _ _ input
#print axioms source_binding
#print axioms source_interface
#print axioms source_pre_satisfiable

theorem source_prefix_all_shapes (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    LarkCollective.runLane ops (layout p) (geometry p) sourceProgram t sourceFuel.lane
      (initial p input outside) = some (prefixState ops input t (initial p input outside)) := by
  simpa only [source_binding.1, source_binding.2.2.2.2.1] using initial_prefix_run p ops input outside t ht
theorem source_prefix_values (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    (prefixState ops input t (initial p input outside)).regs t 0 =
      some (threadSum ops input (t / 1024) (t % 1024)) ∧
    Pending input (t / 1024) (t % 1024) 16 (prefixState ops input t (initial p input outside)) ∧
    Completed ops input (t / 1024) (t % 1024) t 16 (prefixState ops input t (initial p input outside)) :=
  initial_prefix_values p ops input outside t ht
theorem source_prefix_good (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    ∀ a ∈ (prefixState ops input t (initial p input outside)).trace, Good a :=
  initial_prefix_good p ops input outside t ht
theorem source_prefix_race_free (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) (ht : t < p.rows * 1024) :
    raceFree (geometry p) (prefixState ops input t (initial p input outside)).trace = true :=
  initial_prefix_race_free p ops input outside t ht
theorem source_prefix_access_count (p : Shape) (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) (t : Nat) :
    (prefixState ops input t (initial p input outside)).trace.length = 64 :=
  initial_prefix_trace_length p ops input outside t
#print axioms source_prefix_all_shapes
#print axioms source_prefix_values
#print axioms source_prefix_good
#print axioms source_prefix_race_free
#print axioms source_prefix_access_count
