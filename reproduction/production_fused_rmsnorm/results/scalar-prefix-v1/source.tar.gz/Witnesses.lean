import Lark.NativeFusedRmsNormPrefix
open LarkNonlinear LarkNativeFusedRmsNorm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def p : Shape := ⟨1, by decide, by decide⟩
def ops : Ops Nat := ⟨fun n d => n.toNat / d, (· + ·), (· - ·), (· * ·), Nat.max,
  (· / ·), id, id, id, id, fun x => x + 1000⟩
def values (b i : Nat) : Nat := b * 7 + i + 1
def start : State Nat := initial p values (fun _ => none)
def once : State Nat := componentAfter ops values 0 0 0 0 0 0 start
example : once.memory (globalCell 1 0) = some 1009 := by decide
example : once.memory (unroundedCell 0 0) = some 9 := by decide
example : once.memory (globalCell 1 1) = some 9 := by decide
example : once.regs 0 0 = some 81 := by decide
example : (prefixState ops values 0 start).pc 0 = 23 := by decide
