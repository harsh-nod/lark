# Native attention lane-prefix proof

Run `lake build`, then `lake env lean Main.lean` with Lean 4.19.0.
The three other top-level Lean files intentionally fail at false postconditions.
This proves each lane reaches PC 20. It does not compose the launch, resume
the barrier, execute attention computation, or prove dense-reference equality.
