import Lark.NativeAttentionFirstResume
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (b t : Nat) (s : State α)
    (ht : t ∈ blockThreads (geometry p) b) : (firstResumed p ops input b s).pc t = 20 := by
  rw [first_resumed_pc p ops input b t s ht]
  decide
