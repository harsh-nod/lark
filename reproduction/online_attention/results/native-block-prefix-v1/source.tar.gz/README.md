# Native attention first-block prefix proof

Run `lake build`, then `lake env lean Main.lean` with Lean 4.19.0.
The 6 other top-level Lean files intentionally fail at false postconditions.
Scope: actual first runBlock phase, including 32 native lanes, block convergence and resume to PC 21.
It does not execute attention computation or later block phases, compose
the whole launch, or prove dense-reference equality.
