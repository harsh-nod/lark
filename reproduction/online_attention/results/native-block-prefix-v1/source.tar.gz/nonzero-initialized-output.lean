import Lark.NativeAttentionFirstResume
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t : Nat) (s : State Nat)
    (hz : zeroValue ops = 0) :
    (firstLane ops input t s).memory (globalCell 0 (globalAddress t 0 0)) = some 1 := by
  rw [first_lane_output ops input t 0 0 s (by decide) (by decide), hz]
  decide
