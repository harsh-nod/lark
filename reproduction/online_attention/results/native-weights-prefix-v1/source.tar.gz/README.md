# Native attention weights prefix proof

Run `lake build`, then `lake env lean Main.lean` with Lean 4.19.0.
The 9 other top-level Lean files intentionally fail at false postconditions.
Scope: native first block phase and resume, then a per-lane continuation from PC 21 through 58891 instructions to PC 56: first query row scores, maximum, exponential weights and denominator.
Output updates, later query/key tiles, whole-launch execution and dense-reference equality remain unproved.
