import Lark.NativeAttentionWeights
open LarkNonlinear LarkNativeAttention

example (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    (firstLane ops input t s).pc t = 21 := by
  rw [(first_lane_fields ops input t s).1]
  decide
