import Lark.NativeAttentionWeights
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (t : Nat) (values : Nat → Nat) (maximum : Nat) (s : State Nat)
    (hw : normalizedWeight ops (values 0) maximum = 0) :
    (weightsComputed ops t values maximum s).memory (sharedCell t 3 (scoreAddress t 0)) = some 1 := by
  rw [weights_computed_value ops t values 0 maximum s (by decide), hw]
  decide
