import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α)
    (t : Nat) (ht : t < p.groups * 32) : (gridState p ops input (initial (layout p) input outside)).pc t = 88 := by
  rw [grid_pc p ops input outside t ht]
  decide
