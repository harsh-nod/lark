import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t key : Nat) (s : State Nat)
    (hv : ops.fromHalf (input 2 (globalAddress t (key + 1) 255)) = 0) :
    (nextLoad ops input t key s).memory (sharedCell t 1 (sharedAddress t 255)) = some 1 := by
  rw [next_load_value ops input t key 1 255 s (Or.inl rfl) (by decide), hv]
  decide
