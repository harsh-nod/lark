import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (b t : Nat) (s : State α)
    (ht : t ∈ blockThreads (geometry p) b) : (finalBlock p ops input b s).pc t = 88 := by
  rw [(final_block_member p ops input b t s ht).1]
  decide
