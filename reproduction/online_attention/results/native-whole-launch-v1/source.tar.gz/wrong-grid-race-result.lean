import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    raceFree (geometry p) (gridState p ops input (initial (layout p) input outside)).trace = false := by
  rw [grid_race_free p ops input outside]
  decide
