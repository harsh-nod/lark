import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat) (outside : Location → Option Nat)
    (offset : Nat) (hi : offset < p.groups * 32768) (hv : outputValue ops input offset = 0) :
    (gridState p ops input (initial (layout p) input outside)).memory (globalCell 0 offset) = some 1 := by
  rw [grid_value p ops input outside offset hi, hv]
  decide
