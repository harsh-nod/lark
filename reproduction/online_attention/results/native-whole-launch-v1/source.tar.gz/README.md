# Native attention whole-launch proof

Run `lake build`, then `lake env lean Main.lean` with Lean 4.19.0.
The 29 other top-level Lean files intentionally fail at false postconditions.
Scope: actual full native runLaunch for every allowed group count: all four keys, nine block phases, full grid halt, all outputs extracted against the source-ordered online recurrence, input preservation and actual trace race freedom.
Canonical dense-real equality is checked separately with Mathlib. No IEEE equivalence or error bound, NVIDIA execution or original-paper completion is claimed.
