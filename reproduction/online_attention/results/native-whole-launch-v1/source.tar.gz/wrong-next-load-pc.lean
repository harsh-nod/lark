import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (ops : Ops α) (input : Nat → Nat → α) (t key : Nat) (s : State α) :
    (nextLoad ops input t key s).pc t = 21 := by
  rw [(next_load_fields ops input t key s).1]
  decide
