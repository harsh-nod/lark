import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) :
    (sourceSpec ⟨1, by decide, by decide⟩ ops input).length = 32767 := by
  simp only [sourceSpec, List.length_map, List.length_range]
  decide
