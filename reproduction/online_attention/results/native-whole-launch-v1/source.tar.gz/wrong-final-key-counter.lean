import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (b t : Nat) (s : State α)
    (ht : t ∈ blockThreads (geometry p) b) : (finalBlock p ops input b s).indices t 5 = some 3 := by
  rw [(final_block_member p ops input b t s ht).2]
  decide
