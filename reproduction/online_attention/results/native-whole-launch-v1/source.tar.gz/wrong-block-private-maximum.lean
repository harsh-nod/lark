import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat) (b t : Nat) (s : State Nat)
    (ht : t ∈ blockThreads (geometry p) b) (hv : (firstKeyValues ops input t 3).maximum = 0) :
    (firstKeyResumed p ops input b s).memory (privateCell t 0 3) = some 1 := by
  rw [(first_key_resumed_private p ops input b t 3 s ht (by decide)).1, hv]
  decide
