import Lark.NativeAttentionCorrect
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (t : Nat) (values : Nat → Nat) (maximum : Nat) (s : State Nat)
    (hd : expFold ops values maximum 0 32 (ops.literal 0 1) = 0) :
    (weightsComputed ops t values maximum s).regs t 5 = some 1 := by
  rw [(weights_computed_fields ops t values maximum s).2.2.1, hd]
  decide
