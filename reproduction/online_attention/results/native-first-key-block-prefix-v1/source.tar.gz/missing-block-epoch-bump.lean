import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α)
    (b t : Nat) (ht : t ∈ blockThreads (geometry p) b) :
    ((firstResumed p ops input b (initial (layout p) input outside)).epochs t).block = 0 := by
  rw [first_resumed_epoch p ops input b t (initial (layout p) input outside) ht]
  change 1 = 0
  decide
