# Native attention first-key-block prefix proof

Run `lake build`, then `lake env lean Main.lean` with Lean 4.19.0.
The 21 other top-level Lean files intentionally fail at false postconditions.
Scope: actual first two native runBlock phases and barrier resumes to PC 88: all 32 lanes and all four query rows for key tile zero, including all output/private state stores, input preservation and prefix trace race freedom.
The three later key tiles, their copy/barrier phases, whole-launch execution and dense-reference equality remain unproved.
