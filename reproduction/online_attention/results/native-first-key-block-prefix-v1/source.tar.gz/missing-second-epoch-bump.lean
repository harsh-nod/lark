import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α)
    (b t : Nat) (hb : b < p.groups) (ht : t ∈ blockThreads (geometry p) b) :
    ((firstKeyResumed p ops input b (initial (layout p) input outside)).epochs t).block = 1 := by
  rw [(first_key_resumed_member p ops input outside b t hb ht).2.2.2]
  decide
