import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t key col : Nat) (weights : Nat → Nat) (s : State Nat)
    (hv : pvValue ops input t key col weights = 0) :
    (pvComputed ops input t key col weights s).regs t 13 = some 1 := by
  rw [(pv_computed_fields ops input t key col weights s).2.1, hv]
  decide
