import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t qi key col : Nat) (weights : Nat → Nat)
    (scales : ScaleValues Nat) (oldMass oldStored : Nat) (s : State Nat)
    (hv : storedOutput ops scales oldMass oldStored (pvValue ops input t key col weights) = 0) :
    (outputColumn ops input t qi key col weights scales oldMass oldStored s).memory
      (globalCell 0 (globalAddress t qi col)) = some 1 := by
  rw [output_column_memory, if_pos rfl, hv]
  decide
