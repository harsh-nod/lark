import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    (firstKeyLane ops input t s).pc t = 83 := by
  rw [(first_key_lane_fields ops input t s).1]
  decide
