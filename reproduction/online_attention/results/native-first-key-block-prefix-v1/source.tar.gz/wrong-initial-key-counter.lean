import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops α) (input : Nat → Nat → α) (b t : Nat) (s : State α)
    (ht : t ∈ blockThreads (geometry p) b) :
    (firstResumed p ops input b s).indices t 5 = some 1 := by
  rw [first_resumed_key p ops input b t s ht]
  decide
