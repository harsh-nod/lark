import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat) (b t : Nat) (s : State Nat)
    (ht : t ∈ blockThreads (geometry p) b) (hv : (firstKeyValues ops input t 3).stored 255 = 0) :
    (firstKeyResumed p ops input b s).memory (globalCell 0 (globalAddress t 3 255)) = some 1 := by
  rw [first_key_resumed_value p ops input b t 3 255 s ht (by decide) (by decide), hv]
  decide
