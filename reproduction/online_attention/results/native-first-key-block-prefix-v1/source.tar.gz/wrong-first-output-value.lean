import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t : Nat) (s : State Nat)
    (hv : firstOutputValues ops input t 0 = 0) :
    (firstOutput ops input t s).memory (globalCell 0 (globalAddress t 0 0)) = some 1 := by
  rw [first_output_value ops input t 0 s (by decide), hv]
  decide
