import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example : queryTileFuel 1 = 476254 := by
  rw [query_tile_fuel]
  decide
