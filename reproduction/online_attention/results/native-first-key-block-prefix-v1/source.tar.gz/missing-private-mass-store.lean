import Lark.NativeAttentionFirstKeyBlock
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t key : Nat) (old : Nat → QueryValue Nat) (s : State Nat)
    (hv : (nextQueryValue ops input t 3 key (old 3)).mass = 0) :
    (queryTile ops input t key old s).memory (privateCell t 1 3) = some 1 := by
  rw [(query_tile_private ops input t key 3 old s (by decide)).2, hv]
  decide
