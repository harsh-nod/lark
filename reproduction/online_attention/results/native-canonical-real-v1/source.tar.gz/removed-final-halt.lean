import Main
open LarkNativeAttention NativeAttentionExport
example : sourceProgram.dropLast = program := by decide
