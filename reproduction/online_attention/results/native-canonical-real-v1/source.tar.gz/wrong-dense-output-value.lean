import Main
open LarkNativeAttention LarkReal.NativeAttention
example (input : Nat → Nat → ℝ) (t qi col : Nat)
    (hv : LarkReal.OnlineSoftmax.reference (denseEntries input t qi) col = 0) :
    (onlineValues LarkReal.ops input 4 t qi).stored col = 1 := by
  rw [online_dense_reference, hv]
  norm_num
