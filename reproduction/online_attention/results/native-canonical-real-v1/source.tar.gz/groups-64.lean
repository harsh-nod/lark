import Main
open LarkNonlinear LarkNativeAttention NativeAttentionExport
def checkedShape : Shape := ⟨64, by decide, by decide⟩
theorem group_correct : Correct LarkReal.ops (sourceLayout checkedShape) (sourceGeometry checkedShape)
    sourceFuel sourceProgram (LarkReal.NativeAttention.denseSpec checkedShape) := source_bound_correct checkedShape
#print axioms group_correct
