# Canonical-real native attention certificate

Lean 4.19.0 and the exact locked Mathlib revision are required. Run `lake update`, fetch the Mathlib cache, then `lake build`.
Run `lake env lean groups-<n>.lean` for n=1,3,64,65535. The four other top-level Lean files intentionally fail.
The universal theorem covers all group counts 1..65535, all inputs and outside memory, actual native launch/race freedom and dense real SDPA.
Half casts are identities only in this real interpretation. No IEEE equivalence, error bound or original-paper completion is claimed.
