import Main
open NativeAttentionExport
example : sourceGeometry ⟨1, by decide, by decide⟩ = ⟨1, 64, 64⟩ := by decide
