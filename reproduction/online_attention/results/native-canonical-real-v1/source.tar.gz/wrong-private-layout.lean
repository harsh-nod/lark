import Main
open NativeAttentionExport
example : sourceLocals = [4] := by decide
