import LarkReal.OnlineSoftmax
open LarkReal.OnlineSoftmax
noncomputable def entry (v : ℝ) : Entry := ⟨0, fun _ => v⟩
noncomputable def prior : Accumulator := start 0 [entry 2, entry 2]

example : (update prior 0 [entry 4]).o 0 = (8 / 3 : ℝ) := by
  norm_num [update, prior, start, entry, weight, numerator]
