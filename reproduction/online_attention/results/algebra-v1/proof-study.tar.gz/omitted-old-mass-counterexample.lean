import LarkReal.OnlineSoftmax
open LarkReal.OnlineSoftmax
noncomputable def entry (v : ℝ) : Entry := ⟨0, fun _ => v⟩
noncomputable def prior : Accumulator := start 0 [entry 2, entry 2]

noncomputable def changed (a : Accumulator) (tileM : ℝ) (tile : List Entry) : Accumulator :=
  let m := max a.m tileM
  let l := Real.exp (a.m - m) * a.l + Real.exp (tileM - m) * weight tileM tile
  ⟨m, l, fun c => (1 / l) *
    ((Real.exp (a.m - m) * a.o c) +
      (Real.exp (tileM - m) * numerator tileM tile c))⟩

example : (changed prior 0 [entry 4]).o 0 ≠ (8 / 3 : ℝ) := by norm_num [changed, prior, start, entry, weight, numerator]
