import LarkReal.OnlineSoftmax
open LarkReal.OnlineSoftmax
noncomputable def entry (v : ℝ) : Entry := ⟨0, fun _ => v⟩
noncomputable def prior : Accumulator := start 0 [entry 2, entry 2]

example : Real.exp (-1 : ℝ) * Real.exp (0 : ℝ) ≠ Real.exp (1 : ℝ) := by
  simp only [Real.exp_zero, mul_one]
  exact Real.exp_injective.ne (by norm_num)
