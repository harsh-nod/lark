import Lark.NativeAttentionAddress
open LarkNonlinear LarkNativeAttention
def p : Shape := ⟨1, by decide, by decide⟩
def readAt (epoch : Nat) : Access := ⟨0, ⟨.shared,0,1,256⟩, false, ⟨0,epoch,0⟩⟩
def storeAt : Access := ⟨1, ⟨.shared,0,1,256⟩, true, ⟨0,0,0⟩⟩
example : conflict (geometry p) (readAt 0) storeAt = true := by decide
example : conflict (geometry p) (readAt 1) storeAt = false := by decide
example : Good (readAt 1) := by apply Good.tileLoad <;> decide
example : Good storeAt := by apply Good.tileStore <;> decide
example : raceFree (geometry p) [readAt 1, storeAt] = true := by decide
example : location (layout p) (geometry p) 17 .local 0 0 true = some ⟨.local,17,0,0⟩ := by decide
