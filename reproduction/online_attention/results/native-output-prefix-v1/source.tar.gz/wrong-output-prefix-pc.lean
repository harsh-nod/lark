import Lark.NativeAttentionFirstOutput
open LarkNonlinear LarkNativeAttention

example (ops : Ops α) (input : Nat → Nat → α) (t : Nat) (s : State α) :
    (firstOutput ops input t s).pc t = 82 := by
  rw [(first_output_fields ops input t s).1]
  decide
