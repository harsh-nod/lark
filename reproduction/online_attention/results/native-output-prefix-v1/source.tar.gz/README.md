# Native attention output prefix proof

Run `lake build`, then `lake env lean Main.lean` with Lean 4.19.0.
The 14 other top-level Lean files intentionally fail at false postconditions.
Scope: native first block phase and resume, then a per-lane continuation from PC 21 through 119060 instructions to PC 83: first query row scores, weights, denominator, all weighted-V products and 256 output stores.
Private-state stores, later query/key tiles, whole-launch execution and dense-reference equality remain unproved.
