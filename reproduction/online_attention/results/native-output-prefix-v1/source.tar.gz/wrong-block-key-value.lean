import Lark.NativeAttentionFirstOutput
open LarkNonlinear LarkNativeAttention

example (p : Shape) (ops : Ops Nat) (input : Nat → Nat → Nat) (b t : Nat) (s : State Nat)
    (ht : t ∈ blockThreads (geometry p) b) (hv : ops.fromHalf (input 2 (globalAddress t 0 0)) = 0) :
    (firstResumed p ops input b s).memory (sharedCell t 1 (sharedAddress t 0)) = some 1 := by
  rw [first_resumed_tile p ops input b t 1 0 s ht (Or.inl rfl) (by decide), hv]
  decide
