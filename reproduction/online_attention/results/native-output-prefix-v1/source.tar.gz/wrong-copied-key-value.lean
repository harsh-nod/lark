import Lark.NativeAttentionFirstOutput
open LarkNonlinear LarkNativeAttention

example (ops : Ops Nat) (input : Nat → Nat → Nat) (t : Nat) (s : State Nat)
    (hv : ops.fromHalf (input 2 (globalAddress t 0 0)) = 0) :
    (firstLane ops input t s).memory (sharedCell t 1 (sharedAddress t 0)) = some 1 := by
  rw [first_lane_tile ops input t 1 0 s (Or.inl rfl) (by decide), hv]
  decide
