import Lark.NativeAttentionFirstOutput
open LarkNonlinear LarkNativeAttention

example (ops : Ops α) (input : Nat → Nat → α) (t keyTile : Nat) (s : State α) :
    (firstWeights ops input t keyTile s).pc t = 55 := by
  rw [(first_weights_fields ops input t keyTile s).1]
  decide
