	.file	"driver.hip"
                                        # Start of file scope inline assembly
	.globl	_ZSt21ios_base_library_initv

                                        # End of file scope inline assembly
	.text
	.globl	__device_stub__mfma_tile        # -- Begin function __device_stub__mfma_tile
	.p2align	4
	.type	__device_stub__mfma_tile,@function
__device_stub__mfma_tile:               # @__device_stub__mfma_tile
	.cfi_startproc
# %bb.0:
	subq	$120, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, 72(%rsp)
	movq	%rsi, 64(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%rcx, 48(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, 80(%rsp)
	leaq	64(%rsp), %rax
	movq	%rax, 88(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 96(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	80(%rsp), %r9
	movl	$mfma_tile, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$136, %rsp
	.cfi_adjust_cfa_offset -136
	retq
.Lfunc_end0:
	.size	__device_stub__mfma_tile, .Lfunc_end0-__device_stub__mfma_tile
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception0
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2520, %rsp                     # imm = 0x9D8
	.cfi_def_cfa_offset 2576
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpl	$3, %edi
	jne	.LBB1_1
# %bb.6:
	movq	%rsi, %rbx
	movq	8(%rsi), %r14
	leaq	16(%rsp), %r12
	movq	%r12, (%rsp)
	testq	%r14, %r14
	je	.LBB1_7
# %bb.9:
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	strlen
	movq	%rax, %r15
	movq	%rax, 1048(%rsp)
	movq	%r12, %rax
	cmpq	$16, %r15
	jb	.LBB1_12
# %bb.10:                               # %.noexc.i
.Ltmp6:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rsp, %rdi
	leaq	1048(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp7:                                 # EH_LABEL
# %bb.11:                               # %.noexc74
	movq	%rax, (%rsp)
	movq	1048(%rsp), %rcx
	movq	%rcx, 16(%rsp)
.LBB1_12:                               # %._crit_edge.i.i
	testq	%r15, %r15
	je	.LBB1_16
# %bb.13:                               # %._crit_edge.i.i
	cmpq	$1, %r15
	jne	.LBB1_15
# %bb.14:
	movzbl	(%r14), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_16
.LBB1_15:
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	memcpy@PLT
.LBB1_16:
	movq	1048(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	(%rsp), %rcx
	movb	$0, (%rcx,%rax)
	movq	16(%rbx), %rbx
	leaq	80(%rsp), %r15
	movq	%r15, 64(%rsp)
	testq	%rbx, %rbx
	je	.LBB1_17
# %bb.19:
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	strlen
	movq	%rax, %r14
	movq	%rax, 1048(%rsp)
	movq	%r15, %rax
	cmpq	$16, %r14
	jb	.LBB1_22
# %bb.20:                               # %.noexc.i76
.Ltmp8:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	64(%rsp), %rdi
	leaq	1048(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp9:                                 # EH_LABEL
# %bb.21:                               # %.noexc78
	movq	%rax, 64(%rsp)
	movq	1048(%rsp), %rcx
	movq	%rcx, 80(%rsp)
.LBB1_22:                               # %._crit_edge.i.i75
	testq	%r14, %r14
	je	.LBB1_26
# %bb.23:                               # %._crit_edge.i.i75
	cmpq	$1, %r14
	jne	.LBB1_25
# %bb.24:
	movzbl	(%rbx), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_26
.LBB1_25:
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
.LBB1_26:
	movq	1048(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	64(%rsp), %rcx
	movb	$0, (%rcx,%rax)
.Ltmp10:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1048(%rsp), %rdi
	xorl	%esi, %esi
	callq	hipGetDevicePropertiesR0600
.Ltmp11:                                # EH_LABEL
# %bb.27:
	testl	%eax, %eax
	jne	.LBB1_28
# %bb.34:                               # %_ZL5check10hipError_t.exit
	cmpl	$64, 1356(%rsp)
	jne	.LBB1_35
# %bb.40:
	movq	(%rsp), %rbx
	movq	8(%rsp), %r14
	leaq	480(%rsp), %r15
	movq	%r15, 464(%rsp)
	movq	$0, 472(%rsp)
	movb	$0, 480(%rsp)
	leaq	6(%r14), %rsi
.Ltmp23:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7reserveEm
.Ltmp24:                                # EH_LABEL
# %bb.41:
	movabsq	$4611686018427387903, %rax      # imm = 0x3FFFFFFFFFFFFFFF
	subq	472(%rsp), %rax
	cmpq	%r14, %rax
	jb	.LBB1_44
# %bb.42:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i.i
.Ltmp25:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp26:                                # EH_LABEL
# %bb.43:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE6appendEPKcm.exit.i.i
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	movq	472(%rsp), %rax
	addq	%rcx, %rax
	cmpq	$5, %rax
	jbe	.LBB1_44
# %bb.47:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i10.i.i
.Ltmp27:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movl	$.L.str.2, %esi
	movl	$6, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp28:                                # EH_LABEL
# %bb.48:                               # %_ZStplIcSt11char_traitsIcESaIcEENSt7__cxx1112basic_stringIT_T0_T1_EERKS8_PKS5_.exit
.Ltmp29:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	168(%rsp), %rdi
	leaq	464(%rsp), %rsi
	callq	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp30:                                # EH_LABEL
# %bb.49:
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_51
# %bb.50:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_51:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit
	movq	(%rsp), %rbx
	movq	8(%rsp), %r14
	movq	%r15, 464(%rsp)
	movq	$0, 472(%rsp)
	movb	$0, 480(%rsp)
	leaq	6(%r14), %rsi
.Ltmp32:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7reserveEm
.Ltmp33:                                # EH_LABEL
# %bb.52:
	movabsq	$4611686018427387903, %rax      # imm = 0x3FFFFFFFFFFFFFFF
	subq	472(%rsp), %rax
	cmpq	%r14, %rax
	jb	.LBB1_55
# %bb.53:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i.i86
.Ltmp34:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp35:                                # EH_LABEL
# %bb.54:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE6appendEPKcm.exit.i.i87
	movq	472(%rsp), %rax
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	addq	%rcx, %rax
	cmpq	$5, %rax
	jbe	.LBB1_55
# %bb.58:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i10.i.i88
.Ltmp36:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movl	$.L.str.3, %esi
	movl	$6, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp37:                                # EH_LABEL
# %bb.59:                               # %_ZStplIcSt11char_traitsIcESaIcEENSt7__cxx1112basic_stringIT_T0_T1_EERKS8_PKS5_.exit93
.Ltmp38:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	144(%rsp), %rdi
	leaq	464(%rsp), %rsi
	callq	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp39:                                # EH_LABEL
# %bb.60:
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_62
# %bb.61:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i94
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_62:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit96
	movq	(%rsp), %rbx
	movq	8(%rsp), %r14
	movq	%r15, 464(%rsp)
	movq	$0, 472(%rsp)
	movb	$0, 480(%rsp)
	leaq	6(%r14), %rsi
.Ltmp41:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7reserveEm
.Ltmp42:                                # EH_LABEL
# %bb.63:
	movabsq	$4611686018427387903, %rax      # imm = 0x3FFFFFFFFFFFFFFF
	subq	472(%rsp), %rax
	cmpq	%r14, %rax
	jb	.LBB1_66
# %bb.64:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i.i100
.Ltmp43:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp44:                                # EH_LABEL
# %bb.65:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE6appendEPKcm.exit.i.i101
	movq	472(%rsp), %rax
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	addq	%rcx, %rax
	cmpq	$5, %rax
	jbe	.LBB1_66
# %bb.69:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i10.i.i102
.Ltmp45:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movl	$.L.str.4, %esi
	movl	$6, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp46:                                # EH_LABEL
# %bb.70:                               # %_ZStplIcSt11char_traitsIcESaIcEENSt7__cxx1112basic_stringIT_T0_T1_EERKS8_PKS5_.exit107
.Ltmp47:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	120(%rsp), %rdi
	leaq	464(%rsp), %rsi
	callq	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp48:                                # EH_LABEL
# %bb.71:
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_73
# %bb.72:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i108
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_73:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit110
	movq	176(%rsp), %rax
	subq	168(%rsp), %rax
	movq	152(%rsp), %rcx
	subq	144(%rsp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB1_75
# %bb.74:
	addq	%rax, %rax
	movq	128(%rsp), %rcx
	subq	120(%rsp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB1_75
# %bb.89:
.Ltmp56:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	240(%rsp), %rdi
	leaq	168(%rsp), %rsi
	movl	$512, %edx                      # imm = 0x200
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp57:                                # EH_LABEL
# %bb.90:
.Ltmp59:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	408(%rsp), %rdi
	leaq	144(%rsp), %rsi
	movl	$512, %edx                      # imm = 0x200
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp60:                                # EH_LABEL
# %bb.91:
.Ltmp62:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	352(%rsp), %rdi
	leaq	120(%rsp), %rsi
	movl	$1024, %edx                     # imm = 0x400
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp63:                                # EH_LABEL
# %bb.92:
	movq	128(%rsp), %rbx
	subq	120(%rsp), %rbx
	js	.LBB1_93
# %bb.95:                               # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	je	.LBB1_96
# %bb.97:
.Ltmp65:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	_Znwm
.Ltmp66:                                # EH_LABEL
# %bb.98:                               # %.noexc121
	movq	%rax, 464(%rsp)
	movq	%rax, 472(%rsp)
	movq	%rax, %r14
	addq	%rbx, %r14
	movq	%r14, 480(%rsp)
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	memset@PLT
	jmp	.LBB1_99
.LBB1_96:                               # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 464(%rsp)
	movq	$0, 480(%rsp)
	xorl	%r14d, %r14d
.LBB1_99:
	movq	%r14, 472(%rsp)
.Ltmp67:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	296(%rsp), %rdi
	leaq	464(%rsp), %rsi
	movl	$1024, %edx                     # imm = 0x400
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp68:                                # EH_LABEL
# %bb.100:
	movq	464(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_102
# %bb.101:
	movq	480(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_102:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit
	cmpq	$0, 256(%rsp)
	je	.LBB1_111
# %bb.103:                              # %.lr.ph
	xorl	%r13d, %r13d
	movabsq	$4294967297, %rbx               # imm = 0x100000001
	movabsq	$4294967360, %r14               # imm = 0x100000040
	leaq	192(%rsp), %rbp
	leaq	464(%rsp), %r15
	.p2align	4
.LBB1_104:                              # =>This Inner Loop Header: Depth=1
.Ltmp70:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	movl	$1, %esi
	movq	%r14, %rdx
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp71:                                # EH_LABEL
# %bb.105:                              #   in Loop: Header=BB1_104 Depth=1
	testl	%eax, %eax
	jne	.LBB1_108
# %bb.106:                              #   in Loop: Header=BB1_104 Depth=1
	movq	240(%rsp), %rax
	movq	264(%rsp), %rcx
	imulq	%r13, %rcx
	addq	%rcx, %rax
	addq	$128, %rax
	movq	408(%rsp), %rcx
	movq	432(%rsp), %rdx
	imulq	%r13, %rdx
	addq	%rdx, %rcx
	addq	$128, %rcx
	movq	352(%rsp), %rdx
	movq	376(%rsp), %rsi
	imulq	%r13, %rsi
	addq	%rsi, %rdx
	addq	$128, %rdx
	movq	296(%rsp), %rsi
	movq	320(%rsp), %rdi
	imulq	%r13, %rdi
	addq	%rdi, %rsi
	addq	$128, %rsi
	movq	%rax, 232(%rsp)
	movq	%rcx, 224(%rsp)
	movq	%rdx, 216(%rsp)
	movq	%rsi, 208(%rsp)
	leaq	232(%rsp), %rax
	movq	%rax, 464(%rsp)
	leaq	224(%rsp), %rax
	movq	%rax, 472(%rsp)
	leaq	216(%rsp), %rax
	movq	%rax, 480(%rsp)
	leaq	208(%rsp), %rax
	movq	%rax, 488(%rsp)
.Ltmp72:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	leaq	96(%rsp), %rsi
	leaq	200(%rsp), %rdx
	movq	%rbp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp73:                                # EH_LABEL
# %bb.107:                              # %.noexc124
                                        #   in Loop: Header=BB1_104 Depth=1
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	96(%rsp), %rcx
	movl	104(%rsp), %r8d
.Ltmp74:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$mfma_tile, %edi
	movq	%r15, %r9
	pushq	192(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	208(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp75:                                # EH_LABEL
.LBB1_108:                              #   in Loop: Header=BB1_104 Depth=1
.Ltmp76:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipGetLastError
.Ltmp77:                                # EH_LABEL
# %bb.109:                              # %_ZL5check10hipError_t.exit130
                                        #   in Loop: Header=BB1_104 Depth=1
	movl	%eax, %r12d
	testl	%eax, %eax
	jne	.LBB1_125
# %bb.110:                              #   in Loop: Header=BB1_104 Depth=1
	incq	%r13
	cmpq	256(%rsp), %r13
	jb	.LBB1_104
.LBB1_111:                              # %._crit_edge
.Ltmp87:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipDeviceSynchronize
.Ltmp88:                                # EH_LABEL
# %bb.112:
	testl	%eax, %eax
	jne	.LBB1_113
# %bb.133:                              # %_ZL5check10hipError_t.exit135
.Ltmp96:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1024(%rsp), %rdi
	leaq	240(%rsp), %rsi
	movl	$1, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp97:                                # EH_LABEL
# %bb.134:
	movq	1024(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_136
# %bb.135:
	movq	1040(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_136:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit137
.Ltmp98:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1000(%rsp), %rdi
	leaq	408(%rsp), %rsi
	movl	$1, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp99:                                # EH_LABEL
# %bb.137:
	movq	1000(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_139
# %bb.138:
	movq	1016(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_139:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit139
.Ltmp100:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	976(%rsp), %rdi
	leaq	352(%rsp), %rsi
	movl	$1, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp101:                               # EH_LABEL
# %bb.140:
	movq	976(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_142
# %bb.141:
	movq	992(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_142:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit141
.Ltmp103:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	96(%rsp), %rdi
	leaq	296(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp104:                               # EH_LABEL
# %bb.143:
	movq	64(%rsp), %rbx
	movq	72(%rsp), %r14
	leaq	48(%rsp), %r15
	movq	%r15, 32(%rsp)
	movq	$0, 40(%rsp)
	movb	$0, 48(%rsp)
	leaq	11(%r14), %rsi
.Ltmp106:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7reserveEm
.Ltmp107:                               # EH_LABEL
# %bb.144:
	movabsq	$4611686018427387903, %rax      # imm = 0x3FFFFFFFFFFFFFFF
	subq	40(%rsp), %rax
	cmpq	%r14, %rax
	jb	.LBB1_147
# %bb.145:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i.i145
.Ltmp108:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp109:                               # EH_LABEL
# %bb.146:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE6appendEPKcm.exit.i.i146
	movq	40(%rsp), %rax
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	addq	%rcx, %rax
	addq	$5, %rax
	cmpq	$10, %rax
	jbe	.LBB1_147
# %bb.150:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i10.i.i147
.Ltmp110:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	movl	$.L.str.6, %esi
	movl	$11, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp111:                               # EH_LABEL
# %bb.151:                              # %_ZStplIcSt11char_traitsIcESaIcEENSt7__cxx1112basic_stringIT_T0_T1_EERKS8_PKS5_.exit152
.Ltmp112:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	leaq	32(%rsp), %rsi
	movl	$4, %edx
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEEC1ERKNSt7__cxx1112basic_stringIcS1_SaIcEEESt13_Ios_Openmode
.Ltmp113:                               # EH_LABEL
# %bb.152:
	movq	32(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_154
# %bb.153:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i153
	movq	48(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_154:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit155
	movq	96(%rsp), %rsi
	movq	104(%rsp), %rdx
	subq	%rsi, %rdx
.Ltmp115:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSo5writeEPKcl
.Ltmp116:                               # EH_LABEL
# %bb.155:
	movq	464(%rsp), %rax
	movq	-24(%rax), %rax
	testb	$5, 496(%rsp,%rax)
	jne	.LBB1_156
# %bb.164:
.Ltmp122:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movl	$.L.str.8, %esi
	movl	$11, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp123:                               # EH_LABEL
# %bb.165:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit
	.cfi_escape 0x2e, 0x00
	leaq	1048(%rsp), %rbx
	movq	%rbx, %rdi
	callq	strlen
.Ltmp124:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movq	%rbx, %rsi
	movq	%rax, %rdx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp125:                               # EH_LABEL
# %bb.166:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit162
.Ltmp126:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movl	$.L.str.9, %esi
	movl	$18, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp127:                               # EH_LABEL
# %bb.167:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit164
	leaq	2208(%rsp), %rbx
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	strlen
.Ltmp128:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movq	%rbx, %rsi
	movq	%rax, %rdx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp129:                               # EH_LABEL
# %bb.168:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit167
.Ltmp130:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movl	$.L.str.10, %esi
	movl	$9, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp131:                               # EH_LABEL
# %bb.169:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit169
	movl	1356(%rsp), %esi
.Ltmp132:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	callq	_ZNSolsEi
.Ltmp133:                               # EH_LABEL
# %bb.170:
.Ltmp134:                               # EH_LABEL
	movq	%rax, %rbx
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.11, %esi
	movl	$10, %edx
	movq	%rax, %rdi
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp135:                               # EH_LABEL
# %bb.171:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit171
	movq	256(%rsp), %rsi
.Ltmp136:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	_ZNSo9_M_insertImEERSoT_
.Ltmp137:                               # EH_LABEL
# %bb.172:                              # %_ZNSolsEm.exit
.Ltmp138:                               # EH_LABEL
	movq	%rax, %rbx
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.12, %esi
	movl	$63, %edx
	movq	%rax, %rdi
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp139:                               # EH_LABEL
# %bb.173:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit174
	movq	(%rbx), %rax
	movq	-24(%rax), %rax
	movq	240(%rbx,%rax), %r14
	testq	%r14, %r14
	je	.LBB1_174
# %bb.176:                              # %_ZSt13__check_facetISt5ctypeIcEERKT_PS3_.exit.i.i
	cmpb	$0, 56(%r14)
	je	.LBB1_178
# %bb.177:
	movzbl	67(%r14), %eax
	jmp	.LBB1_180
.LBB1_178:
.Ltmp140:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	_ZNKSt5ctypeIcE13_M_widen_initEv
.Ltmp141:                               # EH_LABEL
# %bb.179:                              # %.noexc219
	movq	(%r14), %rax
.Ltmp142:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	movl	$10, %esi
	callq	*48(%rax)
.Ltmp143:                               # EH_LABEL
.LBB1_180:                              # %_ZNKSt9basic_iosIcSt11char_traitsIcEE5widenEc.exit.i
.Ltmp144:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movsbl	%al, %esi
	movq	%rbx, %rdi
	callq	_ZNSo3putEc
.Ltmp145:                               # EH_LABEL
# %bb.181:                              # %.noexc221
.Ltmp146:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	_ZNSo5flushEv
.Ltmp147:                               # EH_LABEL
# %bb.182:                              # %_ZNSolsEPFRSoS_E.exit
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
	movq	96(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_184
# %bb.183:
	movq	112(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_184:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit177
	movq	296(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_186
# %bb.185:
.Ltmp148:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp149:                               # EH_LABEL
.LBB1_186:
	movq	328(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_188
# %bb.187:
	movq	344(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_188:                              # %_ZN5TilesD2Ev.exit
	movq	352(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_190
# %bb.189:
.Ltmp151:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp152:                               # EH_LABEL
.LBB1_190:
	movq	384(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_192
# %bb.191:
	movq	400(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_192:                              # %_ZN5TilesD2Ev.exit182
	movq	408(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_194
# %bb.193:
.Ltmp154:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp155:                               # EH_LABEL
.LBB1_194:
	movq	440(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_196
# %bb.195:
	movq	456(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_196:                              # %_ZN5TilesD2Ev.exit185
	movq	240(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_198
# %bb.197:
.Ltmp157:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp158:                               # EH_LABEL
.LBB1_198:
	movq	272(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_200
# %bb.199:
	movq	288(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_200:                              # %_ZN5TilesD2Ev.exit188
	movq	120(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_202
# %bb.201:
	movq	136(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_202:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit190
	movq	144(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_204
# %bb.203:
	movq	160(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_204:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit192
	movq	168(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_206
# %bb.205:
	movq	184(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_206:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit194
	movq	64(%rsp), %rdi
	leaq	80(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_208
# %bb.207:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i195
	movq	80(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_208:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit197
	movq	(%rsp), %rdi
	leaq	16(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_210
# %bb.209:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i198
	movq	16(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_210:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit200
	xorl	%eax, %eax
.LBB1_211:
	addq	$2520, %rsp                     # imm = 0x9D8
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB1_125:
	.cfi_def_cfa_offset 2576
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp79:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%r12d, %edi
	callq	hipGetErrorString
.Ltmp80:                                # EH_LABEL
# %bb.126:
.Ltmp81:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp82:                                # EH_LABEL
# %bb.127:
.Ltmp84:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp85:                                # EH_LABEL
# %bb.128:                              # %.noexc127
.LBB1_44:                               # %.invoke.i.i
.Ltmp175:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.20, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp176:                               # EH_LABEL
# %bb.45:                               # %.cont.i.i
.LBB1_55:                               # %.invoke.i.i89
.Ltmp172:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.20, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp173:                               # EH_LABEL
# %bb.56:                               # %.cont.i.i90
.LBB1_66:                               # %.invoke.i.i103
.Ltmp169:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.20, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp170:                               # EH_LABEL
# %bb.67:                               # %.cont.i.i104
.LBB1_75:
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp50:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.5, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp51:                                # EH_LABEL
# %bb.76:
.Ltmp53:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp54:                                # EH_LABEL
	jmp	.LBB1_240
.LBB1_147:                              # %.invoke.i.i148
.Ltmp163:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.20, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp164:                               # EH_LABEL
# %bb.148:                              # %.cont.i.i149
.LBB1_1:
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp0:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp1:                                 # EH_LABEL
# %bb.2:
.Ltmp3:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp4:                                 # EH_LABEL
	jmp	.LBB1_240
.LBB1_7:
.Ltmp181:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.19, %edi
	callq	_ZSt19__throw_logic_errorPKc
.Ltmp182:                               # EH_LABEL
# %bb.8:                                # %.noexc
.LBB1_17:
.Ltmp178:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.19, %edi
	callq	_ZSt19__throw_logic_errorPKc
.Ltmp179:                               # EH_LABEL
# %bb.18:                               # %.noexc77
.LBB1_28:
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	movl	%eax, %ebx
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp12:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%ebx, %edi
	callq	hipGetErrorString
.Ltmp13:                                # EH_LABEL
# %bb.29:
.Ltmp14:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp15:                                # EH_LABEL
	jmp	.LBB1_30
.LBB1_35:
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp17:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.1, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp18:                                # EH_LABEL
.LBB1_30:                               # %.invoke
.Ltmp20:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp21:                                # EH_LABEL
# %bb.31:                               # %.cont
.LBB1_93:
.Ltmp166:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp167:                               # EH_LABEL
# %bb.94:                               # %.noexc120
.LBB1_113:
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	movl	%eax, %ebx
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp89:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%ebx, %edi
	callq	hipGetErrorString
.Ltmp90:                                # EH_LABEL
# %bb.114:
.Ltmp91:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp92:                                # EH_LABEL
# %bb.115:
.Ltmp94:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp95:                                # EH_LABEL
# %bb.131:                              # %.noexc132
.LBB1_156:
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp117:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.7, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp118:                               # EH_LABEL
# %bb.157:
.Ltmp120:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp121:                               # EH_LABEL
.LBB1_240:
.LBB1_174:
.Ltmp160:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	_ZSt16__throw_bad_castv
.Ltmp161:                               # EH_LABEL
# %bb.175:                              # %.noexc218
.LBB1_163:
.Ltmp119:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_213
.LBB1_39:
.Ltmp19:                                # EH_LABEL
	jmp	.LBB1_33
.LBB1_4:
.Ltmp5:                                 # EH_LABEL
	jmp	.LBB1_5
.LBB1_3:
.Ltmp2:                                 # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_233
.LBB1_244:
.Ltmp159:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_243:
.Ltmp156:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_242:
.Ltmp153:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_241:
.Ltmp150:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_132:
.Ltmp93:                                # EH_LABEL
	jmp	.LBB1_130
.LBB1_32:
.Ltmp16:                                # EH_LABEL
.LBB1_33:                               # %.body
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_229
.LBB1_160:
.Ltmp114:                               # EH_LABEL
	jmp	.LBB1_161
.LBB1_159:
.Ltmp105:                               # EH_LABEL
	jmp	.LBB1_123
.LBB1_120:
.Ltmp69:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_217
# %bb.121:
	movq	480(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
	jmp	.LBB1_217
.LBB1_118:
.Ltmp64:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_218
.LBB1_117:
.Ltmp61:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_219
.LBB1_116:
.Ltmp58:                                # EH_LABEL
	jmp	.LBB1_88
.LBB1_87:
.Ltmp55:                                # EH_LABEL
.LBB1_88:
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_220
.LBB1_86:
.Ltmp52:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_220
.LBB1_83:
.Ltmp49:                                # EH_LABEL
	jmp	.LBB1_84
.LBB1_80:
.Ltmp40:                                # EH_LABEL
	jmp	.LBB1_81
.LBB1_77:
.Ltmp31:                                # EH_LABEL
	jmp	.LBB1_78
.LBB1_37:
.Ltmp180:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_231
.LBB1_36:
.Ltmp183:                               # EH_LABEL
.LBB1_5:
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_233
.LBB1_119:
.Ltmp168:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_217
.LBB1_38:
.Ltmp22:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_229
.LBB1_158:
.Ltmp102:                               # EH_LABEL
	jmp	.LBB1_123
.LBB1_124:                              # %.loopexit.split-lp
.Ltmp86:                                # EH_LABEL
	jmp	.LBB1_123
.LBB1_149:
.Ltmp165:                               # EH_LABEL
.LBB1_161:
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	32(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_214
# %bb.162:                              # %.body150.sink.split
	movq	48(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
	jmp	.LBB1_214
.LBB1_68:
.Ltmp171:                               # EH_LABEL
.LBB1_84:
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_223
# %bb.85:                               # %.body105.sink.split
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	jmp	.LBB1_222
.LBB1_57:
.Ltmp174:                               # EH_LABEL
.LBB1_81:
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_226
# %bb.82:                               # %.body91.sink.split
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	jmp	.LBB1_225
.LBB1_46:
.Ltmp177:                               # EH_LABEL
.LBB1_78:
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_229
# %bb.79:                               # %.body81.sink.split
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	jmp	.LBB1_228
.LBB1_212:
.Ltmp162:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
.LBB1_213:
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
.LBB1_214:
	movq	96(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_216
# %bb.215:
	movq	112(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
	jmp	.LBB1_216
.LBB1_129:
.Ltmp83:                                # EH_LABEL
.LBB1_130:                              # %.body128
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_216
.LBB1_122:                              # %.loopexit
.Ltmp78:                                # EH_LABEL
.LBB1_123:                              # %.body128
	movq	%rdx, %rbx
	movq	%rax, %r14
.LBB1_216:                              # %.body128
	.cfi_escape 0x2e, 0x00
	leaq	296(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_217:
	.cfi_escape 0x2e, 0x00
	leaq	352(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_218:
	.cfi_escape 0x2e, 0x00
	leaq	408(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_219:
	.cfi_escape 0x2e, 0x00
	leaq	240(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_220:
	movq	120(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_223
# %bb.221:
	movq	136(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
.LBB1_222:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit204
	callq	_ZdlPvm
.LBB1_223:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit204
	movq	144(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_226
# %bb.224:
	movq	160(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
.LBB1_225:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit206
	callq	_ZdlPvm
.LBB1_226:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit206
	movq	168(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_229
# %bb.227:
	movq	184(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
.LBB1_228:                              # %.body
	callq	_ZdlPvm
.LBB1_229:                              # %.body
	movq	64(%rsp), %rdi
	leaq	80(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_231
# %bb.230:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i209
	movq	80(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_231:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit211
	movq	(%rsp), %rdi
	leaq	16(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_233
# %bb.232:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE11_M_is_localEv.exit.i.i212
	movq	16(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_233:
	cmpl	$1, %ebx
	jne	.LBB1_238
# %bb.234:
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	__cxa_begin_catch
	movq	(%rax), %rcx
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	*16(%rcx)
.Ltmp184:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cerr, %edi
	movq	%rax, %rsi
	callq	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc
.Ltmp185:                               # EH_LABEL
# %bb.235:
.Ltmp186:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_
.Ltmp187:                               # EH_LABEL
# %bb.236:                              # %_ZNSolsEPFRSoS_E.exit216
	.cfi_escape 0x2e, 0x00
	callq	__cxa_end_catch
	movl	$1, %eax
	jmp	.LBB1_211
.LBB1_237:
.Ltmp188:                               # EH_LABEL
	movq	%rax, %r14
.Ltmp189:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	__cxa_end_catch
.Ltmp190:                               # EH_LABEL
.LBB1_238:
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.LBB1_239:
.Ltmp191:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
	.section	.gcc_except_table,"a",@progbits
	.p2align	2, 0x0
GCC_except_table1:
.Lexception0:
	.byte	255                             # @LPStart Encoding = omit
	.byte	3                               # @TType Encoding = udata4
	.uleb128 .Lttbase0-.Lttbaseref0
.Lttbaseref0:
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Ltmp6-.Lfunc_begin0           # >> Call Site 1 <<
	.uleb128 .Ltmp7-.Ltmp6                  #   Call between .Ltmp6 and .Ltmp7
	.uleb128 .Ltmp183-.Lfunc_begin0         #     jumps to .Ltmp183
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp7-.Lfunc_begin0           # >> Call Site 2 <<
	.uleb128 .Ltmp8-.Ltmp7                  #   Call between .Ltmp7 and .Ltmp8
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp8-.Lfunc_begin0           # >> Call Site 3 <<
	.uleb128 .Ltmp9-.Ltmp8                  #   Call between .Ltmp8 and .Ltmp9
	.uleb128 .Ltmp180-.Lfunc_begin0         #     jumps to .Ltmp180
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp9-.Lfunc_begin0           # >> Call Site 4 <<
	.uleb128 .Ltmp10-.Ltmp9                 #   Call between .Ltmp9 and .Ltmp10
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp10-.Lfunc_begin0          # >> Call Site 5 <<
	.uleb128 .Ltmp11-.Ltmp10                #   Call between .Ltmp10 and .Ltmp11
	.uleb128 .Ltmp22-.Lfunc_begin0          #     jumps to .Ltmp22
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp23-.Lfunc_begin0          # >> Call Site 6 <<
	.uleb128 .Ltmp28-.Ltmp23                #   Call between .Ltmp23 and .Ltmp28
	.uleb128 .Ltmp177-.Lfunc_begin0         #     jumps to .Ltmp177
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp29-.Lfunc_begin0          # >> Call Site 7 <<
	.uleb128 .Ltmp30-.Ltmp29                #   Call between .Ltmp29 and .Ltmp30
	.uleb128 .Ltmp31-.Lfunc_begin0          #     jumps to .Ltmp31
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp32-.Lfunc_begin0          # >> Call Site 8 <<
	.uleb128 .Ltmp37-.Ltmp32                #   Call between .Ltmp32 and .Ltmp37
	.uleb128 .Ltmp174-.Lfunc_begin0         #     jumps to .Ltmp174
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp38-.Lfunc_begin0          # >> Call Site 9 <<
	.uleb128 .Ltmp39-.Ltmp38                #   Call between .Ltmp38 and .Ltmp39
	.uleb128 .Ltmp40-.Lfunc_begin0          #     jumps to .Ltmp40
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp41-.Lfunc_begin0          # >> Call Site 10 <<
	.uleb128 .Ltmp46-.Ltmp41                #   Call between .Ltmp41 and .Ltmp46
	.uleb128 .Ltmp171-.Lfunc_begin0         #     jumps to .Ltmp171
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp47-.Lfunc_begin0          # >> Call Site 11 <<
	.uleb128 .Ltmp48-.Ltmp47                #   Call between .Ltmp47 and .Ltmp48
	.uleb128 .Ltmp49-.Lfunc_begin0          #     jumps to .Ltmp49
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp56-.Lfunc_begin0          # >> Call Site 12 <<
	.uleb128 .Ltmp57-.Ltmp56                #   Call between .Ltmp56 and .Ltmp57
	.uleb128 .Ltmp58-.Lfunc_begin0          #     jumps to .Ltmp58
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp59-.Lfunc_begin0          # >> Call Site 13 <<
	.uleb128 .Ltmp60-.Ltmp59                #   Call between .Ltmp59 and .Ltmp60
	.uleb128 .Ltmp61-.Lfunc_begin0          #     jumps to .Ltmp61
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp62-.Lfunc_begin0          # >> Call Site 14 <<
	.uleb128 .Ltmp63-.Ltmp62                #   Call between .Ltmp62 and .Ltmp63
	.uleb128 .Ltmp64-.Lfunc_begin0          #     jumps to .Ltmp64
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp65-.Lfunc_begin0          # >> Call Site 15 <<
	.uleb128 .Ltmp66-.Ltmp65                #   Call between .Ltmp65 and .Ltmp66
	.uleb128 .Ltmp168-.Lfunc_begin0         #     jumps to .Ltmp168
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp66-.Lfunc_begin0          # >> Call Site 16 <<
	.uleb128 .Ltmp67-.Ltmp66                #   Call between .Ltmp66 and .Ltmp67
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp67-.Lfunc_begin0          # >> Call Site 17 <<
	.uleb128 .Ltmp68-.Ltmp67                #   Call between .Ltmp67 and .Ltmp68
	.uleb128 .Ltmp69-.Lfunc_begin0          #     jumps to .Ltmp69
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp70-.Lfunc_begin0          # >> Call Site 18 <<
	.uleb128 .Ltmp77-.Ltmp70                #   Call between .Ltmp70 and .Ltmp77
	.uleb128 .Ltmp78-.Lfunc_begin0          #     jumps to .Ltmp78
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp87-.Lfunc_begin0          # >> Call Site 19 <<
	.uleb128 .Ltmp101-.Ltmp87               #   Call between .Ltmp87 and .Ltmp101
	.uleb128 .Ltmp102-.Lfunc_begin0         #     jumps to .Ltmp102
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp103-.Lfunc_begin0         # >> Call Site 20 <<
	.uleb128 .Ltmp104-.Ltmp103              #   Call between .Ltmp103 and .Ltmp104
	.uleb128 .Ltmp105-.Lfunc_begin0         #     jumps to .Ltmp105
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp106-.Lfunc_begin0         # >> Call Site 21 <<
	.uleb128 .Ltmp111-.Ltmp106              #   Call between .Ltmp106 and .Ltmp111
	.uleb128 .Ltmp165-.Lfunc_begin0         #     jumps to .Ltmp165
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp112-.Lfunc_begin0         # >> Call Site 22 <<
	.uleb128 .Ltmp113-.Ltmp112              #   Call between .Ltmp112 and .Ltmp113
	.uleb128 .Ltmp114-.Lfunc_begin0         #     jumps to .Ltmp114
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp115-.Lfunc_begin0         # >> Call Site 23 <<
	.uleb128 .Ltmp147-.Ltmp115              #   Call between .Ltmp115 and .Ltmp147
	.uleb128 .Ltmp162-.Lfunc_begin0         #     jumps to .Ltmp162
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp148-.Lfunc_begin0         # >> Call Site 24 <<
	.uleb128 .Ltmp149-.Ltmp148              #   Call between .Ltmp148 and .Ltmp149
	.uleb128 .Ltmp150-.Lfunc_begin0         #     jumps to .Ltmp150
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp151-.Lfunc_begin0         # >> Call Site 25 <<
	.uleb128 .Ltmp152-.Ltmp151              #   Call between .Ltmp151 and .Ltmp152
	.uleb128 .Ltmp153-.Lfunc_begin0         #     jumps to .Ltmp153
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp154-.Lfunc_begin0         # >> Call Site 26 <<
	.uleb128 .Ltmp155-.Ltmp154              #   Call between .Ltmp154 and .Ltmp155
	.uleb128 .Ltmp156-.Lfunc_begin0         #     jumps to .Ltmp156
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp157-.Lfunc_begin0         # >> Call Site 27 <<
	.uleb128 .Ltmp158-.Ltmp157              #   Call between .Ltmp157 and .Ltmp158
	.uleb128 .Ltmp159-.Lfunc_begin0         #     jumps to .Ltmp159
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp158-.Lfunc_begin0         # >> Call Site 28 <<
	.uleb128 .Ltmp79-.Ltmp158               #   Call between .Ltmp158 and .Ltmp79
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp79-.Lfunc_begin0          # >> Call Site 29 <<
	.uleb128 .Ltmp82-.Ltmp79                #   Call between .Ltmp79 and .Ltmp82
	.uleb128 .Ltmp83-.Lfunc_begin0          #     jumps to .Ltmp83
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp84-.Lfunc_begin0          # >> Call Site 30 <<
	.uleb128 .Ltmp85-.Ltmp84                #   Call between .Ltmp84 and .Ltmp85
	.uleb128 .Ltmp86-.Lfunc_begin0          #     jumps to .Ltmp86
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp175-.Lfunc_begin0         # >> Call Site 31 <<
	.uleb128 .Ltmp176-.Ltmp175              #   Call between .Ltmp175 and .Ltmp176
	.uleb128 .Ltmp177-.Lfunc_begin0         #     jumps to .Ltmp177
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp172-.Lfunc_begin0         # >> Call Site 32 <<
	.uleb128 .Ltmp173-.Ltmp172              #   Call between .Ltmp172 and .Ltmp173
	.uleb128 .Ltmp174-.Lfunc_begin0         #     jumps to .Ltmp174
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp169-.Lfunc_begin0         # >> Call Site 33 <<
	.uleb128 .Ltmp170-.Ltmp169              #   Call between .Ltmp169 and .Ltmp170
	.uleb128 .Ltmp171-.Lfunc_begin0         #     jumps to .Ltmp171
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp170-.Lfunc_begin0         # >> Call Site 34 <<
	.uleb128 .Ltmp50-.Ltmp170               #   Call between .Ltmp170 and .Ltmp50
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp50-.Lfunc_begin0          # >> Call Site 35 <<
	.uleb128 .Ltmp51-.Ltmp50                #   Call between .Ltmp50 and .Ltmp51
	.uleb128 .Ltmp52-.Lfunc_begin0          #     jumps to .Ltmp52
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp53-.Lfunc_begin0          # >> Call Site 36 <<
	.uleb128 .Ltmp54-.Ltmp53                #   Call between .Ltmp53 and .Ltmp54
	.uleb128 .Ltmp55-.Lfunc_begin0          #     jumps to .Ltmp55
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp163-.Lfunc_begin0         # >> Call Site 37 <<
	.uleb128 .Ltmp164-.Ltmp163              #   Call between .Ltmp163 and .Ltmp164
	.uleb128 .Ltmp165-.Lfunc_begin0         #     jumps to .Ltmp165
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp164-.Lfunc_begin0         # >> Call Site 38 <<
	.uleb128 .Ltmp0-.Ltmp164                #   Call between .Ltmp164 and .Ltmp0
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp0-.Lfunc_begin0           # >> Call Site 39 <<
	.uleb128 .Ltmp1-.Ltmp0                  #   Call between .Ltmp0 and .Ltmp1
	.uleb128 .Ltmp2-.Lfunc_begin0           #     jumps to .Ltmp2
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp3-.Lfunc_begin0           # >> Call Site 40 <<
	.uleb128 .Ltmp4-.Ltmp3                  #   Call between .Ltmp3 and .Ltmp4
	.uleb128 .Ltmp5-.Lfunc_begin0           #     jumps to .Ltmp5
	.byte	5                               #   On action: 3
	.uleb128 .Ltmp181-.Lfunc_begin0         # >> Call Site 41 <<
	.uleb128 .Ltmp182-.Ltmp181              #   Call between .Ltmp181 and .Ltmp182
	.uleb128 .Ltmp183-.Lfunc_begin0         #     jumps to .Ltmp183
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp178-.Lfunc_begin0         # >> Call Site 42 <<
	.uleb128 .Ltmp179-.Ltmp178              #   Call between .Ltmp178 and .Ltmp179
	.uleb128 .Ltmp180-.Lfunc_begin0         #     jumps to .Ltmp180
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp179-.Lfunc_begin0         # >> Call Site 43 <<
	.uleb128 .Ltmp12-.Ltmp179               #   Call between .Ltmp179 and .Ltmp12
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp12-.Lfunc_begin0          # >> Call Site 44 <<
	.uleb128 .Ltmp15-.Ltmp12                #   Call between .Ltmp12 and .Ltmp15
	.uleb128 .Ltmp16-.Lfunc_begin0          #     jumps to .Ltmp16
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp15-.Lfunc_begin0          # >> Call Site 45 <<
	.uleb128 .Ltmp17-.Ltmp15                #   Call between .Ltmp15 and .Ltmp17
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp17-.Lfunc_begin0          # >> Call Site 46 <<
	.uleb128 .Ltmp18-.Ltmp17                #   Call between .Ltmp17 and .Ltmp18
	.uleb128 .Ltmp19-.Lfunc_begin0          #     jumps to .Ltmp19
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp20-.Lfunc_begin0          # >> Call Site 47 <<
	.uleb128 .Ltmp21-.Ltmp20                #   Call between .Ltmp20 and .Ltmp21
	.uleb128 .Ltmp22-.Lfunc_begin0          #     jumps to .Ltmp22
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp166-.Lfunc_begin0         # >> Call Site 48 <<
	.uleb128 .Ltmp167-.Ltmp166              #   Call between .Ltmp166 and .Ltmp167
	.uleb128 .Ltmp168-.Lfunc_begin0         #     jumps to .Ltmp168
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp167-.Lfunc_begin0         # >> Call Site 49 <<
	.uleb128 .Ltmp89-.Ltmp167               #   Call between .Ltmp167 and .Ltmp89
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp89-.Lfunc_begin0          # >> Call Site 50 <<
	.uleb128 .Ltmp92-.Ltmp89                #   Call between .Ltmp89 and .Ltmp92
	.uleb128 .Ltmp93-.Lfunc_begin0          #     jumps to .Ltmp93
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp94-.Lfunc_begin0          # >> Call Site 51 <<
	.uleb128 .Ltmp95-.Ltmp94                #   Call between .Ltmp94 and .Ltmp95
	.uleb128 .Ltmp102-.Lfunc_begin0         #     jumps to .Ltmp102
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp95-.Lfunc_begin0          # >> Call Site 52 <<
	.uleb128 .Ltmp117-.Ltmp95               #   Call between .Ltmp95 and .Ltmp117
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp117-.Lfunc_begin0         # >> Call Site 53 <<
	.uleb128 .Ltmp118-.Ltmp117              #   Call between .Ltmp117 and .Ltmp118
	.uleb128 .Ltmp119-.Lfunc_begin0         #     jumps to .Ltmp119
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp120-.Lfunc_begin0         # >> Call Site 54 <<
	.uleb128 .Ltmp161-.Ltmp120              #   Call between .Ltmp120 and .Ltmp161
	.uleb128 .Ltmp162-.Lfunc_begin0         #     jumps to .Ltmp162
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp161-.Lfunc_begin0         # >> Call Site 55 <<
	.uleb128 .Ltmp184-.Ltmp161              #   Call between .Ltmp161 and .Ltmp184
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp184-.Lfunc_begin0         # >> Call Site 56 <<
	.uleb128 .Ltmp187-.Ltmp184              #   Call between .Ltmp184 and .Ltmp187
	.uleb128 .Ltmp188-.Lfunc_begin0         #     jumps to .Ltmp188
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp187-.Lfunc_begin0         # >> Call Site 57 <<
	.uleb128 .Ltmp189-.Ltmp187              #   Call between .Ltmp187 and .Ltmp189
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp189-.Lfunc_begin0         # >> Call Site 58 <<
	.uleb128 .Ltmp190-.Ltmp189              #   Call between .Ltmp189 and .Ltmp190
	.uleb128 .Ltmp191-.Lfunc_begin0         #     jumps to .Ltmp191
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp190-.Lfunc_begin0         # >> Call Site 59 <<
	.uleb128 .Lfunc_end1-.Ltmp190           #   Call between .Ltmp190 and .Lfunc_end1
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end0:
	.byte	0                               # >> Action Record 1 <<
                                        #   Cleanup
	.byte	0                               #   No further actions
	.byte	1                               # >> Action Record 2 <<
                                        #   Catch TypeInfo 1
	.byte	125                             #   Continue to action 1
	.byte	1                               # >> Action Record 3 <<
                                        #   Catch TypeInfo 1
	.byte	0                               #   No further actions
	.byte	2                               # >> Action Record 4 <<
                                        #   Catch TypeInfo 2
	.byte	0                               #   No further actions
	.p2align	2, 0x0
                                        # >> Catch TypeInfos <<
	.long	0                               # TypeInfo 2
	.long	_ZTISt9exception                # TypeInfo 1
.Lttbase0:
	.p2align	2, 0x0
                                        # -- End function
	.text
	.p2align	4                               # -- Begin function _ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,@function
_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE: # @_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception1
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$520, %rsp                      # imm = 0x208
	.cfi_def_cfa_offset 560
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %r15
	movq	%rsp, %rdi
	movl	$6, %edx
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEEC1ERKNSt7__cxx1112basic_stringIcS1_SaIcEEESt13_Ios_Openmode
	movq	(%rsp), %rax
	movq	-24(%rax), %rax
	testb	$5, 32(%rsp,%rax)
	jne	.LBB2_12
# %bb.1:
.Ltmp198:                               # EH_LABEL
	movq	%rsp, %rdi
	callq	_ZNSi5tellgEv
.Ltmp199:                               # EH_LABEL
# %bb.2:
.Ltmp201:                               # EH_LABEL
	movq	%rax, %r12
	movq	%rsp, %rdi
	xorl	%esi, %esi
	xorl	%edx, %edx
	callq	_ZNSi5seekgESt4fposI11__mbstate_tE
.Ltmp202:                               # EH_LABEL
# %bb.3:
	testq	%r12, %r12
	js	.LBB2_14
# %bb.4:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r15)
	movq	$0, 16(%r15)
	je	.LBB2_8
# %bb.5:
.Ltmp204:                               # EH_LABEL
	movq	%r12, %rdi
	callq	_Znwm
.Ltmp205:                               # EH_LABEL
# %bb.6:                                # %.noexc12
	movq	%rax, %rbx
	movq	%rax, (%r15)
	leaq	(%rax,%r12), %r14
	movq	%r14, 16(%r15)
	movb	$0, (%rax)
	movq	%rax, %rdi
	incq	%rdi
	movq	%r12, %rdx
	decq	%rdx
	je	.LBB2_9
# %bb.7:
	xorl	%esi, %esi
	callq	memset@PLT
	movq	%r14, %rdi
	jmp	.LBB2_9
.LBB2_8:
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	xorl	%edi, %edi
.LBB2_9:                                # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i
	movq	%rdi, 8(%r15)
.Ltmp206:                               # EH_LABEL
	movq	%rsp, %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	callq	_ZNSi4readEPcl
.Ltmp207:                               # EH_LABEL
# %bb.10:
	movq	(%rsp), %rax
	movq	-24(%rax), %rax
	testb	$5, 32(%rsp,%rax)
	jne	.LBB2_16
# %bb.11:
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	addq	$520, %rsp                      # imm = 0x208
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB2_12:
	.cfi_def_cfa_offset 560
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %rbx
.Ltmp192:                               # EH_LABEL
	movl	$.L.str.13, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp193:                               # EH_LABEL
# %bb.13:
.Ltmp195:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%rbx, %rdi
	callq	__cxa_throw
.Ltmp196:                               # EH_LABEL
	jmp	.LBB2_18
.LBB2_14:
.Ltmp214:                               # EH_LABEL
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp215:                               # EH_LABEL
# %bb.15:                               # %.noexc
.LBB2_16:
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r12
.Ltmp208:                               # EH_LABEL
	movl	$.L.str.14, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp209:                               # EH_LABEL
# %bb.17:
.Ltmp211:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r12, %rdi
	callq	__cxa_throw
.Ltmp212:                               # EH_LABEL
.LBB2_18:
.LBB2_19:
.Ltmp210:                               # EH_LABEL
	movq	%rax, %r15
	movq	%r12, %rdi
	callq	__cxa_free_exception
	jmp	.LBB2_26
.LBB2_20:
.Ltmp197:                               # EH_LABEL
	jmp	.LBB2_21
.LBB2_22:
.Ltmp194:                               # EH_LABEL
	movq	%rax, %r15
	movq	%rbx, %rdi
	callq	__cxa_free_exception
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_23:
.Ltmp203:                               # EH_LABEL
	jmp	.LBB2_21
.LBB2_24:
.Ltmp200:                               # EH_LABEL
.LBB2_21:
	movq	%rax, %r15
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_25:
.Ltmp213:                               # EH_LABEL
	movq	%rax, %r15
.LBB2_26:
	testq	%rbx, %rbx
	je	.LBB2_29
# %bb.27:
	subq	%rbx, %r14
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	_ZdlPvm
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_28:
.Ltmp216:                               # EH_LABEL
	movq	%rax, %r15
.LBB2_29:                               # %_ZNSt6vectorIcSaIcEED2Ev.exit
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end2:
	.size	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .Lfunc_end2-_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.cfi_endproc
	.section	.gcc_except_table,"a",@progbits
	.p2align	2, 0x0
GCC_except_table2:
.Lexception1:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Lfunc_begin1-.Lfunc_begin1    # >> Call Site 1 <<
	.uleb128 .Ltmp198-.Lfunc_begin1         #   Call between .Lfunc_begin1 and .Ltmp198
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp198-.Lfunc_begin1         # >> Call Site 2 <<
	.uleb128 .Ltmp199-.Ltmp198              #   Call between .Ltmp198 and .Ltmp199
	.uleb128 .Ltmp200-.Lfunc_begin1         #     jumps to .Ltmp200
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp201-.Lfunc_begin1         # >> Call Site 3 <<
	.uleb128 .Ltmp202-.Ltmp201              #   Call between .Ltmp201 and .Ltmp202
	.uleb128 .Ltmp203-.Lfunc_begin1         #     jumps to .Ltmp203
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp204-.Lfunc_begin1         # >> Call Site 4 <<
	.uleb128 .Ltmp205-.Ltmp204              #   Call between .Ltmp204 and .Ltmp205
	.uleb128 .Ltmp216-.Lfunc_begin1         #     jumps to .Ltmp216
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp205-.Lfunc_begin1         # >> Call Site 5 <<
	.uleb128 .Ltmp206-.Ltmp205              #   Call between .Ltmp205 and .Ltmp206
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp206-.Lfunc_begin1         # >> Call Site 6 <<
	.uleb128 .Ltmp207-.Ltmp206              #   Call between .Ltmp206 and .Ltmp207
	.uleb128 .Ltmp213-.Lfunc_begin1         #     jumps to .Ltmp213
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp207-.Lfunc_begin1         # >> Call Site 7 <<
	.uleb128 .Ltmp192-.Ltmp207              #   Call between .Ltmp207 and .Ltmp192
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp192-.Lfunc_begin1         # >> Call Site 8 <<
	.uleb128 .Ltmp193-.Ltmp192              #   Call between .Ltmp192 and .Ltmp193
	.uleb128 .Ltmp194-.Lfunc_begin1         #     jumps to .Ltmp194
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp195-.Lfunc_begin1         # >> Call Site 9 <<
	.uleb128 .Ltmp196-.Ltmp195              #   Call between .Ltmp195 and .Ltmp196
	.uleb128 .Ltmp197-.Lfunc_begin1         #     jumps to .Ltmp197
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp214-.Lfunc_begin1         # >> Call Site 10 <<
	.uleb128 .Ltmp215-.Ltmp214              #   Call between .Ltmp214 and .Ltmp215
	.uleb128 .Ltmp216-.Lfunc_begin1         #     jumps to .Ltmp216
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp215-.Lfunc_begin1         # >> Call Site 11 <<
	.uleb128 .Ltmp208-.Ltmp215              #   Call between .Ltmp215 and .Ltmp208
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp208-.Lfunc_begin1         # >> Call Site 12 <<
	.uleb128 .Ltmp209-.Ltmp208              #   Call between .Ltmp208 and .Ltmp209
	.uleb128 .Ltmp210-.Lfunc_begin1         #     jumps to .Ltmp210
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp211-.Lfunc_begin1         # >> Call Site 13 <<
	.uleb128 .Ltmp212-.Ltmp211              #   Call between .Ltmp211 and .Ltmp212
	.uleb128 .Ltmp213-.Lfunc_begin1         #     jumps to .Ltmp213
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp212-.Lfunc_begin1         # >> Call Site 14 <<
	.uleb128 .Lfunc_end2-.Ltmp212           #   Call between .Ltmp212 and .Lfunc_end2
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end1:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN5TilesC2ERKSt6vectorIcSaIcEEm,"axG",@progbits,_ZN5TilesC2ERKSt6vectorIcSaIcEEm,comdat
	.weak	_ZN5TilesC2ERKSt6vectorIcSaIcEEm # -- Begin function _ZN5TilesC2ERKSt6vectorIcSaIcEEm
	.p2align	4
	.type	_ZN5TilesC2ERKSt6vectorIcSaIcEEm,@function
_ZN5TilesC2ERKSt6vectorIcSaIcEEm:       # @_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception2
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r15
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	$0, (%rdi)
	movq	%rdx, 8(%rdi)
	movq	8(%rsi), %rsi
	subq	(%r14), %rsi
	movq	%rsi, %rax
	orq	%rdx, %rax
	shrq	$32, %rax
	je	.LBB3_1
# %bb.2:
	movq	%rsi, %rax
	xorl	%edx, %edx
	divq	%r15
	movq	%rax, %r12
	jmp	.LBB3_3
.LBB3_1:
	movl	%esi, %eax
	xorl	%edx, %edx
	divl	%r15d
	movl	%eax, %r12d
.LBB3_3:
	movq	%r12, 16(%rbx)
	leaq	256(%r15), %rax
	movq	%rax, 24(%rbx)
	imulq	%rax, %r12
	testq	%r12, %r12
	js	.LBB3_36
# %bb.4:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	leaq	32(%rbx), %rax
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%rax)
	movq	$0, 16(%rax)
	testq	%r12, %r12
	je	.LBB3_5
# %bb.6:                                # %.noexc18
	movq	%r12, %rdi
	movq	%rsi, (%rsp)                    # 8-byte Spill
	callq	_Znwm
	movq	%rax, %r13
	movq	%rax, 32(%rbx)
	movq	%rax, 40(%rbx)
	leaq	(%rax,%r12), %rbp
	movq	%rbp, 48(%rbx)
	movq	%rax, %rdi
	movl	$90, %esi
	movq	%r12, %rdx
	callq	memset@PLT
	leaq	40(%rbx), %rax
	movq	(%rsp), %rsi                    # 8-byte Reload
	jmp	.LBB3_7
.LBB3_5:                                # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i
	leaq	40(%rbx), %rax
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
.LBB3_7:
	movq	%rbp, (%rax)
	movq	(%r14), %rcx
	movq	8(%r14), %rax
	cmpq	%rax, %rcx
	je	.LBB3_20
# %bb.8:
	subq	%rcx, %rax
	movq	%rax, %rcx
	orq	%r15, %rcx
	shrq	$32, %rcx
	je	.LBB3_9
# %bb.10:
	xorl	%edx, %edx
	divq	%r15
	testq	%rdx, %rdx
	jne	.LBB3_20
.LBB3_12:                               # %.preheader
	cmpq	%rsi, %r15
	ja	.LBB3_16
# %bb.13:                               # %.lr.ph.preheader
	xorl	%r15d, %r15d
	.p2align	4
.LBB3_14:                               # %.lr.ph
                                        # =>This Inner Loop Header: Depth=1
	movq	8(%rbx), %rdx
	movq	32(%rbx), %rax
	movq	24(%rbx), %rcx
	imulq	%r15, %rcx
	leaq	(%rax,%rcx), %rdi
	addq	$128, %rdi
	movq	%rdx, %rsi
	imulq	%r15, %rsi
	addq	(%r14), %rsi
	callq	memcpy@PLT
	incq	%r15
	cmpq	16(%rbx), %r15
	jb	.LBB3_14
# %bb.15:                               # %._crit_edge.loopexit
	movq	32(%rbx), %r13
	movq	40(%rbx), %rbp
.LBB3_16:                               # %._crit_edge
	subq	%r13, %rbp
.Ltmp217:                               # EH_LABEL
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	callq	hipMalloc
.Ltmp218:                               # EH_LABEL
# %bb.17:
	testl	%eax, %eax
	jne	.LBB3_18
# %bb.24:                               # %_ZL5check10hipError_t.exit
	movq	(%rbx), %rdi
	movq	32(%rbx), %rsi
	movq	40(%rbx), %rdx
	subq	%rsi, %rdx
.Ltmp224:                               # EH_LABEL
	movl	$1, %ecx
	callq	hipMemcpy
.Ltmp225:                               # EH_LABEL
# %bb.25:
	testl	%eax, %eax
	jne	.LBB3_26
# %bb.31:                               # %_ZL5check10hipError_t.exit24
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB3_9:
	.cfi_def_cfa_offset 64
                                        # kill: def $eax killed $eax killed $rax
	xorl	%edx, %edx
	divl	%r15d
                                        # kill: def $edx killed $edx def $rdx
	testq	%rdx, %rdx
	je	.LBB3_12
.LBB3_20:
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r14
.Ltmp231:                               # EH_LABEL
	movl	$.L.str.16, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp232:                               # EH_LABEL
.LBB3_28:                               # %.invoke
.Ltmp234:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r14, %rdi
	callq	__cxa_throw
.Ltmp235:                               # EH_LABEL
# %bb.29:                               # %.cont
.LBB3_36:                               # %.noexc
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.LBB3_18:
	movl	$16, %edi
	movl	%eax, %ebp
	callq	__cxa_allocate_exception
	movq	%rax, %r14
.Ltmp219:                               # EH_LABEL
	movl	%ebp, %edi
	callq	hipGetErrorString
.Ltmp220:                               # EH_LABEL
# %bb.19:
.Ltmp221:                               # EH_LABEL
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp222:                               # EH_LABEL
	jmp	.LBB3_28
.LBB3_26:
	movl	$16, %edi
	movl	%eax, %ebp
	callq	__cxa_allocate_exception
	movq	%rax, %r14
.Ltmp226:                               # EH_LABEL
	movl	%ebp, %edi
	callq	hipGetErrorString
.Ltmp227:                               # EH_LABEL
# %bb.27:
.Ltmp228:                               # EH_LABEL
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp229:                               # EH_LABEL
	jmp	.LBB3_28
.LBB3_30:
.Ltmp230:                               # EH_LABEL
	jmp	.LBB3_22
.LBB3_23:
.Ltmp223:                               # EH_LABEL
	jmp	.LBB3_22
.LBB3_21:
.Ltmp233:                               # EH_LABEL
.LBB3_22:                               # %.body
	movq	%rax, %r15
	movq	%r14, %rdi
	callq	__cxa_free_exception
	jmp	.LBB3_33
.LBB3_32:
.Ltmp236:                               # EH_LABEL
	movq	%rax, %r15
.LBB3_33:                               # %.body
	leaq	32(%rbx), %rax
	movq	(%rax), %rdi
	testq	%rdi, %rdi
	je	.LBB3_35
# %bb.34:
	movq	48(%rbx), %rsi
	subq	%rdi, %rsi
	callq	_ZdlPvm
.LBB3_35:                               # %_ZNSt6vectorIcSaIcEED2Ev.exit
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end3:
	.size	_ZN5TilesC2ERKSt6vectorIcSaIcEEm, .Lfunc_end3-_ZN5TilesC2ERKSt6vectorIcSaIcEEm
	.cfi_endproc
	.section	.gcc_except_table._ZN5TilesC2ERKSt6vectorIcSaIcEEm,"aG",@progbits,_ZN5TilesC2ERKSt6vectorIcSaIcEEm,comdat
	.p2align	2, 0x0
GCC_except_table3:
.Lexception2:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end2-.Lcst_begin2
.Lcst_begin2:
	.uleb128 .Lfunc_begin2-.Lfunc_begin2    # >> Call Site 1 <<
	.uleb128 .Ltmp217-.Lfunc_begin2         #   Call between .Lfunc_begin2 and .Ltmp217
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp217-.Lfunc_begin2         # >> Call Site 2 <<
	.uleb128 .Ltmp225-.Ltmp217              #   Call between .Ltmp217 and .Ltmp225
	.uleb128 .Ltmp236-.Lfunc_begin2         #     jumps to .Ltmp236
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp225-.Lfunc_begin2         # >> Call Site 3 <<
	.uleb128 .Ltmp231-.Ltmp225              #   Call between .Ltmp225 and .Ltmp231
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp231-.Lfunc_begin2         # >> Call Site 4 <<
	.uleb128 .Ltmp232-.Ltmp231              #   Call between .Ltmp231 and .Ltmp232
	.uleb128 .Ltmp233-.Lfunc_begin2         #     jumps to .Ltmp233
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp234-.Lfunc_begin2         # >> Call Site 5 <<
	.uleb128 .Ltmp235-.Ltmp234              #   Call between .Ltmp234 and .Ltmp235
	.uleb128 .Ltmp236-.Lfunc_begin2         #     jumps to .Ltmp236
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp235-.Lfunc_begin2         # >> Call Site 6 <<
	.uleb128 .Ltmp219-.Ltmp235              #   Call between .Ltmp235 and .Ltmp219
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp219-.Lfunc_begin2         # >> Call Site 7 <<
	.uleb128 .Ltmp222-.Ltmp219              #   Call between .Ltmp219 and .Ltmp222
	.uleb128 .Ltmp223-.Lfunc_begin2         #     jumps to .Ltmp223
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp222-.Lfunc_begin2         # >> Call Site 8 <<
	.uleb128 .Ltmp226-.Ltmp222              #   Call between .Ltmp222 and .Ltmp226
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp226-.Lfunc_begin2         # >> Call Site 9 <<
	.uleb128 .Ltmp229-.Ltmp226              #   Call between .Ltmp226 and .Ltmp229
	.uleb128 .Ltmp230-.Lfunc_begin2         #     jumps to .Ltmp230
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp229-.Lfunc_begin2         # >> Call Site 10 <<
	.uleb128 .Lfunc_end3-.Ltmp229           #   Call between .Ltmp229 and .Lfunc_end3
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end2:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN5Tiles6verifyEb,"axG",@progbits,_ZN5Tiles6verifyEb,comdat
	.weak	_ZN5Tiles6verifyEb              # -- Begin function _ZN5Tiles6verifyEb
	.p2align	4
	.type	_ZN5Tiles6verifyEb,@function
_ZN5Tiles6verifyEb:                     # @_ZN5Tiles6verifyEb
.Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception3
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	32(%rsi), %rax
	movq	40(%rsi), %r15
	subq	%rax, %r15
	js	.LBB4_50
# %bb.1:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	movl	%edx, %r14d
	movq	%rsi, %rbp
	movq	%rdi, %r12
	movl	%edx, 8(%rsp)                   # 4-byte Spill
	je	.LBB4_2
# %bb.3:                                # %.noexc25
	movq	%r15, %rdi
	callq	_Znwm
	movq	%rax, %r13
	leaq	(%rax,%r15), %r14
	movb	$0, (%rax)
	movq	%rax, %rbx
	incq	%rbx
	decq	%r15
	movq	%r14, 24(%rsp)                  # 8-byte Spill
	je	.LBB4_5
# %bb.4:
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	memset@PLT
	movq	%r14, %rbx
.LBB4_5:                                # %_ZNSt6vectorIcSaIcEEC2EmRKS0_.exit
	movl	8(%rsp), %r14d                  # 4-byte Reload
	jmp	.LBB4_6
.LBB4_2:
	movq	$0, 24(%rsp)                    # 8-byte Folded Spill
	xorl	%r13d, %r13d
	xorl	%ebx, %ebx
.LBB4_6:                                # %_ZNSt6vectorIcSaIcEEC2EmRKS0_.exit
	movq	8(%rbp), %r15
	imulq	16(%rbp), %r15
	testq	%r15, %r15
	movq	%r13, 32(%rsp)                  # 8-byte Spill
	js	.LBB4_7
# %bb.9:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i26
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r12)
	movq	$0, 16(%r12)
	je	.LBB4_10
# %bb.11:
.Ltmp237:                               # EH_LABEL
	movq	%r15, %rdi
	callq	_Znwm
.Ltmp238:                               # EH_LABEL
# %bb.12:                               # %.noexc31
	movq	%rax, (%r12)
	movq	%r12, %rcx
	leaq	(%rax,%r15), %r12
	movq	%rcx, %r14
	movq	%r12, 16(%rcx)
	movb	$0, (%rax)
	movq	%rax, %rdi
	incq	%rdi
	decq	%r15
	movq	%rax, 16(%rsp)                  # 8-byte Spill
	movq	%r12, 40(%rsp)                  # 8-byte Spill
	je	.LBB4_14
# %bb.13:
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	memset@PLT
	movq	%r12, %rdi
.LBB4_14:                               # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i29
	movq	%r14, %r12
	movl	8(%rsp), %r14d                  # 4-byte Reload
	jmp	.LBB4_15
.LBB4_10:
	movq	$0, 40(%rsp)                    # 8-byte Folded Spill
	movq	$0, 16(%rsp)                    # 8-byte Folded Spill
	xorl	%edi, %edi
.LBB4_15:                               # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i29
	movq	%r12, 48(%rsp)                  # 8-byte Spill
	movq	%rdi, 8(%r12)
	movq	(%rbp), %rsi
	movq	%rbx, %r15
	subq	%r13, %r15
.Ltmp239:                               # EH_LABEL
	movq	%r13, %rdi
	movq	%r15, %rdx
	movl	$2, %ecx
	callq	hipMemcpy
.Ltmp240:                               # EH_LABEL
# %bb.16:
	movl	%eax, %r12d
	testl	%eax, %eax
	jne	.LBB4_17
# %bb.23:                               # %_ZL5check10hipError_t.exit
	testb	%r14b, %r14b
	je	.LBB4_30
# %bb.24:
	movq	32(%rbp), %rsi
	movq	40(%rbp), %rax
	subq	%rsi, %rax
	cmpq	%rax, %r15
	jne	.LBB4_27
# %bb.25:
	cmpq	%r13, %rbx
	je	.LBB4_30
# %bb.26:                               # %_ZStneIcSaIcEEbRKSt6vectorIT_T0_ES6_.exit
	movq	%r13, %rdi
	movq	%r15, %rdx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB4_27
.LBB4_30:                               # %_ZStneIcSaIcEEbRKSt6vectorIT_T0_ES6_.exit.thread52
	movq	16(%rbp), %rax
	movq	%rax, 8(%rsp)                   # 8-byte Spill
	testq	%rax, %rax
	je	.LBB4_39
# %bb.31:                               # %.lr.ph
	movq	8(%rbp), %r14
	movq	%r13, %rax
	movq	24(%rbp), %r13
	movq	32(%rbp), %r12
	xorl	%ebx, %ebx
	movq	%rax, %rbp
	movq	16(%rsp), %r15                  # 8-byte Reload
	.p2align	4
.LBB4_32:                               # =>This Inner Loop Header: Depth=1
	movl	$128, %edx
	movq	%rbp, %rdi
	movq	%r12, %rsi
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB4_34
# %bb.33:                               #   in Loop: Header=BB4_32 Depth=1
	leaq	128(%r14), %rax
	leaq	(%rax,%rbp), %rdi
	leaq	(%r12,%rax), %rsi
	movl	$128, %edx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB4_34
# %bb.38:                               #   in Loop: Header=BB4_32 Depth=1
	leaq	128(%rbp), %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	memcpy@PLT
	incq	%rbx
	addq	%r14, %r15
	addq	%r13, %rbp
	addq	%r13, %r12
	cmpq	8(%rsp), %rbx                   # 8-byte Folded Reload
	jb	.LBB4_32
	jmp	.LBB4_40
.LBB4_39:                               # %._crit_edge
	testq	%r13, %r13
	je	.LBB4_41
.LBB4_40:                               # %._crit_edge.thread
	movq	24(%rsp), %rsi                  # 8-byte Reload
	movq	32(%rsp), %rdi                  # 8-byte Reload
	subq	%rdi, %rsi
	callq	_ZdlPvm
.LBB4_41:                               # %_ZNSt6vectorIcSaIcEED2Ev.exit
	movq	48(%rsp), %rax                  # 8-byte Reload
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB4_34:
	.cfi_def_cfa_offset 112
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp252:                               # EH_LABEL
	movl	$.L.str.18, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp253:                               # EH_LABEL
# %bb.35:
.Ltmp255:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp256:                               # EH_LABEL
# %bb.49:
.LBB4_50:                               # %.noexc
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.LBB4_7:
.Ltmp258:                               # EH_LABEL
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp259:                               # EH_LABEL
# %bb.8:                                # %.noexc30
.LBB4_17:
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp241:                               # EH_LABEL
	movl	%r12d, %edi
	callq	hipGetErrorString
.Ltmp242:                               # EH_LABEL
# %bb.18:
.Ltmp243:                               # EH_LABEL
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp244:                               # EH_LABEL
	jmp	.LBB4_19
.LBB4_27:                               # %_ZStneIcSaIcEEbRKSt6vectorIT_T0_ES6_.exit.thread
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp246:                               # EH_LABEL
	movl	$.L.str.17, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp247:                               # EH_LABEL
.LBB4_19:                               # %.invoke
.Ltmp249:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp250:                               # EH_LABEL
# %bb.20:                               # %.cont
.LBB4_29:
.Ltmp248:                               # EH_LABEL
	jmp	.LBB4_22
.LBB4_21:
.Ltmp245:                               # EH_LABEL
	jmp	.LBB4_22
.LBB4_28:
.Ltmp260:                               # EH_LABEL
	movq	%rax, %r14
	cmpq	$0, 32(%rsp)                    # 8-byte Folded Reload
	je	.LBB4_48
	jmp	.LBB4_47
.LBB4_42:
.Ltmp251:                               # EH_LABEL
	jmp	.LBB4_43
.LBB4_37:
.Ltmp257:                               # EH_LABEL
.LBB4_43:                               # %.body
	movq	%rax, %r14
	jmp	.LBB4_44
.LBB4_36:
.Ltmp254:                               # EH_LABEL
.LBB4_22:                               # %.body
	movq	%rax, %r14
	movq	%r15, %rdi
	callq	__cxa_free_exception
.LBB4_44:                               # %.body
	cmpq	$0, 16(%rsp)                    # 8-byte Folded Reload
	jne	.LBB4_45
# %bb.46:                               # %_ZNSt6vectorIcSaIcEED2Ev.exit35
	cmpq	$0, 32(%rsp)                    # 8-byte Folded Reload
	jne	.LBB4_47
.LBB4_48:                               # %_ZNSt6vectorIcSaIcEED2Ev.exit37
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.LBB4_45:
	movq	16(%rsp), %rdi                  # 8-byte Reload
	movq	40(%rsp), %rsi                  # 8-byte Reload
	subq	%rdi, %rsi
	callq	_ZdlPvm
	cmpq	$0, 32(%rsp)                    # 8-byte Folded Reload
	je	.LBB4_48
.LBB4_47:
	movq	24(%rsp), %rsi                  # 8-byte Reload
	movq	32(%rsp), %rdi                  # 8-byte Reload
	subq	%rdi, %rsi
	callq	_ZdlPvm
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end4:
	.size	_ZN5Tiles6verifyEb, .Lfunc_end4-_ZN5Tiles6verifyEb
	.cfi_endproc
	.section	.gcc_except_table._ZN5Tiles6verifyEb,"aG",@progbits,_ZN5Tiles6verifyEb,comdat
	.p2align	2, 0x0
GCC_except_table4:
.Lexception3:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end3-.Lcst_begin3
.Lcst_begin3:
	.uleb128 .Lfunc_begin3-.Lfunc_begin3    # >> Call Site 1 <<
	.uleb128 .Ltmp237-.Lfunc_begin3         #   Call between .Lfunc_begin3 and .Ltmp237
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp237-.Lfunc_begin3         # >> Call Site 2 <<
	.uleb128 .Ltmp238-.Ltmp237              #   Call between .Ltmp237 and .Ltmp238
	.uleb128 .Ltmp260-.Lfunc_begin3         #     jumps to .Ltmp260
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp238-.Lfunc_begin3         # >> Call Site 3 <<
	.uleb128 .Ltmp239-.Ltmp238              #   Call between .Ltmp238 and .Ltmp239
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp239-.Lfunc_begin3         # >> Call Site 4 <<
	.uleb128 .Ltmp240-.Ltmp239              #   Call between .Ltmp239 and .Ltmp240
	.uleb128 .Ltmp251-.Lfunc_begin3         #     jumps to .Ltmp251
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp240-.Lfunc_begin3         # >> Call Site 5 <<
	.uleb128 .Ltmp252-.Ltmp240              #   Call between .Ltmp240 and .Ltmp252
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp252-.Lfunc_begin3         # >> Call Site 6 <<
	.uleb128 .Ltmp253-.Ltmp252              #   Call between .Ltmp252 and .Ltmp253
	.uleb128 .Ltmp254-.Lfunc_begin3         #     jumps to .Ltmp254
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp255-.Lfunc_begin3         # >> Call Site 7 <<
	.uleb128 .Ltmp256-.Ltmp255              #   Call between .Ltmp255 and .Ltmp256
	.uleb128 .Ltmp257-.Lfunc_begin3         #     jumps to .Ltmp257
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp256-.Lfunc_begin3         # >> Call Site 8 <<
	.uleb128 .Ltmp258-.Ltmp256              #   Call between .Ltmp256 and .Ltmp258
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp258-.Lfunc_begin3         # >> Call Site 9 <<
	.uleb128 .Ltmp259-.Ltmp258              #   Call between .Ltmp258 and .Ltmp259
	.uleb128 .Ltmp260-.Lfunc_begin3         #     jumps to .Ltmp260
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp259-.Lfunc_begin3         # >> Call Site 10 <<
	.uleb128 .Ltmp241-.Ltmp259              #   Call between .Ltmp259 and .Ltmp241
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp241-.Lfunc_begin3         # >> Call Site 11 <<
	.uleb128 .Ltmp244-.Ltmp241              #   Call between .Ltmp241 and .Ltmp244
	.uleb128 .Ltmp245-.Lfunc_begin3         #     jumps to .Ltmp245
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp244-.Lfunc_begin3         # >> Call Site 12 <<
	.uleb128 .Ltmp246-.Ltmp244              #   Call between .Ltmp244 and .Ltmp246
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp246-.Lfunc_begin3         # >> Call Site 13 <<
	.uleb128 .Ltmp247-.Ltmp246              #   Call between .Ltmp246 and .Ltmp247
	.uleb128 .Ltmp248-.Lfunc_begin3         #     jumps to .Ltmp248
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp249-.Lfunc_begin3         # >> Call Site 14 <<
	.uleb128 .Ltmp250-.Ltmp249              #   Call between .Ltmp249 and .Ltmp250
	.uleb128 .Ltmp251-.Lfunc_begin3         #     jumps to .Ltmp251
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp250-.Lfunc_begin3         # >> Call Site 15 <<
	.uleb128 .Lfunc_end4-.Ltmp250           #   Call between .Ltmp250 and .Lfunc_end4
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end3:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN5TilesD2Ev,"axG",@progbits,_ZN5TilesD2Ev,comdat
	.weak	_ZN5TilesD2Ev                   # -- Begin function _ZN5TilesD2Ev
	.p2align	4
	.type	_ZN5TilesD2Ev,@function
_ZN5TilesD2Ev:                          # @_ZN5TilesD2Ev
.Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception4
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB5_2
# %bb.1:
.Ltmp261:                               # EH_LABEL
	callq	hipFree
.Ltmp262:                               # EH_LABEL
.LBB5_2:
	movq	32(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB5_3
# %bb.5:
	movq	48(%rbx), %rsi
	subq	%rdi, %rsi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm                         # TAILCALL
.LBB5_3:                                # %_ZNSt6vectorIcSaIcEED2Ev.exit
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB5_4:
	.cfi_def_cfa_offset 16
.Ltmp263:                               # EH_LABEL
	movq	%rax, %rdi
	callq	__clang_call_terminate
.Lfunc_end5:
	.size	_ZN5TilesD2Ev, .Lfunc_end5-_ZN5TilesD2Ev
	.cfi_endproc
	.section	.gcc_except_table._ZN5TilesD2Ev,"aG",@progbits,_ZN5TilesD2Ev,comdat
	.p2align	2, 0x0
GCC_except_table5:
.Lexception4:
	.byte	255                             # @LPStart Encoding = omit
	.byte	3                               # @TType Encoding = udata4
	.uleb128 .Lttbase1-.Lttbaseref1
.Lttbaseref1:
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end4-.Lcst_begin4
.Lcst_begin4:
	.uleb128 .Ltmp261-.Lfunc_begin4         # >> Call Site 1 <<
	.uleb128 .Ltmp262-.Ltmp261              #   Call between .Ltmp261 and .Ltmp262
	.uleb128 .Ltmp263-.Lfunc_begin4         #     jumps to .Ltmp263
	.byte	1                               #   On action: 1
.Lcst_end4:
	.byte	1                               # >> Action Record 1 <<
                                        #   Catch TypeInfo 1
	.byte	0                               #   No further actions
	.p2align	2, 0x0
                                        # >> Catch TypeInfos <<
	.long	0                               # TypeInfo 1
.Lttbase1:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text.__clang_call_terminate,"axG",@progbits,__clang_call_terminate,comdat
	.hidden	__clang_call_terminate          # -- Begin function __clang_call_terminate
	.weak	__clang_call_terminate
	.p2align	4
	.type	__clang_call_terminate,@function
__clang_call_terminate:                 # @__clang_call_terminate
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	__cxa_begin_catch
	callq	_ZSt9terminatev
.Lfunc_end6:
	.size	__clang_call_terminate, .Lfunc_end6-__clang_call_terminate
	.cfi_endproc
                                        # -- End function
	.text
	.p2align	4                               # -- Begin function __hip_module_ctor
	.type	__hip_module_ctor,@function
__hip_module_ctor:                      # @__hip_module_ctor
	.cfi_startproc
# %bb.0:
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	__hip_gpubin_handle_df10107830186ee8(%rip), %rdi
	testq	%rdi, %rdi
	jne	.LBB7_2
# %bb.1:
	movl	$__hip_fatbin_wrapper, %edi
	callq	__hipRegisterFatBinary
	movq	%rax, %rdi
	movq	%rax, __hip_gpubin_handle_df10107830186ee8(%rip)
.LBB7_2:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$mfma_tile, %esi
	movl	$.L__unnamed_1, %edx
	movl	$.L__unnamed_1, %ecx
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	movl	$__hip_module_dtor, %edi
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	jmp	atexit                          # TAILCALL
.Lfunc_end7:
	.size	__hip_module_ctor, .Lfunc_end7-__hip_module_ctor
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function __hip_module_dtor
	.type	__hip_module_dtor,@function
__hip_module_dtor:                      # @__hip_module_dtor
	.cfi_startproc
# %bb.0:
	movq	__hip_gpubin_handle_df10107830186ee8(%rip), %rdi
	testq	%rdi, %rdi
	je	.LBB8_2
# %bb.1:
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	__hipUnregisterFatBinary
	movq	$0, __hip_gpubin_handle_df10107830186ee8(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
.LBB8_2:
	retq
.Lfunc_end8:
	.size	__hip_module_dtor, .Lfunc_end8-__hip_module_dtor
	.cfi_endproc
                                        # -- End function
	.type	mfma_tile,@object               # @mfma_tile
	.section	.rodata,"a",@progbits
	.globl	mfma_tile
	.p2align	3, 0x0
mfma_tile:
	.quad	__device_stub__mfma_tile
	.size	mfma_tile, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Expected data and output directories"
	.size	.L.str, 37

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Wave64 required"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"/a.bin"
	.size	.L.str.2, 7

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"/b.bin"
	.size	.L.str.3, 7

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"/c.bin"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"Input extents differ"
	.size	.L.str.5, 21

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"/actual.bin"
	.size	.L.str.6, 12

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"Cannot write output"
	.size	.L.str.7, 20

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"{\"device\":\""
	.size	.L.str.8, 12

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"\",\"architecture\":\""
	.size	.L.str.9, 19

	.type	.L.str.10,@object               # @.str.10
.L.str.10:
	.asciz	"\",\"warp\":"
	.size	.L.str.10, 10

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	",\"trials\":"
	.size	.L.str.11, 11

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	",\"inputs_unchanged\":true,\"per_tile_guard_zones_unchanged\":true}"
	.size	.L.str.12, 64

	.type	.L.str.13,@object               # @.str.13
.L.str.13:
	.asciz	"Cannot open data"
	.size	.L.str.13, 17

	.type	.L.str.14,@object               # @.str.14
.L.str.14:
	.asciz	"Incomplete data"
	.size	.L.str.14, 16

	.type	.L.str.15,@object               # @.str.15
.L.str.15:
	.asciz	"cannot create std::vector larger than max_size()"
	.size	.L.str.15, 49

	.type	.L.str.16,@object               # @.str.16
.L.str.16:
	.asciz	"Invalid tile extents"
	.size	.L.str.16, 21

	.type	.L.str.17,@object               # @.str.17
.L.str.17:
	.asciz	"Input bytes changed"
	.size	.L.str.17, 20

	.type	.L.str.18,@object               # @.str.18
.L.str.18:
	.asciz	"A tile guard changed"
	.size	.L.str.18, 21

	.type	.L.str.19,@object               # @.str.19
.L.str.19:
	.asciz	"basic_string: construction from null is not valid"
	.size	.L.str.19, 50

	.type	.L.str.20,@object               # @.str.20
.L.str.20:
	.asciz	"basic_string::append"
	.size	.L.str.20, 21

	.type	.L__unnamed_1,@object           # @0
.L__unnamed_1:
	.asciz	"mfma_tile"
	.size	.L__unnamed_1, 10

	.type	.L__unnamed_2,@object           # @1
	.section	.hip_fatbin,"a",@progbits
	.p2align	12, 0x0
.L__unnamed_2:
	.asciz	"__CLANG_OFFLOAD_BUNDLE__\002\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\000\000\000\000\000\000\000\036\000\000\000\000\000\000\000host-x86_64-unknown-linux-gnu-\000\020\000\000\000\000\000\000\250\025\000\000\000\000\000\000\037\000\000\000\000\000\000\000hipv4-amdgcn-amd-amdhsa--gfx950\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\177ELF\002\001\001@\004\000\000\000\000\000\000\000\003\000\340\000\001\000\000\000\000\000\000\000\000\000\000\000@\000\000\000\000\000\000\000h\021\000\000\000\000\000\000O\005\000\000@\0008\000\t\000@\000\021\000\017\000\006\000\000\000\004\000\000\000@\000\000\000\000\000\000\000@\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\370\001\000\000\000\000\000\000\370\001\000\000\000\000\000\000\b\000\000\000\000\000\000\000\001\000\000\000\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\006\000\000\000\000\000\000@\006\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\005\000\000\000\000\007\000\000\000\000\000\000\000\027\000\000\000\000\000\000\000\027\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\006\000\000\000\000\f\000\000\000\000\000\000\000,\000\000\000\000\000\000\000,\000\000\000\000\000\000p\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\006\000\000\000p\f\000\000\000\000\000\000p<\000\000\000\000\000\000p<\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\002\000\000\000\006\000\000\000\000\f\000\000\000\000\000\000\000,\000\000\000\000\000\000\000,\000\000\000\000\000\000p\000\000\000\000\000\000\000p\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000R\345td\004\000\000\000\000\f\000\000\000\000\000\000\000,\000\000\000\000\000\000\000,\000\000\000\000\000\000p\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\001\000\000\000\000\000\000\000Q\345td\006\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\004\000\000\000\004\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\000\314\002\000\000\000\000\000\000\314\002\000\000\000\000\000\000\004\000\000\000\000\000\000\000\007\000\000\000\266\002\000\000 \000\000\000AMDGPU\000\000\203\256amdhsa.kernels\221\336\000\022\253.agpr_count\000\245.args\224\204\256.address_space\246global\247.offset\000\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\b\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\020\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\030\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size \251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\251mfma_tile\273.private_segment_fixed_size\000\253.sgpr_count\022\261.sgpr_spill_count\000\247.symbol\254mfma_tile.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\f\261.vgpr_spill_count\000\257.wavefront_size@\255amdhsa.target\271amdgcn-amd-amdhsa--gfx950\256amdhsa.version\222\001\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\022\003\007\000\000\027\000\000\000\000\000\000\354\000\000\000\000\000\000\000\013\000\000\000\021\003\006\000\000\006\000\000\000\000\000\000@\000\000\000\000\000\000\000\030\000\000\000\021\000\n\000p<\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\001\000\000\000\001\000\000\000\032\000\000\000@\000\200\004\000@\t\000\001\000\000\000\262=\034]\260\026r\271\207C\ri\004\000\000\000\004\000\000\000\003\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\000\000\000\000mfma_tile\000mfma_tile.kd\000__hip_cuid_df10107830186ee8\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000 \000\000\000\000\000\000\000\000\021\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\000\000\000\201\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\016\300\000\000\000\000\217\000\002&\202\000\000 \204\002\004$\377\000\006&\374\000\000\000\002\000\376\321\002\007\006\002\177\300\214\277\000\200T\334\002\000\004\004\002\000\000\322\003\t\005\004\204\000\000$\201\004\006$\000\000\002\322\000\003\302\002\201\000\002$\000\200H\334\003\000\006\006 \200H\334\003\000\006\b@\200H\334\003\000\006\007\000\200H\334\001\000\006\t\202\004\024$\202\000\026$\000\200P\334\n\000\b\000@\200P\334\n\000\b\001\200\200P\334\n\000\b\002\000\200P\334\013\000\b\003\377\000\200\276\000\001\004\005v\017\214\277\006\000\355\321\b\r\002\000t\017\214\277\007\000\355\321\t\017\002\000p\017\214\277\000\000\200\277\000\000\315\323\004\r\002\004\007\000\200\277\000\200p\334\n\000\n\000@\200p\334\n\001\n\000\200\200p\334\n\002\n\000\000\200p\334\013\003\n\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\006\000\000\000\000\000\000\000\b\005\000\000\000\000\000\000\013\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\270\005\000\000\000\000\000\000\n\000\000\000\000\000\000\0004\000\000\000\000\000\000\000\365\376\377o\000\000\000\000h\005\000\000\000\000\000\000\004\000\000\000\000\000\000\000\220\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.1 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)\000\000Linker: AMD LLD 22.0.0 (/longer_pathname_so_that_rpms_can_support_packaging_the_debug_info_for_all_os_profiles/src/llvm-project/llvm f58b06dce1f9c15707c5f808fd002e18c2accf7e)\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\361\377\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\024\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'\000\000\000\000\000\361\377\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000?\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000[\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000v\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\211\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\245\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\303\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\333\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\367\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\013\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\037\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000f\001\000\000\000\002\b\000\000,\000\000\000\000\000\000\000\000\000\000\000\000\000\0003\001\000\000\022\003\007\000\000\027\000\000\000\000\000\000\354\000\000\000\000\000\000\000=\001\000\000\021\003\006\000\000\006\000\000\000\000\000\000@\000\000\000\000\000\000\000J\001\000\000\021\000\n\000p<\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000.note\000.dynsym\000.gnu.hash\000.hash\000.dynstr\000.rodata\000.text\000.dynamic\000.relro_padding\000.bss\000.AMDGPU.csdata\000.AMDGPU.gpr_maximums\000.comment\000.symtab\000.shstrtab\000.strtab\000\000mfma_tile.num_vgpr\000mfma_tile.num_agpr\000mfma_tile.numbered_sgpr\000mfma_tile.num_named_barrier\000mfma_tile.private_seg_size\000mfma_tile.uses_vcc\000mfma_tile.uses_flat_scratch\000mfma_tile.has_dyn_sized_stack\000mfma_tile.has_recursion\000mfma_tile.has_indirect_call\000amdgpu.max_num_vgpr\000amdgpu.max_num_agpr\000amdgpu.max_num_sgpr\000mfma_tile\000mfma_tile.kd\000__hip_cuid_df10107830186ee8\000_DYNAMIC\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\007\000\000\000\002\000\000\000\000\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\000\314\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\007\000\000\000\013\000\000\000\002\000\000\000\000\000\000\000\b\005\000\000\000\000\000\000\b\005\000\000\000\000\000\000`\000\000\000\000\000\000\000\005\000\000\000\001\000\000\000\b\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\017\000\000\000\366\377\377o\002\000\000\000\000\000\000\000h\005\000\000\000\000\000\000h\005\000\000\000\000\000\000(\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\031\000\000\000\005\000\000\000\002\000\000\000\000\000\000\000\220\005\000\000\000\000\000\000\220\005\000\000\000\000\000\000(\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\037\000\000\000\003\000\000\000\002\000\000\000\000\000\000\000\270\005\000\000\000\000\000\000\270\005\000\000\000\000\000\0004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'\000\000\000\001\000\000\000\002\000\000\000\000\000\000\000\000\006\000\000\000\000\000\000\000\006\000\000\000\000\000\000@\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000/\000\000\000\001\000\000\000\006\000\000\000\000\000\000\000\000\027\000\000\000\000\000\000\000\007\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\0005\000\000\000\006\000\000\000\003\000\000\000\000\000\000\000\000,\000\000\000\000\000\000\000\f\000\000\000\000\000\000p\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000>\000\000\000\b\000\000\000\003\000\000\000\000\000\000\000p,\000\000\000\000\000\000p\f\000\000\000\000\000\000\220\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000M\000\000\000\b\000\000\000\003\000\000\000\000\000\000\000p<\000\000\000\000\000\000p\f\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000R\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000p\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000a\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000p\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000v\000\000\000\001\000\000\0000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000p\f\000\000\000\000\000\0009\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\177\000\000\000\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\260\r\000\000\000\000\000\000\260\001\000\000\000\000\000\000\020\000\000\000\017\000\000\000\b\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\207\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000`\017\000\000\000\000\000\000\231\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\221\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\371\017\000\000\000\000\000\000o\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	.L__unnamed_2, 9640

	.type	__hip_fatbin_wrapper,@object    # @__hip_fatbin_wrapper
	.section	.hipFatBinSegment,"a",@progbits
	.p2align	3, 0x0
__hip_fatbin_wrapper:
	.long	1212764230                      # 0x48495046
	.long	1                               # 0x1
	.quad	.L__unnamed_2
	.quad	0
	.size	__hip_fatbin_wrapper, 24

	.type	__hip_gpubin_handle_df10107830186ee8,@object # @__hip_gpubin_handle_df10107830186ee8
	.local	__hip_gpubin_handle_df10107830186ee8
	.comm	__hip_gpubin_handle_df10107830186ee8,8,8
	.section	.init_array,"aw",@init_array
	.p2align	3, 0x0
	.quad	__hip_module_ctor
	.type	__hip_cuid_df10107830186ee8,@object # @__hip_cuid_df10107830186ee8
	.bss
	.globl	__hip_cuid_df10107830186ee8
__hip_cuid_df10107830186ee8:
	.byte	0                               # 0x0
	.size	__hip_cuid_df10107830186ee8, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.1 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __device_stub__mfma_tile
	.addrsig_sym __gxx_personality_v0
	.addrsig_sym __hip_module_ctor
	.addrsig_sym __hip_module_dtor
	.addrsig_sym _Unwind_Resume
	.addrsig_sym mfma_tile
	.addrsig_sym _ZTISt9exception
	.addrsig_sym _ZTISt13runtime_error
	.addrsig_sym _ZSt4cout
	.addrsig_sym _ZSt4cerr
	.addrsig_sym .L__unnamed_2
	.addrsig_sym __hip_fatbin_wrapper
	.addrsig_sym __hip_cuid_df10107830186ee8
