	.amdgcn_target "amdgcn-amd-amdhsa--gfx950"
	.amdhsa_code_object_version 6
	.text
	.protected	mfma_tile               ; -- Begin function mfma_tile
	.globl	mfma_tile
	.p2align	8
	.type	mfma_tile,@function
mfma_tile:                              ; @mfma_tile
; %bb.0:
	s_load_dwordx8 s[4:11], s[0:1], 0x0
	v_and_b32_e32 v1, 15, v0
	v_lshrrev_b32_e32 v0, 2, v0
	v_lshlrev_b32_e32 v2, 4, v1
	v_and_b32_e32 v3, 0xfc, v0
	v_add_lshl_u32 v2, v2, v3, 1
	s_waitcnt lgkmcnt(0)
	global_load_dwordx2 v[4:5], v2, s[4:5]
	v_lshl_or_b32 v2, v3, 4, v1
	v_lshlrev_b32_e32 v0, 4, v0
	v_lshlrev_b32_e32 v3, 1, v2
	v_or3_b32 v0, v0, v1, 48
	v_lshlrev_b32_e32 v1, 1, v0
	global_load_ushort v6, v3, s[6:7]
	global_load_ushort v8, v3, s[6:7] offset:32
	global_load_ushort v7, v3, s[6:7] offset:64
	global_load_ushort v9, v1, s[6:7]
	v_lshlrev_b32_e32 v10, 2, v2
	v_lshlrev_b32_e32 v11, 2, v0
	global_load_dword v0, v10, s[8:9]
	global_load_dword v1, v10, s[8:9] offset:64
	global_load_dword v2, v10, s[8:9] offset:128
	global_load_dword v3, v11, s[8:9]
	s_mov_b32 s0, 0x5040100
	s_waitcnt vmcnt(6)
	v_perm_b32 v6, v8, v6, s0
	s_waitcnt vmcnt(4)
	v_perm_b32 v7, v9, v7, s0
	s_waitcnt vmcnt(0)
	s_nop 0
	v_mfma_f32_16x16x16_f16 v[0:3], v[4:5], v[6:7], v[0:3]
	s_nop 7
	global_store_dword v10, v0, s[10:11]
	global_store_dword v10, v1, s[10:11] offset:64
	global_store_dword v10, v2, s[10:11] offset:128
	global_store_dword v11, v3, s[10:11]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel mfma_tile
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 32
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 12
		.amdhsa_next_free_sgpr 12
		.amdhsa_accum_offset 12
		.amdhsa_reserve_vcc 0
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	mfma_tile, .Lfunc_end0-mfma_tile
                                        ; -- End function
	.set mfma_tile.num_vgpr, 12
	.set mfma_tile.num_agpr, 0
	.set mfma_tile.numbered_sgpr, 12
	.set mfma_tile.num_named_barrier, 0
	.set mfma_tile.private_seg_size, 0
	.set mfma_tile.uses_vcc, 0
	.set mfma_tile.uses_flat_scratch, 0
	.set mfma_tile.has_dyn_sized_stack, 0
	.set mfma_tile.has_recursion, 0
	.set mfma_tile.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 236
; TotalNumSgprs: 18
; NumVgprs: 12
; NumAgprs: 0
; TotalNumVgprs: 12
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 2
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 18
; NumVGPRsForWavesPerEU: 12
; AccumOffset: 12
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 2
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.text
	.type	__hip_cuid_df10107830186ee8,@object ; @__hip_cuid_df10107830186ee8
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_df10107830186ee8
__hip_cuid_df10107830186ee8:
	.byte	0                               ; 0x0
	.size	__hip_cuid_df10107830186ee8, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.1 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __hip_cuid_df10107830186ee8
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     0
    .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 32
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           mfma_tile
    .private_segment_fixed_size: 0
    .sgpr_count:     18
    .sgpr_spill_count: 0
    .symbol:         mfma_tile.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     12
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx950
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
