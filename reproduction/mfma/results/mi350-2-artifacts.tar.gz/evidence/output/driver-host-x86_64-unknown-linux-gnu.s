	.file	"driver.hip"
	.text
	.globl	__device_stub__mfma_tile        # -- Begin function __device_stub__mfma_tile
	.p2align	4
	.type	__device_stub__mfma_tile,@function
__device_stub__mfma_tile:               # @__device_stub__mfma_tile
	.cfi_startproc
# %bb.0:                                # %entry
	subq	$120, %rsp
	.cfi_def_cfa_offset 128
	movq	%rdi, 72(%rsp)
	movq	%rsi, 64(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%rcx, 48(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, 80(%rsp)
	leaq	64(%rsp), %rax
	movq	%rax, 88(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 96(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	80(%rsp), %r9
	movl	$mfma_tile, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$136, %rsp
	.cfi_adjust_cfa_offset -136
	retq
.Lfunc_end0:
	.size	__device_stub__mfma_tile, .Lfunc_end0-__device_stub__mfma_tile
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception0
# %bb.0:                                # %entry
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2520, %rsp                     # imm = 0x9D8
	.cfi_def_cfa_offset 2576
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpl	$3, %edi
	jne	.LBB1_1
# %bb.6:                                # %if.end
	movq	%rsi, %rbx
	movq	8(%rsi), %r14
	leaq	56(%rsp), %r12
	movq	%r12, 40(%rsp)
	testq	%r14, %r14
	je	.LBB1_7
# %bb.9:                                # %if.end.i
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	strlen
	movq	%rax, %r15
	movq	%rax, 1048(%rsp)
	movq	%r12, %rax
	cmpq	$16, %r15
	jb	.LBB1_12
# %bb.10:                               # %if.then.i.i
.Ltmp6:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	40(%rsp), %rdi
	leaq	1048(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp7:                                 # EH_LABEL
# %bb.11:                               # %call2.i5.i.noexc
	movq	%rax, 40(%rsp)
	movq	1048(%rsp), %rcx
	movq	%rcx, 56(%rsp)
.LBB1_12:                               # %if.end.i.i
	testq	%r15, %r15
	je	.LBB1_16
# %bb.13:                               # %if.end.i.i
	cmpq	$1, %r15
	jne	.LBB1_15
# %bb.14:                               # %if.then.i.i.i.i
	movzbl	(%r14), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_16
.LBB1_15:                               # %if.end.i.i.i.i.i
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	memcpy@PLT
.LBB1_16:                               # %invoke.cont3
	movq	1048(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	40(%rsp), %rcx
	movb	$0, (%rcx,%rax)
	movq	16(%rbx), %rbx
	leaq	88(%rsp), %r15
	movq	%r15, 72(%rsp)
	testq	%rbx, %rbx
	je	.LBB1_17
# %bb.19:                               # %if.end.i41
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	strlen
	movq	%rax, %r14
	movq	%rax, 1048(%rsp)
	movq	%r15, %rax
	cmpq	$16, %r14
	jb	.LBB1_22
# %bb.20:                               # %if.then.i.i49
.Ltmp8:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	72(%rsp), %rdi
	leaq	1048(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp9:                                 # EH_LABEL
# %bb.21:                               # %call2.i5.i.noexc52
	movq	%rax, 72(%rsp)
	movq	1048(%rsp), %rcx
	movq	%rcx, 88(%rsp)
.LBB1_22:                               # %if.end.i.i44
	testq	%r14, %r14
	je	.LBB1_26
# %bb.23:                               # %if.end.i.i44
	cmpq	$1, %r14
	jne	.LBB1_25
# %bb.24:                               # %if.then.i.i.i.i47
	movzbl	(%rbx), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_26
.LBB1_25:                               # %if.end.i.i.i.i.i48
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
.LBB1_26:                               # %invoke.cont7
	movq	1048(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	72(%rsp), %rcx
	movb	$0, (%rcx,%rax)
.Ltmp10:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1048(%rsp), %rdi
	xorl	%esi, %esi
	callq	hipGetDevicePropertiesR0600
.Ltmp11:                                # EH_LABEL
# %bb.27:                               # %invoke.cont9
	testl	%eax, %eax
	jne	.LBB1_28
# %bb.34:                               # %invoke.cont10
	cmpl	$64, 1356(%rsp)
	jne	.LBB1_35
# %bb.41:                               # %if.end16
	leaq	480(%rsp), %r15
	movq	%r15, 464(%rsp)
	movq	40(%rsp), %rbx
	movq	48(%rsp), %r14
	movq	%r14, 152(%rsp)
	movq	%r15, %rax
	cmpq	$16, %r14
	jb	.LBB1_44
# %bb.42:                               # %if.then.i.i.i
.Ltmp23:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	leaq	152(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp24:                                # EH_LABEL
# %bb.43:                               # %call2.i4.i.i.noexc
	movq	%rax, 464(%rsp)
	movq	152(%rsp), %rcx
	movq	%rcx, 480(%rsp)
.LBB1_44:                               # %if.end.i.i.i
	testq	%r14, %r14
	je	.LBB1_48
# %bb.45:                               # %if.end.i.i.i
	cmpq	$1, %r14
	jne	.LBB1_47
# %bb.46:                               # %if.then.i.i.i.i.i
	movzbl	(%rbx), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_48
.LBB1_47:                               # %if.end.i.i.i.i.i.i
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
.LBB1_48:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2ERKS4_.exit.i
	movabsq	$-4611686018427387898, %rdx     # imm = 0xC000000000000006
	movq	152(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	464(%rsp), %rcx
	movb	$0, (%rcx,%rax)
	movq	472(%rsp), %rax
	addq	%rdx, %rax
	cmpq	$5, %rax
	jbe	.LBB1_49
# %bb.52:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i
.Ltmp26:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movl	$.L.str.2, %esi
	movl	$6, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp27:                                # EH_LABEL
# %bb.53:                               # %invoke.cont19
.Ltmp28:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	232(%rsp), %rdi
	leaq	464(%rsp), %rsi
	callq	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp29:                                # EH_LABEL
# %bb.54:                               # %invoke.cont21
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_56
# %bb.55:                               # %if.then.i.i62
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_56:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit
	leaq	480(%rsp), %r15
	movq	%r15, 464(%rsp)
	movq	40(%rsp), %rbx
	movq	48(%rsp), %r14
	movq	%r14, 152(%rsp)
	movq	%r15, %rax
	cmpq	$16, %r14
	jb	.LBB1_59
# %bb.57:                               # %if.then.i.i.i88
.Ltmp31:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	leaq	152(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp32:                                # EH_LABEL
# %bb.58:                               # %call2.i4.i.i.noexc89
	movq	%rax, 464(%rsp)
	movq	152(%rsp), %rcx
	movq	%rcx, 480(%rsp)
.LBB1_59:                               # %if.end.i.i.i68
	testq	%r14, %r14
	je	.LBB1_63
# %bb.60:                               # %if.end.i.i.i68
	cmpq	$1, %r14
	jne	.LBB1_62
# %bb.61:                               # %if.then.i.i.i.i.i86
	movzbl	(%rbx), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_63
.LBB1_62:                               # %if.end.i.i.i.i.i.i87
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
.LBB1_63:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2ERKS4_.exit.i69
	movq	152(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	464(%rsp), %rcx
	movb	$0, (%rcx,%rax)
	movq	472(%rsp), %rax
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	addq	%rcx, %rax
	cmpq	$5, %rax
	jbe	.LBB1_64
# %bb.67:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i75
.Ltmp34:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movl	$.L.str.3, %esi
	movl	$6, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp35:                                # EH_LABEL
# %bb.68:                               # %invoke.cont24
.Ltmp36:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	208(%rsp), %rdi
	leaq	464(%rsp), %rsi
	callq	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp37:                                # EH_LABEL
# %bb.69:                               # %invoke.cont26
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_71
# %bb.70:                               # %if.then.i.i94
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_71:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit100
	leaq	480(%rsp), %r15
	movq	%r15, 464(%rsp)
	movq	40(%rsp), %rbx
	movq	48(%rsp), %r14
	movq	%r14, 152(%rsp)
	movq	%r15, %rax
	cmpq	$16, %r14
	jb	.LBB1_74
# %bb.72:                               # %if.then.i.i.i124
.Ltmp39:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	leaq	152(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp40:                                # EH_LABEL
# %bb.73:                               # %call2.i4.i.i.noexc125
	movq	%rax, 464(%rsp)
	movq	152(%rsp), %rcx
	movq	%rcx, 480(%rsp)
.LBB1_74:                               # %if.end.i.i.i104
	testq	%r14, %r14
	je	.LBB1_78
# %bb.75:                               # %if.end.i.i.i104
	cmpq	$1, %r14
	jne	.LBB1_77
# %bb.76:                               # %if.then.i.i.i.i.i122
	movzbl	(%rbx), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_78
.LBB1_77:                               # %if.end.i.i.i.i.i.i123
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
.LBB1_78:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2ERKS4_.exit.i105
	movq	152(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	464(%rsp), %rcx
	movb	$0, (%rcx,%rax)
	movq	472(%rsp), %rax
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	addq	%rcx, %rax
	cmpq	$5, %rax
	jbe	.LBB1_79
# %bb.82:                               # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i111
.Ltmp42:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	movl	$.L.str.4, %esi
	movl	$6, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp43:                                # EH_LABEL
# %bb.83:                               # %invoke.cont31
.Ltmp44:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	leaq	464(%rsp), %rsi
	callq	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Ltmp45:                                # EH_LABEL
# %bb.84:                               # %invoke.cont33
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_86
# %bb.85:                               # %if.then.i.i130
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_86:                               # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit136
	movq	240(%rsp), %rax
	subq	232(%rsp), %rax
	movq	216(%rsp), %rcx
	subq	208(%rsp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB1_88
# %bb.87:                               # %lor.lhs.false
	addq	%rax, %rax
	movq	136(%rsp), %rcx
	subq	128(%rsp), %rcx
	cmpq	%rcx, %rax
	jne	.LBB1_88
# %bb.105:                              # %if.end48
.Ltmp53:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	152(%rsp), %rdi
	leaq	232(%rsp), %rsi
	movl	$512, %edx                      # imm = 0x200
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp54:                                # EH_LABEL
# %bb.106:                              # %invoke.cont50
.Ltmp56:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	408(%rsp), %rdi
	leaq	208(%rsp), %rsi
	movl	$512, %edx                      # imm = 0x200
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp57:                                # EH_LABEL
# %bb.107:                              # %invoke.cont52
.Ltmp59:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	352(%rsp), %rdi
	leaq	128(%rsp), %rsi
	movl	$1024, %edx                     # imm = 0x400
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp60:                                # EH_LABEL
# %bb.108:                              # %invoke.cont54
	movq	136(%rsp), %rbx
	subq	128(%rsp), %rbx
	js	.LBB1_109
# %bb.111:                              # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	je	.LBB1_112
# %bb.113:                              # %if.then.i.i.i.i.i.i.i.i.i
.Ltmp62:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	_Znwm
.Ltmp63:                                # EH_LABEL
# %bb.114:                              # %call5.i.i.i.i1.i.i.noexc
	movq	%rax, 464(%rsp)
	movq	%rax, 472(%rsp)
	movq	%rax, %r14
	addq	%rbx, %r14
	movq	%r14, 480(%rsp)
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	xorl	%esi, %esi
	movq	%rbx, %rdx
	callq	memset@PLT
	jmp	.LBB1_115
.LBB1_112:                              # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 464(%rsp)
	movq	$0, 480(%rsp)
	xorl	%r14d, %r14d
.LBB1_115:                              # %invoke.cont60
	movq	%r14, 472(%rsp)
.Ltmp64:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	296(%rsp), %rdi
	leaq	464(%rsp), %rsi
	movl	$1024, %edx                     # imm = 0x400
	callq	_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Ltmp65:                                # EH_LABEL
# %bb.116:                              # %invoke.cont62
	movq	464(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_118
# %bb.117:                              # %if.then.i.i.i183
	movq	480(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_118:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit
	cmpq	$0, 168(%rsp)
	je	.LBB1_127
# %bb.119:                              # %do.body.lr.ph
	xorl	%r13d, %r13d
	movabsq	$4294967297, %rbx               # imm = 0x100000001
	movabsq	$4294967360, %r14               # imm = 0x100000040
	leaq	256(%rsp), %rbp
	leaq	464(%rsp), %r15
	.p2align	4
.LBB1_120:                              # %do.body
                                        # =>This Inner Loop Header: Depth=1
.Ltmp67:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	movl	$1, %esi
	movq	%r14, %rdx
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp68:                                # EH_LABEL
# %bb.121:                              # %invoke.cont73
                                        #   in Loop: Header=BB1_120 Depth=1
	testl	%eax, %eax
	jne	.LBB1_124
# %bb.122:                              # %kcall.configok
                                        #   in Loop: Header=BB1_120 Depth=1
	movq	152(%rsp), %rax
	movq	176(%rsp), %rcx
	imulq	%r13, %rcx
	addq	%rcx, %rax
	addq	$128, %rax
	movq	408(%rsp), %rcx
	movq	432(%rsp), %rdx
	imulq	%r13, %rdx
	addq	%rdx, %rcx
	addq	$128, %rcx
	movq	352(%rsp), %rdx
	movq	376(%rsp), %rsi
	imulq	%r13, %rsi
	addq	%rsi, %rdx
	addq	$128, %rdx
	movq	296(%rsp), %rsi
	movq	320(%rsp), %rdi
	imulq	%r13, %rdi
	addq	%rdi, %rsi
	addq	$128, %rsi
	movq	%rax, (%rsp)
	movq	%rcx, 288(%rsp)
	movq	%rdx, 280(%rsp)
	movq	%rsi, 272(%rsp)
	movq	%rsp, %rax
	movq	%rax, 464(%rsp)
	leaq	288(%rsp), %rax
	movq	%rax, 472(%rsp)
	leaq	280(%rsp), %rax
	movq	%rax, 480(%rsp)
	leaq	272(%rsp), %rax
	movq	%rax, 488(%rsp)
.Ltmp69:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	8(%rsp), %rdi
	leaq	104(%rsp), %rsi
	leaq	264(%rsp), %rdx
	movq	%rbp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp70:                                # EH_LABEL
# %bb.123:                              # %.noexc207
                                        #   in Loop: Header=BB1_120 Depth=1
	movq	8(%rsp), %rsi
	movl	16(%rsp), %edx
	movq	104(%rsp), %rcx
	movl	112(%rsp), %r8d
.Ltmp71:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$mfma_tile, %edi
	movq	%r15, %r9
	pushq	256(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	272(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp72:                                # EH_LABEL
.LBB1_124:                              # %do.end
                                        #   in Loop: Header=BB1_120 Depth=1
.Ltmp73:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipGetLastError
.Ltmp74:                                # EH_LABEL
# %bb.125:                              # %invoke.cont84
                                        #   in Loop: Header=BB1_120 Depth=1
	movl	%eax, %r12d
	testl	%eax, %eax
	jne	.LBB1_141
# %bb.126:                              # %for.cond
                                        #   in Loop: Header=BB1_120 Depth=1
	incq	%r13
	cmpq	168(%rsp), %r13
	jb	.LBB1_120
.LBB1_127:                              # %for.cond.cleanup
.Ltmp84:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipDeviceSynchronize
.Ltmp85:                                # EH_LABEL
# %bb.128:                              # %invoke.cont89
	testl	%eax, %eax
	jne	.LBB1_129
# %bb.149:                              # %invoke.cont91
.Ltmp93:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1024(%rsp), %rdi
	leaq	152(%rsp), %rsi
	movl	$1, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp94:                                # EH_LABEL
# %bb.150:                              # %invoke.cont92
	movq	1024(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_152
# %bb.151:                              # %if.then.i.i.i233
	movq	1040(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_152:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit238
.Ltmp95:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1000(%rsp), %rdi
	leaq	408(%rsp), %rsi
	movl	$1, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp96:                                # EH_LABEL
# %bb.153:                              # %invoke.cont94
	movq	1000(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_155
# %bb.154:                              # %if.then.i.i.i241
	movq	1016(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_155:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit246
.Ltmp97:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	976(%rsp), %rdi
	leaq	352(%rsp), %rsi
	movl	$1, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp98:                                # EH_LABEL
# %bb.156:                              # %invoke.cont96
	movq	976(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_158
# %bb.157:                              # %if.then.i.i.i249
	movq	992(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_158:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit254
.Ltmp100:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	104(%rsp), %rdi
	leaq	296(%rsp), %rsi
	xorl	%edx, %edx
	callq	_ZN5Tiles6verifyEb
.Ltmp101:                               # EH_LABEL
# %bb.159:                              # %invoke.cont98
	leaq	24(%rsp), %r15
	movq	%r15, 8(%rsp)
	movq	72(%rsp), %rbx
	movq	80(%rsp), %r14
	movq	%r14, (%rsp)
	movq	%r15, %rax
	cmpq	$16, %r14
	jb	.LBB1_162
# %bb.160:                              # %if.then.i.i.i278
.Ltmp103:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	8(%rsp), %rdi
	movq	%rsp, %rsi
	xorl	%edx, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm
.Ltmp104:                               # EH_LABEL
# %bb.161:                              # %call2.i4.i.i.noexc279
	movq	%rax, 8(%rsp)
	movq	(%rsp), %rcx
	movq	%rcx, 24(%rsp)
.LBB1_162:                              # %if.end.i.i.i258
	testq	%r14, %r14
	je	.LBB1_166
# %bb.163:                              # %if.end.i.i.i258
	cmpq	$1, %r14
	jne	.LBB1_165
# %bb.164:                              # %if.then.i.i.i.i.i276
	movzbl	(%rbx), %ecx
	movb	%cl, (%rax)
	jmp	.LBB1_166
.LBB1_165:                              # %if.end.i.i.i.i.i.i277
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	memcpy@PLT
.LBB1_166:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC2ERKS4_.exit.i259
	movq	(%rsp), %rax
	movq	%rax, 16(%rsp)
	movq	8(%rsp), %rcx
	movb	$0, (%rcx,%rax)
	movq	16(%rsp), %rax
	movabsq	$-4611686018427387898, %rcx     # imm = 0xC000000000000006
	addq	%rcx, %rax
	addq	$5, %rax
	cmpq	$10, %rax
	jbe	.LBB1_167
# %bb.170:                              # %_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE15_M_check_lengthEmmPKc.exit.i.i265
.Ltmp106:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	8(%rsp), %rdi
	movl	$.L.str.6, %esi
	movl	$11, %edx
	callq	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm
.Ltmp107:                               # EH_LABEL
# %bb.171:                              # %invoke.cont101
.Ltmp108:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	leaq	8(%rsp), %rsi
	movl	$4, %edx
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEEC1ERKNSt7__cxx1112basic_stringIcS1_SaIcEEESt13_Ios_Openmode
.Ltmp109:                               # EH_LABEL
# %bb.172:                              # %invoke.cont103
	movq	8(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_174
# %bb.173:                              # %if.then.i.i284
	movq	24(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_174:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit290
	movq	104(%rsp), %rsi
	movq	112(%rsp), %rdx
	subq	%rsi, %rdx
.Ltmp111:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSo5writeEPKcl
.Ltmp112:                               # EH_LABEL
# %bb.175:                              # %invoke.cont111
	movq	464(%rsp), %rax
	movq	-24(%rax), %rax
	testb	$5, 496(%rsp,%rax)
	jne	.LBB1_176
# %bb.185:                              # %if.end118
.Ltmp118:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movl	$.L.str.8, %esi
	movl	$11, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp119:                               # EH_LABEL
# %bb.186:                              # %invoke.cont119
	.cfi_escape 0x2e, 0x00
	leaq	1048(%rsp), %rbx
	movq	%rbx, %rdi
	callq	strlen
.Ltmp120:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movq	%rbx, %rsi
	movq	%rax, %rdx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp121:                               # EH_LABEL
# %bb.187:                              # %invoke.cont121
.Ltmp122:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movl	$.L.str.9, %esi
	movl	$18, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp123:                               # EH_LABEL
# %bb.188:                              # %invoke.cont123
	leaq	2208(%rsp), %rbx
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	strlen
.Ltmp124:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movq	%rbx, %rsi
	movq	%rax, %rdx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp125:                               # EH_LABEL
# %bb.189:                              # %invoke.cont126
.Ltmp126:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	movl	$.L.str.10, %esi
	movl	$9, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp127:                               # EH_LABEL
# %bb.190:                              # %invoke.cont128
	movl	1356(%rsp), %esi
.Ltmp128:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cout, %edi
	callq	_ZNSolsEi
.Ltmp129:                               # EH_LABEL
# %bb.191:                              # %invoke.cont131
.Ltmp130:                               # EH_LABEL
	movq	%rax, %rbx
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.11, %esi
	movl	$10, %edx
	movq	%rax, %rdi
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp131:                               # EH_LABEL
# %bb.192:                              # %invoke.cont133
	movq	168(%rsp), %rsi
.Ltmp132:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	_ZNSo9_M_insertImEERSoT_
.Ltmp133:                               # EH_LABEL
# %bb.193:                              # %invoke.cont136
.Ltmp134:                               # EH_LABEL
	movq	%rax, %rbx
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.12, %esi
	movl	$63, %edx
	movq	%rax, %rdi
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp135:                               # EH_LABEL
# %bb.194:                              # %invoke.cont138
	movq	(%rbx), %rax
	movq	-24(%rax), %rax
	movq	240(%rbx,%rax), %r14
	testq	%r14, %r14
	je	.LBB1_195
# %bb.197:                              # %_ZSt13__check_facetISt5ctypeIcEERKT_PS3_.exit.i.i
	cmpb	$0, 56(%r14)
	je	.LBB1_199
# %bb.198:                              # %if.then.i2.i.i
	movzbl	67(%r14), %eax
	jmp	.LBB1_201
.LBB1_199:                              # %if.end.i.i.i488
.Ltmp136:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	_ZNKSt5ctypeIcE13_M_widen_initEv
.Ltmp137:                               # EH_LABEL
# %bb.200:                              # %.noexc492
	movq	(%r14), %rax
.Ltmp138:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	movl	$10, %esi
	callq	*48(%rax)
.Ltmp139:                               # EH_LABEL
.LBB1_201:                              # %_ZNKSt9basic_iosIcSt11char_traitsIcEE5widenEc.exit.i
.Ltmp140:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movsbl	%al, %esi
	movq	%rbx, %rdi
	callq	_ZNSo3putEc
.Ltmp141:                               # EH_LABEL
# %bb.202:                              # %call1.i.noexc
.Ltmp142:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	_ZNSo5flushEv
.Ltmp143:                               # EH_LABEL
# %bb.203:                              # %invoke.cont140
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
	movq	104(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_205
# %bb.204:                              # %if.then.i.i.i343
	movq	120(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_205:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit348
	movq	296(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_207
# %bb.206:                              # %if.then.i349
.Ltmp144:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp145:                               # EH_LABEL
.LBB1_207:                              # %if.end.i351
	movq	328(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_209
# %bb.208:                              # %if.then.i.i.i.i352
	movq	344(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_209:                              # %_ZN5TilesD2Ev.exit
	movq	352(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_211
# %bb.210:                              # %if.then.i355
.Ltmp147:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp148:                               # EH_LABEL
.LBB1_211:                              # %if.end.i358
	movq	384(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_213
# %bb.212:                              # %if.then.i.i.i.i361
	movq	400(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_213:                              # %_ZN5TilesD2Ev.exit366
	movq	408(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_215
# %bb.214:                              # %if.then.i368
.Ltmp150:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp151:                               # EH_LABEL
.LBB1_215:                              # %if.end.i371
	movq	440(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_217
# %bb.216:                              # %if.then.i.i.i.i374
	movq	456(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_217:                              # %_ZN5TilesD2Ev.exit379
	movq	152(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_219
# %bb.218:                              # %if.then.i381
.Ltmp153:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp154:                               # EH_LABEL
.LBB1_219:                              # %if.end.i384
	movq	184(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_221
# %bb.220:                              # %if.then.i.i.i.i387
	movq	200(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_221:                              # %_ZN5TilesD2Ev.exit392
	movq	128(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_223
# %bb.222:                              # %if.then.i.i.i395
	movq	144(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_223:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit400
	movq	208(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_225
# %bb.224:                              # %if.then.i.i.i403
	movq	224(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_225:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit408
	movq	232(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_227
# %bb.226:                              # %if.then.i.i.i411
	movq	248(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_227:                              # %_ZNSt6vectorIcSaIcEED2Ev.exit416
	movq	72(%rsp), %rdi
	leaq	88(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_229
# %bb.228:                              # %if.then.i.i418
	movq	88(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_229:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit424
	movq	40(%rsp), %rdi
	leaq	56(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_231
# %bb.230:                              # %if.then.i.i426
	movq	56(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_231:                              # %_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEED2Ev.exit432
	xorl	%eax, %eax
.LBB1_232:                              # %try.cont
	addq	$2520, %rsp                     # imm = 0x9D8
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB1_141:                              # %if.then.i210
	.cfi_def_cfa_offset 2576
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp76:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%r12d, %edi
	callq	hipGetErrorString
.Ltmp77:                                # EH_LABEL
# %bb.142:                              # %invoke.cont.i214
.Ltmp78:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp79:                                # EH_LABEL
# %bb.143:                              # %invoke.cont1.i215
.Ltmp81:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp82:                                # EH_LABEL
# %bb.144:                              # %.noexc217
.LBB1_88:                               # %if.then42
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp47:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.5, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp48:                                # EH_LABEL
# %bb.89:                               # %invoke.cont45
.Ltmp50:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp51:                                # EH_LABEL
	jmp	.LBB1_261
.LBB1_1:                                # %if.then
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp0:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp1:                                 # EH_LABEL
# %bb.2:                                # %invoke.cont
.Ltmp3:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp4:                                 # EH_LABEL
	jmp	.LBB1_261
.LBB1_7:                                # %if.then.i
.Ltmp177:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.20, %edi
	callq	_ZSt19__throw_logic_errorPKc
.Ltmp178:                               # EH_LABEL
# %bb.8:                                # %.noexc
.LBB1_17:                               # %if.then.i50
.Ltmp174:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.20, %edi
	callq	_ZSt19__throw_logic_errorPKc
.Ltmp175:                               # EH_LABEL
# %bb.18:                               # %.noexc51
.LBB1_28:                               # %if.then.i55
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	movl	%eax, %ebx
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp12:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%ebx, %edi
	callq	hipGetErrorString
.Ltmp13:                                # EH_LABEL
# %bb.29:                               # %invoke.cont.i
.Ltmp14:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp15:                                # EH_LABEL
	jmp	.LBB1_30
.LBB1_35:                               # %if.then12
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp17:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.1, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp18:                                # EH_LABEL
.LBB1_30:                               # %invoke.cont1.i.invoke
.Ltmp20:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp21:                                # EH_LABEL
# %bb.31:                               # %invoke.cont1.i.cont
.LBB1_49:                               # %if.then.i.i2.i
.Ltmp171:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.19, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp172:                               # EH_LABEL
# %bb.50:                               # %.noexc.i
.LBB1_64:                               # %if.then.i.i2.i84
.Ltmp168:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.19, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp169:                               # EH_LABEL
# %bb.65:                               # %.noexc.i85
.LBB1_79:                               # %if.then.i.i2.i120
.Ltmp165:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.19, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp166:                               # EH_LABEL
# %bb.80:                               # %.noexc.i121
.LBB1_109:                              # %if.then.i.i179
.Ltmp162:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp163:                               # EH_LABEL
# %bb.110:                              # %.noexc180
.LBB1_129:                              # %if.then.i221
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	movl	%eax, %ebx
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp86:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%ebx, %edi
	callq	hipGetErrorString
.Ltmp87:                                # EH_LABEL
# %bb.130:                              # %invoke.cont.i225
.Ltmp88:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp89:                                # EH_LABEL
# %bb.131:                              # %invoke.cont1.i226
.Ltmp91:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp92:                                # EH_LABEL
# %bb.147:                              # %.noexc228
.LBB1_167:                              # %if.then.i.i2.i274
.Ltmp159:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.19, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp160:                               # EH_LABEL
# %bb.168:                              # %.noexc.i275
.LBB1_176:                              # %if.then113
	.cfi_escape 0x2e, 0x00
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp113:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.7, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp114:                               # EH_LABEL
# %bb.177:                              # %invoke.cont116
.Ltmp116:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp117:                               # EH_LABEL
.LBB1_261:                              # %unreachable
.LBB1_195:                              # %if.then.i.i.i490
.Ltmp156:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	_ZSt16__throw_bad_castv
.Ltmp157:                               # EH_LABEL
# %bb.196:                              # %.noexc491
.LBB1_184:                              # %lpad115
.Ltmp115:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_234
.LBB1_180:                              # %lpad100
.Ltmp105:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_235
.LBB1_98:                               # %lpad30
.Ltmp41:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_244
.LBB1_94:                               # %lpad23
.Ltmp33:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_247
.LBB1_90:                               # %lpad18
.Ltmp25:                                # EH_LABEL
	jmp	.LBB1_39
.LBB1_40:                               # %lpad14
.Ltmp19:                                # EH_LABEL
	jmp	.LBB1_33
.LBB1_4:                                # %lpad1
.Ltmp5:                                 # EH_LABEL
	jmp	.LBB1_5
.LBB1_3:                                # %lpad
.Ltmp2:                                 # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_254
.LBB1_265:                              # %terminate.lpad.i383
.Ltmp155:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_264:                              # %terminate.lpad.i370
.Ltmp152:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_263:                              # %terminate.lpad.i357
.Ltmp149:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_262:                              # %terminate.lpad.i
.Ltmp146:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.LBB1_148:                              # %lpad.i224
.Ltmp90:                                # EH_LABEL
	jmp	.LBB1_146
.LBB1_32:                               # %lpad.i
.Ltmp16:                                # EH_LABEL
.LBB1_33:                               # %ehcleanup160
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_250
.LBB1_181:                              # %lpad102
.Ltmp110:                               # EH_LABEL
	jmp	.LBB1_182
.LBB1_179:                              # %lpad97
.Ltmp102:                               # EH_LABEL
	jmp	.LBB1_139
.LBB1_136:                              # %lpad61
.Ltmp66:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_238
# %bb.137:                              # %if.then.i.i.i186
	movq	480(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
	jmp	.LBB1_238
.LBB1_134:                              # %lpad53
.Ltmp61:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_239
.LBB1_133:                              # %lpad51
.Ltmp58:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_240
.LBB1_132:                              # %lpad49
.Ltmp55:                                # EH_LABEL
	jmp	.LBB1_104
.LBB1_103:                              # %lpad47
.Ltmp52:                                # EH_LABEL
.LBB1_104:                              # %ehcleanup154
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_241
.LBB1_102:                              # %lpad44
.Ltmp49:                                # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_241
.LBB1_99:                               # %lpad32
.Ltmp46:                                # EH_LABEL
	jmp	.LBB1_100
.LBB1_95:                               # %lpad25
.Ltmp38:                                # EH_LABEL
	jmp	.LBB1_96
.LBB1_91:                               # %lpad20
.Ltmp30:                                # EH_LABEL
	jmp	.LBB1_92
.LBB1_37:                               # %lpad6
.Ltmp176:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_252
.LBB1_36:                               # %lpad2
.Ltmp179:                               # EH_LABEL
.LBB1_5:                                # %catch.dispatch
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_254
.LBB1_135:                              # %lpad59
.Ltmp164:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_238
.LBB1_38:                               # %lpad8
.Ltmp22:                                # EH_LABEL
.LBB1_39:                               # %ehcleanup160
	movq	%rdx, %rbx
	movq	%rax, %r14
	jmp	.LBB1_250
.LBB1_169:                              # %lpad.i267
.Ltmp161:                               # EH_LABEL
.LBB1_182:                              # %lpad102
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	8(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_235
# %bb.183:                              # %if.then.i.i297
	movq	24(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
	jmp	.LBB1_235
.LBB1_81:                               # %lpad.i113
.Ltmp167:                               # EH_LABEL
.LBB1_100:                              # %lpad32
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_244
# %bb.101:                              # %if.then.i.i166
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	jmp	.LBB1_243
.LBB1_66:                               # %lpad.i77
.Ltmp170:                               # EH_LABEL
.LBB1_96:                               # %lpad25
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_247
# %bb.97:                               # %if.then.i.i158
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	jmp	.LBB1_246
.LBB1_51:                               # %lpad.i58
.Ltmp173:                               # EH_LABEL
.LBB1_92:                               # %lpad20
	movq	%rdx, %rbx
	movq	%rax, %r14
	movq	464(%rsp), %rdi
	cmpq	%r15, %rdi
	je	.LBB1_250
# %bb.93:                               # %if.then.i.i150
	movq	480(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	jmp	.LBB1_249
.LBB1_178:                              # %lpad88
.Ltmp99:                                # EH_LABEL
	jmp	.LBB1_139
.LBB1_140:                              # %lpad69.loopexit.split-lp
.Ltmp83:                                # EH_LABEL
	jmp	.LBB1_139
.LBB1_233:                              # %lpad108
.Ltmp158:                               # EH_LABEL
	movq	%rdx, %rbx
	movq	%rax, %r14
.LBB1_234:                              # %ehcleanup142
	.cfi_escape 0x2e, 0x00
	leaq	464(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
.LBB1_235:                              # %ehcleanup143
	movq	104(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_237
# %bb.236:                              # %if.then.i.i.i435
	movq	120(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
	jmp	.LBB1_237
.LBB1_145:                              # %lpad.i213
.Ltmp80:                                # EH_LABEL
.LBB1_146:                              # %ehcleanup146
	movq	%rdx, %rbx
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movq	%r15, %rdi
	callq	__cxa_free_exception
	jmp	.LBB1_237
.LBB1_138:                              # %lpad69.loopexit
.Ltmp75:                                # EH_LABEL
.LBB1_139:                              # %ehcleanup146
	movq	%rdx, %rbx
	movq	%rax, %r14
.LBB1_237:                              # %ehcleanup146
	.cfi_escape 0x2e, 0x00
	leaq	296(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_238:                              # %ehcleanup147
	.cfi_escape 0x2e, 0x00
	leaq	352(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_239:                              # %ehcleanup149
	.cfi_escape 0x2e, 0x00
	leaq	408(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_240:                              # %ehcleanup151
	.cfi_escape 0x2e, 0x00
	leaq	152(%rsp), %rdi
	callq	_ZN5TilesD2Ev
.LBB1_241:                              # %ehcleanup154
	movq	128(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_244
# %bb.242:                              # %if.then.i.i.i443
	movq	144(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
.LBB1_243:                              # %ehcleanup155
	callq	_ZdlPvm
.LBB1_244:                              # %ehcleanup155
	movq	208(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_247
# %bb.245:                              # %if.then.i.i.i451
	movq	224(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
.LBB1_246:                              # %ehcleanup157
	callq	_ZdlPvm
.LBB1_247:                              # %ehcleanup157
	movq	232(%rsp), %rdi
	testq	%rdi, %rdi
	je	.LBB1_250
# %bb.248:                              # %if.then.i.i.i459
	movq	248(%rsp), %rsi
	subq	%rdi, %rsi
	.cfi_escape 0x2e, 0x00
.LBB1_249:                              # %ehcleanup160
	callq	_ZdlPvm
.LBB1_250:                              # %ehcleanup160
	movq	72(%rsp), %rdi
	leaq	88(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_252
# %bb.251:                              # %if.then.i.i466
	movq	88(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_252:                              # %ehcleanup162
	movq	40(%rsp), %rdi
	leaq	56(%rsp), %rax
	cmpq	%rax, %rdi
	je	.LBB1_254
# %bb.253:                              # %if.then.i.i474
	movq	56(%rsp), %rsi
	incq	%rsi
	.cfi_escape 0x2e, 0x00
	callq	_ZdlPvm
.LBB1_254:                              # %catch.dispatch
	cmpl	$1, %ebx
	jne	.LBB1_259
# %bb.255:                              # %catch
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	__cxa_begin_catch
	movq	(%rax), %rcx
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	*16(%rcx)
.Ltmp180:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$_ZSt4cerr, %edi
	movq	%rax, %rsi
	callq	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc
.Ltmp181:                               # EH_LABEL
# %bb.256:                              # %invoke.cont168
.Ltmp182:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_
.Ltmp183:                               # EH_LABEL
# %bb.257:                              # %invoke.cont170
	.cfi_escape 0x2e, 0x00
	callq	__cxa_end_catch
	movl	$1, %eax
	jmp	.LBB1_232
.LBB1_258:                              # %lpad167
.Ltmp184:                               # EH_LABEL
	movq	%rax, %r14
.Ltmp185:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	__cxa_end_catch
.Ltmp186:                               # EH_LABEL
.LBB1_259:                              # %eh.resume
	.cfi_escape 0x2e, 0x00
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.LBB1_260:                              # %terminate.lpad
.Ltmp187:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movq	%rax, %rdi
	callq	__clang_call_terminate
.Lfunc_end1:
	.size	main, .Lfunc_end1-main
	.cfi_endproc
	.section	.gcc_except_table,"a",@progbits
	.p2align	2, 0x0
GCC_except_table1:
.Lexception0:
	.byte	255                             # @LPStart Encoding = omit
	.byte	3                               # @TType Encoding = udata4
	.uleb128 .Lttbase0-.Lttbaseref0
.Lttbaseref0:
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Ltmp6-.Lfunc_begin0           # >> Call Site 1 <<
	.uleb128 .Ltmp7-.Ltmp6                  #   Call between .Ltmp6 and .Ltmp7
	.uleb128 .Ltmp179-.Lfunc_begin0         #     jumps to .Ltmp179
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp7-.Lfunc_begin0           # >> Call Site 2 <<
	.uleb128 .Ltmp8-.Ltmp7                  #   Call between .Ltmp7 and .Ltmp8
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp8-.Lfunc_begin0           # >> Call Site 3 <<
	.uleb128 .Ltmp9-.Ltmp8                  #   Call between .Ltmp8 and .Ltmp9
	.uleb128 .Ltmp176-.Lfunc_begin0         #     jumps to .Ltmp176
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp9-.Lfunc_begin0           # >> Call Site 4 <<
	.uleb128 .Ltmp10-.Ltmp9                 #   Call between .Ltmp9 and .Ltmp10
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp10-.Lfunc_begin0          # >> Call Site 5 <<
	.uleb128 .Ltmp11-.Ltmp10                #   Call between .Ltmp10 and .Ltmp11
	.uleb128 .Ltmp22-.Lfunc_begin0          #     jumps to .Ltmp22
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp23-.Lfunc_begin0          # >> Call Site 6 <<
	.uleb128 .Ltmp24-.Ltmp23                #   Call between .Ltmp23 and .Ltmp24
	.uleb128 .Ltmp25-.Lfunc_begin0          #     jumps to .Ltmp25
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp24-.Lfunc_begin0          # >> Call Site 7 <<
	.uleb128 .Ltmp26-.Ltmp24                #   Call between .Ltmp24 and .Ltmp26
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp26-.Lfunc_begin0          # >> Call Site 8 <<
	.uleb128 .Ltmp27-.Ltmp26                #   Call between .Ltmp26 and .Ltmp27
	.uleb128 .Ltmp173-.Lfunc_begin0         #     jumps to .Ltmp173
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp28-.Lfunc_begin0          # >> Call Site 9 <<
	.uleb128 .Ltmp29-.Ltmp28                #   Call between .Ltmp28 and .Ltmp29
	.uleb128 .Ltmp30-.Lfunc_begin0          #     jumps to .Ltmp30
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp31-.Lfunc_begin0          # >> Call Site 10 <<
	.uleb128 .Ltmp32-.Ltmp31                #   Call between .Ltmp31 and .Ltmp32
	.uleb128 .Ltmp33-.Lfunc_begin0          #     jumps to .Ltmp33
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp32-.Lfunc_begin0          # >> Call Site 11 <<
	.uleb128 .Ltmp34-.Ltmp32                #   Call between .Ltmp32 and .Ltmp34
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp34-.Lfunc_begin0          # >> Call Site 12 <<
	.uleb128 .Ltmp35-.Ltmp34                #   Call between .Ltmp34 and .Ltmp35
	.uleb128 .Ltmp170-.Lfunc_begin0         #     jumps to .Ltmp170
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp36-.Lfunc_begin0          # >> Call Site 13 <<
	.uleb128 .Ltmp37-.Ltmp36                #   Call between .Ltmp36 and .Ltmp37
	.uleb128 .Ltmp38-.Lfunc_begin0          #     jumps to .Ltmp38
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp39-.Lfunc_begin0          # >> Call Site 14 <<
	.uleb128 .Ltmp40-.Ltmp39                #   Call between .Ltmp39 and .Ltmp40
	.uleb128 .Ltmp41-.Lfunc_begin0          #     jumps to .Ltmp41
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp40-.Lfunc_begin0          # >> Call Site 15 <<
	.uleb128 .Ltmp42-.Ltmp40                #   Call between .Ltmp40 and .Ltmp42
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp42-.Lfunc_begin0          # >> Call Site 16 <<
	.uleb128 .Ltmp43-.Ltmp42                #   Call between .Ltmp42 and .Ltmp43
	.uleb128 .Ltmp167-.Lfunc_begin0         #     jumps to .Ltmp167
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp44-.Lfunc_begin0          # >> Call Site 17 <<
	.uleb128 .Ltmp45-.Ltmp44                #   Call between .Ltmp44 and .Ltmp45
	.uleb128 .Ltmp46-.Lfunc_begin0          #     jumps to .Ltmp46
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp53-.Lfunc_begin0          # >> Call Site 18 <<
	.uleb128 .Ltmp54-.Ltmp53                #   Call between .Ltmp53 and .Ltmp54
	.uleb128 .Ltmp55-.Lfunc_begin0          #     jumps to .Ltmp55
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp56-.Lfunc_begin0          # >> Call Site 19 <<
	.uleb128 .Ltmp57-.Ltmp56                #   Call between .Ltmp56 and .Ltmp57
	.uleb128 .Ltmp58-.Lfunc_begin0          #     jumps to .Ltmp58
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp59-.Lfunc_begin0          # >> Call Site 20 <<
	.uleb128 .Ltmp60-.Ltmp59                #   Call between .Ltmp59 and .Ltmp60
	.uleb128 .Ltmp61-.Lfunc_begin0          #     jumps to .Ltmp61
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp62-.Lfunc_begin0          # >> Call Site 21 <<
	.uleb128 .Ltmp63-.Ltmp62                #   Call between .Ltmp62 and .Ltmp63
	.uleb128 .Ltmp164-.Lfunc_begin0         #     jumps to .Ltmp164
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp63-.Lfunc_begin0          # >> Call Site 22 <<
	.uleb128 .Ltmp64-.Ltmp63                #   Call between .Ltmp63 and .Ltmp64
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp64-.Lfunc_begin0          # >> Call Site 23 <<
	.uleb128 .Ltmp65-.Ltmp64                #   Call between .Ltmp64 and .Ltmp65
	.uleb128 .Ltmp66-.Lfunc_begin0          #     jumps to .Ltmp66
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp67-.Lfunc_begin0          # >> Call Site 24 <<
	.uleb128 .Ltmp74-.Ltmp67                #   Call between .Ltmp67 and .Ltmp74
	.uleb128 .Ltmp75-.Lfunc_begin0          #     jumps to .Ltmp75
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp84-.Lfunc_begin0          # >> Call Site 25 <<
	.uleb128 .Ltmp98-.Ltmp84                #   Call between .Ltmp84 and .Ltmp98
	.uleb128 .Ltmp99-.Lfunc_begin0          #     jumps to .Ltmp99
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp100-.Lfunc_begin0         # >> Call Site 26 <<
	.uleb128 .Ltmp101-.Ltmp100              #   Call between .Ltmp100 and .Ltmp101
	.uleb128 .Ltmp102-.Lfunc_begin0         #     jumps to .Ltmp102
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp103-.Lfunc_begin0         # >> Call Site 27 <<
	.uleb128 .Ltmp104-.Ltmp103              #   Call between .Ltmp103 and .Ltmp104
	.uleb128 .Ltmp105-.Lfunc_begin0         #     jumps to .Ltmp105
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp104-.Lfunc_begin0         # >> Call Site 28 <<
	.uleb128 .Ltmp106-.Ltmp104              #   Call between .Ltmp104 and .Ltmp106
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp106-.Lfunc_begin0         # >> Call Site 29 <<
	.uleb128 .Ltmp107-.Ltmp106              #   Call between .Ltmp106 and .Ltmp107
	.uleb128 .Ltmp161-.Lfunc_begin0         #     jumps to .Ltmp161
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp108-.Lfunc_begin0         # >> Call Site 30 <<
	.uleb128 .Ltmp109-.Ltmp108              #   Call between .Ltmp108 and .Ltmp109
	.uleb128 .Ltmp110-.Lfunc_begin0         #     jumps to .Ltmp110
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp111-.Lfunc_begin0         # >> Call Site 31 <<
	.uleb128 .Ltmp143-.Ltmp111              #   Call between .Ltmp111 and .Ltmp143
	.uleb128 .Ltmp158-.Lfunc_begin0         #     jumps to .Ltmp158
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp144-.Lfunc_begin0         # >> Call Site 32 <<
	.uleb128 .Ltmp145-.Ltmp144              #   Call between .Ltmp144 and .Ltmp145
	.uleb128 .Ltmp146-.Lfunc_begin0         #     jumps to .Ltmp146
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp147-.Lfunc_begin0         # >> Call Site 33 <<
	.uleb128 .Ltmp148-.Ltmp147              #   Call between .Ltmp147 and .Ltmp148
	.uleb128 .Ltmp149-.Lfunc_begin0         #     jumps to .Ltmp149
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp150-.Lfunc_begin0         # >> Call Site 34 <<
	.uleb128 .Ltmp151-.Ltmp150              #   Call between .Ltmp150 and .Ltmp151
	.uleb128 .Ltmp152-.Lfunc_begin0         #     jumps to .Ltmp152
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp153-.Lfunc_begin0         # >> Call Site 35 <<
	.uleb128 .Ltmp154-.Ltmp153              #   Call between .Ltmp153 and .Ltmp154
	.uleb128 .Ltmp155-.Lfunc_begin0         #     jumps to .Ltmp155
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp154-.Lfunc_begin0         # >> Call Site 36 <<
	.uleb128 .Ltmp76-.Ltmp154               #   Call between .Ltmp154 and .Ltmp76
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp76-.Lfunc_begin0          # >> Call Site 37 <<
	.uleb128 .Ltmp79-.Ltmp76                #   Call between .Ltmp76 and .Ltmp79
	.uleb128 .Ltmp80-.Lfunc_begin0          #     jumps to .Ltmp80
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp81-.Lfunc_begin0          # >> Call Site 38 <<
	.uleb128 .Ltmp82-.Ltmp81                #   Call between .Ltmp81 and .Ltmp82
	.uleb128 .Ltmp83-.Lfunc_begin0          #     jumps to .Ltmp83
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp82-.Lfunc_begin0          # >> Call Site 39 <<
	.uleb128 .Ltmp47-.Ltmp82                #   Call between .Ltmp82 and .Ltmp47
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp47-.Lfunc_begin0          # >> Call Site 40 <<
	.uleb128 .Ltmp48-.Ltmp47                #   Call between .Ltmp47 and .Ltmp48
	.uleb128 .Ltmp49-.Lfunc_begin0          #     jumps to .Ltmp49
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp50-.Lfunc_begin0          # >> Call Site 41 <<
	.uleb128 .Ltmp51-.Ltmp50                #   Call between .Ltmp50 and .Ltmp51
	.uleb128 .Ltmp52-.Lfunc_begin0          #     jumps to .Ltmp52
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp51-.Lfunc_begin0          # >> Call Site 42 <<
	.uleb128 .Ltmp0-.Ltmp51                 #   Call between .Ltmp51 and .Ltmp0
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp0-.Lfunc_begin0           # >> Call Site 43 <<
	.uleb128 .Ltmp1-.Ltmp0                  #   Call between .Ltmp0 and .Ltmp1
	.uleb128 .Ltmp2-.Lfunc_begin0           #     jumps to .Ltmp2
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp3-.Lfunc_begin0           # >> Call Site 44 <<
	.uleb128 .Ltmp4-.Ltmp3                  #   Call between .Ltmp3 and .Ltmp4
	.uleb128 .Ltmp5-.Lfunc_begin0           #     jumps to .Ltmp5
	.byte	5                               #   On action: 3
	.uleb128 .Ltmp177-.Lfunc_begin0         # >> Call Site 45 <<
	.uleb128 .Ltmp178-.Ltmp177              #   Call between .Ltmp177 and .Ltmp178
	.uleb128 .Ltmp179-.Lfunc_begin0         #     jumps to .Ltmp179
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp174-.Lfunc_begin0         # >> Call Site 46 <<
	.uleb128 .Ltmp175-.Ltmp174              #   Call between .Ltmp174 and .Ltmp175
	.uleb128 .Ltmp176-.Lfunc_begin0         #     jumps to .Ltmp176
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp175-.Lfunc_begin0         # >> Call Site 47 <<
	.uleb128 .Ltmp12-.Ltmp175               #   Call between .Ltmp175 and .Ltmp12
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp12-.Lfunc_begin0          # >> Call Site 48 <<
	.uleb128 .Ltmp15-.Ltmp12                #   Call between .Ltmp12 and .Ltmp15
	.uleb128 .Ltmp16-.Lfunc_begin0          #     jumps to .Ltmp16
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp15-.Lfunc_begin0          # >> Call Site 49 <<
	.uleb128 .Ltmp17-.Ltmp15                #   Call between .Ltmp15 and .Ltmp17
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp17-.Lfunc_begin0          # >> Call Site 50 <<
	.uleb128 .Ltmp18-.Ltmp17                #   Call between .Ltmp17 and .Ltmp18
	.uleb128 .Ltmp19-.Lfunc_begin0          #     jumps to .Ltmp19
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp20-.Lfunc_begin0          # >> Call Site 51 <<
	.uleb128 .Ltmp21-.Ltmp20                #   Call between .Ltmp20 and .Ltmp21
	.uleb128 .Ltmp22-.Lfunc_begin0          #     jumps to .Ltmp22
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp171-.Lfunc_begin0         # >> Call Site 52 <<
	.uleb128 .Ltmp172-.Ltmp171              #   Call between .Ltmp171 and .Ltmp172
	.uleb128 .Ltmp173-.Lfunc_begin0         #     jumps to .Ltmp173
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp168-.Lfunc_begin0         # >> Call Site 53 <<
	.uleb128 .Ltmp169-.Ltmp168              #   Call between .Ltmp168 and .Ltmp169
	.uleb128 .Ltmp170-.Lfunc_begin0         #     jumps to .Ltmp170
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp165-.Lfunc_begin0         # >> Call Site 54 <<
	.uleb128 .Ltmp166-.Ltmp165              #   Call between .Ltmp165 and .Ltmp166
	.uleb128 .Ltmp167-.Lfunc_begin0         #     jumps to .Ltmp167
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp162-.Lfunc_begin0         # >> Call Site 55 <<
	.uleb128 .Ltmp163-.Ltmp162              #   Call between .Ltmp162 and .Ltmp163
	.uleb128 .Ltmp164-.Lfunc_begin0         #     jumps to .Ltmp164
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp163-.Lfunc_begin0         # >> Call Site 56 <<
	.uleb128 .Ltmp86-.Ltmp163               #   Call between .Ltmp163 and .Ltmp86
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp86-.Lfunc_begin0          # >> Call Site 57 <<
	.uleb128 .Ltmp89-.Ltmp86                #   Call between .Ltmp86 and .Ltmp89
	.uleb128 .Ltmp90-.Lfunc_begin0          #     jumps to .Ltmp90
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp91-.Lfunc_begin0          # >> Call Site 58 <<
	.uleb128 .Ltmp92-.Ltmp91                #   Call between .Ltmp91 and .Ltmp92
	.uleb128 .Ltmp99-.Lfunc_begin0          #     jumps to .Ltmp99
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp159-.Lfunc_begin0         # >> Call Site 59 <<
	.uleb128 .Ltmp160-.Ltmp159              #   Call between .Ltmp159 and .Ltmp160
	.uleb128 .Ltmp161-.Lfunc_begin0         #     jumps to .Ltmp161
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp160-.Lfunc_begin0         # >> Call Site 60 <<
	.uleb128 .Ltmp113-.Ltmp160              #   Call between .Ltmp160 and .Ltmp113
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp113-.Lfunc_begin0         # >> Call Site 61 <<
	.uleb128 .Ltmp114-.Ltmp113              #   Call between .Ltmp113 and .Ltmp114
	.uleb128 .Ltmp115-.Lfunc_begin0         #     jumps to .Ltmp115
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp116-.Lfunc_begin0         # >> Call Site 62 <<
	.uleb128 .Ltmp157-.Ltmp116              #   Call between .Ltmp116 and .Ltmp157
	.uleb128 .Ltmp158-.Lfunc_begin0         #     jumps to .Ltmp158
	.byte	3                               #   On action: 2
	.uleb128 .Ltmp157-.Lfunc_begin0         # >> Call Site 63 <<
	.uleb128 .Ltmp180-.Ltmp157              #   Call between .Ltmp157 and .Ltmp180
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp180-.Lfunc_begin0         # >> Call Site 64 <<
	.uleb128 .Ltmp183-.Ltmp180              #   Call between .Ltmp180 and .Ltmp183
	.uleb128 .Ltmp184-.Lfunc_begin0         #     jumps to .Ltmp184
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp183-.Lfunc_begin0         # >> Call Site 65 <<
	.uleb128 .Ltmp185-.Ltmp183              #   Call between .Ltmp183 and .Ltmp185
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp185-.Lfunc_begin0         # >> Call Site 66 <<
	.uleb128 .Ltmp186-.Ltmp185              #   Call between .Ltmp185 and .Ltmp186
	.uleb128 .Ltmp187-.Lfunc_begin0         #     jumps to .Ltmp187
	.byte	7                               #   On action: 4
	.uleb128 .Ltmp186-.Lfunc_begin0         # >> Call Site 67 <<
	.uleb128 .Lfunc_end1-.Ltmp186           #   Call between .Ltmp186 and .Lfunc_end1
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end0:
	.byte	0                               # >> Action Record 1 <<
                                        #   Cleanup
	.byte	0                               #   No further actions
	.byte	1                               # >> Action Record 2 <<
                                        #   Catch TypeInfo 1
	.byte	125                             #   Continue to action 1
	.byte	1                               # >> Action Record 3 <<
                                        #   Catch TypeInfo 1
	.byte	0                               #   No further actions
	.byte	2                               # >> Action Record 4 <<
                                        #   Catch TypeInfo 2
	.byte	0                               #   No further actions
	.p2align	2, 0x0
                                        # >> Catch TypeInfos <<
	.long	0                               # TypeInfo 2
	.long	_ZTISt9exception                # TypeInfo 1
.Lttbase0:
	.p2align	2, 0x0
                                        # -- End function
	.text
	.p2align	4                               # -- Begin function _ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.type	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,@function
_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE: # @_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception1
# %bb.0:                                # %invoke.cont
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$520, %rsp                      # imm = 0x208
	.cfi_def_cfa_offset 560
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %r15
	movq	%rsp, %rdi
	movl	$6, %edx
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEEC1ERKNSt7__cxx1112basic_stringIcS1_SaIcEEESt13_Ios_Openmode
	movq	(%rsp), %rax
	movq	-24(%rax), %rax
	testb	$5, 32(%rsp,%rax)
	jne	.LBB2_12
# %bb.1:                                # %if.end
.Ltmp194:                               # EH_LABEL
	movq	%rsp, %rdi
	callq	_ZNSi5tellgEv
.Ltmp195:                               # EH_LABEL
# %bb.2:                                # %invoke.cont5
.Ltmp197:                               # EH_LABEL
	movq	%rax, %r12
	movq	%rsp, %rdi
	xorl	%esi, %esi
	xorl	%edx, %edx
	callq	_ZNSi5seekgESt4fposI11__mbstate_tE
.Ltmp198:                               # EH_LABEL
# %bb.3:                                # %invoke.cont11
	testq	%r12, %r12
	js	.LBB2_14
# %bb.4:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r15)
	movq	$0, 16(%r15)
	je	.LBB2_8
# %bb.5:                                # %if.then.i.i.i.i.i
.Ltmp200:                               # EH_LABEL
	movq	%r12, %rdi
	callq	_Znwm
.Ltmp201:                               # EH_LABEL
# %bb.6:                                # %call5.i.i.i.i1.i.i.noexc
	movq	%rax, %rbx
	movq	%rax, (%r15)
	leaq	(%rax,%r12), %r14
	movq	%r14, 16(%r15)
	movb	$0, (%rax)
	movq	%rax, %rdi
	incq	%rdi
	movq	%r12, %rdx
	decq	%rdx
	je	.LBB2_9
# %bb.7:                                # %if.then.i.i.i.i.i.i.i.i.i
	xorl	%esi, %esi
	callq	memset@PLT
	movq	%r14, %rdi
	jmp	.LBB2_9
.LBB2_8:
	xorl	%r14d, %r14d
	xorl	%ebx, %ebx
	xorl	%edi, %edi
.LBB2_9:                                # %invoke.cont15
	movq	%rdi, 8(%r15)
.Ltmp202:                               # EH_LABEL
	movq	%rsp, %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	callq	_ZNSi4readEPcl
.Ltmp203:                               # EH_LABEL
# %bb.10:                               # %invoke.cont24
	movq	(%rsp), %rax
	movq	-24(%rax), %rax
	testb	$5, 32(%rsp,%rax)
	jne	.LBB2_16
# %bb.11:                               # %nrvo.skipdtor
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	addq	$520, %rsp                      # imm = 0x208
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB2_12:                               # %if.then
	.cfi_def_cfa_offset 560
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %rbx
.Ltmp188:                               # EH_LABEL
	movl	$.L.str.13, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp189:                               # EH_LABEL
# %bb.13:                               # %invoke.cont3
.Ltmp191:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%rbx, %rdi
	callq	__cxa_throw
.Ltmp192:                               # EH_LABEL
	jmp	.LBB2_18
.LBB2_14:                               # %if.then.i.i
.Ltmp210:                               # EH_LABEL
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp211:                               # EH_LABEL
# %bb.15:                               # %.noexc
.LBB2_16:                               # %if.then26
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r12
.Ltmp204:                               # EH_LABEL
	movl	$.L.str.14, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp205:                               # EH_LABEL
# %bb.17:                               # %invoke.cont29
.Ltmp207:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r12, %rdi
	callq	__cxa_throw
.Ltmp208:                               # EH_LABEL
.LBB2_18:                               # %unreachable
.LBB2_19:                               # %lpad28
.Ltmp206:                               # EH_LABEL
	movq	%rax, %r15
	movq	%r12, %rdi
	callq	__cxa_free_exception
	jmp	.LBB2_26
.LBB2_20:                               # %lpad
.Ltmp193:                               # EH_LABEL
	jmp	.LBB2_21
.LBB2_22:                               # %lpad2
.Ltmp190:                               # EH_LABEL
	movq	%rax, %r15
	movq	%rbx, %rdi
	callq	__cxa_free_exception
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_23:                               # %lpad9
.Ltmp199:                               # EH_LABEL
	jmp	.LBB2_21
.LBB2_24:                               # %lpad4
.Ltmp196:                               # EH_LABEL
.LBB2_21:                               # %lpad
	movq	%rax, %r15
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_25:                               # %lpad17
.Ltmp209:                               # EH_LABEL
	movq	%rax, %r15
.LBB2_26:                               # %ehcleanup
	testq	%rbx, %rbx
	je	.LBB2_29
# %bb.27:                               # %if.then.i.i.i
	subq	%rbx, %r14
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	_ZdlPvm
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_28:                               # %lpad14
.Ltmp212:                               # EH_LABEL
	movq	%rax, %r15
.LBB2_29:                               # %ehcleanup32
	movq	%rsp, %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end2:
	.size	_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE, .Lfunc_end2-_ZL4readRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE
	.cfi_endproc
	.section	.gcc_except_table,"a",@progbits
	.p2align	2, 0x0
GCC_except_table2:
.Lexception1:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Lfunc_begin1-.Lfunc_begin1    # >> Call Site 1 <<
	.uleb128 .Ltmp194-.Lfunc_begin1         #   Call between .Lfunc_begin1 and .Ltmp194
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp194-.Lfunc_begin1         # >> Call Site 2 <<
	.uleb128 .Ltmp195-.Ltmp194              #   Call between .Ltmp194 and .Ltmp195
	.uleb128 .Ltmp196-.Lfunc_begin1         #     jumps to .Ltmp196
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp197-.Lfunc_begin1         # >> Call Site 3 <<
	.uleb128 .Ltmp198-.Ltmp197              #   Call between .Ltmp197 and .Ltmp198
	.uleb128 .Ltmp199-.Lfunc_begin1         #     jumps to .Ltmp199
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp200-.Lfunc_begin1         # >> Call Site 4 <<
	.uleb128 .Ltmp201-.Ltmp200              #   Call between .Ltmp200 and .Ltmp201
	.uleb128 .Ltmp212-.Lfunc_begin1         #     jumps to .Ltmp212
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp201-.Lfunc_begin1         # >> Call Site 5 <<
	.uleb128 .Ltmp202-.Ltmp201              #   Call between .Ltmp201 and .Ltmp202
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp202-.Lfunc_begin1         # >> Call Site 6 <<
	.uleb128 .Ltmp203-.Ltmp202              #   Call between .Ltmp202 and .Ltmp203
	.uleb128 .Ltmp209-.Lfunc_begin1         #     jumps to .Ltmp209
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp203-.Lfunc_begin1         # >> Call Site 7 <<
	.uleb128 .Ltmp188-.Ltmp203              #   Call between .Ltmp203 and .Ltmp188
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp188-.Lfunc_begin1         # >> Call Site 8 <<
	.uleb128 .Ltmp189-.Ltmp188              #   Call between .Ltmp188 and .Ltmp189
	.uleb128 .Ltmp190-.Lfunc_begin1         #     jumps to .Ltmp190
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp191-.Lfunc_begin1         # >> Call Site 9 <<
	.uleb128 .Ltmp192-.Ltmp191              #   Call between .Ltmp191 and .Ltmp192
	.uleb128 .Ltmp193-.Lfunc_begin1         #     jumps to .Ltmp193
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp210-.Lfunc_begin1         # >> Call Site 10 <<
	.uleb128 .Ltmp211-.Ltmp210              #   Call between .Ltmp210 and .Ltmp211
	.uleb128 .Ltmp212-.Lfunc_begin1         #     jumps to .Ltmp212
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp211-.Lfunc_begin1         # >> Call Site 11 <<
	.uleb128 .Ltmp204-.Ltmp211              #   Call between .Ltmp211 and .Ltmp204
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp204-.Lfunc_begin1         # >> Call Site 12 <<
	.uleb128 .Ltmp205-.Ltmp204              #   Call between .Ltmp204 and .Ltmp205
	.uleb128 .Ltmp206-.Lfunc_begin1         #     jumps to .Ltmp206
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp207-.Lfunc_begin1         # >> Call Site 13 <<
	.uleb128 .Ltmp208-.Ltmp207              #   Call between .Ltmp207 and .Ltmp208
	.uleb128 .Ltmp209-.Lfunc_begin1         #     jumps to .Ltmp209
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp208-.Lfunc_begin1         # >> Call Site 14 <<
	.uleb128 .Lfunc_end2-.Ltmp208           #   Call between .Ltmp208 and .Lfunc_end2
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end1:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN5TilesC2ERKSt6vectorIcSaIcEEm,"axG",@progbits,_ZN5TilesC2ERKSt6vectorIcSaIcEEm,comdat
	.weak	_ZN5TilesC2ERKSt6vectorIcSaIcEEm # -- Begin function _ZN5TilesC2ERKSt6vectorIcSaIcEEm
	.p2align	4
	.type	_ZN5TilesC2ERKSt6vectorIcSaIcEEm,@function
_ZN5TilesC2ERKSt6vectorIcSaIcEEm:       # @_ZN5TilesC2ERKSt6vectorIcSaIcEEm
.Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception2
# %bb.0:                                # %entry
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r15
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	$0, (%rdi)
	movq	%rdx, 8(%rdi)
	movq	8(%rsi), %rsi
	subq	(%r14), %rsi
	movq	%rsi, %rax
	orq	%rdx, %rax
	shrq	$32, %rax
	je	.LBB3_1
# %bb.2:
	movq	%rsi, %rax
	xorl	%edx, %edx
	divq	%r15
	movq	%rax, %r12
	jmp	.LBB3_3
.LBB3_1:
	movl	%esi, %eax
	xorl	%edx, %edx
	divl	%r15d
	movl	%eax, %r12d
.LBB3_3:
	movq	%r12, 16(%rbx)
	leaq	256(%r15), %rax
	movq	%rax, 24(%rbx)
	imulq	%rax, %r12
	testq	%r12, %r12
	js	.LBB3_36
# %bb.4:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	leaq	32(%rbx), %rax
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%rax)
	movq	$0, 16(%rax)
	testq	%r12, %r12
	je	.LBB3_5
# %bb.6:                                # %if.then.i.i.i.i.i.i.i.i.i
	movq	%r12, %rdi
	movq	%rsi, (%rsp)                    # 8-byte Spill
	callq	_Znwm
	movq	%rax, %r13
	movq	%rax, 32(%rbx)
	movq	%rax, 40(%rbx)
	leaq	(%rax,%r12), %rbp
	movq	%rbp, 48(%rbx)
	movq	%rax, %rdi
	movl	$90, %esi
	movq	%r12, %rdx
	callq	memset@PLT
	leaq	40(%rbx), %rax
	movq	(%rsp), %rsi                    # 8-byte Reload
	jmp	.LBB3_7
.LBB3_5:                                # %_ZNSt12_Vector_baseIcSaIcEEC2EmRKS0_.exit.thread.i
	leaq	40(%rbx), %rax
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
.LBB3_7:                                # %invoke.cont
	movq	%rbp, (%rax)
	movq	(%r14), %rcx
	movq	8(%r14), %rax
	cmpq	%rax, %rcx
	je	.LBB3_20
# %bb.8:                                # %lor.lhs.false
	subq	%rcx, %rax
	movq	%rax, %rcx
	orq	%r15, %rcx
	shrq	$32, %rcx
	je	.LBB3_9
# %bb.10:
	xorl	%edx, %edx
	divq	%r15
	testq	%rdx, %rdx
	jne	.LBB3_20
.LBB3_12:                               # %for.cond.preheader
	cmpq	%rsi, %r15
	ja	.LBB3_16
# %bb.13:                               # %for.body.preheader
	xorl	%r15d, %r15d
	.p2align	4
.LBB3_14:                               # %for.body
                                        # =>This Inner Loop Header: Depth=1
	movq	8(%rbx), %rdx
	movq	32(%rbx), %rax
	movq	24(%rbx), %rcx
	imulq	%r15, %rcx
	leaq	(%rax,%rcx), %rdi
	addq	$128, %rdi
	movq	%rdx, %rsi
	imulq	%r15, %rsi
	addq	(%r14), %rsi
	callq	memcpy@PLT
	incq	%r15
	cmpq	16(%rbx), %r15
	jb	.LBB3_14
# %bb.15:                               # %for.cond.cleanup.loopexit
	movq	32(%rbx), %r13
	movq	40(%rbx), %rbp
.LBB3_16:                               # %for.cond.cleanup
	subq	%r13, %rbp
.Ltmp213:                               # EH_LABEL
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	callq	hipMalloc
.Ltmp214:                               # EH_LABEL
# %bb.17:                               # %invoke.cont25
	testl	%eax, %eax
	jne	.LBB3_18
# %bb.24:                               # %invoke.cont27
	movq	(%rbx), %rdi
	movq	32(%rbx), %rsi
	movq	40(%rbx), %rdx
	subq	%rsi, %rdx
.Ltmp220:                               # EH_LABEL
	movl	$1, %ecx
	callq	hipMemcpy
.Ltmp221:                               # EH_LABEL
# %bb.25:                               # %invoke.cont33
	testl	%eax, %eax
	jne	.LBB3_26
# %bb.31:                               # %invoke.cont35
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB3_9:
	.cfi_def_cfa_offset 64
                                        # kill: def $eax killed $eax killed $rax
	xorl	%edx, %edx
	divl	%r15d
                                        # kill: def $edx killed $edx def $rdx
	testq	%rdx, %rdx
	je	.LBB3_12
.LBB3_20:                               # %if.then
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r14
.Ltmp227:                               # EH_LABEL
	movl	$.L.str.16, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp228:                               # EH_LABEL
.LBB3_28:                               # %invoke.cont1.i32.invoke
.Ltmp230:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r14, %rdi
	callq	__cxa_throw
.Ltmp231:                               # EH_LABEL
# %bb.29:                               # %invoke.cont1.i32.cont
.LBB3_36:                               # %if.then.i.i
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.LBB3_18:                               # %if.then.i
	movl	$16, %edi
	movl	%eax, %ebp
	callq	__cxa_allocate_exception
	movq	%rax, %r14
.Ltmp215:                               # EH_LABEL
	movl	%ebp, %edi
	callq	hipGetErrorString
.Ltmp216:                               # EH_LABEL
# %bb.19:                               # %invoke.cont.i
.Ltmp217:                               # EH_LABEL
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp218:                               # EH_LABEL
	jmp	.LBB3_28
.LBB3_26:                               # %if.then.i27
	movl	$16, %edi
	movl	%eax, %ebp
	callq	__cxa_allocate_exception
	movq	%rax, %r14
.Ltmp222:                               # EH_LABEL
	movl	%ebp, %edi
	callq	hipGetErrorString
.Ltmp223:                               # EH_LABEL
# %bb.27:                               # %invoke.cont.i31
.Ltmp224:                               # EH_LABEL
	movq	%r14, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp225:                               # EH_LABEL
	jmp	.LBB3_28
.LBB3_30:                               # %lpad.i30
.Ltmp226:                               # EH_LABEL
	jmp	.LBB3_22
.LBB3_23:                               # %lpad.i
.Ltmp219:                               # EH_LABEL
	jmp	.LBB3_22
.LBB3_21:                               # %lpad8
.Ltmp229:                               # EH_LABEL
.LBB3_22:                               # %ehcleanup
	movq	%rax, %r15
	movq	%r14, %rdi
	callq	__cxa_free_exception
	jmp	.LBB3_33
.LBB3_32:                               # %lpad10
.Ltmp232:                               # EH_LABEL
	movq	%rax, %r15
.LBB3_33:                               # %ehcleanup
	leaq	32(%rbx), %rax
	movq	(%rax), %rdi
	testq	%rdi, %rdi
	je	.LBB3_35
# %bb.34:                               # %if.then.i.i.i
	movq	48(%rbx), %rsi
	subq	%rdi, %rsi
	callq	_ZdlPvm
.LBB3_35:                               # %eh.resume
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end3:
	.size	_ZN5TilesC2ERKSt6vectorIcSaIcEEm, .Lfunc_end3-_ZN5TilesC2ERKSt6vectorIcSaIcEEm
	.cfi_endproc
	.section	.gcc_except_table._ZN5TilesC2ERKSt6vectorIcSaIcEEm,"aG",@progbits,_ZN5TilesC2ERKSt6vectorIcSaIcEEm,comdat
	.p2align	2, 0x0
GCC_except_table3:
.Lexception2:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end2-.Lcst_begin2
.Lcst_begin2:
	.uleb128 .Lfunc_begin2-.Lfunc_begin2    # >> Call Site 1 <<
	.uleb128 .Ltmp213-.Lfunc_begin2         #   Call between .Lfunc_begin2 and .Ltmp213
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp213-.Lfunc_begin2         # >> Call Site 2 <<
	.uleb128 .Ltmp221-.Ltmp213              #   Call between .Ltmp213 and .Ltmp221
	.uleb128 .Ltmp232-.Lfunc_begin2         #     jumps to .Ltmp232
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp221-.Lfunc_begin2         # >> Call Site 3 <<
	.uleb128 .Ltmp227-.Ltmp221              #   Call between .Ltmp221 and .Ltmp227
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp227-.Lfunc_begin2         # >> Call Site 4 <<
	.uleb128 .Ltmp228-.Ltmp227              #   Call between .Ltmp227 and .Ltmp228
	.uleb128 .Ltmp229-.Lfunc_begin2         #     jumps to .Ltmp229
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp230-.Lfunc_begin2         # >> Call Site 5 <<
	.uleb128 .Ltmp231-.Ltmp230              #   Call between .Ltmp230 and .Ltmp231
	.uleb128 .Ltmp232-.Lfunc_begin2         #     jumps to .Ltmp232
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp231-.Lfunc_begin2         # >> Call Site 6 <<
	.uleb128 .Ltmp215-.Ltmp231              #   Call between .Ltmp231 and .Ltmp215
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp215-.Lfunc_begin2         # >> Call Site 7 <<
	.uleb128 .Ltmp218-.Ltmp215              #   Call between .Ltmp215 and .Ltmp218
	.uleb128 .Ltmp219-.Lfunc_begin2         #     jumps to .Ltmp219
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp218-.Lfunc_begin2         # >> Call Site 8 <<
	.uleb128 .Ltmp222-.Ltmp218              #   Call between .Ltmp218 and .Ltmp222
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp222-.Lfunc_begin2         # >> Call Site 9 <<
	.uleb128 .Ltmp225-.Ltmp222              #   Call between .Ltmp222 and .Ltmp225
	.uleb128 .Ltmp226-.Lfunc_begin2         #     jumps to .Ltmp226
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp225-.Lfunc_begin2         # >> Call Site 10 <<
	.uleb128 .Lfunc_end3-.Ltmp225           #   Call between .Ltmp225 and .Lfunc_end3
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end2:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN5Tiles6verifyEb,"axG",@progbits,_ZN5Tiles6verifyEb,comdat
	.weak	_ZN5Tiles6verifyEb              # -- Begin function _ZN5Tiles6verifyEb
	.p2align	4
	.type	_ZN5Tiles6verifyEb,@function
_ZN5Tiles6verifyEb:                     # @_ZN5Tiles6verifyEb
.Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception3
# %bb.0:                                # %entry
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	32(%rsi), %rax
	movq	40(%rsi), %r15
	subq	%rax, %r15
	js	.LBB4_50
# %bb.1:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i
	movl	%edx, %r14d
	movq	%rsi, %rbp
	movq	%rdi, %r12
	movl	%edx, 8(%rsp)                   # 4-byte Spill
	je	.LBB4_2
# %bb.3:                                # %if.then.i.i.i.i.i
	movq	%r15, %rdi
	callq	_Znwm
	movq	%rax, %r13
	leaq	(%rax,%r15), %r14
	movb	$0, (%rax)
	movq	%rax, %rbx
	incq	%rbx
	decq	%r15
	movq	%r14, 24(%rsp)                  # 8-byte Spill
	je	.LBB4_5
# %bb.4:                                # %if.then.i.i.i.i.i.i.i.i.i
	movq	%rbx, %rdi
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	memset@PLT
	movq	%r14, %rbx
.LBB4_5:                                # %invoke.cont
	movl	8(%rsp), %r14d                  # 4-byte Reload
	jmp	.LBB4_6
.LBB4_2:
	movq	$0, 24(%rsp)                    # 8-byte Folded Spill
	xorl	%r13d, %r13d
	xorl	%ebx, %ebx
.LBB4_6:                                # %invoke.cont
	movq	8(%rbp), %r15
	imulq	16(%rbp), %r15
	testq	%r15, %r15
	movq	%r13, 32(%rsp)                  # 8-byte Spill
	js	.LBB4_7
# %bb.9:                                # %_ZNSt6vectorIcSaIcEE17_S_check_init_lenEmRKS0_.exit.i16
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r12)
	movq	$0, 16(%r12)
	je	.LBB4_10
# %bb.11:                               # %if.then.i.i.i.i.i18
.Ltmp233:                               # EH_LABEL
	movq	%r15, %rdi
	callq	_Znwm
.Ltmp234:                               # EH_LABEL
# %bb.12:                               # %call5.i.i.i.i1.i.i.noexc30
	movq	%rax, (%r12)
	movq	%r12, %rcx
	leaq	(%rax,%r15), %r12
	movq	%rcx, %r14
	movq	%r12, 16(%rcx)
	movb	$0, (%rax)
	movq	%rax, %rdi
	incq	%rdi
	decq	%r15
	movq	%rax, 16(%rsp)                  # 8-byte Spill
	movq	%r12, 40(%rsp)                  # 8-byte Spill
	je	.LBB4_14
# %bb.13:                               # %if.then.i.i.i.i.i.i.i.i.i24
	xorl	%esi, %esi
	movq	%r15, %rdx
	callq	memset@PLT
	movq	%r12, %rdi
.LBB4_14:                               # %invoke.cont4
	movq	%r14, %r12
	movl	8(%rsp), %r14d                  # 4-byte Reload
	jmp	.LBB4_15
.LBB4_10:
	movq	$0, 40(%rsp)                    # 8-byte Folded Spill
	movq	$0, 16(%rsp)                    # 8-byte Folded Spill
	xorl	%edi, %edi
.LBB4_15:                               # %invoke.cont4
	movq	%r12, 48(%rsp)                  # 8-byte Spill
	movq	%rdi, 8(%r12)
	movq	(%rbp), %rsi
	movq	%rbx, %r15
	subq	%r13, %r15
.Ltmp235:                               # EH_LABEL
	movq	%r13, %rdi
	movq	%r15, %rdx
	movl	$2, %ecx
	callq	hipMemcpy
.Ltmp236:                               # EH_LABEL
# %bb.16:                               # %invoke.cont8
	movl	%eax, %r12d
	testl	%eax, %eax
	jne	.LBB4_17
# %bb.23:                               # %invoke.cont10
	testb	%r14b, %r14b
	je	.LBB4_30
# %bb.24:                               # %land.lhs.true
	movq	32(%rbp), %rsi
	movq	40(%rbp), %rax
	subq	%rsi, %rax
	cmpq	%rax, %r15
	jne	.LBB4_27
# %bb.25:                               # %land.rhs.i.i
	cmpq	%r13, %rbx
	je	.LBB4_30
# %bb.26:                               # %invoke.cont12
	movq	%r13, %rdi
	movq	%r15, %rdx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB4_27
.LBB4_30:                               # %if.end
	movq	16(%rbp), %rax
	movq	%rax, 8(%rsp)                   # 8-byte Spill
	testq	%rax, %rax
	je	.LBB4_39
# %bb.31:                               # %for.body.lr.ph
	movq	8(%rbp), %r14
	movq	%r13, %rax
	movq	24(%rbp), %r13
	movq	32(%rbp), %r12
	xorl	%ebx, %ebx
	movq	%rax, %rbp
	movq	16(%rsp), %r15                  # 8-byte Reload
	.p2align	4
.LBB4_32:                               # %for.body
                                        # =>This Inner Loop Header: Depth=1
	movl	$128, %edx
	movq	%rbp, %rdi
	movq	%r12, %rsi
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB4_34
# %bb.33:                               # %lor.lhs.false
                                        #   in Loop: Header=BB4_32 Depth=1
	leaq	128(%r14), %rax
	leaq	(%rax,%rbp), %rdi
	leaq	(%r12,%rax), %rsi
	movl	$128, %edx
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB4_34
# %bb.38:                               # %if.end41
                                        #   in Loop: Header=BB4_32 Depth=1
	leaq	128(%rbp), %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	memcpy@PLT
	incq	%rbx
	addq	%r14, %r15
	addq	%r13, %rbp
	addq	%r13, %r12
	cmpq	8(%rsp), %rbx                   # 8-byte Folded Reload
	jb	.LBB4_32
	jmp	.LBB4_40
.LBB4_39:                               # %nrvo.skipdtor
	testq	%r13, %r13
	je	.LBB4_41
.LBB4_40:                               # %if.then.i.i.i
	movq	24(%rsp), %rsi                  # 8-byte Reload
	movq	32(%rsp), %rdi                  # 8-byte Reload
	subq	%rdi, %rsi
	callq	_ZdlPvm
.LBB4_41:                               # %_ZNSt6vectorIcSaIcEED2Ev.exit
	movq	48(%rsp), %rax                  # 8-byte Reload
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB4_34:                               # %if.then36
	.cfi_def_cfa_offset 112
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp248:                               # EH_LABEL
	movl	$.L.str.18, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp249:                               # EH_LABEL
# %bb.35:                               # %invoke.cont39
.Ltmp251:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp252:                               # EH_LABEL
# %bb.49:                               # %unreachable
.LBB4_50:                               # %if.then.i.i
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.LBB4_7:                                # %if.then.i.i28
.Ltmp254:                               # EH_LABEL
	movl	$.L.str.15, %edi
	callq	_ZSt20__throw_length_errorPKc
.Ltmp255:                               # EH_LABEL
# %bb.8:                                # %.noexc29
.LBB4_17:                               # %if.then.i
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp237:                               # EH_LABEL
	movl	%r12d, %edi
	callq	hipGetErrorString
.Ltmp238:                               # EH_LABEL
# %bb.18:                               # %invoke.cont.i
.Ltmp239:                               # EH_LABEL
	movq	%r15, %rdi
	movq	%rax, %rsi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp240:                               # EH_LABEL
	jmp	.LBB4_19
.LBB4_27:                               # %if.then
	movl	$16, %edi
	callq	__cxa_allocate_exception
	movq	%rax, %r15
.Ltmp242:                               # EH_LABEL
	movl	$.L.str.17, %esi
	movq	%rax, %rdi
	callq	_ZNSt13runtime_errorC1EPKc
.Ltmp243:                               # EH_LABEL
.LBB4_19:                               # %invoke.cont1.i.invoke
.Ltmp245:                               # EH_LABEL
	movl	$_ZTISt13runtime_error, %esi
	movl	$_ZNSt13runtime_errorD1Ev, %edx
	movq	%r15, %rdi
	callq	__cxa_throw
.Ltmp246:                               # EH_LABEL
# %bb.20:                               # %invoke.cont1.i.cont
.LBB4_29:                               # %lpad14
.Ltmp244:                               # EH_LABEL
	jmp	.LBB4_22
.LBB4_21:                               # %lpad.i
.Ltmp241:                               # EH_LABEL
	jmp	.LBB4_22
.LBB4_28:                               # %lpad3
.Ltmp256:                               # EH_LABEL
	movq	%rax, %r14
	cmpq	$0, 32(%rsp)                    # 8-byte Folded Reload
	je	.LBB4_48
	jmp	.LBB4_47
.LBB4_42:                               # %lpad7
.Ltmp247:                               # EH_LABEL
	jmp	.LBB4_43
.LBB4_37:                               # %lpad40
.Ltmp253:                               # EH_LABEL
.LBB4_43:                               # %ehcleanup51
	movq	%rax, %r14
	jmp	.LBB4_44
.LBB4_36:                               # %lpad38
.Ltmp250:                               # EH_LABEL
.LBB4_22:                               # %ehcleanup51
	movq	%rax, %r14
	movq	%r15, %rdi
	callq	__cxa_free_exception
.LBB4_44:                               # %ehcleanup51
	cmpq	$0, 16(%rsp)                    # 8-byte Folded Reload
	jne	.LBB4_45
# %bb.46:                               # %ehcleanup52
	cmpq	$0, 32(%rsp)                    # 8-byte Folded Reload
	jne	.LBB4_47
.LBB4_48:                               # %ehcleanup53
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.LBB4_45:                               # %if.then.i.i.i42
	movq	16(%rsp), %rdi                  # 8-byte Reload
	movq	40(%rsp), %rsi                  # 8-byte Reload
	subq	%rdi, %rsi
	callq	_ZdlPvm
	cmpq	$0, 32(%rsp)                    # 8-byte Folded Reload
	je	.LBB4_48
.LBB4_47:                               # %if.then.i.i.i50
	movq	24(%rsp), %rsi                  # 8-byte Reload
	movq	32(%rsp), %rdi                  # 8-byte Reload
	subq	%rdi, %rsi
	callq	_ZdlPvm
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end4:
	.size	_ZN5Tiles6verifyEb, .Lfunc_end4-_ZN5Tiles6verifyEb
	.cfi_endproc
	.section	.gcc_except_table._ZN5Tiles6verifyEb,"aG",@progbits,_ZN5Tiles6verifyEb,comdat
	.p2align	2, 0x0
GCC_except_table4:
.Lexception3:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end3-.Lcst_begin3
.Lcst_begin3:
	.uleb128 .Lfunc_begin3-.Lfunc_begin3    # >> Call Site 1 <<
	.uleb128 .Ltmp233-.Lfunc_begin3         #   Call between .Lfunc_begin3 and .Ltmp233
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp233-.Lfunc_begin3         # >> Call Site 2 <<
	.uleb128 .Ltmp234-.Ltmp233              #   Call between .Ltmp233 and .Ltmp234
	.uleb128 .Ltmp256-.Lfunc_begin3         #     jumps to .Ltmp256
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp234-.Lfunc_begin3         # >> Call Site 3 <<
	.uleb128 .Ltmp235-.Ltmp234              #   Call between .Ltmp234 and .Ltmp235
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp235-.Lfunc_begin3         # >> Call Site 4 <<
	.uleb128 .Ltmp236-.Ltmp235              #   Call between .Ltmp235 and .Ltmp236
	.uleb128 .Ltmp247-.Lfunc_begin3         #     jumps to .Ltmp247
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp236-.Lfunc_begin3         # >> Call Site 5 <<
	.uleb128 .Ltmp248-.Ltmp236              #   Call between .Ltmp236 and .Ltmp248
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp248-.Lfunc_begin3         # >> Call Site 6 <<
	.uleb128 .Ltmp249-.Ltmp248              #   Call between .Ltmp248 and .Ltmp249
	.uleb128 .Ltmp250-.Lfunc_begin3         #     jumps to .Ltmp250
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp251-.Lfunc_begin3         # >> Call Site 7 <<
	.uleb128 .Ltmp252-.Ltmp251              #   Call between .Ltmp251 and .Ltmp252
	.uleb128 .Ltmp253-.Lfunc_begin3         #     jumps to .Ltmp253
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp252-.Lfunc_begin3         # >> Call Site 8 <<
	.uleb128 .Ltmp254-.Ltmp252              #   Call between .Ltmp252 and .Ltmp254
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp254-.Lfunc_begin3         # >> Call Site 9 <<
	.uleb128 .Ltmp255-.Ltmp254              #   Call between .Ltmp254 and .Ltmp255
	.uleb128 .Ltmp256-.Lfunc_begin3         #     jumps to .Ltmp256
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp255-.Lfunc_begin3         # >> Call Site 10 <<
	.uleb128 .Ltmp237-.Ltmp255              #   Call between .Ltmp255 and .Ltmp237
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp237-.Lfunc_begin3         # >> Call Site 11 <<
	.uleb128 .Ltmp240-.Ltmp237              #   Call between .Ltmp237 and .Ltmp240
	.uleb128 .Ltmp241-.Lfunc_begin3         #     jumps to .Ltmp241
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp240-.Lfunc_begin3         # >> Call Site 12 <<
	.uleb128 .Ltmp242-.Ltmp240              #   Call between .Ltmp240 and .Ltmp242
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp242-.Lfunc_begin3         # >> Call Site 13 <<
	.uleb128 .Ltmp243-.Ltmp242              #   Call between .Ltmp242 and .Ltmp243
	.uleb128 .Ltmp244-.Lfunc_begin3         #     jumps to .Ltmp244
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp245-.Lfunc_begin3         # >> Call Site 14 <<
	.uleb128 .Ltmp246-.Ltmp245              #   Call between .Ltmp245 and .Ltmp246
	.uleb128 .Ltmp247-.Lfunc_begin3         #     jumps to .Ltmp247
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp246-.Lfunc_begin3         # >> Call Site 15 <<
	.uleb128 .Lfunc_end4-.Ltmp246           #   Call between .Ltmp246 and .Lfunc_end4
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end3:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text._ZN5TilesD2Ev,"axG",@progbits,_ZN5TilesD2Ev,comdat
	.weak	_ZN5TilesD2Ev                   # -- Begin function _ZN5TilesD2Ev
	.p2align	4
	.type	_ZN5TilesD2Ev,@function
_ZN5TilesD2Ev:                          # @_ZN5TilesD2Ev
.Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception4
# %bb.0:                                # %entry
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB5_2
# %bb.1:                                # %if.then
.Ltmp257:                               # EH_LABEL
	callq	hipFree
.Ltmp258:                               # EH_LABEL
.LBB5_2:                                # %if.end
	movq	32(%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB5_3
# %bb.5:                                # %if.then.i.i.i
	movq	48(%rbx), %rsi
	subq	%rdi, %rsi
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	_ZdlPvm                         # TAILCALL
.LBB5_3:                                # %_ZNSt6vectorIcSaIcEED2Ev.exit
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB5_4:                                # %terminate.lpad
	.cfi_def_cfa_offset 16
.Ltmp259:                               # EH_LABEL
	movq	%rax, %rdi
	callq	__clang_call_terminate
.Lfunc_end5:
	.size	_ZN5TilesD2Ev, .Lfunc_end5-_ZN5TilesD2Ev
	.cfi_endproc
	.section	.gcc_except_table._ZN5TilesD2Ev,"aG",@progbits,_ZN5TilesD2Ev,comdat
	.p2align	2, 0x0
GCC_except_table5:
.Lexception4:
	.byte	255                             # @LPStart Encoding = omit
	.byte	3                               # @TType Encoding = udata4
	.uleb128 .Lttbase1-.Lttbaseref1
.Lttbaseref1:
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end4-.Lcst_begin4
.Lcst_begin4:
	.uleb128 .Ltmp257-.Lfunc_begin4         # >> Call Site 1 <<
	.uleb128 .Ltmp258-.Ltmp257              #   Call between .Ltmp257 and .Ltmp258
	.uleb128 .Ltmp259-.Lfunc_begin4         #     jumps to .Ltmp259
	.byte	1                               #   On action: 1
.Lcst_end4:
	.byte	1                               # >> Action Record 1 <<
                                        #   Catch TypeInfo 1
	.byte	0                               #   No further actions
	.p2align	2, 0x0
                                        # >> Catch TypeInfos <<
	.long	0                               # TypeInfo 1
.Lttbase1:
	.p2align	2, 0x0
                                        # -- End function
	.section	.text.__clang_call_terminate,"axG",@progbits,__clang_call_terminate,comdat
	.hidden	__clang_call_terminate          # -- Begin function __clang_call_terminate
	.weak	__clang_call_terminate
	.p2align	4
	.type	__clang_call_terminate,@function
__clang_call_terminate:                 # @__clang_call_terminate
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	__cxa_begin_catch
	callq	_ZSt9terminatev
.Lfunc_end6:
	.size	__clang_call_terminate, .Lfunc_end6-__clang_call_terminate
	.cfi_endproc
                                        # -- End function
	.section	.text.startup,"ax",@progbits
	.p2align	4                               # -- Begin function _GLOBAL__sub_I_driver.hip
	.type	_GLOBAL__sub_I_driver.hip,@function
_GLOBAL__sub_I_driver.hip:              # @_GLOBAL__sub_I_driver.hip
	.cfi_startproc
# %bb.0:                                # %entry
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	$_ZStL8__ioinit, %edi
	callq	_ZNSt8ios_base4InitC1Ev
	movl	$_ZNSt8ios_base4InitD1Ev, %edi
	movl	$_ZStL8__ioinit, %esi
	movl	$__dso_handle, %edx
	popq	%rax
	.cfi_def_cfa_offset 8
	jmp	__cxa_atexit                    # TAILCALL
.Lfunc_end7:
	.size	_GLOBAL__sub_I_driver.hip, .Lfunc_end7-_GLOBAL__sub_I_driver.hip
	.cfi_endproc
                                        # -- End function
	.text
	.p2align	4                               # -- Begin function __hip_module_ctor
	.type	__hip_module_ctor,@function
__hip_module_ctor:                      # @__hip_module_ctor
	.cfi_startproc
# %bb.0:                                # %entry
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	__hip_gpubin_handle_3ec256e6e8dd71e1(%rip), %rdi
	testq	%rdi, %rdi
	jne	.LBB8_2
# %bb.1:                                # %if
	movl	$__hip_fatbin_wrapper, %edi
	callq	__hipRegisterFatBinary
	movq	%rax, %rdi
	movq	%rax, __hip_gpubin_handle_3ec256e6e8dd71e1(%rip)
.LBB8_2:                                # %exit
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$mfma_tile, %esi
	movl	$.L__unnamed_1, %edx
	movl	$.L__unnamed_1, %ecx
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	movl	$__hip_module_dtor, %edi
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	jmp	atexit                          # TAILCALL
.Lfunc_end8:
	.size	__hip_module_ctor, .Lfunc_end8-__hip_module_ctor
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function __hip_module_dtor
	.type	__hip_module_dtor,@function
__hip_module_dtor:                      # @__hip_module_dtor
	.cfi_startproc
# %bb.0:                                # %entry
	movq	__hip_gpubin_handle_3ec256e6e8dd71e1(%rip), %rdi
	testq	%rdi, %rdi
	je	.LBB9_2
# %bb.1:                                # %if
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	__hipUnregisterFatBinary
	movq	$0, __hip_gpubin_handle_3ec256e6e8dd71e1(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
.LBB9_2:                                # %exit
	retq
.Lfunc_end9:
	.size	__hip_module_dtor, .Lfunc_end9-__hip_module_dtor
	.cfi_endproc
                                        # -- End function
	.type	_ZStL8__ioinit,@object          # @_ZStL8__ioinit
	.local	_ZStL8__ioinit
	.comm	_ZStL8__ioinit,1,1
	.hidden	__dso_handle
	.type	mfma_tile,@object               # @mfma_tile
	.section	.rodata,"a",@progbits
	.globl	mfma_tile
	.p2align	3, 0x0
mfma_tile:
	.quad	__device_stub__mfma_tile
	.size	mfma_tile, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Expected data and output directories"
	.size	.L.str, 37

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Wave64 required"
	.size	.L.str.1, 16

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"/a.bin"
	.size	.L.str.2, 7

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"/b.bin"
	.size	.L.str.3, 7

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"/c.bin"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"Input extents differ"
	.size	.L.str.5, 21

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.asciz	"/actual.bin"
	.size	.L.str.6, 12

	.type	.L.str.7,@object                # @.str.7
.L.str.7:
	.asciz	"Cannot write output"
	.size	.L.str.7, 20

	.type	.L.str.8,@object                # @.str.8
.L.str.8:
	.asciz	"{\"device\":\""
	.size	.L.str.8, 12

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"\",\"architecture\":\""
	.size	.L.str.9, 19

	.type	.L.str.10,@object               # @.str.10
.L.str.10:
	.asciz	"\",\"warp\":"
	.size	.L.str.10, 10

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	",\"trials\":"
	.size	.L.str.11, 11

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	",\"inputs_unchanged\":true,\"per_tile_guard_zones_unchanged\":true}"
	.size	.L.str.12, 64

	.type	.L.str.13,@object               # @.str.13
.L.str.13:
	.asciz	"Cannot open data"
	.size	.L.str.13, 17

	.type	.L.str.14,@object               # @.str.14
.L.str.14:
	.asciz	"Incomplete data"
	.size	.L.str.14, 16

	.type	.L.str.15,@object               # @.str.15
.L.str.15:
	.asciz	"cannot create std::vector larger than max_size()"
	.size	.L.str.15, 49

	.type	.L.str.16,@object               # @.str.16
.L.str.16:
	.asciz	"Invalid tile extents"
	.size	.L.str.16, 21

	.type	.L.str.17,@object               # @.str.17
.L.str.17:
	.asciz	"Input bytes changed"
	.size	.L.str.17, 20

	.type	.L.str.18,@object               # @.str.18
.L.str.18:
	.asciz	"A tile guard changed"
	.size	.L.str.18, 21

	.type	.L.str.19,@object               # @.str.19
.L.str.19:
	.asciz	"basic_string::append"
	.size	.L.str.19, 21

	.type	.L.str.20,@object               # @.str.20
.L.str.20:
	.asciz	"basic_string: construction from null is not valid"
	.size	.L.str.20, 50

	.type	.L__unnamed_1,@object           # @0
.L__unnamed_1:
	.asciz	"mfma_tile"
	.size	.L__unnamed_1, 10

	.type	.L__unnamed_2,@object           # @1
	.section	.hip_fatbin,"a",@progbits
	.p2align	12, 0x0
.L__unnamed_2:
	.asciz	"__CLANG_OFFLOAD_BUNDLE__\002\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\000\000\000\000\000\000\000\036\000\000\000\000\000\000\000host-x86_64-unknown-linux-gnu-\000\020\000\000\000\000\000\000\220\025\000\000\000\000\000\000\037\000\000\000\000\000\000\000hipv4-amdgcn-amd-amdhsa--gfx950\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\177ELF\002\001\001@\004\000\000\000\000\000\000\000\003\000\340\000\001\000\000\000\000\000\000\000\000\000\000\000@\000\000\000\000\000\000\000P\021\000\000\000\000\000\000O\005\000\000@\0008\000\t\000@\000\021\000\017\000\006\000\000\000\004\000\000\000@\000\000\000\000\000\000\000@\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\370\001\000\000\000\000\000\000\370\001\000\000\000\000\000\000\b\000\000\000\000\000\000\000\001\000\000\000\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\200\006\000\000\000\000\000\000\200\006\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\005\000\000\000\000\007\000\000\000\000\000\000\000\027\000\000\000\000\000\000\000\027\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\006\000\000\000\000\f\000\000\000\000\000\000\000,\000\000\000\000\000\000\000,\000\000\000\000\000\000p\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\006\000\000\000p\f\000\000\000\000\000\000p<\000\000\000\000\000\000p<\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\002\000\000\000\006\000\000\000\000\f\000\000\000\000\000\000\000,\000\000\000\000\000\000\000,\000\000\000\000\000\000p\000\000\000\000\000\000\000p\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000R\345td\004\000\000\000\000\f\000\000\000\000\000\000\000,\000\000\000\000\000\000\000,\000\000\000\000\000\000p\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\001\000\000\000\000\000\000\000Q\345td\006\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\004\000\000\000\004\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\000\b\003\000\000\000\000\000\000\b\003\000\000\000\000\000\000\004\000\000\000\000\000\000\000\007\000\000\000\364\002\000\000 \000\000\000AMDGPU\000\000\203\256amdhsa.kernels\221\336\000\022\253.agpr_count\000\245.args\224\205\256.address_space\246global\245.name\250a.coerce\247.offset\000\245.size\b\253.value_kind\255global_buffer\205\256.address_space\246global\245.name\250b.coerce\247.offset\b\245.size\b\253.value_kind\255global_buffer\205\256.address_space\246global\245.name\250c.coerce\247.offset\020\245.size\b\253.value_kind\255global_buffer\205\256.address_space\246global\245.name\252out.coerce\247.offset\030\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size \251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\251mfma_tile\273.private_segment_fixed_size\000\253.sgpr_count\022\261.sgpr_spill_count\000\247.symbol\254mfma_tile.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\f\261.vgpr_spill_count\000\257.wavefront_size@\255amdhsa.target\271amdgcn-amd-amdhsa--gfx950\256amdhsa.version\222\001\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\022\003\007\000\000\027\000\000\000\000\000\000\354\000\000\000\000\000\000\000\013\000\000\000\021\003\006\000@\006\000\000\000\000\000\000@\000\000\000\000\000\000\000\030\000\000\000\021\000\n\000p<\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\001\000\000\000\001\000\000\000\032\000\000\000\000\000\200\000\000@\t \001\000\000\000\262=\034]\260\026r\271}H\212\\\004\000\000\000\004\000\000\000\002\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000mfma_tile\000mfma_tile.kd\000__hip_cuid_3ec256e6e8dd71e1\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000 \000\000\000\000\000\000\000\300\020\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\000\000\000\201\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\016\300\000\000\000\000\217\000\002&\202\000\000 \204\002\004$\377\000\006&\374\000\000\000\002\000\376\321\002\007\006\002\177\300\214\277\000\200T\334\002\000\004\004\002\000\000\322\003\t\005\004\204\000\000$\201\004\006$\000\000\002\322\000\003\302\002\201\000\002$\000\200H\334\003\000\006\006 \200H\334\003\000\006\b@\200H\334\003\000\006\007\000\200H\334\001\000\006\t\202\004\024$\202\000\026$\000\200P\334\n\000\b\000@\200P\334\n\000\b\001\200\200P\334\n\000\b\002\000\200P\334\013\000\b\003\377\000\200\276\000\001\004\005v\017\214\277\006\000\355\321\b\r\002\000t\017\214\277\007\000\355\321\t\017\002\000p\017\214\277\000\000\200\277\000\000\315\323\004\r\002\004\007\000\200\277\000\200p\334\n\000\n\000@\200p\334\n\001\n\000\200\200p\334\n\002\n\000\000\200p\334\013\003\n\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\006\000\000\000\000\000\000\000@\005\000\000\000\000\000\000\013\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\360\005\000\000\000\000\000\000\n\000\000\000\000\000\000\0004\000\000\000\000\000\000\000\365\376\377o\000\000\000\000\240\005\000\000\000\000\000\000\004\000\000\000\000\000\000\000\310\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000AMD clang version 22.0.0git (https://github.com/ROCm/llvm-project  25496 9b0f9aa3067a907226b0ebb8bee1fe51d1f0fca5)\000\000Linker: AMD LLD 22.0.0 (/longer_pathname_so_that_rpms_can_support_packaging_the_debug_info_for_all_os_profiles/src/llvm-project/llvm 9b0f9aa3067a907226b0ebb8bee1fe51d1f0fca5)\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\361\377\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\024\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'\000\000\000\000\000\361\377\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000?\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000[\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000v\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\211\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\245\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\303\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\333\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\367\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\013\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\037\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000f\001\000\000\000\002\b\000\000,\000\000\000\000\000\000\000\000\000\000\000\000\000\0003\001\000\000\022\003\007\000\000\027\000\000\000\000\000\000\354\000\000\000\000\000\000\000=\001\000\000\021\003\006\000@\006\000\000\000\000\000\000@\000\000\000\000\000\000\000J\001\000\000\021\000\n\000p<\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000.note\000.dynsym\000.gnu.hash\000.hash\000.dynstr\000.rodata\000.text\000.dynamic\000.relro_padding\000.bss\000.AMDGPU.csdata\000.AMDGPU.gpr_maximums\000.comment\000.symtab\000.shstrtab\000.strtab\000\000mfma_tile.num_vgpr\000mfma_tile.num_agpr\000mfma_tile.numbered_sgpr\000mfma_tile.num_named_barrier\000mfma_tile.private_seg_size\000mfma_tile.uses_vcc\000mfma_tile.uses_flat_scratch\000mfma_tile.has_dyn_sized_stack\000mfma_tile.has_recursion\000mfma_tile.has_indirect_call\000amdgpu.max_num_vgpr\000amdgpu.max_num_agpr\000amdgpu.max_num_sgpr\000mfma_tile\000mfma_tile.kd\000__hip_cuid_3ec256e6e8dd71e1\000_DYNAMIC\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\007\000\000\000\002\000\000\000\000\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\000\b\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\007\000\000\000\013\000\000\000\002\000\000\000\000\000\000\000@\005\000\000\000\000\000\000@\005\000\000\000\000\000\000`\000\000\000\000\000\000\000\005\000\000\000\001\000\000\000\b\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\017\000\000\000\366\377\377o\002\000\000\000\000\000\000\000\240\005\000\000\000\000\000\000\240\005\000\000\000\000\000\000(\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\031\000\000\000\005\000\000\000\002\000\000\000\000\000\000\000\310\005\000\000\000\000\000\000\310\005\000\000\000\000\000\000(\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\037\000\000\000\003\000\000\000\002\000\000\000\000\000\000\000\360\005\000\000\000\000\000\000\360\005\000\000\000\000\000\0004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'\000\000\000\001\000\000\000\002\000\000\000\000\000\000\000@\006\000\000\000\000\000\000@\006\000\000\000\000\000\000@\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000/\000\000\000\001\000\000\000\006\000\000\000\000\000\000\000\000\027\000\000\000\000\000\000\000\007\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\0005\000\000\000\006\000\000\000\003\000\000\000\000\000\000\000\000,\000\000\000\000\000\000\000\f\000\000\000\000\000\000p\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000>\000\000\000\b\000\000\000\003\000\000\000\000\000\000\000p,\000\000\000\000\000\000p\f\000\000\000\000\000\000\220\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000M\000\000\000\b\000\000\000\003\000\000\000\000\000\000\000p<\000\000\000\000\000\000p\f\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000R\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000p\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000a\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000p\f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000v\000\000\000\001\000\000\0000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000p\f\000\000\000\000\000\000#\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\177\000\000\000\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\230\r\000\000\000\000\000\000\260\001\000\000\000\000\000\000\020\000\000\000\017\000\000\000\b\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\207\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000H\017\000\000\000\000\000\000\231\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\221\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\341\017\000\000\000\000\000\000o\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	.L__unnamed_2, 9616

	.type	__hip_fatbin_wrapper,@object    # @__hip_fatbin_wrapper
	.section	.hipFatBinSegment,"a",@progbits
	.p2align	3, 0x0
__hip_fatbin_wrapper:
	.long	1212764230                      # 0x48495046
	.long	1                               # 0x1
	.quad	.L__unnamed_2
	.quad	0
	.size	__hip_fatbin_wrapper, 24

	.type	__hip_gpubin_handle_3ec256e6e8dd71e1,@object # @__hip_gpubin_handle_3ec256e6e8dd71e1
	.local	__hip_gpubin_handle_3ec256e6e8dd71e1
	.comm	__hip_gpubin_handle_3ec256e6e8dd71e1,8,8
	.section	.init_array,"aw",@init_array
	.p2align	3, 0x0
	.quad	_GLOBAL__sub_I_driver.hip
	.quad	__hip_module_ctor
	.type	__hip_cuid_3ec256e6e8dd71e1,@object # @__hip_cuid_3ec256e6e8dd71e1
	.bss
	.globl	__hip_cuid_3ec256e6e8dd71e1
__hip_cuid_3ec256e6e8dd71e1:
	.byte	0                               # 0x0
	.size	__hip_cuid_3ec256e6e8dd71e1, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/ROCm/llvm-project  25496 9b0f9aa3067a907226b0ebb8bee1fe51d1f0fca5)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __device_stub__mfma_tile
	.addrsig_sym __gxx_personality_v0
	.addrsig_sym _GLOBAL__sub_I_driver.hip
	.addrsig_sym __hip_module_ctor
	.addrsig_sym __hip_module_dtor
	.addrsig_sym _Unwind_Resume
	.addrsig_sym _ZStL8__ioinit
	.addrsig_sym __dso_handle
	.addrsig_sym mfma_tile
	.addrsig_sym _ZTISt9exception
	.addrsig_sym _ZTISt13runtime_error
	.addrsig_sym _ZSt4cout
	.addrsig_sym _ZSt4cerr
	.addrsig_sym .L__unnamed_2
	.addrsig_sym __hip_fatbin_wrapper
	.addrsig_sym __hip_cuid_3ec256e6e8dd71e1
