extern "C" __global__ void ffn_up_hip_64_1048576_16_256(const __half* x, const __half* w1, __half* hidden) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1048576) {
    acc = acc + __half2float(x[(i / 16) * 1048576 + j]) * __half2float(w1[j * 16 + i % 16]);
    j++;
  }
  hidden[i] = __float2half(fmaxf(acc, 0.0f));
}
