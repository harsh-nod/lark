extern "C" __global__ void ffn_down_hip_1_1_1_1(const __half* hidden, const __half* down, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1) {
    acc = acc + __half2float(hidden[(i / 1) * 1 + j]) * __half2float(down[j * 1 + i % 1]);
    j++;
  }
  out[i] = __float2half(acc);
}
