extern "C" __global__ void ffn_down_hip_1024_256_1024_1024(const __half* hidden, const __half* down, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1024) {
    acc = acc + __half2float(hidden[(i / 1024) * 1024 + j]) * __half2float(down[j * 1024 + i % 1024]);
    j++;
  }
  out[i] = __float2half(acc);
}
