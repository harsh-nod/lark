import LarkReal.NativeAwqGemm
open LarkReal.NativeAwqGemm LarkNativeAwqGemm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : Shape := ⟨1,32,64,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide⟩
example : denseTerm shape (fun _ _ => (2 : ℝ)) 0 0 0=2 := by norm_num [denseTerm]
