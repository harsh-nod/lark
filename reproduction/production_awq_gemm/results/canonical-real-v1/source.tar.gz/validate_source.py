from pathlib import Path
from lark_kernels import native_awq_gemm_certificate as native
root = Path(__file__).resolve().parent
cases = ('m17_k32_n64', 'm17_k32_n128', 'm33_k64_n192', 'm33_k64_n256')
for i, case in enumerate(cases):
    folder = root/'cases'/case
    task, translation = native.prepare(*((folder/name).read_text() for name in ('kernel.hip','reference.py','task.json')))
    assert (root/('Main.lean' if i==0 else case+'.lean')).read_text()==native.render(task,translation)
    if i==0:
        assert all((root/name).read_bytes()==(folder/name).read_bytes() for name in ('kernel.hip','reference.py','task.json'))
folder = root/'cases/m33_k64_n192'
for source in sorted(root.glob('source-*.hip')):
    task, translation = native.prepare(source.read_text(),(folder/'reference.py').read_text(),(folder/'task.json').read_text())
    assert source.with_suffix('.lean').read_text()==native.render(task,translation)
print('Frozen typed reader, all four complete source/reference bindings and altered-source bindings passed.')
