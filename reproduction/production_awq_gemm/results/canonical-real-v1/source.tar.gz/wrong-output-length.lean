import LarkReal.NativeAwqGemm
open LarkReal.NativeAwqGemm LarkNativeAwqGemm
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
def shape : Shape := ⟨1,32,64,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide⟩
example (input : Nat → Nat → ℝ) : (denseSpec shape input).length=63 := by simp [denseSpec,shape]
