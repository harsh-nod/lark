Source replay: python3 validate_source.py. Fresh proof: lake build.
Requires Lean4.19.0 and exact locked Mathlib dependencies/cache.
Three other case-name Lean files specialize the universal supported-shape theorem.
source-* and wrong-* Lean files intentionally fail on false claims.
Complete initialized native launch, actual-trace race freedom and independent dense real reference outputs are proved.
Storage conversions are identities here; no IEEE error bound or original-paper completion is claimed.
