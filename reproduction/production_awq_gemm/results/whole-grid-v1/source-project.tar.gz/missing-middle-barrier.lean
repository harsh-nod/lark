import Lark.NativeAwqGemmGrid
namespace AwqSource
open LarkNonlinear
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
set_option autoImplicit false
attribute [local irreducible] LarkNativeAwqGemm.aLoopState LarkNativeAwqGemm.aRoundState LarkNativeAwqGemm.aBodyState
attribute [local irreducible] LarkNativeAwqGemm.bChunksState LarkNativeAwqGemm.bChunkState LarkNativeAwqGemm.bChunkBody LarkNativeAwqGemm.bLoopState LarkNativeAwqGemm.bRoundState LarkNativeAwqGemm.bBodyState
attribute [local irreducible] LarkNativeAwqGemm.stagingState LarkNativeAwqGemm.stagingFold
attribute [local irreducible] LarkNativeAwqGemm.operandLoop LarkNativeAwqGemm.operandLoaded LarkNativeAwqGemm.operandLaneState LarkNativeAwqGemm.operandFold LarkNativeAwqGemm.blockOperands LarkNativeAwqGemm.matrixState LarkNativeAwqGemm.matrixBankState LarkNativeAwqGemm.matrixFold LarkNativeAwqGemm.matrixPassState LarkNativeAwqGemm.matrixPhaseState
attribute [local irreducible] LarkNativeAwqGemm.outputRound LarkNativeAwqGemm.outputStored LarkNativeAwqGemm.outputLoop LarkNativeAwqGemm.outputLane LarkNativeAwqGemm.tailLane LarkNativeAwqGemm.tailFold LarkNativeAwqGemm.blockTail LarkNativeAwqGemm.nextTile LarkNativeAwqGemm.tileMatrix LarkNativeAwqGemm.tileEnd LarkNativeAwqGemm.tileNext LarkNativeAwqGemm.kLoopState LarkNativeAwqGemm.wholeBlock LarkNativeAwqGemm.gridFold LarkNativeAwqGemm.wholeGrid
def shape : LarkNativeAwqGemm.Shape := ⟨33,64,192,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide⟩
def sourceProgram : List LarkMFMA.Instr := [(.scalar (.index 0 .tid)), (.scalar (.index 1 (.mod (.ivar (0)) (.const (32))))), (.scalar (.index 2 (.div (.ivar (0)) (.const (32))))), (.scalar (.index 3 .bid)), (.scalar (.index 4 (.div (.ivar (3)) (.const (3))))), (.scalar (.index 5 (.mod (.ivar (3)) (.const (3))))), (.scalar (.index 6 (.add (.add (.mul (.ivar (4)) (.const (16))) (.mul (.ivar (2)) (.const (8)))) (.div (.ivar (1)) (.const (4)))))), (.scalar (.index 7 (.mul (.mod (.ivar (1)) (.const (4))) (.const (8))))), (.scalar (.index 8 (.add (.mul (.add (.mul (.ivar (2)) (.const (8))) (.div (.ivar (1)) (.const (4)))) (.const (40))) (.ivar (7))))), (.scalar (.index 9 (.add (.add (.mul (.ivar (4)) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))))), (.scalar (.index 10 (.add (.add (.mul (.ivar (4)) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))))), (.scalar (.index 11 (.add (.add (.mul (.ivar (4)) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))))), (.scalar (.index 12 (.add (.add (.mul (.ivar (4)) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))))), (.scalar (.assign 0 (.lit (0) 1))), (.scalar (.assign 1 (.lit (0) 1))), (.scalar (.assign 2 (.lit (0) 1))), (.scalar (.assign 3 (.lit (0) 1))), (.scalar (.assign 4 (.lit (0) 1))), (.scalar (.assign 5 (.lit (0) 1))), (.scalar (.assign 6 (.lit (0) 1))), (.scalar (.assign 7 (.lit (0) 1))), (.scalar (.assign 8 (.lit (0) 1))), (.scalar (.assign 9 (.lit (0) 1))), (.scalar (.assign 10 (.lit (0) 1))), (.scalar (.assign 11 (.lit (0) 1))), (.scalar (.assign 12 (.lit (0) 1))), (.scalar (.assign 13 (.lit (0) 1))), (.scalar (.assign 14 (.lit (0) 1))), (.scalar (.assign 15 (.lit (0) 1))), (.scalar (.index 13 (.const (0)))), (.scalar (.branch (.lt (.ivar (13)) (.const (2))) 104)), (.scalar (.barrier .block)), (.scalar (.index 14 (.const (0)))), (.scalar (.branch (.lt (.ivar (6)) (.const (33))) 39)), (.scalar (.branch (.lt (.ivar (14)) (.const (8))) 38)), (.scalar (.store .shared 0 (.add (.ivar (8)) (.ivar (14))) (.load .global 0 (.add (.add (.add (.mul (.ivar (6)) (.const (64))) (.mul (.ivar (13)) (.const (32)))) (.ivar (7))) (.ivar (14)))))), (.scalar (.index 14 (.add (.ivar (14)) (.const (1))))), (.scalar (.jump 34)), (.scalar (.jump 43)), (.scalar (.branch (.lt (.ivar (14)) (.const (8))) 43)), (.scalar (.store .shared 0 (.add (.ivar (8)) (.ivar (14))) (.un .toHalf (.lit (0) 1)))), (.scalar (.index 14 (.add (.ivar (14)) (.const (1))))), (.scalar (.jump 39)), (.scalar (.index 15 (.const (0)))), (.scalar (.branch (.lt (.ivar (15)) (.const (4))) 54)), (.scalar (.index 16 (.add (.add (.mul (.ivar (2)) (.const (4))) (.div (.ivar (1)) (.const (8)))) (.mul (.ivar (15)) (.const (8)))))), (.scalar (.index 17 (.mul (.mod (.ivar (1)) (.const (8))) (.const (8))))), (.scalar (.index 18 (.const (0)))), (.scalar (.branch (.lt (.ivar (18)) (.const (8))) 52)), (.scalar (.store .shared 1 (.add (.add (.mul (.ivar (16)) (.const (72))) (.ivar (17))) (.ivar (18))) (.load .global 1 (.add (.add (.add (.mul (.add (.mul (.ivar (13)) (.const (32))) (.ivar (16))) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.ivar (17))) (.ivar (18)))))), (.scalar (.index 18 (.add (.ivar (18)) (.const (1))))), (.scalar (.jump 48)), (.scalar (.index 15 (.add (.ivar (15)) (.const (1))))), (.scalar (.jump 44)), (.scalar (.assign 16 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (0))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0)))))), (.scalar (.assign 17 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (0))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1)))))), (.scalar (.assign 18 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (0))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2)))))), (.scalar (.assign 19 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (0))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3)))))), (.scalar (.assign 20 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 21 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 22 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 23 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 0 16 20 0), (.scalar (.assign 24 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 25 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 26 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 27 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 4 16 24 4), (.scalar (.assign 28 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 29 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 30 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 31 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 8 16 28 8), (.scalar (.assign 32 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 33 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 34 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 35 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (0)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 12 16 32 12), (.scalar (.assign 36 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0)))))), (.scalar (.assign 37 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1)))))), (.scalar (.assign 38 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2)))))), (.scalar (.assign 39 (.load .shared 0 (.add (.add (.add (.mul (.mod (.ivar (0)) (.const (16))) (.const (40))) (.const (16))) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3)))))), (.scalar (.assign 40 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 41 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 42 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 43 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (0))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 0 36 40 0), (.scalar (.assign 44 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 45 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 46 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 47 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (16))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 4 36 44 4), (.scalar (.assign 48 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 49 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 50 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 51 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (32))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 8 36 48 8), (.scalar (.assign 52 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (0))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 53 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (1))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 54 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (2))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.scalar (.assign 55 (.load .shared 1 (.add (.add (.mul (.add (.add (.const (16)) (.mul (.div (.ivar (0)) (.const (16))) (.const (4)))) (.const (3))) (.const (72))) (.const (48))) (.mod (.ivar (0)) (.const (16))))))), (.mfma 12 36 52 12), (.scalar (.index 13 (.add (.ivar (13)) (.const (1))))), (.scalar (.jump 30)), (.scalar (.branch (.lt (.ivar (9)) (.const (33))) 106)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (9)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (0))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (0))))), (.scalar (.branch (.lt (.ivar (10)) (.const (33))) 108)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (10)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (0))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (1))))), (.scalar (.branch (.lt (.ivar (11)) (.const (33))) 110)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (11)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (0))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (2))))), (.scalar (.branch (.lt (.ivar (12)) (.const (33))) 112)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (12)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (0))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (3))))), (.scalar (.branch (.lt (.ivar (9)) (.const (33))) 114)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (9)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (16))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (4))))), (.scalar (.branch (.lt (.ivar (10)) (.const (33))) 116)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (10)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (16))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (5))))), (.scalar (.branch (.lt (.ivar (11)) (.const (33))) 118)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (11)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (16))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (6))))), (.scalar (.branch (.lt (.ivar (12)) (.const (33))) 120)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (12)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (16))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (7))))), (.scalar (.branch (.lt (.ivar (9)) (.const (33))) 122)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (9)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (32))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (8))))), (.scalar (.branch (.lt (.ivar (10)) (.const (33))) 124)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (10)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (32))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (9))))), (.scalar (.branch (.lt (.ivar (11)) (.const (33))) 126)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (11)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (32))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (10))))), (.scalar (.branch (.lt (.ivar (12)) (.const (33))) 128)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (12)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (32))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (11))))), (.scalar (.branch (.lt (.ivar (9)) (.const (33))) 130)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (9)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (48))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (12))))), (.scalar (.branch (.lt (.ivar (10)) (.const (33))) 132)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (10)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (48))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (13))))), (.scalar (.branch (.lt (.ivar (11)) (.const (33))) 134)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (11)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (48))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (14))))), (.scalar (.branch (.lt (.ivar (12)) (.const (33))) 136)), (.scalar (.store .global 2 (.add (.add (.add (.mul (.ivar (12)) (.const (192))) (.mul (.ivar (5)) (.const (64)))) (.const (48))) (.mod (.ivar (0)) (.const (16)))) (.un .toHalf (.reg (15))))), (.scalar .halt)]
def sourceLayout : Layout := ⟨[⟨.input,2112⟩,⟨.input,12288⟩,⟨.output,6336⟩],[640, 2304],[]⟩
def sourceGeometry : Geometry := ⟨9,64,64⟩
def sourceFuel : Fuel := ⟨512,9,5,1⟩
theorem source_binding : sourceProgram=LarkNativeAwqGemm.program shape := by decide
theorem layout_binding : sourceLayout=LarkNativeAwqGemm.layout shape := by rfl
theorem geometry_binding : sourceGeometry=LarkNativeAwqGemm.geometry shape := by rfl
theorem fuel_binding : sourceFuel=LarkNativeAwqGemm.fuel shape := by rfl
theorem first_barrier : sourceProgram[LarkNativeAwqGemm.firstBarrier shape]?=some (.scalar (.barrier .block)) := by decide
theorem middle_barrier : sourceProgram[LarkNativeAwqGemm.middleBarrier shape]?=some (.scalar (.barrier .block)) := by decide
theorem halt_site : sourceProgram[LarkNativeAwqGemm.haltPC shape]?=some (.scalar .halt) := by decide
theorem matrix_sites : (sourceProgram.filter (fun inst => match inst with | .mfma .. => true | _ => false)).length=8 := by decide
theorem source_length : sourceProgram.length=138 := by decide
theorem initial_execution {α : Type} (ops : Ops α) (s : State α) (t : Nat)
    (ht : t<sourceGeometry.grid*64) (hp : s.pc t=0) :
    ∃ final, LarkMFMA.runLane ops sourceLayout sourceGeometry sourceProgram t sourceFuel.lane s=some final ∧
      final.pc t=LarkNativeAwqGemm.firstBarrier shape ∧ final.trace=s.trace ∧
        ∀ r, r<4*LarkNativeAwqGemm.banks shape → final.regs t r=some (ops.literal 0 1) := by
  refine ⟨LarkNativeAwqGemm.prefixState shape ops t s,?_,LarkNativeAwqGemm.prefix_pc shape ops t s,
    (LarkNativeAwqGemm.prefix_frames shape ops t s).2.1,fun r hr => LarkNativeAwqGemm.prefix_accumulators shape ops t r s hr⟩
  rw [layout_binding,geometry_binding,source_binding,fuel_binding]
  exact LarkNativeAwqGemm.initial_prefix_run shape ops t s (by simpa only [geometry_binding] using ht) hp
theorem initial_block_execution {α : Type} (ops : Ops α) (s : State α) (b extra : Nat)
    (hb : b<sourceGeometry.grid) (hp : ∀ t∈blockThreads sourceGeometry b, s.pc t=0) :
    LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b (extra+1) s=
      LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b extra
        (resume (blockThreads sourceGeometry b) .block (LarkNativeAwqGemm.blockPrefix shape ops b s)) := by
  rw [layout_binding,geometry_binding,source_binding,fuel_binding]
  exact LarkNativeAwqGemm.initial_block_step shape ops b extra s
    (by simpa only [geometry_binding] using hb) (by simpa only [geometry_binding] using hp)
theorem a_staging_execution {α : Type} (ops : Ops α) (input : Nat → Nat → α)
    (s : State α) (tile t extra : Nat) (hk : tile<shape.k/32)
    (setup : LarkNativeAwqGemm.SetupIndices shape t s) (ki : s.indices t 13=some (tile : Int))
    (reads : LarkNativeAwqGemm.Reads shape input s) (hp : s.pc t=LarkNativeAwqGemm.firstBarrier shape+1) :
    let final := LarkNativeAwqGemm.aStageState shape ops input tile t s
    (LarkMFMA.runLane ops sourceLayout sourceGeometry sourceProgram t
      (extra+LarkNativeAwqGemm.aStageCost shape t) s=
        LarkMFMA.runLane ops sourceLayout sourceGeometry sourceProgram t extra final) ∧
    final.pc t=LarkNativeAwqGemm.firstBarrier shape+12 ∧ LarkNativeAwqGemm.Reads shape input final ∧
    (∀ e, e<8 → final.memory (LarkNativeAwqGemm.aCell t e)=
      some (if LarkNativeAwqGemm.inputRow shape t<shape.m then
        input 0 (LarkNativeAwqGemm.aSourceOffset shape tile t e) else ops.toHalf (ops.literal 0 1))) ∧
    (∀ loc, (∀ e, e<8 → loc≠LarkNativeAwqGemm.aCell t e) → final.memory loc=s.memory loc) ∧
    final.trace.length=s.trace.length+(if LarkNativeAwqGemm.inputRow shape t<shape.m then 16 else 8) := by
  refine ⟨?_,LarkNativeAwqGemm.a_stage_pc shape ops input tile t s,
    LarkNativeAwqGemm.a_stage_reads shape ops input tile t s reads,
    fun e he => LarkNativeAwqGemm.a_stage_value shape ops input tile t e s he,
    fun loc hl => LarkNativeAwqGemm.a_stage_memory_outside shape ops input tile t s loc hl,
    LarkNativeAwqGemm.a_stage_trace_length shape ops input tile t s⟩
  rw [layout_binding,geometry_binding,source_binding]
  exact LarkNativeAwqGemm.a_stage_eq shape ops input tile t extra s hk setup ki reads hp
theorem lane_staging_execution {α : Type} (ops : Ops α) (input : Nat → Nat → α)
    (s : State α) (tile t : Nat) (hk : tile<shape.k/32)
    (setup : LarkNativeAwqGemm.SetupIndices shape t s) (ki : s.indices t 13=some (tile : Int))
    (reads : LarkNativeAwqGemm.Reads shape input s) (hp : s.pc t=LarkNativeAwqGemm.firstBarrier shape+1) :
    let final := LarkNativeAwqGemm.stagingState shape ops input tile t s
    LarkMFMA.runLane ops sourceLayout sourceGeometry sourceProgram t sourceFuel.lane s=some final ∧
    final.pc t=LarkNativeAwqGemm.middleBarrier shape ∧ LarkNativeAwqGemm.Reads shape input final ∧
    (∀ e, e<8 → final.memory (LarkNativeAwqGemm.aCell t e)=
      some (if LarkNativeAwqGemm.inputRow shape t<shape.m then
        input 0 (LarkNativeAwqGemm.aSourceOffset shape tile t e) else ops.toHalf (ops.literal 0 1))) ∧
    (∀ chunk, chunk<LarkNativeAwqGemm.banks shape → ∀ e, e<8 →
      final.memory (LarkNativeAwqGemm.bCell shape t chunk e)=
        some (input 1 (LarkNativeAwqGemm.bSourceOffset shape tile t chunk e))) ∧
    (∀ loc, (∀ e, e<8 → loc≠LarkNativeAwqGemm.aCell t e) →
      (∀ chunk, chunk<LarkNativeAwqGemm.banks shape → ∀ e, e<8 → loc≠LarkNativeAwqGemm.bCell shape t chunk e) →
        final.memory loc=s.memory loc) ∧
    final.trace.length=s.trace.length+(if LarkNativeAwqGemm.inputRow shape t<shape.m then 16 else 8)+
      16*LarkNativeAwqGemm.banks shape ∧ final.regs=s.regs ∧ final.epochs=s.epochs := by
  refine ⟨?_,LarkNativeAwqGemm.staging_pc shape ops input tile t s,
    LarkNativeAwqGemm.staging_reads shape ops input tile t s reads,
    fun e he => LarkNativeAwqGemm.staging_a_value shape ops input tile t e s he,
    fun chunk hc e he => LarkNativeAwqGemm.staging_b_value shape ops input tile t chunk e s hc he,
    fun loc ha hb => LarkNativeAwqGemm.staging_memory_outside shape ops input tile t s loc ha hb,
    LarkNativeAwqGemm.staging_trace_length shape ops input tile t s,
    LarkNativeAwqGemm.staging_frames shape ops input tile t s⟩
  rw [layout_binding,geometry_binding,source_binding,fuel_binding]
  exact LarkNativeAwqGemm.staging_run shape ops input tile t s hk setup ki reads hp
theorem block_staging_execution {α : Type} (ops : Ops α) (input : Nat → Nat → α)
    (s : State α) (tile b extra : Nat) (hk : tile<shape.k/32)
    (reads : LarkNativeAwqGemm.Reads shape input s)
    (starts : ∀ t∈blockThreads sourceGeometry b, LarkNativeAwqGemm.StagingStart shape tile t s) :
    LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b (extra+1) s=
      LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b extra
        (LarkNativeAwqGemm.afterMiddleBarrier shape ops input tile b s) := by
  rw [layout_binding,geometry_binding,fuel_binding,source_binding]
  exact LarkNativeAwqGemm.block_staging_step shape ops input tile b extra s hk reads
    (by simpa only [geometry_binding] using starts)
theorem initial_through_staging {α : Type} (ops : Ops α) (input : Nat → Nat → α)
    (s : State α) (b extra : Nat) (hb : b<sourceGeometry.grid)
    (reads : LarkNativeAwqGemm.Reads shape input s) (hp : ∀ t∈blockThreads sourceGeometry b, s.pc t=0) :
    let entered := LarkNativeAwqGemm.afterFirstBarrier shape ops b s
    let final := LarkNativeAwqGemm.afterMiddleBarrier shape ops input 0 b entered
    (LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b (extra+2) s=
      LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b extra final) ∧
    (∀ t∈blockThreads sourceGeometry b, final.pc t=LarkNativeAwqGemm.middleBarrier shape+1) ∧
    LarkNativeAwqGemm.Reads shape input final ∧ final.regs=entered.regs ∧
    final.epochs=(resume (blockThreads sourceGeometry b) .block entered).epochs ∧
    (∀ row, row<16 → ∀ col, col<32 → final.memory (LarkNativeAwqGemm.tileCell b 0 (row*40+col))=
      some (if (b/LarkNativeAwqGemm.columnTiles shape)*16+row<shape.m then
        input 0 (((b/LarkNativeAwqGemm.columnTiles shape)*16+row)*shape.k+0*32+col)
        else ops.toHalf (ops.literal 0 1))) ∧
    (∀ row, row<32 → ∀ col, col<LarkNativeAwqGemm.tileN shape →
      final.memory (LarkNativeAwqGemm.tileCell b 1 (row*(LarkNativeAwqGemm.tileN shape+8)+col))=
        some (input 1 ((0*32+row)*shape.n+(b%LarkNativeAwqGemm.columnTiles shape)*LarkNativeAwqGemm.tileN shape+col))) ∧
    (∀ loc, (∀ t∈blockThreads sourceGeometry b, ∀ e, e<8 → loc≠LarkNativeAwqGemm.aCell t e) →
      (∀ t∈blockThreads sourceGeometry b, ∀ chunk, chunk<LarkNativeAwqGemm.banks shape → ∀ e, e<8 →
        loc≠LarkNativeAwqGemm.bCell shape t chunk e) → final.memory loc=entered.memory loc) := by
  rw [geometry_binding] at hb hp ⊢
  refine ⟨?_,?_,LarkNativeAwqGemm.after_middle_reads shape ops input 0 b _
    (LarkNativeAwqGemm.after_first_reads shape ops b s input reads),
    (LarkNativeAwqGemm.after_middle_frames shape ops input 0 b _).1,
    (LarkNativeAwqGemm.after_middle_frames shape ops input 0 b _).2,
    fun row hr col hc => LarkNativeAwqGemm.after_middle_a_tile shape ops input 0 b row col _ hr hc,
    fun row hr col hc => LarkNativeAwqGemm.after_middle_b_tile shape ops input 0 b row col _ hr hc,
    fun loc ha hb => LarkNativeAwqGemm.after_middle_memory_outside shape ops input 0 b _ loc ha hb⟩
  · rw [layout_binding,fuel_binding,source_binding]
    exact LarkNativeAwqGemm.initial_through_staging shape ops input b extra s hb reads hp
  · intro t ht
    exact (LarkNativeAwqGemm.after_middle_ready shape ops input 0 b t _ ht
      (fun u hu => LarkNativeAwqGemm.after_first_staging_start shape ops b u s hu)).1
theorem matrix_iteration_execution {α : Type} (ops : Ops α) (input : Nat → Nat → α)
    (s : State α) (tile b extra : Nat) (acc : Nat → Nat → Nat → α) (hk : tile<shape.k/32)
    (reads : LarkNativeAwqGemm.Reads shape input s)
    (starts : ∀ t∈blockThreads sourceGeometry b, LarkNativeAwqGemm.StagingStart shape tile t s)
    (hc : ∀ bank, bank<LarkNativeAwqGemm.banks shape → ∀ t∈blockThreads sourceGeometry b, ∀ e, e<4 →
      s.regs t (bank*4+e)=some (acc bank t e)) :
    let mid := LarkNativeAwqGemm.afterMiddleBarrier shape ops input tile b s
    let final := LarkNativeAwqGemm.matrixPhaseState shape ops input tile b acc mid
    (LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b (extra+1) s=
      LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b extra mid) ∧
    (LarkMFMA.runWarp ops sourceLayout sourceGeometry sourceFuel sourceProgram (blockThreads sourceGeometry b) sourceFuel.warp mid=
      LarkMFMA.runWarp ops sourceLayout sourceGeometry sourceFuel sourceProgram (blockThreads sourceGeometry b) 1 final) ∧
    (∀ t∈blockThreads sourceGeometry b, final.pc t=47+14*LarkNativeAwqGemm.banks shape) ∧
    (∀ bank, bank<LarkNativeAwqGemm.banks shape → ∀ t∈blockThreads sourceGeometry b, ∀ e, e<4 →
      final.regs t (bank*4+e)=some (LarkNativeAwqGemm.matrixPhaseResult shape ops input tile b acc bank t e)) ∧
    final.memory=mid.memory ∧ final.indices=mid.indices ∧ final.epochs=mid.epochs ∧
    LarkNativeAwqGemm.Reads shape input final := by
  rw [layout_binding,geometry_binding,fuel_binding,source_binding]
  exact LarkNativeAwqGemm.matrix_iteration shape ops input tile b extra acc s hk reads
    (by simpa only [geometry_binding] using starts) (by simpa only [geometry_binding] using hc)
theorem whole_block_execution {α : Type} (ops : Ops α) (input : Nat → Nat → α)
    (s : State α) (b : Nat) (hb : b<sourceGeometry.grid)
    (reads : LarkNativeAwqGemm.Reads shape input s) (hp : ∀ t∈blockThreads sourceGeometry b, s.pc t=0) :
    LarkMFMA.runBlock ops sourceLayout sourceGeometry sourceFuel sourceProgram b sourceFuel.block s=
      some (LarkNativeAwqGemm.wholeBlock shape ops input b s) := by
  rw [layout_binding,geometry_binding,fuel_binding,source_binding]
  exact LarkNativeAwqGemm.whole_block_run shape ops input b s
    (by simpa only [geometry_binding] using hb) reads (by simpa only [geometry_binding] using hp)
theorem whole_grid_execution {α : Type} (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    let start := initial sourceLayout input outside
    let final := LarkNativeAwqGemm.wholeGrid shape ops input start
    LarkMFMA.runGrid ops sourceLayout sourceGeometry sourceFuel sourceProgram sourceFuel.grid start=some final ∧
      (∀ t, t<sourceGeometry.grid*64 → final.pc t=LarkNativeAwqGemm.haltPC shape) ∧
      LarkNativeAwqGemm.Reads shape input final := by
  rw [layout_binding,geometry_binding,fuel_binding,source_binding]
  exact ⟨LarkNativeAwqGemm.initialized_whole_grid_run shape ops input outside,
    fun t ht => LarkNativeAwqGemm.whole_grid_halt shape ops input _ t ht,
    by
      unfold LarkNativeAwqGemm.wholeGrid
      exact LarkNativeAwqGemm.grid_fold_reads shape ops input _ _ (LarkNativeAwqGemm.initial_reads shape input outside)⟩
#print axioms source_binding
#print axioms layout_binding
#print axioms geometry_binding
#print axioms fuel_binding
#print axioms first_barrier
#print axioms middle_barrier
#print axioms halt_site
#print axioms matrix_sites
#print axioms source_length
#print axioms initial_execution
#print axioms initial_block_execution
#print axioms a_staging_execution
#print axioms lane_staging_execution
#print axioms block_staging_execution
#print axioms initial_through_staging
#print axioms matrix_iteration_execution
#print axioms whole_block_execution
#print axioms whole_grid_execution
end AwqSource
