import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def layout : Layout := LarkRotary.layout 16384
def geometry : Geometry := LarkRotary.geometry 16384 64
def fuel : Fuel := LarkRotary.fuel
def program : List Instr := [(.index 0 .bid), (.index 1 (.mul (.div (.ivar (0)) (.const (2))) (.const (2)))), (.assign 0 (.un .fromHalf (.load .global 0 (.ivar (1))))), (.assign 1 (.un .fromHalf (.load .global 0 (.add (.ivar (1)) (.const (1)))))), (.branch (.eq (.mod (.ivar (0)) (.const (2))) (.const (0))) 7), (.store .global 3 (.ivar (0)) (.un .toHalf (.bin .sub (.bin .mul (.reg (0)) (.un .fromHalf (.load .global 1 (.div (.ivar (0)) (.const (2)))))) (.bin .mul (.reg (1)) (.un .fromHalf (.load .global 2 (.div (.ivar (0)) (.const (2))))))))), (.jump 8), (.store .global 3 (.ivar (0)) (.un .toHalf (.bin .add (.bin .mul (.reg (0)) (.un .fromHalf (.load .global 2 (.div (.ivar (0)) (.const (2)))))) (.bin .mul (.reg (1)) (.un .fromHalf (.load .global 1 (.div (.ivar (0)) (.const (2))))))))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkRotary.spec ops 16384 input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkRotary.partialState ops 16384 input outside 32768
theorem segmentation_data : program = LarkRotary.program := by rfl

theorem segmentation (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    runLaunch ops layout geometry fuel program (initial layout input outside) =
      some (finalState ops input outside) := by
  rw [segmentation_data]
  simpa [layout, geometry, fuel, finalState] using LarkRotary.launch_eq ops 16384 64 input outside (by norm_num) (by norm_num) (by norm_num)

theorem race_free (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    raceFree geometry (finalState ops input outside).trace = true := by
  simpa [geometry, finalState] using LarkBias.owned_raceFree (LarkRotary.geometry 16384 64) (LarkRotary.partialState ops 16384 input outside 32768).trace (LarkRotary.partialState_owned ops 16384 input outside 32768)

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    extract layout (finalState ops input outside) = some (spec ops input) := by
  simpa [layout, finalState, spec] using LarkRotary.partialState_extract ops 16384 input outside

theorem kernel_eq_spec (ops : Ops α) :
    Correct ops layout geometry fuel program (spec ops) := by
  intro input outside
  exact ⟨finalState ops input outside, segmentation ops input outside,
    race_free ops input outside, segment_equivalence ops input outside⟩
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (s : State α)
    (pre : StdPre layout input s) :
    ∃ final, runLaunch ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec ops input) := by
  exact correct_from_pre ops layout geometry fuel program (spec ops)
    (kernel_eq_spec ops) input s pre
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
