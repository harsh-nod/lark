import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def shape : LarkFeedForward.Shape := ⟨64,256,1024,256,by decide,by decide,by decide,by decide,
  by decide,by decide,by decide,by decide,by decide⟩
def programs : LarkSwiGLU.Programs := ⟨[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (1024))) (.const (256))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (1024))) (.mod (.ivar (0)) (.const (1024))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.reg (0))), .halt],[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (1024))) (.const (256))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (1024))) (.mod (.ivar (0)) (.const (1024))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.reg (0))), .halt],[(.index 0 .bid), (.assign 0 (.load .global 0 (.ivar (0)))), (.assign 1 (.load .global 1 (.ivar (0)))), (.store .global 2 (.ivar (0)) (.un .toHalf (.bin .mul (.bin .mul (.reg (0)) (.bin .div (.lit (1) 1) (.bin .add (.lit (1) 1) (.un .exp (.bin .sub (.lit (0) 1) (.reg (0))))))) (.reg (1))))), .halt],[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (1024))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (256))) (.const (1024))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (256))) (.mod (.ivar (0)) (.const (256))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]⟩
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkSwiGLU.spec shape ops input
theorem segmentation_data : programs=LarkSwiGLU.programs shape := by rfl

theorem segmentation (ops : Ops α) : LarkSwiGLU.Correct shape ops 64 programs := by exact LarkSwiGLU.correct shape ops 64 (by decide)

theorem race_free (ops : Ops α) (input : Nat → Nat → α) (og ou oh oo : Location → Option α) :
    raceFree (LarkDotMap.geometry (LarkSwiGLU.projection shape) 64) (LarkSwiGLU.gateFinal shape ops input og).trace=true ∧
    raceFree (LarkDotMap.geometry (LarkSwiGLU.projection shape) 64) (LarkSwiGLU.upFinal shape ops input ou).trace=true ∧
    raceFree (LarkPairMap.geometry 65536 64) (LarkSwiGLU.hiddenFinal shape ops input oh).trace=true ∧
    raceFree (LarkDotMap.geometry (LarkFeedForward.stage2 shape) 64) (LarkSwiGLU.finalState shape ops input oo).trace=true := by
  refine ⟨?_,?_,?_,?_⟩
  · exact LarkReduction.owned_raceFree _ _
      (LarkDotMap.partialState_owned ops input og (LarkSwiGLU.projection shape) (shape.m*shape.h))
  · exact LarkReduction.owned_raceFree _ _
      (LarkDotMap.partialState_owned ops (LarkSwiGLU.upInput input) ou (LarkSwiGLU.projection shape) (shape.m*shape.h))
  · exact LarkReduction.owned_raceFree _ _
      (LarkPairMap.partialState_owned (LarkSwiPointwise.profile (shape.m*shape.h)) ops
        (LarkSwiGLU.pairInput shape ops input) oh (shape.m*shape.h))
  · exact LarkReduction.owned_raceFree _ _
      (LarkDotMap.partialState_owned ops (LarkSwiGLU.downInput shape ops input) oo
        (LarkFeedForward.stage2 shape) (shape.m*shape.n))

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    extract (LarkDotMap.layout (LarkFeedForward.stage2 shape)) (LarkSwiGLU.finalState shape ops input outside)=some (spec ops input) := by
  have he := LarkDotMap.extract_eq ops (LarkSwiGLU.downInput shape ops input) outside (LarkFeedForward.stage2 shape)
  rw [LarkDotMap.spec_eq_matrixSpec] at he
  exact he

theorem kernel_eq_spec (ops : Ops α) : LarkSwiGLU.Correct shape ops 64 programs := segmentation ops
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (start : State α) (ou oh oo : Location → Option α)
    (pre : StdPre (LarkDotMap.layout (LarkSwiGLU.projection shape)) input start) :
    ∃ fg fu fh fo,LarkSwiGLU.RunsWith shape ops 64 programs input start ou oh oo fg fu fh fo := by
  obtain ⟨og,rfl⟩:=pre
  exact kernel_eq_spec ops input og ou oh oo
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
