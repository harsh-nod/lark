import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def profile : LarkUnaryMap.Profile := LarkNormalization.profile .softmax 16384
def layout : Layout := LarkUnaryMap.layout 16384
def geometry : Geometry := LarkUnaryMap.geometry 16384 32
def fuel : Fuel := LarkUnaryMap.fuel profile
def program : List Instr := [(.index 0 .bid), (.assign 0 (.un .fromHalf (.load .global 0 (.const (0))))), (.assign 1 (.lit (0) 1)), (.assign 2 (.lit (0) 1)), (.index 1 (.const (1))), (.branch (.lt (.ivar (1)) (.const (16384))) 10), (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (1))))), (.assign 0 (.bin .max (.reg (0)) (.reg (2)))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 5), (.assign 1 (.reg (0))), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (16384))) 18), (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (1))))), (.assign 0 (.bin .add (.reg (0)) (.un .exp (.bin .sub (.reg (2)) (.reg (1)))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 13), (.assign 2 (.un .fromHalf (.load .global 0 (.ivar (0))))), (.store .global 1 (.ivar (0)) (.un .toHalf (.bin .div (.un .exp (.bin .sub (.reg (2)) (.reg (1)))) (.reg (0))))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkUnaryMap.spec profile ops input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α := LarkUnaryMap.partialState profile ops input outside 16384
theorem segmentation_data : program=LarkNormalization.program .softmax 16384 := by rfl

theorem segmentation (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    runLaunch ops layout geometry fuel program (initial layout input outside)=some (finalState ops input outside) := by
  rw [segmentation_data]
  exact LarkUnaryMap.launch_eq profile ops input outside 32 (by decide) (by decide) (by decide)

theorem race_free (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    raceFree geometry (finalState ops input outside).trace=true := by
  exact LarkUnaryMap.owned_raceFree geometry _ (LarkUnaryMap.partialState_owned profile ops input outside 16384)

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    extract layout (finalState ops input outside)=some (spec ops input) := by
  exact LarkUnaryMap.extract_eq profile ops input outside

theorem kernel_eq_spec (ops : Ops α) : Correct ops layout geometry fuel program (spec ops) := by
  intro input outside
  exact ⟨finalState ops input outside,segmentation ops input outside,race_free ops input outside,segment_equivalence ops input outside⟩
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (s : State α) (pre : StdPre layout input s) :
    ∃ final,runLaunch ops layout geometry fuel program s=some final ∧ raceFree geometry final.trace=true ∧ extract layout final=some (spec ops input) := by
  exact correct_from_pre ops layout geometry fuel program (spec ops) (kernel_eq_spec ops) input s pre
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
