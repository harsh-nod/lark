import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def profile : LarkBias.Profile := LarkBias.linearProfile 64 512 256 (by decide) (by decide) (by decide) (by decide) (by decide)
def layout : Layout := LarkBias.layout profile
def geometry : Geometry := LarkBias.geometry profile 32
def fuel : Fuel := LarkBias.fuel profile
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (512))) (.const (256))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (512))) (.mod (.ivar (0)) (.const (512))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 3 (.ivar (0)) (.un .toHalf (.bin .add (.reg (0)) (.un .fromHalf (.load .global 2 (.mod (.ivar (0)) (.const (512)))))))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkBias.matrixSpec ops profile input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkBias.partialState ops input outside profile profile.n
theorem segmentation_data : program = LarkBias.program profile := by rfl

theorem segmentation (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    runLaunch ops layout geometry fuel program (initial layout input outside) =
      some (finalState ops input outside) := by
  rw [segmentation_data]
  exact LarkBias.launch_eq ops input outside profile 32
    (by decide) (by decide) (by decide) (by decide)

theorem race_free (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    raceFree geometry (finalState ops input outside).trace = true := by
  exact LarkBias.owned_raceFree geometry _
    (LarkBias.partialState_owned ops input outside profile profile.n)

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    extract layout (finalState ops input outside) = some (spec ops input) := by
  have he := LarkBias.extract_eq ops input outside profile
  rw [LarkBias.spec_eq_matrixSpec] at he
  exact he

theorem kernel_eq_spec (ops : Ops α) :
    Correct ops layout geometry fuel program (spec ops) := by
  intro input outside
  exact ⟨finalState ops input outside, segmentation ops input outside,
    race_free ops input outside, segment_equivalence ops input outside⟩
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (s : State α)
    (pre : StdPre layout input s) :
    ∃ final, runLaunch ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec ops input) := by
  exact correct_from_pre ops layout geometry fuel program (spec ops)
    (kernel_eq_spec ops) input s pre
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
