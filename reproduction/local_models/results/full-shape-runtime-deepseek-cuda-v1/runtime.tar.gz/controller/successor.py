"""Run DeepSeek CUDA once after both audited Flash services have stopped.

Starts only the previously staged/pinned owned service on GPUs2,3,4,5. Every
launch/child has a durable journal before invocation. Errors require inspection;
no automatic restart, model retry, container replacement or publication occurs.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

ROOT = Path('/tmp/lark-full-shape-cuda-models-20261113')
RUNTIME = Path('/tmp/lark-full-shape-deepseek-cuda-runtime-20261113')
REMOTE_ROOT = '/tmp/lark-full-shape-deepseek-cuda-20261113'
OUT = Path('/tmp/lark-deepseek-cuda-successor-v1-20261113')
FINISH_JOURNAL = Path('/tmp/lark-finish-flash-cohorts-v1-20261113/progress.json')
CUDA_RAW = Path('/tmp/lark-full-shape-deepseek-cuda-cohort-v1-20261113')
CUDA_AUDIT = Path('/tmp/lark-full-shape-deepseek-cuda-cohort-replay-v1-20261113')
PREPARED = Path('/tmp/lark-full-shape-cuda-model-preflight-v1-20261113')
LEAN = Path('/tmp/lean-4.19.0-linux/bin/lean')
PROJECT = Path('/tmp/lark-native-softmax-exp-block-20261111/lean-real')
FORWARD = '/tmp/lark-full-shape-deepseek-cuda-forward-20261113.sock'
SSH = ['ssh', '-q', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'mi350']
MODEL = 'deepseek-ai/DeepSeek-V4.1-Flash-1017'
EXPECTED = {
    ROOT / 'reproduction/local_models/full_shape_run.py': '05438858483e7f0369e6342ecb9ab0d1f6a6820b982a8dcea270ddb3813f34b1',
    ROOT / 'reproduction/local_models/audit_full_shape.py': '9dca817c6de0ae82a294274ae6525db6714fe74b43e54c4e709850c793d26487',
    RUNTIME / 'serve_deepseek.py': '743aadb69c9a102bb05aec7e3e26cacb7cd1712648b1cb6a9e271ccaca785b9f',
    RUNTIME / 'ready.py': 'cd84be35df37514aa0c3dbb724e03ab7969ea724945cfeca07bb544fb9da1394',
    RUNTIME / 'checkpoint.json': 'da3d41868c3e4f7eefc5c73b36d6e1dcc61f7274d83a754f6b3df254b80ea3f3',
    RUNTIME / 'expected-docker-command.json': '27529d12e3e8374e31e674a85155096a411cda1a5c0130b3576144d2ca669f2d',
    RUNTIME / 'context-and-warmup.py': '6895d54e6c5205b8a72fa553b34f9baf7ac88349cc6292f9fc564abd680fff9c',
    Path('/tmp/lark-finish-flash-cohorts-20261113.py'): 'bba280f1c8a94e6f5148f9460c3d50afec9c262ffb200c465da8e6c7180a5830',
}
sys.path.insert(0, str(ROOT))
from reproduction.local_models import full_shape_run as run

REMOTE = r'''
from datetime import datetime, timezone
import hashlib, json, subprocess, sys
from pathlib import Path

def require(ok, message):
    if not ok:
        raise ValueError(message)

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def inspect(name):
    return json.loads(subprocess.check_output(['docker', 'inspect', name], text=True, timeout=20))[0]

def main(config):
    root = Path(config['remote_root'])
    progress = root / 'cuda-launch-progress.json'
    require(not progress.exists() and not (root / 'preflight-server.json').exists() and not (root / 'server.json').exists(), 'Prior launch/preflight state exists; inspect it instead of launching again')
    for name, digest in config['remote_sources'].items():
        require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, 'Pinned remote source/checkpoint record changed: ' + name)
    for item in config['finished_flash']:
        receipt = Path(item['remote_receipt']).read_bytes()
        require(hashlib.sha256(receipt).hexdigest() == item['receipt_sha256'], 'Owned Flash lifecycle receipt differs')
        recorded = json.loads(receipt)
        require(recorded['container_id'] == item['container_id'] and recorded['running'] is False and recorded['other_container_stop_commands_issued'] == 0, 'Flash service was not recorded stopped')
        current = inspect(item['container_id'])
        require(current['Id'] == item['container_id'] and not current['State']['Running'], 'Exact owned Flash service is still running')
    available_kib = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
    require(available_kib >= 512 * 1024**2, 'Less than512GiB host memory available for the existing CPU-offload configuration')
    image = json.loads(subprocess.check_output(['docker', 'image', 'inspect', config['image']], text=True, timeout=20))[0]
    require(image['Id'] == config['image_id'], 'Pinned cached Docker image differs')
    base = ['python3', str(root / 'serve_deepseek.py'), '--checkpoint', str(root / 'checkpoint.json'), '--cache', '/dev/shm/lark-models-20261109/hub', '--runtime-cache', '/dev/shm/lark-deepseek-cuda-runtime-cache-20261113', '--name', 'lark-full-shape-deepseek-cuda-20261113', '--gpu-ids', '2,3,4,5', '--port', '19086']
    state = {'schema': 1, 'status': 'fresh-hardware-preflight-starting', 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'memory_available_kib': available_kib, 'source_bindings': config['remote_sources'], 'finished_flash': config['finished_flash'], 'model_calls': 0, 'other_container_stops_or_launches': 0, 'original_paper_fully_reproduced': False}
    write(progress, state)
    try:
        preflight = subprocess.run(base + ['--output', str(root / 'preflight-server.json')], text=True, capture_output=True, timeout=90)
        (root / 'cuda-preflight.stdout').write_text(preflight.stdout)
        (root / 'cuda-preflight.stderr').write_text(preflight.stderr)
        require(preflight.returncode == 0, 'Actual fresh GPU/name/port preflight failed; no launch')
        planned = read(root / 'preflight-server.json')
        require(planned['docker_command'] == config['expected_command'] and planned['model'] == config['model'] and planned['revision'] == config['revision'] and planned['image'] == config['image'], 'Actual preflight differs from the staged successful inference command')
        state.update(status='preflight-passed-single-launch-pending', expected_docker_command=config['expected_command'], preflight_record_sha256=hashlib.sha256((root / 'preflight-server.json').read_bytes()).hexdigest())
        write(progress, state)
        # The actual launcher rechecks GPU/name/port state. Its output is fresh;
        # the durable marker above forbids any blind retry on an observation loss.
        launched = subprocess.run(base + ['--output', str(root / 'server.json'), '--launch'], text=True, capture_output=True, timeout=180)
        (root / 'cuda-launch.stdout').write_text(launched.stdout)
        (root / 'cuda-launch.stderr').write_text(launched.stderr)
        state['launch_process_exit_code'] = launched.returncode
        write(progress, state)
        require(launched.returncode == 0, 'Launch returned an error; inspect actual container and retained launch state before further action')
        server = read(root / 'server.json')
        require(server['status'] == 'started' and server['docker_command'] == config['expected_command'], 'Actual launched record differs')
        current = inspect(server['container_name'])
        require(current['Name'] == '/' + server['container_name'] and current['State']['Running'] and current['Image'] == config['image_id'] and current['Config']['Image'] == config['image'] and 'HIP_VISIBLE_DEVICES=2,3,4,5' in current['Config']['Env'], 'Owned launched container identity/image/GPU selection differs')
        image_at = config['expected_command'].index(config['image'])
        require(current['Config']['Cmd'] == config['expected_command'][image_at + 1:], 'Launched inference arguments differ')
        server['container_id'] = current['Id']
        write(root / 'server.json', server)
        state.update(status='exact-owned-DeepSeek-CUDA-container-started-readiness-pending', container_id=current['Id'], container_name=server['container_name'], gpu_ids=server['gpu_ids'], observed_at_utc=datetime.now(timezone.utc).isoformat())
        write(progress, state)
        print(json.dumps(state))
    except Exception as error:
        state.update(status='preflight-or-launch-failed-needs-authoritative-review-no-retry', error=str(error), observed_at_utc=datetime.now(timezone.utc).isoformat())
        write(progress, state)
        raise
'''


def require(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def source_gate():
    require(all(run.sha(path) == digest for path, digest in EXPECTED.items()), 'Pinned successor source or staged inference plan changed')
    require(run.sha(PREPARED / 'manifest.json') == run.CUDA_PREPARATION_SHA256 and LEAN.is_file() and PROJECT.is_dir(), 'Frozen CUDA preparation or initialized Lean project unavailable')
    plan = read(RUNTIME / 'launch-plan.json')
    validation = read(RUNTIME / 'preparation-validation.json')
    require(plan['gpu_ids'] == ['2', '3', '4', '5'] and plan['port'] == 19086 and plan['model'] == MODEL and plan['revision'] == run.MODELS[MODEL] and plan['image'] == run.IMAGE and validation['checkpoint_record_sha256'] == EXPECTED[RUNTIME / 'checkpoint.json'] and validation['cached_weight_files'] == 48 and validation['cached_support_files'] == 31 and validation['new_weight_downloads'] == 0, 'Cached checkpoint or pinned launch plan differs')


def journal(state, status, **values):
    state.update(status=status, observed_at_utc=now(), **values)
    write(OUT / 'progress.json', state)


def child(state, label, command, *, input_text=None):
    source_gate()
    journal(state, label + '-starting', child_command=command)
    environment = dict(os.environ)
    environment['LARK_REAL_PROJECT'] = str(PROJECT)
    with (OUT / (label + '.log')).open('x') as log:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.PIPE if input_text is not None else subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, text=True)
        journal(state, label + '-running', child_pid=process.pid, child_started_at_utc=now())
        if input_text is not None:
            process.stdin.write(input_text)
            process.stdin.close()
        while process.poll() is None:
            journal(state, label + '-running')
            time.sleep(10)
        journal(state, label + '-finished', child_exit_code=process.returncode)
        require(process.returncode == 0, label + ' failed; inspect existing journal/child/remote state, no retry')


def flash_receipts():
    state = read(FINISH_JOURNAL)
    rows = []
    for language, container_id, remote in (
        ('hip', '324b3f46004bac687d261c1ce9ca08c8d02591cdc67210b5f30726bcb9ee8f1b', '/tmp/lark-full-shape-flash-20261113'),
        ('cuda', 'b362a94e7835930941dbda78b01b13aef5a84c890d80a812555e2bf70ab76c83', '/tmp/lark-full-shape-flash-cuda-20261113'),
    ):
        entry = state['cohorts'][language]
        if entry['status'] == 'waiting-for-fresh-audit' or entry['status'].endswith('-starting') or entry['status'] in {'owned-service-stopped', 'closing-owned-forward'}:
            return None
        require(entry['status'] == 'stopped-and-complete-packet-validated', 'Owned Flash finishing needs review; no DeepSeek launch')
        receipt = Path(entry['authoritative_receipt'])
        actual = read(receipt)
        require(actual['container_id'] == container_id and actual['running'] is False and actual['other_container_stop_commands_issued'] == actual['model_calls_by_lifecycle_check'] == 0 and run.sha(Path(entry['packet']) / 'manifest.json') == entry['packet_manifest_sha256'], 'Completed owned Flash receipt/packet differs')
        rows.append({'container_id': container_id, 'remote_receipt': remote + '/lifecycle-stop.json', 'receipt_sha256': run.sha(receipt)})
    return rows


def validate_cuda():
    raw, audit = read(CUDA_RAW / 'results.json'), read(CUDA_AUDIT / 'results.json')
    require(raw['status'] == 'finished' and run.cohort_complete(raw) and raw['complete_17_case_cohort'] is True and raw['test_stub'] is False and raw['source_language'] == 'cuda' and raw['model'] == MODEL, 'Complete pinned CUDA cohort required')
    totals = run.usage(CUDA_RAW)
    require(totals['usage_incomplete'] is False and all(raw[key] == value for key, value in totals.items()), 'Completed usage differs')
    require(audit['status'] == 'recorded-full-size-protocol-replayed' and audit['complete_17_case_cohort'] is True and audit['recording_results_sha256'] == run.sha(CUDA_RAW / 'results.json') and audit['auditor_sha256'] == EXPECTED[ROOT / 'reproduction/local_models/audit_full_shape.py'] and audit['controller_sha256'] == EXPECTED[ROOT / 'reproduction/local_models/full_shape_run.py'] and audit['source_language'] == 'cuda' and audit['model'] == MODEL and audit['reported_usage'] == raw['reported_usage'] and audit['recorded_verified_model_proofs'] == audit['freshly_verified_model_proofs'] == raw['verified_model_proofs'] and len(audit['fresh_accepted_proof_kernel_checks']) == 2 * raw['verified_model_proofs'] and len(audit['bound_model_requests']) == raw['request_attempts'] and audit['model_calls_by_audit'] == 0, 'Complete fresh CUDA replay binding differs')
    require(raw['original_paper_fully_reproduced'] is audit['original_paper_fully_reproduced'] is False, 'Original-paper overclaim')
    return {'model_requests': raw['request_attempts'], 'verified_model_proofs': raw['verified_model_proofs'], 'reported_usage': raw['reported_usage'], 'additional_fresh_kernel_checks': len(audit['fresh_accepted_proof_kernel_checks']), 'recording_results_sha256': run.sha(CUDA_RAW / 'results.json'), 'audit_results_sha256': run.sha(CUDA_AUDIT / 'results.json')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    source_gate()
    require(not OUT.exists(), 'Prior successor journal exists; inspect it rather than starting another')
    for path in (CUDA_RAW, CUDA_AUDIT, RUNTIME / 'server-ready.json', RUNTIME / 'context', RUNTIME / 'context-results.json', RUNTIME / 'warmup', RUNTIME / 'warmup-summary.json', Path(FORWARD)):
        require(not path.exists(), 'Prior successor output/forward exists: ' + str(path))
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 19086))
    finished = flash_receipts()
    if args.check_only:
        print(json.dumps({'status': 'DeepSeek-CUDA-successor-preflight-passed', 'waiting_for_Flash': finished is None, 'container_launches': 0, 'model_calls': 0, 'future_CUDA_recording': str(CUDA_RAW), 'future_CUDA_audit': str(CUDA_AUDIT)}))
        return
    OUT.mkdir(exist_ok=False)
    state = {'schema': 1, 'pid': os.getpid(), 'status': 'waiting-for-both-Flash-audits-stops-and-archives', 'started_at_utc': now(), 'helper_sha256': run.sha(Path(__file__)), 'CUDA_recording': str(CUDA_RAW), 'CUDA_audit': str(CUDA_AUDIT), 'external_api_spend_usd': 0, 'gpu_kernel_trials': 0, 'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False, 'scope': 'After both complete audited Flash cohorts and exact-owned stopped services, fresh hardware/memory/image/name/port checks, actual launcher preflight versus staged command, one pinned TP4 DeepSeek CUDA service on2,3,4,5, readiness, one separately recorded non-proof warmup, seventeen CUDA tokenizer checks, one unchanged17-case cohort and one fresh replay. No failed child/launch is retried. Final owned shutdown/archive/publication remains later.'}
    journal(state, state['status'])
    try:
        last_print = 0
        while finished is None:
            source_gate()
            finished = flash_receipts()
            journal(state, 'waiting-for-both-Flash-audits-stops-and-archives')
            if finished is not None:
                break
            if time.monotonic() - last_print >= 60:
                print(json.dumps({'status': state['status']}), flush=True)
                last_print = time.monotonic()
            time.sleep(10)
        payload = {'remote_root': REMOTE_ROOT, 'remote_sources': {name: EXPECTED[RUNTIME / name] for name in ('serve_deepseek.py', 'ready.py', 'checkpoint.json')}, 'finished_flash': finished, 'model': MODEL, 'revision': run.MODELS[MODEL], 'image': run.IMAGE, 'image_id': 'sha256:781fca800df9fc455d492f29742d0600597fad1d84a0bbf48f6c9f4e68370b99', 'expected_command': read(RUNTIME / 'expected-docker-command.json')}
        script = REMOTE + '\nmain(' + repr(payload) + ')\n'
        (OUT / 'remote-launch.py').write_text(script)
        child(state, 'remote-preflight-single-launch', SSH + ['python3', '-'], input_text=script)
        child(state, 'owned-service-readiness', SSH + ['python3', REMOTE_ROOT + '/ready.py', '--server', REMOTE_ROOT + '/server.json', '--timeout', '3600'])
        fetch = 'from pathlib import Path\nimport sys\nsys.stdout.write(Path(' + repr(REMOTE_ROOT + '/server.json') + ').read_text())\n'
        child(state, 'ready-record-fetch', SSH + ['python3', '-'], input_text=fetch)
        ready_bytes = (OUT / 'ready-record-fetch.log').read_bytes()
        server = json.loads(ready_bytes)
        require(server['status'] == 'ready' and server['container_name'] == 'lark-full-shape-deepseek-cuda-20261113' and len(server['container_id']) == 64 and server['model'] == MODEL and server['revision'] == run.MODELS[MODEL] and server['image'] == run.IMAGE and server['gpu_ids'] == ['2', '3', '4', '5'] and server['docker_command'] == payload['expected_command'], 'Fresh exact-owned ready record differs')
        (RUNTIME / 'server-ready.json').write_bytes(ready_bytes)
        journal(state, 'opening-owned-19086-forward', container_id=server['container_id'], server_record_sha256=run.sha(RUNTIME / 'server-ready.json'))
        forward_log = (OUT / 'owned-forward.log').open('x')
        tunnel = subprocess.Popen(['ssh', '-q', '-N', '-M', '-S', FORWARD, '-L', '127.0.0.1:19086:127.0.0.1:19086', '-o', 'BatchMode=yes', '-o', 'ExitOnForwardFailure=yes', '-o', 'ServerAliveInterval=30', 'mi350'], stdout=forward_log, stderr=subprocess.STDOUT)
        journal(state, 'owned-forward-opening', forward_pid=tunnel.pid, forward_control_socket=FORWARD)
        started = time.monotonic()
        while True:
            require(tunnel.poll() is None, 'Owned forward exited; inspect log, no automatic restart')
            try:
                run.client.check_health(server['endpoint'], MODEL)
                break
            except Exception:
                require(time.monotonic() - started < 120, 'Owned forward observation timed out; inspect same PID/socket, no restart')
                time.sleep(5)
        child(state, 'CUDA-warmup-context', ['python3', str(RUNTIME / 'context-and-warmup.py')])
        context = read(RUNTIME / 'context-results.json')
        require(context['status'] == 'all-seventeen-full-size-initial-contexts-fit' and len(context['cases']) == 17 and context['source_language'] == 'cuda' and context['preparation_manifest_sha256'] == run.CUDA_PREPARATION_SHA256 and context['runner_sha256'] == EXPECTED[ROOT / 'reproduction/local_models/full_shape_run.py'], 'CUDA context preflight differs')
        child(state, 'CUDA-cohort', ['python3', str(ROOT / 'reproduction/local_models/full_shape_run.py'), '--prepared', str(PREPARED), '--lean', str(LEAN), '--server-record', str(RUNTIME / 'server-ready.json'), '--url', server['endpoint'], '--model', MODEL, '--output', str(CUDA_RAW)])
        raw = read(CUDA_RAW / 'results.json')
        require(raw['status'] == 'finished' and run.cohort_complete(raw) and raw['complete_17_case_cohort'] is True and raw['test_stub'] is False, 'CUDA child exited without a complete cohort')
        child(state, 'CUDA-fresh-replay', ['python3', str(ROOT / 'reproduction/local_models/audit_full_shape.py'), '--recording', str(CUDA_RAW), '--prepared', str(PREPARED), '--output', str(CUDA_AUDIT), '--lean', str(LEAN), '--require-full-cohort'])
        journal(state, 'DeepSeek-CUDA-complete-audited-final-owned-stop-pending', CUDA_results=validate_cuda(), finished_at_utc=now())
        write(OUT / 'results.json', state)
        print(json.dumps({'status': state['status'], 'CUDA_results': state['CUDA_results']}), flush=True)
    except Exception as error:
        journal(state, 'successor-failed-needs-authoritative-review-no-automatic-retry', error=str(error), failed_at_utc=now())
        write(OUT / 'results.json', state)
        raise


if __name__ == '__main__':
    main()
