
from datetime import datetime, timezone
import hashlib, json, subprocess, sys
from pathlib import Path

def require(ok, message):
    if not ok:
        raise ValueError(message)

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def inspect(name):
    return json.loads(subprocess.check_output(['docker', 'inspect', name], text=True, timeout=20))[0]

def main(config):
    root = Path(config['remote_root'])
    progress = root / 'cuda-launch-progress.json'
    require(not progress.exists() and not (root / 'preflight-server.json').exists() and not (root / 'server.json').exists(), 'Prior launch/preflight state exists; inspect it instead of launching again')
    for name, digest in config['remote_sources'].items():
        require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, 'Pinned remote source/checkpoint record changed: ' + name)
    for item in config['finished_flash']:
        receipt = Path(item['remote_receipt']).read_bytes()
        require(hashlib.sha256(receipt).hexdigest() == item['receipt_sha256'], 'Owned Flash lifecycle receipt differs')
        recorded = json.loads(receipt)
        require(recorded['container_id'] == item['container_id'] and recorded['running'] is False and recorded['other_container_stop_commands_issued'] == 0, 'Flash service was not recorded stopped')
        current = inspect(item['container_id'])
        require(current['Id'] == item['container_id'] and not current['State']['Running'], 'Exact owned Flash service is still running')
    available_kib = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
    require(available_kib >= 512 * 1024**2, 'Less than512GiB host memory available for the existing CPU-offload configuration')
    image = json.loads(subprocess.check_output(['docker', 'image', 'inspect', config['image']], text=True, timeout=20))[0]
    require(image['Id'] == config['image_id'], 'Pinned cached Docker image differs')
    base = ['python3', str(root / 'serve_deepseek.py'), '--checkpoint', str(root / 'checkpoint.json'), '--cache', '/dev/shm/lark-models-20261109/hub', '--runtime-cache', '/dev/shm/lark-deepseek-cuda-runtime-cache-20261113', '--name', 'lark-full-shape-deepseek-cuda-20261113', '--gpu-ids', '2,3,4,5', '--port', '19086']
    state = {'schema': 1, 'status': 'fresh-hardware-preflight-starting', 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'memory_available_kib': available_kib, 'source_bindings': config['remote_sources'], 'finished_flash': config['finished_flash'], 'model_calls': 0, 'other_container_stops_or_launches': 0, 'original_paper_fully_reproduced': False}
    write(progress, state)
    try:
        preflight = subprocess.run(base + ['--output', str(root / 'preflight-server.json')], text=True, capture_output=True, timeout=90)
        (root / 'cuda-preflight.stdout').write_text(preflight.stdout)
        (root / 'cuda-preflight.stderr').write_text(preflight.stderr)
        require(preflight.returncode == 0, 'Actual fresh GPU/name/port preflight failed; no launch')
        planned = read(root / 'preflight-server.json')
        require(planned['docker_command'] == config['expected_command'] and planned['model'] == config['model'] and planned['revision'] == config['revision'] and planned['image'] == config['image'], 'Actual preflight differs from the staged successful inference command')
        state.update(status='preflight-passed-single-launch-pending', expected_docker_command=config['expected_command'], preflight_record_sha256=hashlib.sha256((root / 'preflight-server.json').read_bytes()).hexdigest())
        write(progress, state)
        # The actual launcher rechecks GPU/name/port state. Its output is fresh;
        # the durable marker above forbids any blind retry on an observation loss.
        launched = subprocess.run(base + ['--output', str(root / 'server.json'), '--launch'], text=True, capture_output=True, timeout=180)
        (root / 'cuda-launch.stdout').write_text(launched.stdout)
        (root / 'cuda-launch.stderr').write_text(launched.stderr)
        state['launch_process_exit_code'] = launched.returncode
        write(progress, state)
        require(launched.returncode == 0, 'Launch returned an error; inspect actual container and retained launch state before further action')
        server = read(root / 'server.json')
        require(server['status'] == 'started' and server['docker_command'] == config['expected_command'], 'Actual launched record differs')
        current = inspect(server['container_name'])
        require(current['Name'] == '/' + server['container_name'] and current['State']['Running'] and current['Image'] == config['image_id'] and current['Config']['Image'] == config['image'] and 'HIP_VISIBLE_DEVICES=2,3,4,5' in current['Config']['Env'], 'Owned launched container identity/image/GPU selection differs')
        image_at = config['expected_command'].index(config['image'])
        require(current['Config']['Cmd'] == config['expected_command'][image_at + 1:], 'Launched inference arguments differ')
        server['container_id'] = current['Id']
        write(root / 'server.json', server)
        state.update(status='exact-owned-DeepSeek-CUDA-container-started-readiness-pending', container_id=current['Id'], container_name=server['container_name'], gpu_ids=server['gpu_ids'], observed_at_utc=datetime.now(timezone.utc).isoformat())
        write(progress, state)
        print(json.dumps(state))
    except Exception as error:
        state.update(status='preflight-or-launch-failed-needs-authoritative-review-no-retry', error=str(error), observed_at_utc=datetime.now(timezone.utc).isoformat())
        write(progress, state)
        raise

main({'remote_root': '/tmp/lark-full-shape-deepseek-cuda-20261113', 'remote_sources': {'serve_deepseek.py': '743aadb69c9a102bb05aec7e3e26cacb7cd1712648b1cb6a9e271ccaca785b9f', 'ready.py': 'cd84be35df37514aa0c3dbb724e03ab7969ea724945cfeca07bb544fb9da1394', 'checkpoint.json': 'da3d41868c3e4f7eefc5c73b36d6e1dcc61f7274d83a754f6b3df254b80ea3f3'}, 'finished_flash': [{'container_id': '324b3f46004bac687d261c1ce9ca08c8d02591cdc67210b5f30726bcb9ee8f1b', 'remote_receipt': '/tmp/lark-full-shape-flash-20261113/lifecycle-stop.json', 'receipt_sha256': '1a6cad4158442ed67374f0fb30be6b61be068cf3aca235dfc9506de1316b44eb'}, {'container_id': 'b362a94e7835930941dbda78b01b13aef5a84c890d80a812555e2bf70ab76c83', 'remote_receipt': '/tmp/lark-full-shape-flash-cuda-20261113/lifecycle-stop.json', 'receipt_sha256': '1349347cbdaafba06745bf74ea24f17caf13a43d7ed132e161f6c06418346bb1'}], 'model': 'deepseek-ai/DeepSeek-V4.1-Flash-1017', 'revision': '1bae0e1088993b9b82de08f59de5be5a34e42170', 'image': 'vllm/vllm-openai-rocm@sha256:71a5d125b10a594752014b917a00cb1743387d1be9ee188aa1862af0b143c7dd', 'image_id': 'sha256:781fca800df9fc455d492f29742d0600597fad1d84a0bbf48f6c9f4e68370b99', 'expected_command': ['docker', 'run', '-d', '--name', 'lark-full-shape-deepseek-cuda-20261113', '--group-add', '44', '--group-add', '993', '--cap-add=SYS_PTRACE', '--security-opt', 'seccomp=unconfined', '--device', '/dev/kfd', '--device', '/dev/dri', '--ipc=host', '-p', '127.0.0.1:19086:19086', '-v', '/dev/shm/lark-models-20261109/hub:/model-cache:ro', '-v', '/dev/shm/lark-deepseek-cuda-runtime-cache-20261113:/runtime-cache', '--env', 'HIP_VISIBLE_DEVICES=2,3,4,5', '--env', 'HF_HUB_OFFLINE=1', '--env', 'TRANSFORMERS_OFFLINE=1', '--env', 'VLLM_ENGINE_READY_TIMEOUT_S=3600', '--env', 'VLLM_ROCM_USE_AITER=1', '--env', 'VLLM_ROCM_USE_AITER_MOE=1', '--env', 'AITER_TRITON_LOG_LEVEL=ERROR', '--env', 'VLLM_USE_BREAKABLE_CUDAGRAPH=1', '--env', 'VLLM_ROCM_USE_AITER_TRITON_SPARSE_MLA=1', '--env', 'TRITON_CACHE_DIR=/runtime-cache/triton', '--env', 'TORCHINDUCTOR_CACHE_DIR=/runtime-cache/inductor', '--env', 'VLLM_CACHE_ROOT=/runtime-cache/vllm', 'vllm/vllm-openai-rocm@sha256:71a5d125b10a594752014b917a00cb1743387d1be9ee188aa1862af0b143c7dd', '--model', '/model-cache/models--deepseek-ai--DeepSeek-V4.1-Flash-1017/snapshots/1bae0e1088993b9b82de08f59de5be5a34e42170', '--served-model-name', 'deepseek-ai/DeepSeek-V4.1-Flash-1017', '--host', '0.0.0.0', '--port', '19086', '--tensor-parallel-size', '4', '--distributed-executor-backend', 'mp', '--gpu-memory-utilization', '0.85', '--max-model-len', '65536', '--max-num-seqs', '2', '--max-num-batched-tokens', '4096', '--enforce-eager', '--tokenizer-mode', 'deepseek_v41', '--reasoning-parser', 'deepseek_v41', '--tool-call-parser', 'deepseek_v41', '--enable-auto-tool-choice', '--moe-backend', 'aiter', '--engram-config', '{"cpu_offload":true}', '--attention-config', '{"indexer_kv_dtype":"mxfp4","indexer_sparse_logits":true}', '--block-size', '128', '--disable-custom-all-reduce', '--monokernel', '--language-model-only']})
