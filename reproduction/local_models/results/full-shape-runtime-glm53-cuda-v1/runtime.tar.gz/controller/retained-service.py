"""Record a completed GLM HIP service retained for a sequential CUDA cohort.

No generation, model launch, container stop or GPU kernel is invoked. A live,
partial or unaudited cohort is refused before any SSH command.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

COORDINATOR = Path('/tmp/lark-full-shape-replay-coordinator-20261113.py')
COORDINATOR_SHA = 'ccf18b09e60c1679dcf545eaae35ada11d84ffc1f87d790eb7fc43523b74f098'
REMOTE_ROOT = '/tmp/lark-full-shape-glm53-20261113'
CONTAINER_ID = '167544c9b247f421ab5747d75c6dd8b2a5b63ed1554e7dfa10857cd956a7b886'
IMAGE_ID = 'sha256:781fca800df9fc455d492f29742d0600597fad1d84a0bbf48f6c9f4e68370b99'

REMOTE = r'''
from datetime import datetime, timezone
import hashlib, json, re, subprocess, urllib.request
from pathlib import Path

def require(ok, message):
    if not ok:
        raise ValueError(message)

def main(config):
    root = Path(config['remote_root'])
    output = root / 'lifecycle-service-reuse.json'
    require(not output.exists(), 'Prior reuse observation exists; retrieve and inspect it rather than repeating')
    data = (root / 'server.json').read_bytes()
    require(hashlib.sha256(data).hexdigest() == config['server_sha256'], 'Remote initial ready record changed')
    server = json.loads(data)
    require(server == config['server'], 'Remote server differs from the bound cohort server')
    inspected = json.loads(subprocess.check_output(['docker', 'inspect', config['container_id']], text=True, timeout=20))[0]
    require(inspected['Id'] == config['container_id'] and inspected['Name'] == '/' + server['container_name'] and inspected['State']['Running'], 'Exact owned GLM container is not running')
    require(inspected['Config']['Image'] == server['image'] and inspected['Image'] == config['image_id'], 'Pinned image differs')
    command = server['docker_command']
    image_at = command.index(server['image'])
    require(inspected['Config']['Cmd'] == command[image_at + 1:], 'Original inference arguments changed')
    environment = [command[i + 1] for i, value in enumerate(command[:image_at]) if value == '--env']
    require(all(value in inspected['Config']['Env'] for value in environment), 'Original inference environment changed')
    require('HIP_VISIBLE_DEVICES=0,1,6,7' in inspected['Config']['Env'], 'GPU selection changed')
    binds = [command[i + 1] for i, value in enumerate(command[:image_at]) if value == '-v']
    require(sorted(binds) == sorted(inspected['HostConfig']['Binds']), 'Checkpoint/runtime mounts changed')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    base = server['endpoint'].removesuffix('/v1/chat/completions')
    with opener.open(base + '/health', timeout=10) as response:
        require(response.status == 200, 'Health check failed')
    with opener.open(base + '/v1/models', timeout=10) as response:
        models = json.load(response)
    served = [item for item in models['data'] if item['id'] == server['model']]
    require(len(served) == 1 and served[0]['root'] == command[command.index('--model') + 1] and served[0]['max_model_len'] == server['max_model_len'], 'Served model root/context differs')
    with opener.open(base + '/metrics', timeout=10) as response:
        metrics = response.read().decode()
    drained = {}
    for name in ('num_requests_running', 'num_requests_waiting'):
        values = re.findall(r'^vllm:' + name + r'\{[^}]*\}\s+([0-9.eE+-]+)$', metrics, re.M)
        require(values and all(float(value) == 0 for value in values), 'GLM service is still busy')
        drained[name] = [float(value) for value in values]
    record = {
        'schema': 1, 'status': 'completed-audited-GLM-HIP-service-drained-and-retained',
        'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'container_id': config['container_id'], 'container_name': server['container_name'],
        'model': server['model'], 'revision': server['revision'], 'image': server['image'],
        'gpu_ids': server['gpu_ids'], 'source_language': 'hip', 'next_source_language': 'cuda',
        'running': True, 'retained_for_sequential_cohort': True,
        'docker_stop_commands_issued': 0, 'gpu_services_started': 0,
        'model_calls_by_lifecycle_check': 0, 'gpu_kernel_trials': 0,
        'completion_binding': config['completion'], 'server_record_sha256': config['server_sha256'],
        'drained_metrics': drained, 'metrics_sha256': hashlib.sha256(metrics.encode()).hexdigest(),
        'inference_configuration_unchanged': True, 'original_paper_fully_reproduced': False,
    }
    if config['record']:
        with output.open('x') as target:
            target.write(json.dumps(record, indent=2) + '\n')
    else:
        record['status'] = 'completed-audited-drained-retained-service-check-only'
    print(json.dumps(record))
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check-only', action='store_true')
    mode.add_argument('--record', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.record and (args.output is None or args.output.exists()):
        raise ValueError('A fresh local output file is required for --record')
    import hashlib
    if hashlib.sha256(COORDINATOR.read_bytes()).hexdigest() != COORDINATOR_SHA:
        raise ValueError('Pinned replay coordinator changed')
    spec = importlib.util.spec_from_file_location('lark_completed_cohort_replay', COORDINATOR)
    coordinator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(coordinator)
    coordinator.source_gate()
    config = coordinator.CONFIG['glm53']
    status, _ = coordinator.observe(config)
    coordinator.require(status == 'ready-for-replay', 'GLM HIP cohort is live or incomplete; no SSH command issued')
    recording, audit = Path(config['recording']), Path(config['audit'])
    raw = coordinator.read(recording / 'results.json')
    state = {
        'recording_results_sha256': coordinator.run.sha(recording / 'results.json'),
        'recording_inventory': coordinator.inventory(recording),
    }
    replay = coordinator.validate_replay(config, state)
    totals = coordinator.run.usage(recording)
    coordinator.require(totals['usage_incomplete'] is False and all(raw[k] == value for k, value in totals.items()), 'Completed usage differs')
    server = coordinator.read(recording / 'server.json')
    coordinator.require(server['container_id'] == CONTAINER_ID and server['container_name'] == 'lark-full-shape-glm53-20261113' and server['gpu_ids'] == ['0', '1', '6', '7'] and server['image'] == coordinator.run.IMAGE and server['revision'] == coordinator.run.MODELS[server['model']], 'Bound owned GLM identity differs')
    coordinator.require(coordinator.run.sha(recording / 'server.json') == raw['server_record_sha256'], 'Recorded server binding differs')
    completion = {
        **state, 'replay': replay, 'model_requests': totals['request_attempts'],
        'verified_model_proofs': raw['verified_model_proofs'],
        'helper_sha256': coordinator.run.sha(Path(__file__)),
    }
    payload = {
        'remote_root': REMOTE_ROOT, 'container_id': CONTAINER_ID, 'image_id': IMAGE_ID,
        'server': server, 'server_sha256': raw['server_record_sha256'],
        'record': args.record, 'completion': completion,
    }
    result = subprocess.run(
        ['ssh', '-q', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'mi350', 'python3', '-'],
        input=REMOTE + '\nmain(' + repr(payload) + ')\n', text=True,
        capture_output=True, timeout=90,
    )
    print(result.stderr, end='', file=sys.stderr)
    if result.returncode:
        print(result.stdout, end='')
        raise SystemExit(result.returncode)
    receipt = json.loads(result.stdout)
    coordinator.require(receipt['container_id'] == CONTAINER_ID and receipt['running'] is True and receipt['retained_for_sequential_cohort'] is True, 'Returned retained-service identity differs')
    if args.record:
        with args.output.open('x') as target:
            target.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    try:
        main()
    except ValueError as error:
        print(json.dumps({'status': 'retained-service-observation-refused', 'error': str(error)}))
        raise SystemExit(2)
