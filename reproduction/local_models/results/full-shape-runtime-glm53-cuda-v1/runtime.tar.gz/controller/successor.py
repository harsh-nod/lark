"""After GLM HIP and its audit finish, archive HIP and run/audit CUDA once.

The existing loaded service is reused sequentially. No container is launched or
stopped, no existing output is replaced, and no failed child is retried.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/tmp/lark-full-shape-cuda-models-20261113')
RUNTIME = Path('/tmp/lark-full-shape-glm53-cuda-runtime-20261113')
OUT = Path('/tmp/lark-glm-cuda-successor-v1-20261113')
REPLAY_JOURNAL = Path('/tmp/lark-full-shape-replay-coordinator-v1-20261113/progress.json')
RETAIN = Path('/tmp/lark-record-finished-glm-reuse-20261113.py')
PACKAGE = Path('/tmp/lark-package-full-shape-cohort-20261113.py')
HIP_RAW = Path('/tmp/lark-full-shape-glm53-cohort-v1-20261113')
HIP_AUDIT = Path('/tmp/lark-full-shape-glm53-cohort-replay-v1-20261113')
HIP_PACKET = Path('/tmp/lark-full-shape-glm53-hip-packet-v1-20261113')
CUDA_RAW = Path('/tmp/lark-full-shape-glm53-cuda-cohort-v1-20261113')
CUDA_AUDIT = Path('/tmp/lark-full-shape-glm53-cuda-cohort-replay-v1-20261113')
PREPARED = Path('/tmp/lark-full-shape-cuda-model-preflight-v1-20261113')
LEAN = Path('/tmp/lean-4.19.0-linux/bin/lean')
PROJECT = Path('/tmp/lark-native-softmax-exp-block-20261111/lean-real')
EXPECTED = {
    ROOT / 'reproduction/local_models/full_shape_run.py': '05438858483e7f0369e6342ecb9ab0d1f6a6820b982a8dcea270ddb3813f34b1',
    ROOT / 'reproduction/local_models/audit_full_shape.py': '9dca817c6de0ae82a294274ae6525db6714fe74b43e54c4e709850c793d26487',
    RETAIN: '5df95c5add1eade77dbbb4793df48e45070bb93fb36cd3b4201e9080a20721ec',
    PACKAGE: 'e6e62a6ffe5c26fb5d19b6039b7b3419bdb57f9d0e578a81093fca292e2d939d',
}
sys.path.insert(0, str(ROOT))
from reproduction.local_models import full_shape_run as run


def require(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def source_gate():
    require(all(run.sha(path) == digest for path, digest in EXPECTED.items()), 'Pinned successor source/helper changed')
    require(run.sha(PREPARED / 'manifest.json') == run.CUDA_PREPARATION_SHA256, 'Frozen CUDA preparation changed')
    require(LEAN.is_file() and PROJECT.is_dir(), 'Initialized Lean project unavailable')
    server = read(RUNTIME / 'server-ready.json')
    require(server['container_id'] == '167544c9b247f421ab5747d75c6dd8b2a5b63ed1554e7dfa10857cd956a7b886' and server['model'] == 'zai-org/GLM-5.3' and server['revision'] == run.MODELS[server['model']] and server['gpu_ids'] == ['0', '1', '6', '7'] and server['image'] == run.IMAGE and server['endpoint'] == 'http://127.0.0.1:19085/v1/chat/completions', 'Owned GLM service identity differs')


def journal(state, status, **values):
    state.update(status=status, observed_at_utc=now(), **values)
    write(OUT / 'progress.json', state)


def child(state, label, command, *, cwd=ROOT):
    source_gate()
    journal(state, label + '-starting', child_command=command)
    environment = dict(os.environ)
    environment['LARK_REAL_PROJECT'] = str(PROJECT)
    with (OUT / (label + '.log')).open('x') as log:
        process = subprocess.Popen(command, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT)
        journal(state, label + '-running', child_pid=process.pid, child_started_at_utc=now())
        while process.poll() is None:
            journal(state, label + '-running')
            time.sleep(10)
        journal(state, label + '-finished', child_exit_code=process.returncode)
        require(process.returncode == 0, label + ' failed; inspect same journal/child output, no automatic retry')


def validate_cuda():
    raw, audit = read(CUDA_RAW / 'results.json'), read(CUDA_AUDIT / 'results.json')
    require(raw['status'] == 'finished' and raw['test_stub'] is False and run.cohort_complete(raw) and raw['complete_17_case_cohort'] is True and raw['source_language'] == 'cuda' and raw['model'] == 'zai-org/GLM-5.3', 'CUDA cohort is incomplete or has a different identity')
    totals = run.usage(CUDA_RAW)
    require(totals['usage_incomplete'] is False and all(raw[key] == value for key, value in totals.items()), 'Completed CUDA usage differs')
    require(audit['status'] == 'recorded-full-size-protocol-replayed' and audit['complete_17_case_cohort'] is True and audit['recording_results_sha256'] == run.sha(CUDA_RAW / 'results.json') and audit['auditor_sha256'] == EXPECTED[ROOT / 'reproduction/local_models/audit_full_shape.py'] and audit['controller_sha256'] == EXPECTED[ROOT / 'reproduction/local_models/full_shape_run.py'] and audit['model'] == raw['model'] and audit['source_language'] == 'cuda' and audit['reported_usage'] == raw['reported_usage'] and audit['recorded_verified_model_proofs'] == audit['freshly_verified_model_proofs'] == raw['verified_model_proofs'] and len(audit['fresh_accepted_proof_kernel_checks']) == 2 * raw['verified_model_proofs'] and len(audit['bound_model_requests']) == raw['request_attempts'] and audit['model_calls_by_audit'] == 0, 'Completed CUDA fresh replay differs')
    require(raw['original_paper_fully_reproduced'] is audit['original_paper_fully_reproduced'] is False, 'Original-paper completion overclaim')
    return {'model_requests': raw['request_attempts'], 'verified_model_proofs': raw['verified_model_proofs'], 'reported_usage': raw['reported_usage'], 'additional_fresh_kernel_checks': len(audit['fresh_accepted_proof_kernel_checks']), 'recording_results_sha256': run.sha(CUDA_RAW / 'results.json'), 'audit_results_sha256': run.sha(CUDA_AUDIT / 'results.json')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    source_gate()
    require(not OUT.exists(), 'Prior successor journal exists; inspect its actual PID and children rather than restarting')
    for path in (HIP_PACKET, CUDA_RAW, CUDA_AUDIT, RUNTIME / 'service-reuse.json', RUNTIME / 'context', RUNTIME / 'context-results.json', RUNTIME / 'warmup', RUNTIME / 'warmup-summary.json'):
        require(not path.exists(), 'Prior successor output exists: ' + str(path))
    entry = read(REPLAY_JOURNAL)['cohorts']['glm53']
    require(entry['recording'] == str(HIP_RAW) and entry['audit'] == str(HIP_AUDIT) and entry['pid'] == 3695541, 'Original GLM replay ownership differs')
    warmup_sha = run.sha(RUNTIME / 'context-and-warmup.py')
    if args.check_only:
        print(json.dumps({'status': 'GLM-sequential-CUDA-successor-preflight-passed', 'HIP_replay_status': entry['status'], 'new_model_calls': 0, 'container_launches_or_stops': 0, 'future_HIP_packet': str(HIP_PACKET), 'future_CUDA_recording': str(CUDA_RAW), 'future_CUDA_audit': str(CUDA_AUDIT), 'warmup_context_driver_sha256': warmup_sha}))
        return
    OUT.mkdir(exist_ok=False)
    state = {'schema': 1, 'pid': os.getpid(), 'status': 'waiting-for-HIP-fresh-audit', 'started_at_utc': now(), 'helper_sha256': run.sha(Path(__file__)), 'warmup_context_driver_sha256': warmup_sha, 'HIP_packet': str(HIP_PACKET), 'CUDA_recording': str(CUDA_RAW), 'CUDA_audit': str(CUDA_AUDIT), 'container_launches_or_stops': 0, 'external_api_spend_usd': 0, 'gpu_kernel_trials': 0, 'new_registered_source_certificates': 0, 'original_paper_fully_reproduced': False, 'scope': 'One separately recorded non-proof warmup, seventeen CUDA tokenizer checks, one unchanged17-case CUDA model cohort and one fresh replay, sequentially after HIP completion/audit and fresh exact-owned unchanged-configuration/drained-service observation. Existing outputs or failed children are never replaced/retried. HIP is archived using the retained-service receipt. CUDA final owned shutdown/publication remains a later step.'}
    journal(state, state['status'])
    try:
        last_print = 0
        while True:
            source_gate()
            entry = read(REPLAY_JOURNAL)['cohorts']['glm53']
            journal(state, 'waiting-for-HIP-fresh-audit', observed_HIP_replay_status=entry['status'], observed_HIP_completed_cases=entry.get('completed_cases'))
            if entry['status'] == 'audit-complete':
                break
            require(entry['status'] in {'waiting-for-controller', 'ready-for-replay', 'waiting-observation-error', 'audit-starting', 'audit-running'}, 'Original HIP run/audit needs review; no successor calls')
            if time.monotonic() - last_print >= 60:
                print(json.dumps({'status': state['status'], 'HIP_replay_status': entry['status']}), flush=True)
                last_print = time.monotonic()
            time.sleep(10)
        child(state, 'retained-service-check', ['python3', str(RETAIN), '--check-only'])
        child(state, 'retained-service-record', ['python3', str(RETAIN), '--record', '--output', str(RUNTIME / 'service-reuse.json')])
        child(state, 'archive-HIP', ['python3', str(PACKAGE), '--repository', '/home/harsh/lark', '--recording', str(HIP_RAW), '--audit', str(HIP_AUDIT), '--lifecycle', str(RUNTIME / 'service-reuse.json'), '--lifecycle-kind', 'reuse', '--output', str(HIP_PACKET)])
        require(run.sha(RUNTIME / 'context-and-warmup.py') == warmup_sha, 'Staged warmup/context source changed')
        child(state, 'CUDA-warmup-context', ['python3', str(RUNTIME / 'context-and-warmup.py')])
        context = read(RUNTIME / 'context-results.json')
        require(context['status'] == 'all-seventeen-full-size-initial-contexts-fit' and len(context['cases']) == 17 and context['source_language'] == 'cuda' and context['preparation_manifest_sha256'] == run.CUDA_PREPARATION_SHA256 and context['runner_sha256'] == EXPECTED[ROOT / 'reproduction/local_models/full_shape_run.py'], 'CUDA context preflight differs')
        child(state, 'CUDA-cohort', ['python3', str(ROOT / 'reproduction/local_models/full_shape_run.py'), '--prepared', str(PREPARED), '--lean', str(LEAN), '--server-record', str(RUNTIME / 'server-ready.json'), '--url', 'http://127.0.0.1:19085/v1/chat/completions', '--model', 'zai-org/GLM-5.3', '--output', str(CUDA_RAW)])
        raw = read(CUDA_RAW / 'results.json')
        require(raw['status'] == 'finished' and run.cohort_complete(raw) and raw['complete_17_case_cohort'] is True and raw['test_stub'] is False, 'CUDA child exited without a complete cohort')
        child(state, 'CUDA-fresh-replay', ['python3', str(ROOT / 'reproduction/local_models/audit_full_shape.py'), '--recording', str(CUDA_RAW), '--prepared', str(PREPARED), '--output', str(CUDA_AUDIT), '--lean', str(LEAN), '--require-full-cohort'])
        journal(state, 'GLM-HIP-archived-and-CUDA-complete-audited-final-owned-stop-pending', CUDA_results=validate_cuda(), finished_at_utc=now())
        write(OUT / 'results.json', state)
        print(json.dumps({'status': state['status'], 'CUDA_results': state['CUDA_results']}), flush=True)
    except Exception as error:
        journal(state, 'successor-failed-needs-authoritative-review-no-automatic-retry', error=str(error), failed_at_utc=now())
        write(OUT / 'results.json', state)
        raise


if __name__ == '__main__':
    main()
