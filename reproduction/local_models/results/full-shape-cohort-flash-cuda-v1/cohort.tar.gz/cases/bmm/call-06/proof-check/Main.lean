import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def profile : LarkDot.Profile := LarkMatrix.batchProfile 32 64 512 256 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
def layout : Layout := LarkDot.layout profile
def geometry : Geometry := LarkDot.geometry profile 32
def fuel : Fuel := LarkDot.fuel profile
def program : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (32768))) (.const (16384))) (.add (.mul (.mod (.div (.ivar (0)) (.const (512))) (.const (64))) (.const (256))) (.ivar (1)))))) (.un .fromHalf (.load .global 1 (.add (.mul (.div (.ivar (0)) (.const (32768))) (.const (131072))) (.add (.mul (.ivar (1)) (.const (512))) (.mod (.ivar (0)) (.const (512)))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α :=
  LarkDot.matrixSpec ops profile input
def finalState (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) : State α :=
  LarkDot.partialState ops input outside profile profile.n
theorem segmentation_data : program = LarkDot.program profile := by rfl

theorem segmentation (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    runLaunch ops layout geometry fuel program (initial layout input outside) =
      some (finalState ops input outside) := by
  have h := LarkDot.launch_eq (α := α) ops input outside profile 32
    (by decide) (by decide) ⟨by decide, by decide⟩ (by decide)
  exact h

theorem race_free (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    raceFree geometry (finalState ops input outside).trace = true := by
  have h := LarkDot.correct (α := α) ops profile 32 (by decide) (by decide)
    ⟨by decide, by decide⟩ (by decide)
  exact (h input outside).2.1

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α)
    (outside : Location → Option α) :
    extract layout (finalState ops input outside) = some (spec ops input) := by
  have h := LarkDot.correct (α := α) ops profile 32 (by decide) (by decide)
    ⟨by decide, by decide⟩ (by decide)
  have h2 := h input outside
  rw [LarkDot.spec_eq_matrixSpec] at h2
  exact h2.2.2

theorem kernel_eq_spec (ops : Ops α) :
    Correct ops layout geometry fuel program (spec ops) := by
  intro input outside
  exact ⟨finalState ops input outside, segmentation ops input outside,
    race_free ops input outside, segment_equivalence ops input outside⟩
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (s : State α)
    (pre : StdPre layout input s) :
    ∃ final, runLaunch ops layout geometry fuel program s = some final ∧
      raceFree geometry final.trace = true ∧ extract layout final = some (spec ops input) := by
  exact correct_from_pre ops layout geometry fuel program (spec ops)
    (kernel_eq_spec ops) input s pre
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
