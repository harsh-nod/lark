import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def shape : LarkAttention.Shape := ⟨2,4,128,64,8,
  by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide⟩
def programs : LarkAttention.Programs := ⟨[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (64))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (16384))) (.const (8192))) (.add (.mul (.mod (.div (.ivar (0)) (.const (128))) (.const (128))) (.const (64))) (.ivar (1)))))) (.un .fromHalf (.load .global 1 (.add (.mul (.div (.div (.ivar (0)) (.const (16384))) (.const (4))) (.const (8192))) (.add (.mul (.mod (.ivar (0)) (.const (128))) (.const (64))) (.ivar (1))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.bin .div (.reg (0)) (.lit (8) 1))), .halt],[(.index 0 .bid), (.index 1 (.const (0))), (.assign 0 (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (128))) (.const (128))) (.ivar (1))))), (.assign 1 (.lit (0) 1)), (.assign 2 (.lit (0) 1)), (.index 1 (.const (1))), (.branch (.lt (.ivar (1)) (.const (128))) 11), (.assign 2 (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (128))) (.const (128))) (.ivar (1))))), (.assign 0 (.bin .max (.reg (0)) (.reg (2)))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 6), (.assign 1 (.reg (0))), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (128))) 19), (.assign 2 (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (128))) (.const (128))) (.ivar (1))))), (.assign 0 (.bin .add (.reg (0)) (.un .exp (.bin .sub (.reg (2)) (.reg (1)))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 14), (.assign 2 (.load .global 0 (.ivar (0)))), (.store .global 1 (.ivar (0)) (.bin .div (.un .exp (.bin .sub (.reg (2)) (.reg (1)))) (.reg (0)))), .halt],[(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (128))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (8192))) (.const (16384))) (.add (.mul (.mod (.div (.ivar (0)) (.const (64))) (.const (128))) (.const (128))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.div (.div (.ivar (0)) (.const (8192))) (.const (4))) (.const (8192))) (.add (.mul (.ivar (1)) (.const (64))) (.mod (.ivar (0)) (.const (64)))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]⟩
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkAttention.spec shape ops input
theorem segmentation_data : programs=LarkAttention.programs shape := by rfl

theorem segmentation (ops : Ops α) : LarkAttention.Correct shape ops 32 programs := by rw [segmentation_data]; exact LarkAttention.correct shape ops 32 (by decide)

theorem race_free (ops : Ops α) (input : Nat → Nat → α) (oq os ov : Location → Option α) :
    raceFree (LarkDotMap.geometry (LarkAttention.scoreProfile shape) 32) (LarkAttention.scoreFinal shape ops input oq).trace=true ∧
    raceFree (LarkUnaryMap.geometry (LarkRowSoftmax.total (LarkAttention.softmaxShape shape)) 32) (LarkAttention.softFinal shape ops input os).trace=true ∧
    raceFree (LarkDotMap.geometry (LarkAttention.valueProfile shape) 32) (LarkAttention.finalState shape ops input ov).trace=true := by exact ⟨LarkReduction.owned_raceFree (LarkDotMap.geometry (LarkAttention.scoreProfile shape) 32) (LarkAttention.scoreFinal shape ops input oq).trace (LarkDotMap.partialState_owned ops input oq (LarkAttention.scoreProfile shape) (LarkAttention.scores shape)), LarkUnaryMap.owned_raceFree (LarkUnaryMap.geometry (LarkRowSoftmax.total (LarkAttention.softmaxShape shape)) 32) (LarkAttention.softFinal shape ops input os).trace (LarkUnaryMap.partialState_owned (LarkRowSoftmax.profile (LarkAttention.softmaxShape shape)) ops (LarkAttention.softInput shape ops input) os (LarkRowSoftmax.total (LarkAttention.softmaxShape shape))), LarkReduction.owned_raceFree (LarkDotMap.geometry (LarkAttention.valueProfile shape) 32) (LarkAttention.finalState shape ops input ov).trace (LarkDotMap.partialState_owned ops (LarkAttention.valueInput shape ops input) ov (LarkAttention.valueProfile shape) (LarkAttention.qCells shape))⟩

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) :
    extract (LarkDotMap.layout (LarkAttention.valueProfile shape)) (LarkAttention.finalState shape ops input outside)=some (spec ops input) := by rw [LarkDotMap.extract_eq ops (LarkAttention.valueInput shape ops input) outside (LarkAttention.valueProfile shape), LarkDotMap.spec_eq_matrixSpec]

theorem kernel_eq_spec (ops : Ops α) : LarkAttention.Correct shape ops 32 programs := segmentation ops
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (start : State α) (os ov : Location → Option α)
    (pre : StdPre (LarkDotMap.layout (LarkAttention.scoreProfile shape)) input start) :
    ∃ fs fp fo,LarkAttention.RunsWith shape ops 32 programs input start os ov fs fp fo := by
  obtain ⟨oq,rfl⟩:=pre
  exact kernel_eq_spec ops input oq os ov
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
