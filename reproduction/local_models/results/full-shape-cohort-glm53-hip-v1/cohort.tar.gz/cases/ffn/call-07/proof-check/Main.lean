import LarkReal.BenchmarkReferenceImports
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000
namespace LarkCertificate
open LarkNonlinear
def shape : LarkFeedForward.Shape :=
  ⟨64,256,1024,256,by decide,by decide,by decide,by decide,
    by decide,by decide,by decide,by decide,by decide⟩
def chain : LarkPipeline.Chain := LarkFeedForward.chain shape
def upProgram : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (256))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (1024))) (.const (256))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (1024))) (.mod (.ivar (0)) (.const (1024))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.bin .max (.reg (0)) (.lit (0) 1)))), .halt]
def downProgram : List Instr := [(.index 0 .bid), (.assign 0 (.lit (0) 1)), (.index 1 (.const (0))), (.branch (.lt (.ivar (1)) (.const (1024))) 7), (.assign 0 (.bin .add (.reg (0)) (.bin .mul (.un .fromHalf (.load .global 0 (.add (.mul (.div (.ivar (0)) (.const (256))) (.const (1024))) (.ivar (1))))) (.un .fromHalf (.load .global 1 (.add (.mul (.ivar (1)) (.const (256))) (.mod (.ivar (0)) (.const (256))))))))), (.index 1 (.add (.ivar (1)) (.const (1)))), (.jump 3), (.store .global 2 (.ivar (0)) (.un .toHalf (.reg (0)))), .halt]
def spec (ops : Ops α) (input : Nat → Nat → α) : List α := LarkPipeline.spec chain ops input
def firstFinal (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  LarkPipeline.firstFinal chain ops input outside
def secondFinal (ops : Ops α) (input : Nat → Nat → α) (outside : Location → Option α) : State α :=
  LarkPipeline.secondFinal chain ops input outside
theorem segmentation_data : upProgram=LarkDotMap.program chain.first ∧ downProgram=LarkDotMap.program chain.second := by rfl

theorem segmentation (ops : Ops α) : ∀ input outside1 outside2,∃ f1 f2,
    LarkPipeline.RunsWith chain ops 64 upProgram downProgram input
      (initial (LarkDotMap.layout chain.first) input outside1) outside2 f1 f2 := by
  intro input outside1 outside2
  exact LarkFeedForward.correct shape ops 64 (by decide) input outside1 outside2

theorem race_free (ops : Ops α) (input : Nat → Nat → α) (outside1 outside2 : Location → Option α) :
    raceFree (LarkDotMap.geometry chain.first 64) (firstFinal ops input outside1).trace=true ∧
    raceFree (LarkDotMap.geometry chain.second 64) (secondFinal ops input outside2).trace=true := by
  refine ⟨?_,?_⟩
  · exact LarkReduction.owned_raceFree (LarkDotMap.geometry chain.first 64) _
      (LarkDotMap.partialState_owned ops input outside1 chain.first chain.first.n)
  · exact LarkReduction.owned_raceFree (LarkDotMap.geometry chain.second 64) _
      (LarkDotMap.partialState_owned ops (LarkPipeline.idealInput chain ops input) outside2
        chain.second chain.second.n)

theorem segment_equivalence (ops : Ops α) (input : Nat → Nat → α) (outside2 : Location → Option α) :
    extract (LarkDotMap.layout chain.second) (secondFinal ops input outside2)=some (spec ops input) := by
  have h := LarkDotMap.extract_eq ops (LarkPipeline.idealInput chain ops input) outside2 chain.second
  rw [LarkDotMap.spec_eq_matrixSpec] at h
  exact h

theorem kernel_eq_spec (ops : Ops α) : ∀ input outside1 outside2,∃ f1 f2,
    LarkPipeline.RunsWith chain ops 64 upProgram downProgram input
      (initial (LarkDotMap.layout chain.first) input outside1) outside2 f1 f2 := segmentation ops
theorem kernel_eq_spec_pre (ops : Ops α) (input : Nat → Nat → α) (start : State α)
    (outside2 : Location → Option α) (pre : StdPre (LarkDotMap.layout chain.first) input start) :
    ∃ f1 f2,LarkPipeline.RunsWith chain ops 64 upProgram downProgram input start outside2 f1 f2 := by
  obtain ⟨outside1,rfl⟩:=pre
  exact kernel_eq_spec ops input outside1 outside2
#print axioms segmentation_data
#print axioms segmentation
#print axioms race_free
#print axioms segment_equivalence
#print axioms kernel_eq_spec
#print axioms kernel_eq_spec_pre
end LarkCertificate
