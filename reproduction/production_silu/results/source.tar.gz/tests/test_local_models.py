import http.server
import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import unittest
import urllib.error
import sys
from unittest.mock import patch

from reproduction.local_models import client

LEAN = os.environ.get("LARK_LEAN") or shutil.which("lean")


class LocalClientTests(unittest.TestCase):
    def test_remote_urls_credentials_and_unexpected_paths_are_refused(self):
        for url in [
            "https://api.openai.com/v1/chat/completions",
            "http://127.0.0.1.example.com/v1/chat/completions",
            "http://user:secret@127.0.0.1/v1/chat/completions",
            "http://127.0.0.1/v1/chat/completions?target=cloud",
            "http://127.0.0.1/other",
        ]:
            with self.subTest(url=url), self.assertRaises(ValueError):
                client.endpoint(url)

    def test_json_proposals_have_only_the_two_fixed_fields(self):
        expected = {"segments": [], "proofs": {}}
        self.assertEqual(client.proposal("```json\n" + json.dumps(expected) + "\n```"), expected)
        for data in [[], {"segments": []}, {**expected, "new_statement": "True"}]:
            with self.subTest(data=data), self.assertRaises(ValueError):
                client.proposal(json.dumps(data))

    def test_local_request_and_usage_are_recorded_and_redirects_are_refused(self):
        class Handler(http.server.BaseHTTPRequestHandler):
            redirect = False
            empty = False
            seen = None

            def do_GET(self):
                self.send_response(200)
                self.end_headers()
                self.wfile.write(json.dumps({"data": [{"id": "zai-org/GLM-5.3-Flash"}]}).encode())

            def do_POST(self):
                request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                Handler.seen = request
                if self.redirect:
                    self.send_response(302)
                    self.send_header("Location", "https://example.com/v1/chat/completions")
                    self.end_headers()
                    return
                self.send_response(200)
                self.end_headers()
                self.wfile.write(
                    json.dumps(
                        {
                            "model": request["model"],
                            "usage": {"prompt_tokens": 2, "completion_tokens": 3},
                            "choices": [
                                {
                                    "finish_reason": "stop",
                                    "message": {"content": None if self.empty else "{}"},
                                }
                            ],
                        }
                    ).encode()
                )

            def log_message(self, *args):
                pass

        server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp:
                url = f"http://127.0.0.1:{server.server_port}/v1/chat/completions"
                self.assertEqual(
                    client.check_health(url, "zai-org/GLM-5.3-Flash")["data"][0]["id"],
                    "zai-org/GLM-5.3-Flash",
                )
                with self.assertRaises(ValueError):
                    client.check_health(url, "zai-org/GLM-5.3")
                target = Path(tmp) / "success"
                self.assertEqual(
                    client.call(
                        url,
                        "zai-org/GLM-5.3-Flash",
                        [],
                        target,
                        reasoning_effort="low",
                        thinking_token_budget=128,
                    ),
                    "{}",
                )
                self.assertEqual(Handler.seen["reasoning_effort"], "low")
                self.assertEqual(Handler.seen["thinking_token_budget"], 128)
                record = json.loads((target / "receipt.json").read_text())
                self.assertEqual(record["usage"]["completion_tokens"], 3)
                self.assertEqual(record["external_api_spend_usd"], 0)
                Handler.empty = True
                with self.assertRaises(ValueError):
                    client.call(url, "zai-org/GLM-5.3-Flash", [], Path(tmp) / "empty")
                empty = json.loads((Path(tmp) / "empty/receipt.json").read_text())
                self.assertEqual(empty["usage"]["completion_tokens"], 3)
                self.assertTrue((Path(tmp) / "empty/response.json").exists())
                Handler.redirect = True
                with self.assertRaises(urllib.error.HTTPError):
                    client.call(url, "zai-org/GLM-5.3-Flash", [], Path(tmp) / "redirect")
                rejected = json.loads((Path(tmp) / "redirect/receipt.json").read_text())
                self.assertEqual(rejected["status"], "error")
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_reasoning_only_response_is_not_a_transport_or_proof_rejection(self):
        from reproduction.local_models.run import ROOT, run_case
        from lark_kernels import certificate

        def no_content(*args, **kwargs):
            self.assertEqual(kwargs["reasoning_effort"], "low")
            output = Path(args[3])
            output.mkdir()
            (output / "response.json").write_text(
                json.dumps({"choices": [{"message": {"content": None}}]})
            )
            raise ValueError("Model produced no proof content")

        with tempfile.TemporaryDirectory() as tmp:
            args = argparse.Namespace(
                model="zai-org/GLM-5.3-Flash",
                url="http://127.0.0.1:1/v1/chat/completions",
                lean=None,
                attempts=1,
                seed=0,
                temperature=0,
                max_tokens=64,
                model_timeout=1,
                lean_timeout=1,
                reasoning_effort="low",
            )
            with (
                patch.object(certificate, "lean_binary", return_value="/unused/lean"),
                patch.object(client, "call", no_content),
                patch.object(certificate, "run_lean") as checked,
            ):
                result = run_case(
                    ROOT / "reproduction/nonlinear/cases/float16/relu",
                    Path(tmp) / "case",
                    args,
                    {"revision": "fixture"},
                )
            self.assertEqual(result["status"], "no-proof-content")
            self.assertEqual(result["calls"][0]["status"], "no-proof-content")
            checked.assert_not_called()

    def test_dead_runtime_stops_before_any_model_request(self):
        from reproduction.local_models.run import main

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            server = root / "server.json"
            server.write_text(
                json.dumps(
                    {"model": "zai-org/GLM-5.3-Flash", "revision": "fixture", "status": "ready"}
                )
            )
            dest = root / "result"
            argv = [
                "run.py",
                "--url",
                "http://127.0.0.1:1/v1/chat/completions",
                "--model",
                "zai-org/GLM-5.3-Flash",
                "--server-record",
                str(server),
                "--case",
                "unused",
                "--output",
                str(dest),
                "--lean",
                "/unused/lean",
            ]
            with (
                patch.object(sys, "argv", argv),
                patch.object(client, "check_health", side_effect=ConnectionRefusedError("fixture")),
                patch.object(client, "call") as model_call,
                contextlib.redirect_stdout(io.StringIO()),
            ):
                main()
            result = json.loads((dest / "results.json").read_text())
            self.assertEqual(result["status"], "runtime-unavailable")
            self.assertEqual(result["cases"], [])
            model_call.assert_not_called()

    @unittest.skipUnless(LEAN, "Lean is needed")
    def test_stub_proposal_gets_an_independently_checked_certificate(self):
        from lark_kernels.certificate import DEFAULT_PROOFS
        from reproduction.local_models.run import ROOT, run_case

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                prompt = json.loads(request["messages"][-1]["content"])
                candidate = {"segments": prompt["proposal"]["segments"], "proofs": DEFAULT_PROOFS}
                response = {
                    "model": request["model"],
                    "usage": {},
                    "choices": [
                        {"finish_reason": "stop", "message": {"content": json.dumps(candidate)}}
                    ],
                }
                self.send_response(200)
                self.end_headers()
                self.wfile.write(json.dumps(response).encode())

            def log_message(self, *args):
                pass

        server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
                args = argparse.Namespace(
                    lean=LEAN,
                    attempts=1,
                    model="zai-org/GLM-5.3-Flash",
                    seed=0,
                    temperature=0,
                    max_tokens=100,
                    model_timeout=10,
                    lean_timeout=120,
                    url=f"http://127.0.0.1:{server.server_port}/v1/chat/completions",
                )
                result = run_case(
                    ROOT / "reproduction/nonlinear/cases/float16/relu",
                    Path(tmp) / "case",
                    args,
                    {"revision": "unit-test-stub-not-a-model-run"},
                )
                self.assertEqual(result["status"], "verified")
                self.assertTrue((Path(tmp) / "case/certificate/report.json").exists())
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    unittest.main()
