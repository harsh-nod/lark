	.file	"driver.hip"
	.text
	.globl	__device_stub__broadcast_subgroup # -- Begin function __device_stub__broadcast_subgroup
	.p2align	4
	.type	__device_stub__broadcast_subgroup,@function
__device_stub__broadcast_subgroup:      # @__device_stub__broadcast_subgroup
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 56(%rsp)
	movq	%rsi, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 72(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	64(%rsp), %r9
	movl	$broadcast_subgroup, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$104, %rsp
	.cfi_adjust_cfa_offset -104
	retq
.Lfunc_end0:
	.size	__device_stub__broadcast_subgroup, .Lfunc_end0-__device_stub__broadcast_subgroup
	.cfi_endproc
                                        # -- End function
	.globl	__device_stub__down_subgroup    # -- Begin function __device_stub__down_subgroup
	.p2align	4
	.type	__device_stub__down_subgroup,@function
__device_stub__down_subgroup:           # @__device_stub__down_subgroup
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 56(%rsp)
	movq	%rsi, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 72(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	64(%rsp), %r9
	movl	$down_subgroup, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$104, %rsp
	.cfi_adjust_cfa_offset -104
	retq
.Lfunc_end1:
	.size	__device_stub__down_subgroup, .Lfunc_end1-__device_stub__down_subgroup
	.cfi_endproc
                                        # -- End function
	.globl	__device_stub__reverse_wave     # -- Begin function __device_stub__reverse_wave
	.p2align	4
	.type	__device_stub__reverse_wave,@function
__device_stub__reverse_wave:            # @__device_stub__reverse_wave
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 56(%rsp)
	movq	%rsi, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 72(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	64(%rsp), %r9
	movl	$reverse_wave, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$104, %rsp
	.cfi_adjust_cfa_offset -104
	retq
.Lfunc_end2:
	.size	__device_stub__reverse_wave, .Lfunc_end2-__device_stub__reverse_wave
	.cfi_endproc
                                        # -- End function
	.globl	__device_stub__up_subgroup      # -- Begin function __device_stub__up_subgroup
	.p2align	4
	.type	__device_stub__up_subgroup,@function
__device_stub__up_subgroup:             # @__device_stub__up_subgroup
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 56(%rsp)
	movq	%rsi, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 72(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	64(%rsp), %r9
	movl	$up_subgroup, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$104, %rsp
	.cfi_adjust_cfa_offset -104
	retq
.Lfunc_end3:
	.size	__device_stub__up_subgroup, .Lfunc_end3-__device_stub__up_subgroup
	.cfi_endproc
                                        # -- End function
	.globl	__device_stub__xor_subgroup     # -- Begin function __device_stub__xor_subgroup
	.p2align	4
	.type	__device_stub__xor_subgroup,@function
__device_stub__xor_subgroup:            # @__device_stub__xor_subgroup
	.cfi_startproc
# %bb.0:
	subq	$88, %rsp
	.cfi_def_cfa_offset 96
	movq	%rdi, 56(%rsp)
	movq	%rsi, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 72(%rsp)
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
	leaq	64(%rsp), %r9
	movl	$xor_subgroup, %edi
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$104, %rsp
	.cfi_adjust_cfa_offset -104
	retq
.Lfunc_end4:
	.size	__device_stub__xor_subgroup, .Lfunc_end4-__device_stub__xor_subgroup
	.cfi_endproc
                                        # -- End function
	.globl	main                            # -- Begin function main
	.p2align	4
	.type	main,@function
main:                                   # @main
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 3, __gxx_personality_v0
	.cfi_lsda 3, .Lexception0
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$3144, %rsp                     # imm = 0xC48
	.cfi_def_cfa_offset 3200
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	$2, %r15d
	cmpl	$4, %edi
	jne	.LBB5_119
# %bb.1:
	movq	%rsi, %rbx
	.cfi_escape 0x2e, 0x00
	leaq	1672(%rsp), %rdi
	xorl	%esi, %esi
	callq	hipGetDevicePropertiesR0600
	testl	%eax, %eax
	jne	.LBB5_2
# %bb.3:                                # %_ZL7checked10hipError_t.exit
	movl	$3, %r15d
	cmpl	$64, 1980(%rsp)
	jne	.LBB5_119
# %bb.4:
	.cfi_escape 0x2e, 0x00
	movl	$2560, %edi                     # imm = 0xA00
	callq	_Znwm
	movq	%rax, %r14
	.cfi_escape 0x2e, 0x00
	movl	$2560, %edx                     # imm = 0xA00
	movq	%rax, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	movq	8(%rbx), %rsi
.Ltmp0:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1152(%rsp), %rdi
	movl	$4, %edx
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode
.Ltmp1:                                 # EH_LABEL
# %bb.5:
.Ltmp3:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1152(%rsp), %rdi
	movl	$2560, %edx                     # imm = 0xA00
	movq	%r14, %rsi
	callq	_ZNSi4readEPcl
.Ltmp4:                                 # EH_LABEL
# %bb.6:
	movl	$4, %r15d
	cmpq	$2560, 1160(%rsp)               # imm = 0xA00
	jne	.LBB5_118
# %bb.7:
.Ltmp5:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	1152(%rsp), %rdi
	callq	_ZNSi4peekEv
.Ltmp6:                                 # EH_LABEL
# %bb.8:
	cmpl	$-1, %eax
	jne	.LBB5_118
# %bb.9:
	movq	%r14, 64(%rsp)                  # 8-byte Spill
	movq	16(%rbx), %rsi
.Ltmp8:                                 # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	640(%rsp), %rdi
	movl	$4, %edx
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode
.Ltmp9:                                 # EH_LABEL
# %bb.10:
.Ltmp11:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	104(%rsp), %rdi
	movl	$512, %esi                      # imm = 0x200
	callq	hipMalloc
.Ltmp12:                                # EH_LABEL
# %bb.11:                               # %_ZL9hipMallocIjE10hipError_tPPT_m.exit
	testl	%eax, %eax
	jne	.LBB5_12
# %bb.17:                               # %_ZL7checked10hipError_t.exit104
.Ltmp15:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	96(%rsp), %rdi
	movl	$512, %esi                      # imm = 0x200
	callq	hipMalloc
.Ltmp16:                                # EH_LABEL
# %bb.18:                               # %_ZL9hipMallocIjE10hipError_tPPT_m.exit106
	movq	%rbx, 112(%rsp)                 # 8-byte Spill
	testl	%eax, %eax
	jne	.LBB5_21
# %bb.19:                               # %_ZL7checked10hipError_t.exit109.preheader
	movq	$0, 80(%rsp)                    # 8-byte Folded Spill
	xorl	%eax, %eax
.LBB5_20:                               # %.preheader
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB5_25 Depth 2
	movl	%eax, 76(%rsp)                  # 4-byte Spill
	movl	%eax, %eax
	movq	%rax, 120(%rsp)                 # 8-byte Spill
	xorl	%r13d, %r13d
	.p2align	4
.LBB5_25:                               #   Parent Loop BB5_20 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
.Ltmp19:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edi                      # imm = 0x200
	callq	_Znwm
.Ltmp20:                                # EH_LABEL
# %bb.26:                               # %.lr.ph.i.i.i.i.i.i.i.i.i.preheader
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	%rax, %r12
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%rax, %rdi
	movl	$165, %esi
	callq	memset@PLT
.Ltmp22:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edi                      # imm = 0x200
	callq	_Znwm
.Ltmp23:                                # EH_LABEL
# %bb.27:                               # %.lr.ph.i.i.i.i.i.i.i.i.i111.preheader
                                        #   in Loop: Header=BB5_25 Depth=2
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%rax, 88(%rsp)                  # 8-byte Spill
	movq	%rax, %rdi
	movl	$165, %esi
	callq	memset@PLT
.Ltmp25:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edi                      # imm = 0x200
	callq	_Znwm
.Ltmp26:                                # EH_LABEL
# %bb.28:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%rax, %rbp
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%rax, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
.Ltmp28:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edi                      # imm = 0x200
	callq	_Znwm
.Ltmp29:                                # EH_LABEL
# %bb.29:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%rax, %r14
	movq	64(%rsp), %rax                  # 8-byte Reload
	leaq	(%rax,%r13), %rbx
	movq	%r12, %r15
	subq	$-128, %r15
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%r14, %rdi
	xorl	%esi, %esi
	callq	memset@PLT
	.cfi_escape 0x2e, 0x00
	movl	$256, %edx                      # imm = 0x100
	movq	%r15, %rdi
	movq	%rbx, %rsi
	callq	memcpy@PLT
	movq	104(%rsp), %rdi
.Ltmp31:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%r12, %rsi
	movl	$1, %ecx
	callq	hipMemcpy
.Ltmp32:                                # EH_LABEL
# %bb.30:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_31
# %bb.34:                               # %_ZL7checked10hipError_t.exit122
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	96(%rsp), %rdi
.Ltmp35:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	88(%rsp), %rsi                  # 8-byte Reload
	movl	$1, %ecx
	callq	hipMemcpy
.Ltmp36:                                # EH_LABEL
# %bb.35:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_36
# %bb.38:                               # %_ZL7checked10hipError_t.exit125
                                        #   in Loop: Header=BB5_25 Depth=2
	cmpl	$4, 76(%rsp)                    # 4-byte Folded Reload
	ja	.LBB5_67
# %bb.39:                               # %_ZL7checked10hipError_t.exit125
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	104(%rsp), %r15
	subq	$-128, %r15
	movq	96(%rsp), %rbx
	subq	$-128, %rbx
	movq	120(%rsp), %rax                 # 8-byte Reload
	jmpq	*.LJTI5_0(,%rax,8)
.LBB5_45:                               #   in Loop: Header=BB5_25 Depth=2
.Ltmp65:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movabsq	$4294967297, %rdi               # imm = 0x100000001
	movl	$1, %esi
	movabsq	$4294967360, %rdx               # imm = 0x100000040
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp66:                                # EH_LABEL
# %bb.46:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_67
# %bb.47:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%r15, 56(%rsp)
	movq	%rbx, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 136(%rsp)
.Ltmp67:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp68:                                # EH_LABEL
# %bb.48:                               # %.noexc126
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
.Ltmp69:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$broadcast_subgroup, %edi
	leaq	128(%rsp), %r9
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp70:                                # EH_LABEL
	jmp	.LBB5_67
.LBB5_63:                               #   in Loop: Header=BB5_25 Depth=2
.Ltmp41:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movabsq	$4294967297, %rdi               # imm = 0x100000001
	movl	$1, %esi
	movabsq	$4294967360, %rdx               # imm = 0x100000040
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp42:                                # EH_LABEL
# %bb.64:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_67
# %bb.65:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%r15, 56(%rsp)
	movq	%rbx, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 136(%rsp)
.Ltmp43:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp44:                                # EH_LABEL
# %bb.66:                               # %.noexc158
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
.Ltmp45:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$xor_subgroup, %edi
	leaq	128(%rsp), %r9
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp46:                                # EH_LABEL
	jmp	.LBB5_67
.LBB5_55:                               #   in Loop: Header=BB5_25 Depth=2
.Ltmp53:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movabsq	$4294967297, %rdi               # imm = 0x100000001
	movl	$1, %esi
	movabsq	$4294967360, %rdx               # imm = 0x100000040
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp54:                                # EH_LABEL
# %bb.56:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_67
# %bb.57:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%r15, 56(%rsp)
	movq	%rbx, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 136(%rsp)
.Ltmp55:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp56:                                # EH_LABEL
# %bb.58:                               # %.noexc142
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
.Ltmp57:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$reverse_wave, %edi
	leaq	128(%rsp), %r9
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp58:                                # EH_LABEL
	jmp	.LBB5_67
.LBB5_59:                               #   in Loop: Header=BB5_25 Depth=2
.Ltmp47:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movabsq	$4294967297, %rdi               # imm = 0x100000001
	movl	$1, %esi
	movabsq	$4294967360, %rdx               # imm = 0x100000040
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp48:                                # EH_LABEL
# %bb.60:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_67
# %bb.61:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%r15, 56(%rsp)
	movq	%rbx, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 136(%rsp)
.Ltmp49:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp50:                                # EH_LABEL
# %bb.62:                               # %.noexc150
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
.Ltmp51:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$up_subgroup, %edi
	leaq	128(%rsp), %r9
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp52:                                # EH_LABEL
	jmp	.LBB5_67
.LBB5_51:                               #   in Loop: Header=BB5_25 Depth=2
.Ltmp59:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movabsq	$4294967297, %rdi               # imm = 0x100000001
	movl	$1, %esi
	movabsq	$4294967360, %rdx               # imm = 0x100000040
	movl	$1, %ecx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	callq	__hipPushCallConfiguration
.Ltmp60:                                # EH_LABEL
# %bb.52:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_67
# %bb.53:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%r15, 56(%rsp)
	movq	%rbx, 48(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 136(%rsp)
.Ltmp61:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%rsp, %rcx
	callq	__hipPopCallConfiguration
.Ltmp62:                                # EH_LABEL
# %bb.54:                               # %.noexc134
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	32(%rsp), %rsi
	movl	40(%rsp), %edx
	movq	16(%rsp), %rcx
	movl	24(%rsp), %r8d
.Ltmp63:                                # EH_LABEL
	.cfi_escape 0x2e, 0x10
	movl	$down_subgroup, %edi
	leaq	128(%rsp), %r9
	pushq	(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	16(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	hipLaunchKernel
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
.Ltmp64:                                # EH_LABEL
	.p2align	4
.LBB5_67:                               #   in Loop: Header=BB5_25 Depth=2
.Ltmp71:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipGetLastError
.Ltmp72:                                # EH_LABEL
# %bb.68:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_69
# %bb.71:                               # %_ZL7checked10hipError_t.exit162
                                        #   in Loop: Header=BB5_25 Depth=2
.Ltmp75:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipDeviceSynchronize
.Ltmp76:                                # EH_LABEL
# %bb.72:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_73
# %bb.75:                               # %_ZL7checked10hipError_t.exit165
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	104(%rsp), %rsi
.Ltmp79:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%rbp, %rdi
	movl	$2, %ecx
	callq	hipMemcpy
.Ltmp80:                                # EH_LABEL
# %bb.76:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_77
# %bb.79:                               # %_ZL7checked10hipError_t.exit168
                                        #   in Loop: Header=BB5_25 Depth=2
	movq	96(%rsp), %rsi
.Ltmp83:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%r14, %rdi
	movl	$2, %ecx
	callq	hipMemcpy
.Ltmp84:                                # EH_LABEL
# %bb.80:                               #   in Loop: Header=BB5_25 Depth=2
	testl	%eax, %eax
	jne	.LBB5_81
# %bb.83:                               # %_ZStneIjSaIjEEbRKSt6vectorIT_T0_ES6_.exit
                                        #   in Loop: Header=BB5_25 Depth=2
	.cfi_escape 0x2e, 0x00
	movl	$512, %edx                      # imm = 0x200
	movq	%rbp, %rdi
	movq	%r12, %rsi
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB5_84
# %bb.85:                               #   in Loop: Header=BB5_25 Depth=2
	.cfi_escape 0x2e, 0x00
	movl	$128, %edx
	movq	%r14, %rdi
	movq	88(%rsp), %rbx                  # 8-byte Reload
	movq	%rbx, %rsi
	callq	bcmp@PLT
	testl	%eax, %eax
	jne	.LBB5_84
# %bb.86:                               #   in Loop: Header=BB5_25 Depth=2
	leaq	384(%r14), %rdi
	addq	$384, %rbx                      # imm = 0x180
	.cfi_escape 0x2e, 0x00
	movl	$128, %edx
	movq	%rbx, %rsi
	callq	bcmp@PLT
	testl	%eax, %eax
	je	.LBB5_87
	.p2align	4
.LBB5_84:                               #   in Loop: Header=BB5_25 Depth=2
	xorl	%ebx, %ebx
	movl	$5, %eax
	movq	%rax, 80(%rsp)                  # 8-byte Spill
.LBB5_88:                               # %_ZNSt6vectorIjSaIjEED2Ev.exit182
                                        #   in Loop: Header=BB5_25 Depth=2
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	%r14, %rdi
	callq	_ZdlPvm
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	%rbp, %rdi
	callq	_ZdlPvm
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	88(%rsp), %rdi                  # 8-byte Reload
	callq	_ZdlPvm
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	%r12, %rdi
	callq	_ZdlPvm
	testb	%bl, %bl
	je	.LBB5_89
# %bb.24:                               #   in Loop: Header=BB5_25 Depth=2
	addq	$256, %r13                      # imm = 0x100
	cmpq	$2560, %r13                     # imm = 0xA00
	jne	.LBB5_25
	jmp	.LBB5_95
.LBB5_87:                               #   in Loop: Header=BB5_25 Depth=2
	movq	%r14, %rsi
	subq	$-128, %rsi
	movb	$1, %bl
.Ltmp88:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$256, %edx                      # imm = 0x100
	leaq	640(%rsp), %rdi
	callq	_ZNSo5writeEPKcl
.Ltmp89:                                # EH_LABEL
	jmp	.LBB5_88
.LBB5_95:                               # %_ZL7checked10hipError_t.exit109
                                        #   in Loop: Header=BB5_20 Depth=1
	movl	76(%rsp), %eax                  # 4-byte Reload
	incl	%eax
	cmpl	$5, %eax
	jne	.LBB5_20
# %bb.96:                               # %.thread317
	movq	104(%rsp), %rdi
.Ltmp91:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp92:                                # EH_LABEL
	movq	112(%rsp), %rbx                 # 8-byte Reload
# %bb.97:
	testl	%eax, %eax
	jne	.LBB5_98
# %bb.100:                              # %_ZL7checked10hipError_t.exit193
	movq	96(%rsp), %rdi
.Ltmp95:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	hipFree
.Ltmp96:                                # EH_LABEL
# %bb.101:
	testl	%eax, %eax
	jne	.LBB5_102
# %bb.104:                              # %_ZL7checked10hipError_t.exit196
	leaq	648(%rsp), %rdi
.Ltmp99:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	_ZNSt13basic_filebufIcSt11char_traitsIcEE5closeEv
.Ltmp100:                               # EH_LABEL
# %bb.105:                              # %.noexc198
	testq	%rax, %rax
	jne	.LBB5_107
# %bb.106:
	movq	640(%rsp), %rax
	movq	-24(%rax), %rax
	leaq	(%rsp,%rax), %rdi
	addq	$640, %rdi                      # imm = 0x280
	movl	672(%rsp,%rax), %esi
	orl	$4, %esi
.Ltmp101:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	callq	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate
.Ltmp102:                               # EH_LABEL
.LBB5_107:
	movq	640(%rsp), %rax
	movq	-24(%rax), %rax
	movl	$6, %r15d
	testb	$5, 672(%rsp,%rax)
	movq	64(%rsp), %r14                  # 8-byte Reload
	jne	.LBB5_117
# %bb.108:
	movq	24(%rbx), %rsi
.Ltmp104:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	movl	$16, %edx
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode
.Ltmp105:                               # EH_LABEL
# %bb.109:
.Ltmp107:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	movl	$.L.str, %esi
	movl	$11, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp108:                               # EH_LABEL
# %bb.110:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit
	.cfi_escape 0x2e, 0x00
	leaq	1672(%rsp), %rbx
	movq	%rbx, %rdi
	callq	strlen
.Ltmp109:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%rax, %rdx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp110:                               # EH_LABEL
# %bb.111:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit203
.Ltmp111:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	movl	$.L.str.1, %esi
	movl	$18, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp112:                               # EH_LABEL
# %bb.112:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit205
	leaq	2832(%rsp), %rbx
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	strlen
.Ltmp113:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%rax, %rdx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp114:                               # EH_LABEL
# %bb.113:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit208
.Ltmp115:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	movl	$.L.str.2, %esi
	movl	$9, %edx
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp116:                               # EH_LABEL
# %bb.114:                              # %_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc.exit210
	movl	1980(%rsp), %esi
.Ltmp117:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	callq	_ZNSolsEi
.Ltmp118:                               # EH_LABEL
# %bb.115:
.Ltmp119:                               # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	$.L.str.3, %esi
	movl	$66, %edx
	movq	%rax, %rdi
	callq	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l
.Ltmp120:                               # EH_LABEL
# %bb.116:
	movq	128(%rsp), %rax
	movq	-24(%rax), %rax
	xorl	%r15d, %r15d
	testb	$5, 160(%rsp,%rax)
	setne	%r15b
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
	jmp	.LBB5_117
.LBB5_89:
	movq	64(%rsp), %r14                  # 8-byte Reload
	movq	80(%rsp), %r15                  # 8-byte Reload
.LBB5_117:                              # %.loopexit325
	.cfi_escape 0x2e, 0x00
	leaq	640(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
.LBB5_118:                              # %_ZNSt6vectorIjSaIjEED2Ev.exit214
	.cfi_escape 0x2e, 0x00
	leaq	1152(%rsp), %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	.cfi_escape 0x2e, 0x00
	movl	$2560, %esi                     # imm = 0xA00
	movq	%r14, %rdi
	callq	_ZdlPvm
.LBB5_119:
	movl	%r15d, %eax
	addq	$3144, %rsp                     # imm = 0xC48
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB5_31:
	.cfi_def_cfa_offset 3200
	movq	stderr(%rip), %rbx
.Ltmp33:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp34:                                # EH_LABEL
# %bb.32:                               # %.noexc121
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_33
.LBB5_77:
	movq	stderr(%rip), %rbx
.Ltmp81:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp82:                                # EH_LABEL
# %bb.78:                               # %.noexc167
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_33
.LBB5_69:
	movq	stderr(%rip), %rbx
.Ltmp73:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp74:                                # EH_LABEL
# %bb.70:                               # %.noexc161
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_33
.LBB5_73:
	movq	stderr(%rip), %rbx
.Ltmp77:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp78:                                # EH_LABEL
# %bb.74:                               # %.noexc164
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_33
.LBB5_36:
	movq	stderr(%rip), %rbx
.Ltmp38:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp39:                                # EH_LABEL
# %bb.37:                               # %.noexc124
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_33
.LBB5_81:
	movq	stderr(%rip), %rbx
.Ltmp85:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp86:                                # EH_LABEL
# %bb.82:                               # %.noexc170
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_33
.LBB5_2:
	movq	stderr(%rip), %rbx
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
	.cfi_escape 0x2e, 0x00
.LBB5_33:                               # %.noexc121
	movl	$.L.str.4, %esi
	movq	%rbx, %rdi
.LBB5_15:                               # %.noexc
	movq	%rax, %rdx
	xorl	%eax, %eax
	callq	fprintf
	.cfi_escape 0x2e, 0x00
	movl	$1, %edi
	callq	exit
.LBB5_12:
	movq	stderr(%rip), %r14
.Ltmp13:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp14:                                # EH_LABEL
# %bb.13:                               # %.noexc
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_14
.LBB5_21:
	movq	stderr(%rip), %r14
.Ltmp17:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp18:                                # EH_LABEL
# %bb.22:                               # %.noexc108
	.cfi_escape 0x2e, 0x00
.LBB5_14:                               # %.noexc
	movl	$.L.str.4, %esi
	movq	%r14, %rdi
	jmp	.LBB5_15
.LBB5_98:
	movq	stderr(%rip), %r14
.Ltmp93:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp94:                                # EH_LABEL
# %bb.99:                               # %.noexc192
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_14
.LBB5_102:
	movq	stderr(%rip), %r14
.Ltmp97:                                # EH_LABEL
	.cfi_escape 0x2e, 0x00
	movl	%eax, %edi
	callq	hipGetErrorString
.Ltmp98:                                # EH_LABEL
# %bb.103:                              # %.noexc195
	.cfi_escape 0x2e, 0x00
	jmp	.LBB5_14
.LBB5_120:
.Ltmp106:                               # EH_LABEL
	jmp	.LBB5_123
.LBB5_121:
.Ltmp121:                               # EH_LABEL
	movq	%rax, %rbx
	.cfi_escape 0x2e, 0x00
	leaq	128(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
	jmp	.LBB5_124
.LBB5_23:
.Ltmp10:                                # EH_LABEL
	jmp	.LBB5_126
.LBB5_122:
.Ltmp103:                               # EH_LABEL
	jmp	.LBB5_123
.LBB5_16:
.Ltmp2:                                 # EH_LABEL
	movq	%r14, 64(%rsp)                  # 8-byte Spill
	movq	%rax, %rbx
	jmp	.LBB5_128
.LBB5_125:
.Ltmp7:                                 # EH_LABEL
	movq	%r14, 64(%rsp)                  # 8-byte Spill
.LBB5_126:
	movq	%rax, %rbx
	jmp	.LBB5_127
.LBB5_41:
.Ltmp24:                                # EH_LABEL
	movq	%rax, %rbx
	jmp	.LBB5_94
.LBB5_43:
.Ltmp30:                                # EH_LABEL
	movq	%rax, %rbx
	jmp	.LBB5_92
.LBB5_44:                               # %.loopexit.split-lp
.Ltmp40:                                # EH_LABEL
	jmp	.LBB5_91
.LBB5_40:
.Ltmp21:                                # EH_LABEL
.LBB5_123:
	movq	%rax, %rbx
	jmp	.LBB5_124
.LBB5_42:
.Ltmp27:                                # EH_LABEL
	movq	%rax, %rbx
	jmp	.LBB5_93
.LBB5_50:                               # %.loopexit.split-lp321
.Ltmp87:                                # EH_LABEL
	jmp	.LBB5_91
.LBB5_90:                               # %.loopexit
.Ltmp37:                                # EH_LABEL
	jmp	.LBB5_91
.LBB5_49:                               # %.loopexit320
.Ltmp90:                                # EH_LABEL
.LBB5_91:                               # %_ZNSt6vectorIjSaIjEED2Ev.exit184
	movq	%rax, %rbx
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	%r14, %rdi
	callq	_ZdlPvm
.LBB5_92:                               # %_ZNSt6vectorIjSaIjEED2Ev.exit186
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	%rbp, %rdi
	callq	_ZdlPvm
.LBB5_93:                               # %_ZNSt6vectorIjSaIjEED2Ev.exit188
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	88(%rsp), %rdi                  # 8-byte Reload
	callq	_ZdlPvm
.LBB5_94:                               # %_ZNSt6vectorIjSaIjEED2Ev.exit190
	.cfi_escape 0x2e, 0x00
	movl	$512, %esi                      # imm = 0x200
	movq	%r12, %rdi
	callq	_ZdlPvm
.LBB5_124:
	.cfi_escape 0x2e, 0x00
	leaq	640(%rsp), %rdi
	callq	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
.LBB5_127:
	.cfi_escape 0x2e, 0x00
	leaq	1152(%rsp), %rdi
	callq	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
.LBB5_128:                              # %_ZNSt6vectorIjSaIjEED2Ev.exit216
	.cfi_escape 0x2e, 0x00
	movl	$2560, %esi                     # imm = 0xA00
	movq	64(%rsp), %rdi                  # 8-byte Reload
	callq	_ZdlPvm
	.cfi_escape 0x2e, 0x00
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc
	.section	.rodata,"a",@progbits
	.p2align	3, 0x0
.LJTI5_0:
	.quad	.LBB5_45
	.quad	.LBB5_51
	.quad	.LBB5_55
	.quad	.LBB5_59
	.quad	.LBB5_63
	.section	.gcc_except_table,"a",@progbits
	.p2align	2, 0x0
GCC_except_table5:
.Lexception0:
	.byte	255                             # @LPStart Encoding = omit
	.byte	255                             # @TType Encoding = omit
	.byte	1                               # Call site Encoding = uleb128
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Lfunc_begin0-.Lfunc_begin0    # >> Call Site 1 <<
	.uleb128 .Ltmp0-.Lfunc_begin0           #   Call between .Lfunc_begin0 and .Ltmp0
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp0-.Lfunc_begin0           # >> Call Site 2 <<
	.uleb128 .Ltmp1-.Ltmp0                  #   Call between .Ltmp0 and .Ltmp1
	.uleb128 .Ltmp2-.Lfunc_begin0           #     jumps to .Ltmp2
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp3-.Lfunc_begin0           # >> Call Site 3 <<
	.uleb128 .Ltmp6-.Ltmp3                  #   Call between .Ltmp3 and .Ltmp6
	.uleb128 .Ltmp7-.Lfunc_begin0           #     jumps to .Ltmp7
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp8-.Lfunc_begin0           # >> Call Site 4 <<
	.uleb128 .Ltmp9-.Ltmp8                  #   Call between .Ltmp8 and .Ltmp9
	.uleb128 .Ltmp10-.Lfunc_begin0          #     jumps to .Ltmp10
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp11-.Lfunc_begin0          # >> Call Site 5 <<
	.uleb128 .Ltmp16-.Ltmp11                #   Call between .Ltmp11 and .Ltmp16
	.uleb128 .Ltmp103-.Lfunc_begin0         #     jumps to .Ltmp103
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp19-.Lfunc_begin0          # >> Call Site 6 <<
	.uleb128 .Ltmp20-.Ltmp19                #   Call between .Ltmp19 and .Ltmp20
	.uleb128 .Ltmp21-.Lfunc_begin0          #     jumps to .Ltmp21
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp20-.Lfunc_begin0          # >> Call Site 7 <<
	.uleb128 .Ltmp22-.Ltmp20                #   Call between .Ltmp20 and .Ltmp22
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp22-.Lfunc_begin0          # >> Call Site 8 <<
	.uleb128 .Ltmp23-.Ltmp22                #   Call between .Ltmp22 and .Ltmp23
	.uleb128 .Ltmp24-.Lfunc_begin0          #     jumps to .Ltmp24
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp23-.Lfunc_begin0          # >> Call Site 9 <<
	.uleb128 .Ltmp25-.Ltmp23                #   Call between .Ltmp23 and .Ltmp25
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp25-.Lfunc_begin0          # >> Call Site 10 <<
	.uleb128 .Ltmp26-.Ltmp25                #   Call between .Ltmp25 and .Ltmp26
	.uleb128 .Ltmp27-.Lfunc_begin0          #     jumps to .Ltmp27
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp26-.Lfunc_begin0          # >> Call Site 11 <<
	.uleb128 .Ltmp28-.Ltmp26                #   Call between .Ltmp26 and .Ltmp28
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp28-.Lfunc_begin0          # >> Call Site 12 <<
	.uleb128 .Ltmp29-.Ltmp28                #   Call between .Ltmp28 and .Ltmp29
	.uleb128 .Ltmp30-.Lfunc_begin0          #     jumps to .Ltmp30
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp29-.Lfunc_begin0          # >> Call Site 13 <<
	.uleb128 .Ltmp31-.Ltmp29                #   Call between .Ltmp29 and .Ltmp31
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp31-.Lfunc_begin0          # >> Call Site 14 <<
	.uleb128 .Ltmp36-.Ltmp31                #   Call between .Ltmp31 and .Ltmp36
	.uleb128 .Ltmp37-.Lfunc_begin0          #     jumps to .Ltmp37
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp65-.Lfunc_begin0          # >> Call Site 15 <<
	.uleb128 .Ltmp89-.Ltmp65                #   Call between .Ltmp65 and .Ltmp89
	.uleb128 .Ltmp90-.Lfunc_begin0          #     jumps to .Ltmp90
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp91-.Lfunc_begin0          # >> Call Site 16 <<
	.uleb128 .Ltmp102-.Ltmp91               #   Call between .Ltmp91 and .Ltmp102
	.uleb128 .Ltmp103-.Lfunc_begin0         #     jumps to .Ltmp103
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp104-.Lfunc_begin0         # >> Call Site 17 <<
	.uleb128 .Ltmp105-.Ltmp104              #   Call between .Ltmp104 and .Ltmp105
	.uleb128 .Ltmp106-.Lfunc_begin0         #     jumps to .Ltmp106
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp107-.Lfunc_begin0         # >> Call Site 18 <<
	.uleb128 .Ltmp120-.Ltmp107              #   Call between .Ltmp107 and .Ltmp120
	.uleb128 .Ltmp121-.Lfunc_begin0         #     jumps to .Ltmp121
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp33-.Lfunc_begin0          # >> Call Site 19 <<
	.uleb128 .Ltmp34-.Ltmp33                #   Call between .Ltmp33 and .Ltmp34
	.uleb128 .Ltmp40-.Lfunc_begin0          #     jumps to .Ltmp40
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp81-.Lfunc_begin0          # >> Call Site 20 <<
	.uleb128 .Ltmp78-.Ltmp81                #   Call between .Ltmp81 and .Ltmp78
	.uleb128 .Ltmp87-.Lfunc_begin0          #     jumps to .Ltmp87
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp38-.Lfunc_begin0          # >> Call Site 21 <<
	.uleb128 .Ltmp39-.Ltmp38                #   Call between .Ltmp38 and .Ltmp39
	.uleb128 .Ltmp40-.Lfunc_begin0          #     jumps to .Ltmp40
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp85-.Lfunc_begin0          # >> Call Site 22 <<
	.uleb128 .Ltmp86-.Ltmp85                #   Call between .Ltmp85 and .Ltmp86
	.uleb128 .Ltmp87-.Lfunc_begin0          #     jumps to .Ltmp87
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp86-.Lfunc_begin0          # >> Call Site 23 <<
	.uleb128 .Ltmp13-.Ltmp86                #   Call between .Ltmp86 and .Ltmp13
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp13-.Lfunc_begin0          # >> Call Site 24 <<
	.uleb128 .Ltmp98-.Ltmp13                #   Call between .Ltmp13 and .Ltmp98
	.uleb128 .Ltmp103-.Lfunc_begin0         #     jumps to .Ltmp103
	.byte	0                               #   On action: cleanup
	.uleb128 .Ltmp98-.Lfunc_begin0          # >> Call Site 25 <<
	.uleb128 .Lfunc_end5-.Ltmp98            #   Call between .Ltmp98 and .Lfunc_end5
	.byte	0                               #     has no landing pad
	.byte	0                               #   On action: cleanup
.Lcst_end0:
	.p2align	2, 0x0
                                        # -- End function
	.text
	.p2align	4                               # -- Begin function __hip_module_ctor
	.type	__hip_module_ctor,@function
__hip_module_ctor:                      # @__hip_module_ctor
	.cfi_startproc
# %bb.0:
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$32, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -16
	movq	__hip_gpubin_handle_946190e4b89bbc7f(%rip), %rbx
	testq	%rbx, %rbx
	jne	.LBB6_2
# %bb.1:
	movl	$__hip_fatbin_wrapper, %edi
	callq	__hipRegisterFatBinary
	movq	%rax, %rbx
	movq	%rax, __hip_gpubin_handle_946190e4b89bbc7f(%rip)
.LBB6_2:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$broadcast_subgroup, %esi
	movl	$.L__unnamed_1, %edx
	movl	$.L__unnamed_1, %ecx
	movq	%rbx, %rdi
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$down_subgroup, %esi
	movl	$.L__unnamed_2, %edx
	movl	$.L__unnamed_2, %ecx
	movq	%rbx, %rdi
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$reverse_wave, %esi
	movl	$.L__unnamed_3, %edx
	movl	$.L__unnamed_3, %ecx
	movq	%rbx, %rdi
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$up_subgroup, %esi
	movl	$.L__unnamed_4, %edx
	movl	$.L__unnamed_4, %ecx
	movq	%rbx, %rdi
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rsp)
	movups	%xmm0, (%rsp)
	movl	$xor_subgroup, %esi
	movl	$.L__unnamed_5, %edx
	movl	$.L__unnamed_5, %ecx
	movq	%rbx, %rdi
	movl	$-1, %r8d
	xorl	%r9d, %r9d
	callq	__hipRegisterFunction
	movl	$__hip_module_dtor, %edi
	addq	$32, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmp	atexit                          # TAILCALL
.Lfunc_end6:
	.size	__hip_module_ctor, .Lfunc_end6-__hip_module_ctor
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function __hip_module_dtor
	.type	__hip_module_dtor,@function
__hip_module_dtor:                      # @__hip_module_dtor
	.cfi_startproc
# %bb.0:
	movq	__hip_gpubin_handle_946190e4b89bbc7f(%rip), %rdi
	testq	%rdi, %rdi
	je	.LBB7_2
# %bb.1:
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	__hipUnregisterFatBinary
	movq	$0, __hip_gpubin_handle_946190e4b89bbc7f(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
.LBB7_2:
	retq
.Lfunc_end7:
	.size	__hip_module_dtor, .Lfunc_end7-__hip_module_dtor
	.cfi_endproc
                                        # -- End function
	.type	broadcast_subgroup,@object      # @broadcast_subgroup
	.section	.rodata,"a",@progbits
	.globl	broadcast_subgroup
	.p2align	3, 0x0
broadcast_subgroup:
	.quad	__device_stub__broadcast_subgroup
	.size	broadcast_subgroup, 8

	.type	down_subgroup,@object           # @down_subgroup
	.globl	down_subgroup
	.p2align	3, 0x0
down_subgroup:
	.quad	__device_stub__down_subgroup
	.size	down_subgroup, 8

	.type	reverse_wave,@object            # @reverse_wave
	.globl	reverse_wave
	.p2align	3, 0x0
reverse_wave:
	.quad	__device_stub__reverse_wave
	.size	reverse_wave, 8

	.type	up_subgroup,@object             # @up_subgroup
	.globl	up_subgroup
	.p2align	3, 0x0
up_subgroup:
	.quad	__device_stub__up_subgroup
	.size	up_subgroup, 8

	.type	xor_subgroup,@object            # @xor_subgroup
	.globl	xor_subgroup
	.p2align	3, 0x0
xor_subgroup:
	.quad	__device_stub__xor_subgroup
	.size	xor_subgroup, 8

	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"{\"device\":\""
	.size	.L.str, 12

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"\",\"architecture\":\""
	.size	.L.str.1, 19

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"\",\"warp\":"
	.size	.L.str.2, 10

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	",\"inputs_unchanged\":true,\"guard_zones_unchanged\":true,\"trials\":50}"
	.size	.L.str.3, 67

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"%s\n"
	.size	.L.str.4, 4

	.type	.L__unnamed_1,@object           # @0
.L__unnamed_1:
	.asciz	"broadcast_subgroup"
	.size	.L__unnamed_1, 19

	.type	.L__unnamed_2,@object           # @1
.L__unnamed_2:
	.asciz	"down_subgroup"
	.size	.L__unnamed_2, 14

	.type	.L__unnamed_3,@object           # @2
.L__unnamed_3:
	.asciz	"reverse_wave"
	.size	.L__unnamed_3, 13

	.type	.L__unnamed_4,@object           # @3
.L__unnamed_4:
	.asciz	"up_subgroup"
	.size	.L__unnamed_4, 12

	.type	.L__unnamed_5,@object           # @4
.L__unnamed_5:
	.asciz	"xor_subgroup"
	.size	.L__unnamed_5, 13

	.type	.L__unnamed_6,@object           # @5
	.section	.hip_fatbin,"a",@progbits
	.p2align	12, 0x0
.L__unnamed_6:
	.asciz	"__CLANG_OFFLOAD_BUNDLE__\002\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\000\000\000\000\000\000\000\036\000\000\000\000\000\000\000host-x86_64-unknown-linux-gnu-\000\020\000\000\000\000\000\000\330,\000\000\000\000\000\000\037\000\000\000\000\000\000\000hipv4-amdgcn-amd-amdhsa--gfx950\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\177ELF\002\001\001@\004\000\000\000\000\000\000\000\003\000\340\000\001\000\000\000\000\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\230(\000\000\000\000\000\000O\005\000\000@\0008\000\t\000@\000\021\000\017\000\006\000\000\000\004\000\000\000@\000\000\000\000\000\000\000@\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\370\001\000\000\000\000\000\000\370\001\000\000\000\000\000\000\b\000\000\000\000\000\000\000\001\000\000\000\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\020\000\000\000\000\000\000@\020\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\005\000\000\000\000\021\000\000\000\000\000\000\000!\000\000\000\000\000\000\000!\000\000\000\000\000\000\200\b\000\000\000\000\000\000\200\b\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\006\000\000\000\200\031\000\000\000\000\000\000\2009\000\000\000\000\000\000\2009\000\000\000\000\000\000p\000\000\000\000\000\000\000\200\006\000\000\000\000\000\000\000\020\000\000\000\000\000\000\001\000\000\000\006\000\000\000\360\031\000\000\000\000\000\000\360I\000\000\000\000\000\000\360I\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\002\000\000\000\006\000\000\000\200\031\000\000\000\000\000\000\2009\000\000\000\000\000\000\2009\000\000\000\000\000\000p\000\000\000\000\000\000\000p\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000R\345td\004\000\000\000\200\031\000\000\000\000\000\000\2009\000\000\000\000\000\000\2009\000\000\000\000\000\000p\000\000\000\000\000\000\000\200\006\000\000\000\000\000\000\001\000\000\000\000\000\000\000Q\345td\006\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\004\000\000\000\004\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\000\030\n\000\000\000\000\000\000\030\n\000\000\000\000\000\000\004\000\000\000\000\000\000\000\007\000\000\000\002\n\000\000 \000\000\000AMDGPU\000\000\203\256amdhsa.kernels\225\336\000\022\253.agpr_count\000\245.args\222\204\256.address_space\246global\247.offset\000\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\b\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size\020\251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\262broadcast_subgroup\273.private_segment_fixed_size\000\253.sgpr_count\n\261.sgpr_spill_count\000\247.symbol\265broadcast_subgroup.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\003\261.vgpr_spill_count\000\257.wavefront_size@\336\000\022\253.agpr_count\000\245.args\222\204\256.address_space\246global\247.offset\000\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\b\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size\020\251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\255down_subgroup\273.private_segment_fixed_size\000\253.sgpr_count\n\261.sgpr_spill_count\000\247.symbol\260down_subgroup.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\004\261.vgpr_spill_count\000\257.wavefront_size@\336\000\022\253.agpr_count\000\245.args\222\204\256.address_space\246global\247.offset\000\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\b\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size\020\251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\254reverse_wave\273.private_segment_fixed_size\000\253.sgpr_count\n\261.sgpr_spill_count\000\247.symbol\257reverse_wave.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\004\261.vgpr_spill_count\000\257.wavefront_size@\336\000\022\253.agpr_count\000\245.args\222\204\256.address_space\246global\247.offset\000\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\b\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size\020\251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\253up_subgroup\273.private_segment_fixed_size\000\253.sgpr_count\n\261.sgpr_spill_count\000\247.symbol\256up_subgroup.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\005\261.vgpr_spill_count\000\257.wavefront_size@\336\000\022\253.agpr_count\000\245.args\222\204\256.address_space\246global\247.offset\000\245.size\b\253.value_kind\255global_buffer\204\256.address_space\246global\247.offset\b\245.size\b\253.value_kind\255global_buffer\271.group_segment_fixed_size\000\266.kernarg_segment_align\b\265.kernarg_segment_size\020\251.language\250OpenCL C\261.language_version\222\002\000\270.max_flat_workgroup_size\315\004\000\245.name\254xor_subgroup\273.private_segment_fixed_size\000\253.sgpr_count\n\261.sgpr_spill_count\000\247.symbol\257xor_subgroup.kd\270.uniform_work_group_size\001\263.uses_dynamic_stack\302\253.vgpr_count\005\261.vgpr_spill_count\000\257.wavefront_size@\255amdhsa.target\271amdgcn-amd-amdhsa--gfx950\256amdhsa.version\222\001\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\022\003\007\000\000!\000\000\000\000\000\000P\000\000\000\000\000\000\0008\000\000\000\021\003\006\000@\017\000\000\000\000\000\000@\000\000\000\000\000\000\000V\000\000\000\021\003\006\000\200\017\000\000\000\000\000\000@\000\000\000\000\000\000\000f\000\000\000\022\003\007\000\000$\000\000\000\000\000\000`\000\000\000\000\000\000\000\201\000\000\000\022\003\007\000\000%\000\000\000\000\000\000d\000\000\000\000\000\000\000\236\000\000\000\021\000\n\000\360I\000\000\000\000\000\000\001\000\000\000\000\000\000\000\024\000\000\000\021\003\006\000\000\017\000\000\000\000\000\000@\000\000\000\000\000\000\000*\000\000\000\022\003\007\000\000\"\000\000\000\000\000\000X\000\000\000\000\000\000\000I\000\000\000\022\003\007\000\000#\000\000\000\000\000\000\\\000\000\000\000\000\000\000r\000\000\000\021\003\006\000\300\017\000\000\000\000\000\000@\000\000\000\000\000\000\000\216\000\000\000\021\003\006\000\000\020\000\000\000\000\000\000@\000\000\000\000\000\000\000\002\000\000\000\001\000\000\000\004\000\000\000\032\000\000\000@\000\t\000\001\000@\000\020\000\002\000\000\000\000\000\200\200\031\000\000\000\000\000\000@\000\001\000\213\020 \001\000\000\000\007\000\000\000\316\365\377\247\020,\000\331\220\247\321\035 F\250\031\364\352\335`\2253\375<\352\234i\242\022O\203\330\222z\332P\374\343\034\277QH\224\020\f\000\000\000\f\000\000\000\013\000\000\000\000\000\000\000\006\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\000\000\000\t\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\003\000\000\000\004\000\000\000\000\000\000\000\002\000\000\000\001\000\000\000\000\000\000\000\007\000\000\000\b\000\000\000\000broadcast_subgroup\000broadcast_subgroup.kd\000down_subgroup\000down_subgroup.kd\000reverse_wave\000reverse_wave.kd\000up_subgroup\000up_subgroup.kd\000xor_subgroup\000xor_subgroup.kd\000__hip_cuid_946190e4b89bbc7f\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\000\022\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\300\022\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\200\023\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000@\024\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000@\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000\000\025\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000@\000\257\000\204\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\300\000\000\000\000\202\000\000$\002\000\214\322\301\000\001\000\002\000\215\322\301\004\002\000\202\004\004$\177\300\214\277\000\200P\334\000\000\000\001\377\004\004&\340\001\000\000p\017\214\277\004\000~\330\002\001\000\001\177\300\214\277\000\200p\334\000\001\002\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\n\300\000\000\000\000\202\000\000$\002\000\214\322\301\000\001\000\002\000\215\322\301\004\002\000\207\004\006&\177\300\214\277\000\200P\334\000\000\000\001\207\006\232}\001\000\200\277\200\004\0048\202\004\004$p\017\214\277\000\000~\330\002\001\000\001\177\300\214\277\000\200p\334\000\001\002\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\n\300\000\000\000\000\202\000\002$\003\000\214\322\301\000\001\000\003\000\215\322\301\006\002\000\277\000\000&\177\300\214\277\000\200P\334\001\000\000\002\000\000\001\322\003\201\001\004\202\000\000$\377\000\000*\374\000\000\000p\017\214\277\000\000~\330\000\002\000\000\177\300\214\277\000\200p\334\001\000\002\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\n\300\000\000\000\000\202\000\000$\002\000\214\322\301\000\001\000\002\000\215\322\301\004\002\000\301\004\006h\177\300\214\277\000\200P\334\000\000\000\001\377\004\b&x\000\000\000\003\t\202}\001\000\200\277\003\005\004\000\202\004\004$p\017\214\277\000\000~\330\002\001\000\001\177\300\214\277\000\200p\334\000\001\002\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\n\300\000\000\000\000\202\000\000$\002\000\214\322\301\000\001\000\002\000\215\322\301\004\002\000\377\004\b&x\000\000\000\177\300\214\277\000\200P\334\000\000\000\001\201\004\006*\210\b\bh\003\t\202}\001\000\200\277\002\007\004\000\202\004\004$p\017\214\277\000\000~\330\002\001\000\001\177\300\214\277\000\200p\334\000\001\002\000\000\000\201\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\000\000\200\277\006\000\000\000\000\000\000\000P\f\000\000\000\000\000\000\013\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000<\016\000\000\000\000\000\000\n\000\000\000\000\000\000\000\272\000\000\000\000\000\000\000\365\376\377o\000\000\000\000p\r\000\000\000\000\000\000\004\000\000\000\000\000\000\000\324\r\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.1 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)\000\000Linker: AMD LLD 22.0.0 (/longer_pathname_so_that_rpms_can_support_packaging_the_debug_info_for_all_os_profiles/src/llvm-project/llvm f58b06dce1f9c15707c5f808fd002e18c2accf7e)\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\361\377\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\035\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\0009\000\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000Z\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\177\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\243\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\277\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\344\000\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\013\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000,\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000Q\001\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000h\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\177\001\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\233\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\273\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\332\001\000\000\000\000\361\377\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\361\001\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\021\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\0003\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000O\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000o\002\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\205\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\233\002\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\266\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\325\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\363\002\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\t\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000(\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000I\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000d\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\203\003\000\000\000\000\361\377\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\230\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\255\003\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\307\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\345\003\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\004\000\000\000\000\361\377\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\027\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\0005\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000U\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000o\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\215\004\000\000\000\000\361\377\005\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\243\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\271\004\000\000\000\000\361\377\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\324\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\363\004\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\021\005\000\000\000\000\361\377\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000F\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000g\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\202\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\241\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\265\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\311\005\000\000\000\000\361\377\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\226\006\000\000\000\002\b\000\2009\000\000\000\000\000\000\000\000\000\000\000\000\000\000\335\005\000\000\022\003\007\000\000!\000\000\000\000\000\000P\000\000\000\000\000\000\000\360\005\000\000\021\003\006\000\000\017\000\000\000\000\000\000@\000\000\000\000\000\000\000\006\006\000\000\022\003\007\000\000\"\000\000\000\000\000\000X\000\000\000\000\000\000\000\024\006\000\000\021\003\006\000@\017\000\000\000\000\000\000@\000\000\000\000\000\000\000%\006\000\000\022\003\007\000\000#\000\000\000\000\000\000\\\000\000\000\000\000\000\0002\006\000\000\021\003\006\000\200\017\000\000\000\000\000\000@\000\000\000\000\000\000\000B\006\000\000\022\003\007\000\000$\000\000\000\000\000\000`\000\000\000\000\000\000\000N\006\000\000\021\003\006\000\300\017\000\000\000\000\000\000@\000\000\000\000\000\000\000]\006\000\000\022\003\007\000\000%\000\000\000\000\000\000d\000\000\000\000\000\000\000j\006\000\000\021\003\006\000\000\020\000\000\000\000\000\000@\000\000\000\000\000\000\000z\006\000\000\021\000\n\000\360I\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000.note\000.dynsym\000.gnu.hash\000.hash\000.dynstr\000.rodata\000.text\000.dynamic\000.relro_padding\000.bss\000.AMDGPU.csdata\000.AMDGPU.gpr_maximums\000.comment\000.symtab\000.shstrtab\000.strtab\000\000broadcast_subgroup.num_vgpr\000broadcast_subgroup.num_agpr\000broadcast_subgroup.numbered_sgpr\000broadcast_subgroup.num_named_barrier\000broadcast_subgroup.private_seg_size\000broadcast_subgroup.uses_vcc\000broadcast_subgroup.uses_flat_scratch\000broadcast_subgroup.has_dyn_sized_stack\000broadcast_subgroup.has_recursion\000broadcast_subgroup.has_indirect_call\000down_subgroup.num_vgpr\000down_subgroup.num_agpr\000down_subgroup.numbered_sgpr\000down_subgroup.num_named_barrier\000down_subgroup.private_seg_size\000down_subgroup.uses_vcc\000down_subgroup.uses_flat_scratch\000down_subgroup.has_dyn_sized_stack\000down_subgroup.has_recursion\000down_subgroup.has_indirect_call\000reverse_wave.num_vgpr\000reverse_wave.num_agpr\000reverse_wave.numbered_sgpr\000reverse_wave.num_named_barrier\000reverse_wave.private_seg_size\000reverse_wave.uses_vcc\000reverse_wave.uses_flat_scratch\000reverse_wave.has_dyn_sized_stack\000reverse_wave.has_recursion\000reverse_wave.has_indirect_call\000up_subgroup.num_vgpr\000up_subgroup.num_agpr\000up_subgroup.numbered_sgpr\000up_subgroup.num_named_barrier\000up_subgroup.private_seg_size\000up_subgroup.uses_vcc\000up_subgroup.uses_flat_scratch\000up_subgroup.has_dyn_sized_stack\000up_subgroup.has_recursion\000up_subgroup.has_indirect_call\000xor_subgroup.num_vgpr\000xor_subgroup.num_agpr\000xor_subgroup.numbered_sgpr\000xor_subgroup.num_named_barrier\000xor_subgroup.private_seg_size\000xor_subgroup.uses_vcc\000xor_subgroup.uses_flat_scratch\000xor_subgroup.has_dyn_sized_stack\000xor_subgroup.has_recursion\000xor_subgroup.has_indirect_call\000amdgpu.max_num_vgpr\000amdgpu.max_num_agpr\000amdgpu.max_num_sgpr\000broadcast_subgroup\000broadcast_subgroup.kd\000down_subgroup\000down_subgroup.kd\000reverse_wave\000reverse_wave.kd\000up_subgroup\000up_subgroup.kd\000xor_subgroup\000xor_subgroup.kd\000__hip_cuid_946190e4b89bbc7f\000_DYNAMIC\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\007\000\000\000\002\000\000\000\000\000\000\0008\002\000\000\000\000\000\0008\002\000\000\000\000\000\000\030\n\000\000\000\000\000\000\000\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\007\000\000\000\013\000\000\000\002\000\000\000\000\000\000\000P\f\000\000\000\000\000\000P\f\000\000\000\000\000\000 \001\000\000\000\000\000\000\005\000\000\000\001\000\000\000\b\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\017\000\000\000\366\377\377o\002\000\000\000\000\000\000\000p\r\000\000\000\000\000\000p\r\000\000\000\000\000\000d\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\031\000\000\000\005\000\000\000\002\000\000\000\000\000\000\000\324\r\000\000\000\000\000\000\324\r\000\000\000\000\000\000h\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\004\000\000\000\000\000\000\000\037\000\000\000\003\000\000\000\002\000\000\000\000\000\000\000<\016\000\000\000\000\000\000<\016\000\000\000\000\000\000\272\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000'\000\000\000\001\000\000\000\002\000\000\000\000\000\000\000\000\017\000\000\000\000\000\000\000\017\000\000\000\000\000\000@\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000@\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000/\000\000\000\001\000\000\000\006\000\000\000\000\000\000\000\000!\000\000\000\000\000\000\000\021\000\000\000\000\000\000\200\b\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\0005\000\000\000\006\000\000\000\003\000\000\000\000\000\000\000\2009\000\000\000\000\000\000\200\031\000\000\000\000\000\000p\000\000\000\000\000\000\000\005\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\020\000\000\000\000\000\000\000>\000\000\000\b\000\000\000\003\000\000\000\000\000\000\000\3609\000\000\000\000\000\000\360\031\000\000\000\000\000\000\020\006\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000M\000\000\000\b\000\000\000\003\000\000\000\000\000\000\000\360I\000\000\000\000\000\000\360\031\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000R\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\360\031\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000a\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\360\031\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000v\000\000\000\001\000\000\0000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\360\031\000\000\000\000\000\0009\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\177\000\000\000\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\0000\033\000\000\000\000\000\0000\006\000\000\000\000\000\000\020\000\000\0007\000\000\000\b\000\000\000\000\000\000\000\030\000\000\000\000\000\000\000\207\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000`!\000\000\000\000\000\000\231\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\221\000\000\000\003\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\371!\000\000\000\000\000\000\237\006\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	.L__unnamed_6, 15576

	.type	__hip_fatbin_wrapper,@object    # @__hip_fatbin_wrapper
	.section	.hipFatBinSegment,"a",@progbits
	.p2align	3, 0x0
__hip_fatbin_wrapper:
	.long	1212764230                      # 0x48495046
	.long	1                               # 0x1
	.quad	.L__unnamed_6
	.quad	0
	.size	__hip_fatbin_wrapper, 24

	.type	__hip_gpubin_handle_946190e4b89bbc7f,@object # @__hip_gpubin_handle_946190e4b89bbc7f
	.local	__hip_gpubin_handle_946190e4b89bbc7f
	.comm	__hip_gpubin_handle_946190e4b89bbc7f,8,8
	.section	.init_array,"aw",@init_array
	.p2align	3, 0x0
	.quad	__hip_module_ctor
	.type	__hip_cuid_946190e4b89bbc7f,@object # @__hip_cuid_946190e4b89bbc7f
	.bss
	.globl	__hip_cuid_946190e4b89bbc7f
__hip_cuid_946190e4b89bbc7f:
	.byte	0                               # 0x0
	.size	__hip_cuid_946190e4b89bbc7f, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.1 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __device_stub__broadcast_subgroup
	.addrsig_sym __device_stub__down_subgroup
	.addrsig_sym __device_stub__reverse_wave
	.addrsig_sym __device_stub__up_subgroup
	.addrsig_sym __device_stub__xor_subgroup
	.addrsig_sym __gxx_personality_v0
	.addrsig_sym __hip_module_ctor
	.addrsig_sym __hip_module_dtor
	.addrsig_sym _Unwind_Resume
	.addrsig_sym broadcast_subgroup
	.addrsig_sym down_subgroup
	.addrsig_sym reverse_wave
	.addrsig_sym up_subgroup
	.addrsig_sym xor_subgroup
	.addrsig_sym .L__unnamed_6
	.addrsig_sym __hip_fatbin_wrapper
	.addrsig_sym __hip_cuid_946190e4b89bbc7f
