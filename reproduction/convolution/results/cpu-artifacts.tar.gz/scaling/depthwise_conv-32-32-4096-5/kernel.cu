extern "C" __global__ void induction_depthwise_conv_hip_32_32_4096_5(const __half* x, const __half* w, __half* out) {
  int t = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 25) {
    acc = acc + __half2float(x[(((t / 16744464) * 4096 + (t / 4092) % 4092 + (j / 5) % 5) * 4096 + t % 4092 + j % 5)]) * __half2float(w[(t / 16744464) * 25 + j]);
    j++;
  }
  out[t] = __float2half(acc);
}
