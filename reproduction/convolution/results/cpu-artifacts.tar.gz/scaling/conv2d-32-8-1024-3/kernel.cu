extern "C" __global__ void induction_conv2d_hip_32_8_1024_3(const __half* x, const __half* w, __half* out) {
  int t = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 288) {
    acc = acc + __half2float(x[(((j / 9) * 1024 + (t / 1022) % 1022 + (j / 3) % 3) * 1024 + t % 1022 + j % 3)]) * __half2float(w[(t / 1044484) * 288 + j]);
    j++;
  }
  out[t] = __float2half(acc);
}
