extern "C" __global__ void induction_conv2d_hip_2_1_2_1(const __half* x, const __half* w, __half* out) {
  int t = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 2) {
    acc = acc + __half2float(x[(((j / 1) * 2 + (t / 2) % 2 + (j / 1) % 1) * 2 + t % 2 + j % 1)]) * __half2float(w[(t / 4) * 2 + j]);
    j++;
  }
  out[t] = __float2half(acc);
}
