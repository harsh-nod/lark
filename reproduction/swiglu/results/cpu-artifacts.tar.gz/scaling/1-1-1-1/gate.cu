extern "C" __global__ void swiglu_gate_hip_1_1_1_1(const __half* x, const __half* wgate, float* gate) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1) {
    acc = acc + __half2float(x[(i / 1) * 1 + j]) * __half2float(wgate[j * 1 + i % 1]);
    j++;
  }
  gate[i] = acc;
}
