	.amdgcn_target "amdgcn-amd-amdhsa--gfx950"
	.amdhsa_code_object_version 6
	.text
	.protected	_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj ; -- Begin function _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj
	.globl	_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj
	.p2align	8
	.type	_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj,@function
_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj: ; @_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj
; %bb.0:
	s_load_dwordx4 s[4:7], s[0:1], 0x0
	s_load_dwordx2 s[8:9], s[0:1], 0x10
	v_lshl_add_u32 v0, s2, 7, v0
	v_ashrrev_i32_e32 v1, 31, v0
	s_ashr_i32 s3, s2, 31
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s6
	v_mov_b32_e32 v3, s7
	v_lshl_add_u64 v[2:3], v[0:1], 2, v[2:3]
	global_load_dword v2, v[2:3], off
	s_lshl_b64 s[0:1], s[2:3], 4
	s_add_u32 s0, s4, s0
	s_addc_u32 s1, s5, s1
	s_load_dwordx4 s[4:7], s[0:1], 0x0
	s_waitcnt lgkmcnt(0)
	s_cmp_eq_u32 s4, 0
	s_cselect_b64 s[0:1], -1, 0
	v_cndmask_b32_e64 v4, 0, 1, s[0:1]
	s_cmp_lg_u32 s7, 0
	v_cmp_ne_u32_e64 s[0:1], 1, v4
	s_waitcnt vmcnt(0)
	v_mov_b32_e32 v3, v2
	s_cbranch_scc0 .LBB0_7
; %bb.1:
	s_and_b64 vcc, exec, s[0:1]
	v_mov_b32_e32 v4, v3
	s_cbranch_vccz .LBB0_15
; %bb.2:
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc0 .LBB0_16
.LBB0_3:
	s_cmp_lg_u32 s4, 2
	s_cbranch_scc0 .LBB0_17
.LBB0_4:
	s_cmp_lg_u32 s4, 3
	s_cbranch_scc1 .LBB0_6
.LBB0_5:
	s_waitcnt lgkmcnt(0)
	v_mbcnt_lo_u32_b32 v4, -1, 0
	v_mbcnt_hi_u32_b32 v4, -1, v4
	v_add_u32_e32 v6, s5, v4
	s_sub_i32 s2, 0, s5
	v_xor_b32_e32 v5, s6, v4
	v_and_b32_e32 v6, s2, v6
	v_cmp_lt_i32_e32 vcc, v5, v6
	s_nop 1
	v_cndmask_b32_e32 v4, v4, v5, vcc
	v_lshlrev_b32_e32 v4, 2, v4
	ds_bpermute_b32 v4, v4, v2
.LBB0_6:                                ; %Flow
	s_branch .LBB0_14
.LBB0_7:
                                        ; implicit-def: $vgpr4
	s_cbranch_execz .LBB0_14
; %bb.8:
	s_and_b64 vcc, exec, s[0:1]
	s_waitcnt lgkmcnt(0)
	v_mbcnt_lo_u32_b32 v4, -1, 0
	s_cbranch_vccz .LBB0_18
; %bb.9:
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc0 .LBB0_19
.LBB0_10:
	s_cmp_lg_u32 s4, 2
	s_cbranch_scc0 .LBB0_20
.LBB0_11:
	s_cmp_lg_u32 s4, 3
	s_cbranch_scc1 .LBB0_13
.LBB0_12:
	s_waitcnt lgkmcnt(0)
	v_mbcnt_hi_u32_b32 v3, -1, v4
	v_add_u32_e32 v5, s5, v3
	s_sub_i32 s0, 0, s5
	v_xor_b32_e32 v4, s6, v3
	v_and_b32_e32 v5, s0, v5
	v_cmp_lt_i32_e32 vcc, v4, v5
	s_nop 1
	v_cndmask_b32_e32 v3, v3, v4, vcc
	v_lshlrev_b32_e32 v3, 2, v3
	ds_bpermute_b32 v3, v3, v2
.LBB0_13:                               ; %Flow61
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v4, v3
.LBB0_14:
	v_mov_b32_e32 v2, s8
	v_mov_b32_e32 v3, s9
	v_lshl_add_u64 v[0:1], v[0:1], 2, v[2:3]
	s_waitcnt lgkmcnt(0)
	global_store_dword v[0:1], v4, off
	s_endpgm
.LBB0_15:
	v_mbcnt_lo_u32_b32 v4, -1, 0
	v_mbcnt_hi_u32_b32 v4, -1, v4
	s_add_i32 s2, s5, -1
	s_sub_i32 s3, 0, s5
	s_and_b32 s2, s2, s6
	v_and_b32_e32 v4, s3, v4
	v_add_lshl_u32 v4, v4, s2, 2
	ds_bpermute_b32 v4, v4, v2
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc1 .LBB0_3
.LBB0_16:
	s_waitcnt lgkmcnt(0)
	v_mbcnt_lo_u32_b32 v4, -1, 0
	v_mbcnt_hi_u32_b32 v4, -1, v4
	s_sub_i32 s2, 0, s5
	v_subrev_u32_e32 v5, s6, v4
	v_and_b32_e32 v6, s2, v4
	v_cmp_lt_i32_e32 vcc, v5, v6
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_lshlrev_b32_e32 v4, 2, v4
	ds_bpermute_b32 v4, v4, v2
	s_cmp_lg_u32 s4, 2
	s_cbranch_scc1 .LBB0_4
.LBB0_17:
	s_waitcnt lgkmcnt(0)
	v_mbcnt_lo_u32_b32 v4, -1, 0
	v_mbcnt_hi_u32_b32 v4, -1, v4
	s_add_i32 s2, s5, -1
	v_and_b32_e32 v5, s2, v4
	v_add_u32_e32 v5, s6, v5
	v_mov_b32_e32 v6, s6
	v_cmp_gt_i32_e32 vcc, s5, v5
	s_nop 1
	v_cndmask_b32_e32 v5, 0, v6, vcc
	v_add_lshl_u32 v4, v5, v4, 2
	ds_bpermute_b32 v4, v4, v2
	s_cmp_lg_u32 s4, 3
	s_cbranch_scc0 .LBB0_5
	s_branch .LBB0_6
.LBB0_18:
	v_mbcnt_hi_u32_b32 v3, -1, v4
	s_add_i32 s0, s5, -1
	s_sub_i32 s1, 0, s5
	s_and_b32 s0, s0, s6
	v_and_b32_e32 v3, s1, v3
	v_add_lshl_u32 v3, v3, s0, 2
	ds_bpermute_b32 v3, v3, v2
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc1 .LBB0_10
.LBB0_19:
	s_waitcnt lgkmcnt(0)
	v_mbcnt_hi_u32_b32 v3, -1, v4
	s_sub_i32 s0, 0, s5
	v_subrev_u32_e32 v5, s6, v3
	v_and_b32_e32 v6, s0, v3
	v_cmp_lt_i32_e32 vcc, v5, v6
	s_nop 1
	v_cndmask_b32_e32 v3, v5, v3, vcc
	v_lshlrev_b32_e32 v3, 2, v3
	ds_bpermute_b32 v3, v3, v2
	s_cmp_lg_u32 s4, 2
	s_cbranch_scc1 .LBB0_11
.LBB0_20:
	s_waitcnt lgkmcnt(0)
	v_mbcnt_hi_u32_b32 v3, -1, v4
	s_add_i32 s0, s5, -1
	v_and_b32_e32 v5, s0, v3
	v_add_u32_e32 v5, s6, v5
	v_mov_b32_e32 v6, s6
	v_cmp_gt_i32_e32 vcc, s5, v5
	s_nop 1
	v_cndmask_b32_e32 v5, 0, v6, vcc
	v_add_lshl_u32 v3, v5, v3, 2
	ds_bpermute_b32 v3, v3, v2
	s_cmp_lg_u32 s4, 3
	s_cbranch_scc0 .LBB0_12
	s_branch .LBB0_13
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 24
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 7
		.amdhsa_next_free_sgpr 10
		.amdhsa_accum_offset 8
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj, .Lfunc_end0-_Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj
                                        ; -- End function
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.num_vgpr, 7
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.num_agpr, 0
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.numbered_sgpr, 10
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.num_named_barrier, 0
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.private_seg_size, 0
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.uses_vcc, 1
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.uses_flat_scratch, 0
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.has_dyn_sized_stack, 0
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.has_recursion, 0
	.set _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 732
; TotalNumSgprs: 16
; NumVgprs: 7
; NumAgprs: 0
; TotalNumVgprs: 7
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 0
; NumSGPRsForWavesPerEU: 16
; NumVGPRsForWavesPerEU: 7
; AccumOffset: 8
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 1
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.protected	_Z4mfmaPKDF16_S0_PKfPf  ; -- Begin function _Z4mfmaPKDF16_S0_PKfPf
	.globl	_Z4mfmaPKDF16_S0_PKfPf
	.p2align	8
	.type	_Z4mfmaPKDF16_S0_PKfPf,@function
_Z4mfmaPKDF16_S0_PKfPf:                 ; @_Z4mfmaPKDF16_S0_PKfPf
; %bb.0:
	s_load_dwordx8 s[4:11], s[0:1], 0x0
	v_lshlrev_b32_e32 v0, 2, v0
	v_lshl_add_u32 v0, s2, 8, v0
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshlrev_b64 v[2:3], 1, v[0:1]
	s_waitcnt lgkmcnt(0)
	v_lshl_add_u64 v[4:5], s[4:5], 0, v[2:3]
	global_load_dwordx2 v[4:5], v[4:5], off
	v_lshlrev_b64 v[8:9], 2, v[0:1]
	v_lshl_add_u64 v[2:3], s[6:7], 0, v[2:3]
	v_lshl_add_u64 v[0:1], s[8:9], 0, v[8:9]
	global_load_dwordx2 v[6:7], v[2:3], off
	s_nop 0
	global_load_dwordx4 v[0:3], v[0:1], off
	s_waitcnt vmcnt(0)
	v_mfma_f32_16x16x16_f16 v[0:3], v[4:5], v[6:7], v[0:3]
	v_lshl_add_u64 v[4:5], s[10:11], 0, v[8:9]
	s_nop 6
	global_store_dwordx4 v[4:5], v[0:3], off
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _Z4mfmaPKDF16_S0_PKfPf
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 32
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 10
		.amdhsa_next_free_sgpr 12
		.amdhsa_accum_offset 12
		.amdhsa_reserve_vcc 0
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end1:
	.size	_Z4mfmaPKDF16_S0_PKfPf, .Lfunc_end1-_Z4mfmaPKDF16_S0_PKfPf
                                        ; -- End function
	.set _Z4mfmaPKDF16_S0_PKfPf.num_vgpr, 10
	.set _Z4mfmaPKDF16_S0_PKfPf.num_agpr, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.numbered_sgpr, 12
	.set _Z4mfmaPKDF16_S0_PKfPf.num_named_barrier, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.private_seg_size, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.uses_vcc, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.uses_flat_scratch, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.has_dyn_sized_stack, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.has_recursion, 0
	.set _Z4mfmaPKDF16_S0_PKfPf.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 132
; TotalNumSgprs: 18
; NumVgprs: 10
; NumAgprs: 0
; TotalNumVgprs: 10
; ScratchSize: 0
; MemoryBound: 1
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 2
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 18
; NumVGPRsForWavesPerEU: 10
; AccumOffset: 12
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 2
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.text
	.type	__hip_cuid_2864fee638802788,@object ; @__hip_cuid_2864fee638802788
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_2864fee638802788
__hip_cuid_2864fee638802788:
	.byte	0                               ; 0x0
	.size	__hip_cuid_2864fee638802788, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.1 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __hip_cuid_2864fee638802788
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     0
    .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 24
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj
    .private_segment_fixed_size: 0
    .sgpr_count:     16
    .sgpr_spill_count: 0
    .symbol:         _Z8shufflesPK15HIP_vector_typeIiLj4EEPKjPj.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     7
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .agpr_count:     0
    .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 32
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           _Z4mfmaPKDF16_S0_PKfPf
    .private_segment_fixed_size: 0
    .sgpr_count:     18
    .sgpr_spill_count: 0
    .symbol:         _Z4mfmaPKDF16_S0_PKfPf.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     10
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx950
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
