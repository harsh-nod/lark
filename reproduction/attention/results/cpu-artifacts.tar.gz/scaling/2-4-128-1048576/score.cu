extern "C" __global__ void attention_hip_2_4_128_1048576_score(const __half* q, const __half* k, float* scores) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1048576) {
    acc = acc + __half2float(q[(i / 16384) * 134217728 + (((i / 128) % 128) * 1048576 + j)]) * __half2float(k[((i / 16384) / 4) * 134217728 + ((i % 128) * 1048576 + j)]);
    j++;
  }
  scores[i] = acc / 1024.0f;
}
