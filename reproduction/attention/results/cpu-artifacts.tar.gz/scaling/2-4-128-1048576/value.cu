extern "C" __global__ void attention_hip_2_4_128_1048576_value(const float* probabilities, const __half* v, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 128) {
    acc = acc + probabilities[(i / 134217728) * 16384 + (((i / 1048576) % 128) * 128 + j)] * __half2float(v[((i / 134217728) / 4) * 134217728 + (j * 1048576 + i % 1048576)]);
    j++;
  }
  out[i] = __float2half(acc);
}
