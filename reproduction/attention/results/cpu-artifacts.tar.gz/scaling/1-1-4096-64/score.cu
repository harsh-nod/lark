extern "C" __global__ void attention_hip_1_1_4096_64_score(const __half* q, const __half* k, float* scores) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 64) {
    acc = acc + __half2float(q[(i / 16777216) * 262144 + (((i / 4096) % 4096) * 64 + j)]) * __half2float(k[((i / 16777216) / 1) * 262144 + ((i % 4096) * 64 + j)]);
    j++;
  }
  scores[i] = acc / 8.0f;
}
