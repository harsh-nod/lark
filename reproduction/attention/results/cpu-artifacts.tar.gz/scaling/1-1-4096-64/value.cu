extern "C" __global__ void attention_hip_1_1_4096_64_value(const float* probabilities, const __half* v, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 4096) {
    acc = acc + probabilities[(i / 262144) * 16777216 + (((i / 64) % 4096) * 4096 + j)] * __half2float(v[((i / 262144) / 1) * 262144 + (j * 64 + i % 64)]);
    j++;
  }
  out[i] = __float2half(acc);
}
