extern "C" __global__ void attention_hip_1_1_1_1_softmax(const float* scores, float* probabilities) {
  int i = blockIdx.x;
  int j = 0;
  float acc = scores[(i / 1) * 1 + j];
  float ctx = 0.0f;
  float val = 0.0f;
  j = 1;
  while(j < 1) {
    val = scores[(i / 1) * 1 + j];
    acc = fmaxf(acc, val);
    j++;
  }
  ctx = acc;
  acc = 0.0f;
  j = 0;
  while(j < 1) {
    val = scores[(i / 1) * 1 + j];
    acc = acc + expf(val - ctx);
    j++;
  }
  val = scores[i];
  probabilities[i] = expf(val - ctx) / acc;
}
