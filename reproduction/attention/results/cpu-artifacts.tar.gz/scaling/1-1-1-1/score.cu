extern "C" __global__ void attention_hip_1_1_1_1_score(const __half* q, const __half* k, float* scores) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1) {
    acc = acc + __half2float(q[(i / 1) * 1 + (((i / 1) % 1) * 1 + j)]) * __half2float(k[((i / 1) / 1) * 1 + ((i % 1) * 1 + j)]);
    j++;
  }
  scores[i] = acc / 1.0f;
}
