extern "C" __global__ void attention_hip_1_1_1_1_value(const float* probabilities, const __half* v, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 1) {
    acc = acc + probabilities[(i / 1) * 1 + (((i / 1) % 1) * 1 + j)] * __half2float(v[((i / 1) / 1) * 1 + (j * 1 + i % 1)]);
    j++;
  }
  out[i] = __float2half(acc);
}
