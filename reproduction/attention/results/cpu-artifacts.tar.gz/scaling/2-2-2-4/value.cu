extern "C" __global__ void attention_hip_2_2_2_4_value(const float* probabilities, const __half* v, __half* out) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 2) {
    acc = acc + probabilities[(i / 8) * 4 + (((i / 4) % 2) * 2 + j)] * __half2float(v[((i / 8) / 2) * 8 + (j * 4 + i % 4)]);
    j++;
  }
  out[i] = __float2half(acc);
}
