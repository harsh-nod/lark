extern "C" __global__ void attention_hip_2_2_2_4_score(const __half* q, const __half* k, float* scores) {
  int i = blockIdx.x;
  float acc = 0.0f;
  int j = 0;
  while(j < 4) {
    acc = acc + __half2float(q[(i / 4) * 8 + (((i / 2) % 2) * 4 + j)]) * __half2float(k[((i / 4) / 2) * 8 + ((i % 2) * 4 + j)]);
    j++;
  }
  scores[i] = acc / 2.0f;
}
